import java.nio.channels.*;
public class P { public static void main(String[]x) throws Exception {System.out.println(System.getProperty("java.io.tmpdir")); Pipe p=Pipe.open(); System.out.println(p);}}
