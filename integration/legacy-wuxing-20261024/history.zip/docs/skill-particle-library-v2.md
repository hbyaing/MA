# 2026-09-29 粒子库 V2：降低复用与丰富构图

用户反馈V1粒子复用过多、容易审美疲劳。本轮按逐技能主纹样、运动轨迹、错峰时间和主次层级重新编排，V1目录及ZIP保留。

## 当前入口

- `source-assets/skill-particle-library-v2/preview/index.html`
- `source-assets/skill-particle-library-v2/catalog/逐技能美术设计.md`
- `source-assets/skill-particle-library-v2/catalog/diversity.json`
- `deliverables/wuxingxiantu-skill-particle-library-v2.zip`
- `deliverables/wuxingxiantu-vfx-resourcepack-v2.zip`
- `reports/skill-particle-library-v2/before-after-v2.png`
- `reports/skill-particle-library-v2/nine-flames-v2.png`
- `reports/skill-particle-library-v2/ermei-gray-v2.png`

## 实质修改

1. 新增78种明确区分轮廓与内部结构的材质，总量138；64种动画共1024帧。旧的60种继续作为低层组件，不再用32套通用配方承载全部139项。
2. 每个源码条目一套独立配方：139套。十位Boss有独立纹样体系；九种异火有不同主体；剑技、功法、神通、心法、符箓及炼制各自编排。
3. `motion.py`统一生成位置、转角、横纵缩放和大小曲线；浏览器读取同一组路径，Photon由路径导出速度、旋转、大小和错峰。最大32个原生发射器，密集配方会抽样。
4. 预览增加分层隔离和灰度对照，便于审查轮廓，而非只检查颜色是否不同。JSON导出保留完整路径。
5. 查看截图后，对九种异火增加填充火体、亮芯及软边，避免所有新增图案都只有线稿；九幽冥火采用源码亮芯色增强暗背景辨识。

## 复用统计口径

逐一读取原V1和V2全部139项，先应用V1实际素材覆盖项。纹样集合忽略顺序、配色和数量；动作签名忽略ID、名称、颜色及采样数组。

| 指标 | V1 | V2 |
|---|---:|---:|
| 配方文件 | 32 | 139 |
| 独立纹样集合 | 38 | 131 |
| 重复纹样集合的额外条目 | 101 | 8 |
| 不重复的完整动作组合 | 39 | 139 |
| 最高频单材质出现次数 | 40 | 10 |

保留8项同门纹样组合复用，它们采用不同轨迹与时间编排；不宣称完全没有素材复用。哈希和数量也不能替代审美判断。

## 验证与边界

`validation.json`检查源码映射、138个基础遮罩、1024帧非空动画、透明边界、配方预算、采样路径有限值、277对FX与项目、原生字段/贴图引用和文件哈希。`browser-validation.json`记录139技能的556个画面抽样、138材质的552个抽样、空白帧检测、搜索、分层、灰度、完整路径导出、窄屏布局。截图与对比图均由本轮预览产生，未使用历史实机证据。

Photon速度单位按上游1.20.1实现中线性速度乘0.05处理，导出时转换为每秒单位；旋转曲线为相对于初始值的偏移。本地NBT读回不能证明具体安装版本的引擎渲染正确。原生积分、Billboard朝向与抽样可能使画面区别于浏览器，需要在目标版本实机验收。

本轮为独立素材库修改，未改动生产Java、伤害判定、网络协议，未运行Gradle、Minecraft或替换实例。预览与Photon样片均为制作构图；地面法阵、三维光束、拖尾和实体场景还需实际渲染接入。Boss原有安全区域、真实前摇及多段落点仍由服务器源码决定。
