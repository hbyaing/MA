# 五行仙途 1.20.1 Forge 优化 / 技术债审计

> 对象：当前 `wuxingxiantu 1.0.0-r10` 源码快照  
> 本文件只讨论性能、架构、维护性、文档、测试与兼容优化。明确的玩法 Bug 见 `WUXINGXIANTU_BUG_AUDIT.md`。

## 1. 总体评价

当前工程已经从早期生成式 Mod 代码发展成一个功能非常多的大型项目，但结构仍保留明显的“不断往中心类追加功能”的痕迹。现在最值得优化的不是做极端微优化，而是：

1. **减少每 tick / 每 100 tick 全局轮询；**
2. **拆分超大中心类；**
3. **把重复数值和知识状态收敛到单一权威数据源；**
4. **减少 Attribute Modifier 每秒反复移除/添加；**
5. **避免持有卸载区块中的 BlockEntity 强引用；**
6. **建立最基本的自动验证，让后续 AI 修改不再依赖旧 MD 报告。**

---

## 2. P0/P1 优化事项

### 2.1 `GeneratedMod.java` 责任过多

当前 `GeneratedMod.java` 体量约 100 KB，承担了大量：

- 玩家 tick；
- 服务端 tick；
- 死亡/击杀；
- 灵力恢复；
- 修为；
- 打坐；
- 夜视/领域等持续状态；
- 诸多跨系统事件。

长期风险：

- 新增一个功能很容易误伤别的系统；
- Tick 顺序依赖不透明；
- 很难写局部测试；
- AI 每次读取该类消耗大量 token。

建议按领域拆成：

```text
event/CultivationEvents.java
event/MeditationEvents.java
event/MindscapeEvents.java
event/YujianEvents.java
event/CombatEvents.java
event/AlchemyEvents.java
```

由 Mod Event Bus / Forge Event Bus 明确注册，不再让一个中心类承担所有业务。

---

### 2.2 `Network.java` 过大

`Network.java` 约 157 KB，是当前最大类之一。

建议分成：

```text
network/NetworkChannel.java
network/packet/cultivation/*
network/packet/yujian/*
network/packet/heartsword/*
network/packet/alchemy/*
network/packet/mindscape/*
network/packet/divineart/*
```

每个 Packet：

- 独立 encode/decode/handle；
- 服务端权限检查写在 Packet handler 或专用 service；
- 客户端表现与服务端状态修改分离。

这会明显减少以后“改一个技能误碰整个 Network”的风险。

---

### 2.3 `FormulaKnowledge.tick()` 应从轮询改为事件驱动

当前丹方系统每 100 tick：

- 扫描玩家；
- 遍历丹方目录；
- 检查境界/成就；
- 还对背包旧丹药数据做兼容规范化。

新设计已经确定为显式知识道具，因此这段轮询应该删除。

建议：

- 使用丹方/丹录时直接触发 learn；
- 管理命令直接触发；
- 未来任务/掉落事件明确调用；
- 旧数据迁移改成登录时“一次性版本迁移”，不要永久每 5 秒扫背包。

可以给玩家数据增加：

```text
alchemyDataVersion
```

只有旧版本才执行兼容迁移。

---

### 2.4 `PhysiqueLogic.tick()` 不应每秒重建永久属性 Modifier

当前体质逻辑存在周期性：

- remove modifier；
- addPermanentModifier；
- 下一周期再做一遍。

即使 UUID 相同，这也会不断把 Attribute 标脏、触发同步和计算。

建议：

- 只有体质改变、境界改变、装备影响体质改变时重新 apply；
- 或在 apply 前比较当前 modifier amount 是否真的不同；
- 数值一样就不做 remove/add。

对多人服务器，这种优化比单纯减少一两个粒子更有意义。

---

### 2.5 心境竞技场生成应避免每次大量 `setBlock(..., 3)`

当前心境准备区域会一次性修改约数万块方块，且如果大量使用更新 flag 3，会产生：

- 邻居更新；
- 客户端方块同步；
- 光照/渲染压力；
- 服务器瞬时卡顿。

优化方案按推荐顺序：

1. 预生成固定 arena / 模板结构；
2. 每个实例槽只初始化一次，之后重置必要区域；
3. 使用 StructureTemplate 批量放置；
4. 能使用低更新 flag 的地方避免 `3`；
5. 如果必须动态铺设，分 tick 批处理。

当前固定 64 个实例槽也建议在 README 中注明多人容量上限，未来再做动态实例池。

---

### 2.6 炼丹 Pending 数据不要持有 BlockEntity 强引用

如果网络/炼丹等待队列保存：

```text
AlchemyFurnaceBlockEntity reference
```

而玩家离开导致区块卸载，就可能长期保留已经卸载的 BE 对象。

建议只保存：

```text
dimension key
BlockPos
player UUID
request id
```

需要执行时重新通过 `server.getLevel(dim).getBlockEntity(pos)` 获取，并验证类型/炉状态。

这样不会让 pending request 阻止旧对象回收，也更安全。

---

### 2.7 人皇幡魂仆删除避免全维度实体扫描

当前部分删除/查找魂仆行为会遍历各维度 `getAllEntities()`。

如果只在极少发生的管理操作里问题不大，但以后魂仆多、服务器大时会越来越重。

建议：

- 对活动魂仆保存 `UUID -> dimension` 索引；
- 或使用已有 Entity lookup API 按 UUID 获取；
- 只有索引失效时才回退全局扫描。

---

## 3. Tick 调度优化

### 3.1 建立明确的频率层

不要让所有系统都挤在 ServerTick 每 tick 判断 `%20/%100`。

推荐建立：

```text
每 tick：飞行、动作动画服务端状态等确实要求高频的系统
每 5 tick：轻量持续技能
每 20 tick：灵力恢复、修为、环境状态
每 100 tick：低优先级兼容检查（尽量消除）
登录/数据变化事件：迁移、属性刷新、知识初始化
```

并把“为什么需要这个频率”写进对应 service，而不是集中在 GeneratedMod。

---

### 3.2 避免同一个状态在多个系统独立查询

例如一秒内如果：

- 灵力恢复查询境界/体质/道心/环境；
- 修为又查一次；
- UI 同步又查一次；
- 领域又查一次；

可在单个玩家 tick context 中缓存当前帧/当前秒只读派生数据：

```text
realm
stage
maxMana
physique
rootCount
isMeditating
environmentMultiplier
```

只缓存“本周期必然不变”的值，避免错误跨 tick 缓存。

---

## 4. 数据与数值架构优化

### 4.1 建立核心 `BalanceConfig / BalanceTables`

目前境界、功法、恢复等数值散在多个类中。

建议至少集中：

```text
RealmBalance
CultivationBalance
ManaBalance
ArtBalance
DivineArtCostTable
```

要求：

- UI/Tooltip 从同一数据对象读；
- 服务端结算同样读这个对象；
- 不再 ArtCatalog 一份、Network 又手写一份。

尤其功法已经改成：

```text
fixedMana + maxMana * percentage
```

以后不要让客户端自己复制比例常量。

---

### 4.2 灵力 Setter 不负责吞合法设计效果

数据 Setter 应解决：

- NaN；
- 负数；
- 极端非法存档；

而不是在最后偷偷用 `base * 1.25` 覆盖上层合法叠加。

推荐：

- “设计上限”放在每个 bonus 来源；
- “安全上限”设置得明显高于正常合法范围；
- debug 模式中发现越界时输出一次警告。

---

### 4.3 神通内部 ID 与显示名分层

`guang_yin_suo` 这种旧 ID 如果已经进入存档/网络协议，建议保留兼容。

但：

- `zh_cn` / `en_us`；
- UI；
- README；
- Tooltip；
- 注释；

统一使用“日月停轮”。

不要为了改中文名强行重命名注册 ID，避免存档兼容风险。

---

## 5. 客户端渲染与特效优化

### 5.1 心剑不要用大量粒子拼模型

用户已经明确要求：

> 玩家真实动画 + 武器模型变化 + 少量自定义视觉。

实现建议：

- `heart_mote` / `heart_flame` 可以用粒子；
- `heart_streak` 用 quad/ribbon/transient mesh；
- 凝心/散剑主体用 OBJ group、clip/mask 或可裁切 mesh；
- 不要创建几十/几百 Entity 或 Particle 去“假装剑身”。

这既符合视觉要求，也避免粒子 overdraw。

---

### 5.2 第一/第三人称分别渲染，不要互相硬套

心剑当前仅靠统一 display transform 很难同时解决：

- 第一人称视野；
- 第三人称握持；
- 潜行/跑动；
- 心铸双手动作。

建议：

- 普通持剑：BakedModel/自定义 item renderer 按 display context；
- 动作时：RenderHandEvent 独立轨道；
- 第三人称：PlayerModel 手臂 pose；
- 动作结束必须恢复默认 pose。

---

## 6. 兼容性优化

### 6.1 夜视效果不要误删其他 Mod 的效果

如果系统为了自己的特殊视觉，在退出状态时按“ambient/invisible/amplifier”推断并删除 Night Vision，需要非常谨慎。

建议给自己施加的 Effect 建立明确来源标记或能力状态，而不是仅靠 EffectInstance 属性猜测。否则可能删除其他 Mod 或指令给予的夜视。

---

### 6.2 高生命扩展必须先做兼容策略

如果决定突破原版 MAX_HEALTH 可用范围，要明确选择：

- 修改/替换 Attribute range；还是
- 自定义扩展生命层。

优先保证：

- 原版伤害；
- `LivingEntity#heal`；
- 死亡；
- 吸收生命；
- HUD；
- 网络同步；
- Boss/其他 Mod 读取 MaxHealth

能够一致工作。

不要只让 UI 显示 4000，而服务端仍只有 1024。

---

## 7. Markdown 文档清理

当前根目录有约 19 个 Markdown，其中 `AI_SOURCE_MAP.md` 已约 112 KB / 1500 行，已经背离“减少 AI token”的初衷。

### 建议长期保留并重写

1. `README.md`
2. `AI_SOURCE_MAP.md`

### 建议从正式工作区删除/归档

- `BATCH10_REGRESSION_REPORT.md`
- `BATCH_A_REPAIR_REPORT.md`
- `BATCH_B_REPAIR_REPORT.md`
- `CORE_BALANCE_REWORK_REPORT.md`
- `DUNXU_UPDATE.md`
- `OPTIMIZATION_REPAIR_REPORT.md`
- `TRAIL_RECTANGLE_FIX.md`
- `BOSS_AUDIT.md`
- `FIRE_AUDIT.md`
- `MINDSCAPE_AUDIT.md`
- `PILL_AUDIT.md`
- `PILL_RECIPE_AUDIT.md`
- `PLANT_AUDIT.md`
- `REFINING_AUDIT.md`
- `ROBE_AUDIT.md`
- `SWORD_AUDIT.md`
- `YUJIAN_ADVANCED_AUDIT.md`

删除前只需要确认里面没有“当前源码/资源中完全没有保存的唯一设计约束”。如果只是历史修改记录，应归档到源码工作区外，而不是继续让 Codex 每次看到。

### 不要删除

`reference_assets/**` 中真正的：

- 模型骨骼说明；
- 动画约束；
- 粒子挂点；
- 美术设计；
- Blockbench 接入说明。

这些往往无法从 Java 代码恢复。

### 新 AI_SOURCE_MAP 目标

建议 200～300 行以内，只写：

```text
要改炼丹 -> 哪几个当前类 / 数据文件
要改御剑 -> 哪几个当前类
要改心境 -> 哪几个当前类
要改心剑 -> 哪几个 renderer / packet / item
权威数据源是哪一个
哪些 ID 为兼容不可轻易重命名
```

不要再写第几批修过什么。

---

## 8. Localization / 资源维护

当前：

- 中文 key 约 1376；
- 英文 key 约 1312；
- 中文比英文多约 70 个当前功能 key；
- 英文还残留约 6 个旧 aura 命名 key。

建议加一个开发脚本：

```text
validate_lang.py
```

输出：

- zh only；
- en only；
- 空值；
- 重复 key；
- 可疑旧 key。

同样建议保留现有 JSON validator 作为构建前检查。

---

## 9. 测试体系建议

当前最大风险不是“缺少更多审计 MD”，而是**缺少能重复运行的自动验证**。

建议优先补：

### 9.1 纯 Java / GameTest 可验证项目

- Realm → health/attack/mana 数值；
- 小境界倍率；
- 灵力恢复上限；
- 修为每秒值；
- 功法固定+百分比扣费；
- FormulaKnowledge 初始为空 / 学习 / reset；
- Mindscape snapshot serialize/restore；
- 遁虚 pass/block tag 规则；
- 丹药/物品注册 ID 唯一性。

### 9.2 资源检查

每次构建前自动检查：

- 所有 JSON parse；
- model parent；
- texture path；
- blockstate model；
- lang key；
- 配方引用的 item 是否注册；
- loot table 引用。

### 9.3 必须实机的项目

- 第一/第三人称心剑；
- 御剑动作；
- UI/JEI；
- 粒子/Shader；
- 高生命同步；
- 心境进出；
- 多人同步。

报告中必须区分“自动测试通过”和“实机通过”。

---

## 10. 构建与 CI

当前源码快照没有 Gradle Wrapper。建议仓库补齐：

```text
gradlew
gradlew.bat
gradle/wrapper/*
```

并固定可用 Gradle 版本，避免每个人/每个 AI 环境依赖本机 Gradle。

建议 CI 最少执行：

1. Java 17；
2. `./gradlew compileJava`；
3. `./gradlew processResources`；
4. JSON/lang 自定义校验；
5. `./gradlew build`；
6. 上传 reobf jar artifact。

这样以后“报告说已修复但其实没编译”会大幅减少。

---

## 11. 推荐重构顺序

### 阶段 A：不改变玩法，只降风险

1. Gradle Wrapper + CI；
2. 资源/lang validator；
3. 删除 FormulaKnowledge 永久轮询；
4. Physique Modifier 只在变化时刷新；
5. Pending Alchemy 不持有 BE 强引用。

### 阶段 B：拆超大类

1. Network packet 分包；
2. GeneratedMod 事件按领域拆分；
3. DivineArtLogic 拆为状态/执行/客户端表现；
4. HumanEmperorBanner soul registry 单独 service。

### 阶段 C：收敛数据源

1. BalanceTables；
2. AlchemyKnowledge API；
3. PlantRarity → worldgen；
4. tooltip/UI 一律读取权威数据。

---

## 12. 预期收益

完成上述优化后，主要收益不是“FPS 立刻翻倍”，而是：

- 服务器长期 Tick 更稳定；
- 大型多人存档更安全；
- 新增功能不容易造成跨系统回归；
- Codex/AI 读取源码时上下文更小；
- 数值/Tooltip 不容易再次分叉；
- 历史报告不再误导当前实现；
- 每批修改能通过自动化验证，而不是依赖文字承诺。
