# 功法、心法获取补齐（2026-10-05）

本轮仅按用户要求，用钓鱼和灵修者交易补齐 `01_20261004_BUG审计.md` B-02 / `02_20261004_缺漏与获取链.md` 第四、五节列出的 17 本功法与 9 本心法。附件中的其他整改建议不是本轮实施范围。

源码已修改；未运行 Gradle、编译、GameTest 或 Minecraft，未生成 JAR。历史 JAR 和 `deliverables/wuxingxiantu-source-20261004-latest-source.zip` 不含本轮修改。

## 灵修者交易

成年灵修者下次被玩家交互、原版交易界面打开前，追加当前等级应开放的全部新书目。无需反复刷新职业或依赖村民随机抽取交易。新旧商人使用同一规则；空岛模板保存的旧交易也可接入。

| 开放等级 | 新增书目 | 每本基础灵石价格 | 每本钓鱼权重 |
|---|---|---:|---:|
| 1 | 黄阶：`art_renewal`、`art_spirit_shield`、`art_immobilize`、`art_light_body` | 12 | 40 |
| 2 | 玄阶：`art_golden_bell`、`art_ice_spike`、`art_spirit_gathering`、`art_armor_break` | 24 | 20 |
| 3 | 地阶：`art_flame_wave`、`art_flash_step`、`art_purification`、`art_bloodlust`、`art_thunder` | 40 | 8 |
| 5 | 天阶：`art_myriad_swords`、`art_immovable_mountain`、`art_human_harmony`、`art_five_elements` | 64 | 2 |
| 1 | `heart_method_yuan_hun` | 12 | 40 |
| 2 | `heart_method_gathering` | 16 | 24 |
| 3 | `heart_method_xuanshui` | 20 | 12 |
| 4 | `heart_method_nine_turns`、`heart_method_burning_heaven`、`heart_method_thick_earth` | 40 | 6 |
| 5 | `heart_method_taixu`、`heart_method_beast_taming` | 56 | 2 |
| 5 | `heart_method_wanling` | 64 | 1 |

新交易每本 2 次库存，沿用原版工作站补货、需求/声望价格调整，每次交易经验为开放等级 × 5。达到新等级后，下一次交互补齐新书目。已有同一本书的交易不重复追加，不替换原交易，不重置价格、数据或使用次数。不增加原版牧师的新书目，不给幼年村民发放交易。

此前 `art_sword_aura` 与 `heart_method_tiangang` 的交易、五本剑诀配方继续保留。获取书籍没有新增玩家境界门槛；实际研读、装备、释放仍由原 `ProgressionGate` 校验。

## 钓鱼

Forge `ItemFishedEvent` 在服务端成功收竿、事件未取消、存在原钓获物、鱼钩符合原版开阔水域条件时，额外进行一次 2% 的秘籍抽取。命中后按上表权重选取一本，总权重 **387**；任意一本的每次有效收竿概率为 `0.02 × 本书权重 / 387`。例如黄阶每本约 0.207%，天阶每本约 0.0103%，万灵约 0.00517%；稀有书也有明确交易途径。

不替换原版鱼、垃圾和宝藏，也保留原有水系材料奖励。未给海之眷顾额外秘籍加成；条件不要求特定群系、维度或玩家境界。不是新增宝箱注入。

## 实现与验证

- `acquisition/CultivationBookSources`：26 本书的等级、价格、权重、商人补充、抽取和来源证据共用一份定义。
- `event/CultivationBookEvents`：原版打开交易界面前补充书目；钓鱼追加奖励；注册 `cultivation-books` 来源提供者。
- `event/TooltipEvents`：新增书的 Tooltip 显示开阔水域钓鱼和灵修者最低交易等级；中英文与 `tools/import_item_text_spec.py` 同步。
- `tools/check_resources.py`：覆盖检查对照现有注册、23 功法 / 10 心法目录、五本现有剑诀配方和物品文案目录；检查重复、合法等级、支付堆叠与正权重。**13/13 通过**。
- `tools/CheckJavaSyntax.java`：本轮 4 个相关 Java 文件仅语法解析，**0 错误**；不代表类型检查或运行验收。
- `CultivationBookGameTests`：新增两类来源覆盖、保存交易的无损补充与升级、牧师/幼年隔离、加权区间无缺漏四个用例。**未运行**。

待后续构建及实机验收：新商人和旧空岛商人交互、等级 1→5 解锁、交易补货/存档重启、钓鱼成功与取消、开阔水域条件、中英文 Tooltip。未将其他物品的获取链或其他审计项目标为完成。
