# 心铸持剑方向与第三人称尺寸

按用户截图修正心铸/解心（动作 2、3）的姿势。第一人称右手握点移至屏幕右侧，剑尖横向朝左；右手保持握柄，左手从剑根沿剑面抚向前端，解心反向。导入剑和原生 JSON 剑先统一到“剑尖 +Y、剑面 XY、握点为原点”，再应用视角变换，避免只转左右位置却仍让剑刃朝向玩家。

第三人称右手在身前持剑，前臂保持水平；复用已有六像素上下臂骨骼求解弯肘，左右手使用与剑身相同的握点和抚剑距离，皮肤外层及护甲共用骨骼姿态。心铸时的本地第一人称不再发出脱离物品坐标的世界粒子；第三人称动作粒子跟随当前剑身路径。

全部 `SpiritSwordItem`（含桃木及七把进阶灵剑）的普通第三人称手持尺寸增加 30%，心铸时同步增加。缩放位于物品手掌坐标内，保留握点；第一人称普通手持、物品栏、掉落物、御剑实体尺寸不受这一缩放影响。心剑 OBJ、MTL、PNG、物品栏图标以及灵剑资源模型均未修改。

## 修改入口

- `client/HeartForgeLayout.java`：共用握点、左右视角坐标、固定臂长和水平前臂求解。
- `client/HeartSwordPose.java`、`HeartSwordGeometry.java`：手掌、剑面与心光使用相同剑身路径；保留异火的物品局部渲染入口。
- `client/MeditationModels.java`：心铸动作复用上下臂骨骼，普通行走、打坐、御剑的原骨骼选择仍保留。
- `client/FlyingSwordItemModels.java`：只在第三人称手持上下文增大灵剑。
- `client/HeartSwordClientEffects.java`：动作粒子跟随修正后的方向。
- `src/regression/java/cn/blockforge/generated/generatedmod/BalanceRegression.java`：增加左右方向、水平前臂以及普通/细手臂整段路径的长度检查。

## 实际验证

2026-09-26 03:32 执行 `regressionTest validateResources`，主源码编译成功，403 项平衡/动画边界回归检查和 11 项资源检查通过；`check_heart_sword_assets.py` 4/4 通过。日志：`reports/heart-forge-pose-20260926.log`。

本次没有重新执行 `build` 或打包 JAR，没有运行 GameTest 或客户端。403 项检查包含数学及边界验证，不能证明游戏中的最终观感。需要实机检查第一/第三人称、左右主手设置、普通/细手臂皮肤、护甲、各灵剑剑面及握点。现有 `deliverables/wuxingxiantu-1.0.0-r11-20260926-031144.jar` 早于这些调整，不包含本批修改。
