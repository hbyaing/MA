# 雷纹草原图接入

用户透明原图左中右接入幼苗、生长、成熟阶段，成熟裁片作为物品图标。原始裁片不重采样，透明画布以紧凑 UV 显示；保留原阶段模型尺寸和地面基准。原图、裁片、预览与坐标保存于 source-assets/thunder_vein_grass-20261008，复现脚本 tools/import_flower_vine_references.py。

保留此前六种灵植修改及玄水藻 v2。注册 ID、方块状态、生长、掉落和配方不改。完整构建及资源检查通过，成品 wuxingxiantu-0.2-20261008-thunder-vein-grass.jar 安装到指定测试目录，实机由用户确认。
