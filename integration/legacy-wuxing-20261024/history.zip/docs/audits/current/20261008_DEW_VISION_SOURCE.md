# 2026-10-08 凝露花与内视修正（仅源码）

用户明确要求本轮不直接构建：未运行 Gradle、未生成 JAR、未安装或替换测试实例。

- 凝露花使用用户参考图，从左到右导入幼苗、生长、成熟三个透明 32×32 阶段，成熟物品同步；沿用既有凝露花注册、年龄映射与邻水生长机制。
- 内视满值条为空：原填充调用屏幕坐标 scissor，而内视内容绘制经过位置变换。改用贴图源宽度裁切，不再为条本身建立屏幕裁剪；首页共用条同步使用该方法。0 值不绘制填充，满值绘制完整原图，部分值按比例裁切。
- 药水状态栏整体右移 4 GUI 像素，宽度缩小 4，保留右边界；绘制、滚动和点击共同读取布局框。窄窗口纵向布局保留。

入口：`client/CultivationVisionAssets.java`、`CultivationVisionPage.java`、`CultivationUi.java`、`CultivationVisionLayout.java`；`tools/import_oct08_dew_reference.py`。原图 `source-assets/oct08-gameplay-references/dew_drop_flower.png`，贴图预览 `reports/dew-vision-20261008/preview.png`。

静态资源检查 `tools/check_resources.py` 13/13 通过，已目视检查导入预览。本轮没有编译 Java 或运行 Minecraft，客户端修复需后续构建与实机验收。上一轮已安装 JAR 不包含本轮修改。
