# 首次入档与客户端提示修复

## 本次改动

- 首次登录由服务端在金、木、水、火、土中等概率分配一个下品灵根，保存 Initialized 标记；重复登录和死亡复制继续使用已有数据。旧存档已有灵根但缺少初始化标记时保留灵根。管理员重置修炼数据也走同一初始化入口。
- 删除灵根选择界面及其打开指令。网络包 ID 3 保留为不执行操作的兼容占位，不能通过发送旧包选择或重抽灵根。
- 等级文本在 x=196..238 区域、经验值在 x=190..244 区域居中，两者中心均为 x=217。原有文字缩放和整个 HUD 的位置、缩放设置继续生效。
- 客户端配置 `config/wuxingxiantu-hud-client.toml` 新增 `hideExperimentalWarning = true`。设为 false 恢复原确认界面。
- 用户提供的封面原图完整保存为 `src/main/resources/pack.png`，`META-INF/mods.toml` 通过 `logoFile="pack.png"` 使用它。JAR 内图片与原文件 SHA256 相同，没有裁剪或重绘。

## 源码核对

依据本机 Forge 1.20.1-47.4.10 的 mapped_official_1.20.1 JAR 反编译、SRG 映射及同版本 Forge sources JAR 核实以下调用链：

| 入口 | 实际调用链 | 匹配范围 |
| --- | --- | --- |
| 创建世界 | CreateWorldScreen.onCreate → WorldOpenFlows.confirmWorldCreation → Minecraft.setScreen | ConfirmScreen 精确类型，标题 `selectWorld.warning.experimental.title` 与正文 `selectWorld.warning.experimental.question` 同时匹配 |
| 打开已有世界 | WorldOpenFlows.loadLevel → doLoadLevel → ForgeHooksClient.createWorldConfirmationScreen → Minecraft.setScreen | ConfirmScreen 精确类型，标题 `selectWorld.backupQuestion.experimental` 与正文 `selectWorld.backupWarning.experimental` 同时匹配 |
| 启用实验性数据包 | CreateWorldScreen.tryApplyNewDataPacks → Minecraft.setScreen | ConfirmExperimentalFeaturesScreen 精确类型 |

Forge 对已有世界的实验性确认使用普通 ConfirmScreen。真正的 BackupConfirmScreen 是另一种类型，仍然保留。新建世界的 deprecated lifecycle 提示使用其他翻译键，同样保留。

## 拦截与隔离

`ExperimentalWarningHandler` 监听客户端 Forge `ScreenEvent.Opening`，精确匹配后取消打开界面，通过原 BooleanConsumer 的 `accept(true)` 继续。

使用现有 Access Transformer 体系，只开放两个确认类的三个字段（ConfirmScreen.callback/message、ConfirmExperimentalFeaturesScreen.callback），均保持 final。没有添加 Mixin、反射、模拟按钮点击、计时器或覆盖原版大方法。

原版/Forge 的 doLoadLevel 在 setScreen 返回之后才关闭 WorldStem、释放存档锁，因此必须通过 `Minecraft.tell` 入队执行回调，不能在事件内立即执行。执行前核对当前界面仍为发起时的界面，避免用户已转到其他界面时继续旧请求。

回调走 Forge 原有确认后的加载流程；Forge 自身的 `withConfirmedWarning(true)` 行为与用户手动确认相同。本模组没有直接修改 level.dat、生命周期或注册表，也没有添加对确认标记的写入。

处理器通过 `@Mod.EventBusSubscriber(value = Dist.CLIENT)` 注册。公共初始化代码没有引用处理器或 Screen 类；AT 只在目标类实际被加载时改变成员可见性，不主动加载客户端类。

不匹配版本兼容、升级/降级、备份、数据包错误、注册表错误、模组缺失和损坏提示。不修改任何 dimension、dimension_type、worldgen、结构、矿物、灵植或 biome modifier 资源。

## 修改文件

- `PlayerInitialization.java`：服务端随机初始化。
- `event/PlayerLifecycleEvents.java`、`ModCommands.java`：登录及重置接入。
- `Network.java`、`client/WuXingClientPackets.java`、`network/packet/cultivation/SelectRootPacket.java`：停用选择流程，保留包 ID。
- `client/RootSelectionScreen.java`：删除。
- `client/WuXingClient.java`：两个数值区域居中。
- `HudConfig.java`、`client/ExperimentalWarningHandler.java`、`META-INF/accesstransformer.cfg`：配置与精确界面拦截。
- `tools/check_entry_ui.py`、`build.gradle`：静态回归检查接入构建。
- `src/gametest/java/.../EntryUiGameTests.java` 及 `src/gametest/resources/data/wuxingxiantu_entry/structures/empty.nbt`：独立服务端回归用例与原有空模板的副本；仅测试源集。
- `network/service/CompassService.java`：删除此前未构建改动中重复定义的三个方法，解除编译错误。
- `tools/network-message-ids.json`：短类名机械展开为完整类名；67 项 ID、方向、实际类型不变。
- `tools/check_weapon_flames.py`：检查此前新版异火采用的 48 组上限、12 tick 生命周期、剔除与自定义网格，移除过时的 64/6 断言。
- `src/main/resources/META-INF/mods.toml`、`src/main/resources/pack.png`：模组封面。

Java 路径均相对于 `src/main/java/cn/blockforge/generated/generatedmod/`，META-INF 路径相对于 `src/main/resources/`。

## 验证状态

最终构建成功：`reports/build-20260927-entry-ui-cover.log`，`BUILD SUCCESSFUL in 15s`。

独立服务端检查成功：`reports/build-20260927-entry-ui-final.log`，4/4 required GameTests passed，服务器正常加载并保存 `wuxingxiantu:mindscape`，无客户端类加载错误。

通过内容：1000 次新玩家初始化样本中均为单一下品灵根、五行皆可生成；NBT 保存/读取后不重抽；旧存档灵根和体质保留；心境维度存在。普通构建中的 224 项 Boss 检查、411 项数值/动画边界检查、螺旋几何回归、资源和专项静态检查均通过。生成数值报告 `reports/balance/balance.md`。

交付：`deliverables/wuxingxiantu-1.0.0-r11-20260927-225853.jar`，35,691,017 字节，网络协议 63。已检查封面、配置、初始化类、心境数据已入包；旧选择界面、测试类、GeckoLib 编译桩不在产物中。

本机远程证书预检失败，使用本地缓存离线构建；仅本次命令带 `-Dnet.minecraftforge.gradle.check.certs=false`，没有修改项目的 TLS/证书配置。独立测试目录首次生成 server.properties/配置时出现初始化提示，Forge 联网版本检查超时不影响 4 项测试通过。

全量编译仍报告主源码 69 条、既有 GameTest 5 条弃用警告；超过此前设置的 CI 预算 39，本轮未执行完整 `verifyFull`/CI，也没有宣称该警告门禁通过。

客户端 GUI 尚未运行验收。静态检查及专用服务端检查不能证明客户端全部确认界面、玩家传送和视觉效果已实测，按下列步骤验收。

## 人工 GUI 验收

1. 默认配置创建全新世界：不出现实验性确认或灵根选择界面；背包内视显示五行中一个下品灵根。重进、重启客户端及死亡后，该灵根保持一致。
2. 使用尚未手动确认过实验性设置的旧世界副本进入、返回标题后重进、重启客户端后重进，确认能实际进入世界。Forge 已确认过的世界不会再次显示原提示，不能单独用它验证拦截是否有效。
3. 将配置改为 false 并重启，使用新建世界或未确认的副本确认原提示恢复；无需修改已有世界数据。
4. 启用实验性数据包后确认其加载正常；使用错误数据包的测试副本确认错误界面仍显示。
5. 在适用的测试副本上触发版本升级/降级、缺失模组和备份提示，确认仍能显示并取消；勿用主存档制造损坏。
6. 实际进入心境，检查原有世界生成与结构。自动测试确认维度可加载，不等于玩家传送和全部生成内容已逐项验收。
7. 检查等级 0、多位数等级、经验变化，并在 HUD 缩放 0.5/1/2 和不同 GUI 比例下确认数值居中且不超出原区域。
