# 2026-09-26 三份审计源码更新

输入：01_20260926_BUG_RECHECK、02_20260926_OPTIMIZATION_AUDIT、03_20260926_BALANCE_AND_INCOMPLETE_PLAN。
实现阶段用户要求优先：不补 README、不直接构建；丹录恢复原分组；心剑只修改物品栏贴图，不改模型材质。后续用户要求“构建一次”，已于 2026-09-26 03:12 完成 build；下文验证状态已同步更新。

## 已修改源码，运行验证未执行

| 事项 | 当前实现 |
| --- | --- |
| 心铸御剑与剑诀 | YujianController 两条直接剑伤路径调用 HeartSwordCombatProfile.swordHit，以实际绑定剑验证契约；取原基准和投影较大值，附魔加值及技能倍率结算一次。28 点旧冲撞上限仅保留给普通灵剑，不截断心铸成长。 |
| 心铸唯一性 | 玩家能力和剑 NBT 保存同一契约 UUID。新心铸轮换 UUID，旧箱中剑不再激活；验证覆盖背包与御剑槽，不扫描世界箱子。 |
| 心铸维持与视觉 | 契约存在即耗灵，与存放位置无关；耗尽、解心、死亡及丢弃撤销契约。客户端按服务端契约缓存显示心铸名称/光效，旧 NBT 不单独激活；登录补全、退出清缓存。 |
| 丹道 | 有效单方和每本普通丹录均解锁丹道；重复不消耗；兼容历史已学但未解锁。书本静默学习后汇总一次，保留 COMPLETE 权限限制。 |
| 丹录分组 | 养元：聚灵/修为/筑基；护道：清心/续脉/净神；炼体：金刚/狂暴/疾风/玄水；破境：突破/渡劫；初解与资质沿用原分组。 |
| 创造丹与入侵 | 收束会话并恢复外部快照，再清 pending、原因、道心和心境状态，发送 NONE 状态包；无法安全返回时不消费丹药。创造丹自身的地仙圆满效果仍保留。 |
| 入侵修为 | 普通增长被阻止，已有修为不清零；客户端权威快照使用独立恢复入口，避免被增长门禁截断。突破归零规则未改。 |
| 移魂寄魄 | 游离时右键当前登记且属于自己的本体收束；拒绝他人本体、距离过远、跨维度和附身态返回。发动仍只保留一个身体。保存并恢复末影龙原阶段；宿主到玩家查找改反向索引。 |
| 异火 | 成功点燃及持续 tick 清普通火标记/计时；客户端在独立异火有效时抑制原版实体火和第一人称火。非元素异火湿润接触提前返回；元素规则保持。渲染遍历活动异火快照，按实体 ID+UUID 解析。 |
| 心境重复挑战 | 主线完成不自动强制重打最终 Boss；内视和 /wuxingxiantu rechallenge 显式安排重赛。竞技场写块跳过已有相同方块，仍非分片生成。 |
| 其他一致性 | 神通文案统一固定灵力费用；心铸/解心要求空副手；灵剑 kills 改为实际致死命中，旧计数转存 LegacyHitCount。 |
| 验证入口 | 普通 check 编译 gameTest 源集；verifyFull 依赖 build 和 runGameTestServer，服务器运行排在 build 后。本轮没有调用这些任务。 |

## 心剑物品栏图标

新图标：`src/main/resources/assets/wuxingxiantu/textures/item/heart_sword_inventory.png`，64×64 RGBA。
模型分流：`client/HeartSwordInventoryModel.java` 仅 GUI 选择新生成模型，手持、掉落及四动作保留 OBJ。
脚本 `tools/heart_sword_64.py` 读取既有 OBJ/UV/材质绘制图标，不写模型素材；另外更新物品 display 的手持尺寸及握点补偿。
第一人称 scale 0.78、第三人称 0.85；四动作的纯心剑绘制尺寸同步放大。实际姿势仍需客户端验收。

与 `deliverables/wuxingxiantu-source-20260926-004913.zip` 逐字节比较，以下全部一致：

| 文件 | SHA256 |
| --- | --- |
| heart_sword.obj | a67be018e0b6a507e0b8b1fb2c2d836fe3f652c1343e48db633490a9f8a50c77 |
| heart_sword.mtl | 208612cefa7715003b4d5fe38e9537756494783074a132377203277bef3fef58 |
| heart_sword.png | a8010d78f1b5f5c480045df58a451c6e193d2266d5bd49a5e5dd0a951f4f3a2a |
| heart_sword.bbmodel | 92a34c9877b28b21001d33ac97bdce375f28880a0ba6fc1d07e34f29c084bcaa |

## 实际检查与边界

- `check_resources.py`：11/11 PASS。
- `check_heart_sword_assets.py`：4/4 PASS，含 64px 图标、材质一致、握点变换及模型文件哈希。
- `check_exotic_burn_architecture.py`：6/6 PASS。
- `check_alchemy_art.py`：8 张 32px RGBA、互异图案及模型分流 PASS。
- 已人工查看图标放大预览，已只读核对所用 Forge 接口。静态检查不证明 Java 编译成功、模型烘焙成功或游戏行为正确。
- 后续执行 **build 成功、GameTest 编译通过但未运行、客户端未启动**；227 项平衡/动画边界回归和 11 项资源检查通过。交付 `deliverables/wuxingxiantu-1.0.0-r11-20260926-031144.jar` 包含本批及后续武器异火缠绕修改，日志为 `reports/build-20260926-031144.log`。不得以此标注全部“修复已验证完成”。

新增 `SeptemberAuditGameTests` 11 个 required 用例：入侵冻结与快照、创造修复状态、单方解锁与重复、历史单方修复、无效单方、所有普通丹录、契约轮换/存档/同步、御剑槽和外部存储耗灵、单次心铸真伤及成长、普通冲撞上限、终局显式重赛。
新增 `ExoticBurnGameTests.wetContactCannotDealSameTickDamage` 与 `SoulAppearanceGameTests.dragonPhaseAndReverseIndexRestoreOnDetach`；扩展单身体生命周期验证右键本体、异火用例验证普通火抑制；已有合法心铸测试改为绑定真实契约。
全部是已编写、未运行，不能计入通过数量。共 13 个新增用例，未降级 required。

这些测试中的直接剑伤用例覆盖共享计算入口，不代替完整御剑运动/冲撞/剑诀调度实机测试。创造丹 HUD 消失、双手动画、JEI 图标、异火叠加、多人显示、龙战上下文恢复和首次竞技场进入仍需客户端/集成验证。

## 未实施与后续设计

审计中的后续专项保留为未完成，不冒充本批修复：

- 前九 Boss 正式 AI、阶段、境界映射、数值及奖励；当前仍为视觉测试实现，required_realm=0 仍是占位。
- 正式 Arena Registry、结构资源、分阶段放置；本轮只减少无效写块，未消除首次同步生成峰值。
- 治疗、独立护盾池、攻击强化和持续恢复的高境界数值设计。
- 灵力结晶、炼器、人皇幡、灵蕴台经济以及丹药专项。
- 普通功法定向剑气、推进火浪、链雷、五行阶段等正式机制；万剑诀网络入口当前已优先路由 SwordTechniqueManager，但旧分支尚未清理。
- 心剑分层透明/自发光材质本轮按用户新要求不做；heart_mote/heart_flame 独立资源及最终动作美术仍待后续。
- 九种异火视觉 Profile、其他热点与大类拆分、完整性能采样、外部战斗 Mod 兼容验证，以及其余弃用 API 清理。

RealmBalance、普通御剑低成本、心剑境界/小境界倍率、heart_true 的阶段与玩法无敌边界保持原设计。根目录批次报告已归档，AI_SOURCE_MAP 只保留入口导航；README 未扩写。
