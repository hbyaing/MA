# 2026-10-07 噬灵虫、境界飞行与灵植整合

本轮按用户的图片和噬灵虫说明实装，文件中的技术说明作为参考资料，需求以会话中用户的最终选择为准。

## 实装内容

- 境界飞行：注册独立 `realm_flight` 可见 Buff，元婴及以上持续补回；服务端定期同步飞行权限，低境界移除资格。元婴/化神原耗灵、炼虚以上原免费规则保留。特殊御空和原版飞行在背包设置中切换并同步观察者；创造/旁观不套用特殊动作。客户端动作资格改用服务端标记及实际同步的 Buff，避免依赖本地境界数据。图标使用用户提供的青色羽云图。
- 御剑：常态改为直立、手臂自然下垂；加速时身体前倾、双臂后掠，按加速程度平滑过渡。
- 内视：修为、灵力、生命条复用首页金色、青色、红色装饰轨道与填充素材。
- 龙鳞草、疾风草、灵芽草：每种三个生长阶段，透明 32×32；保留原年龄映射与植物逻辑。疾风草明确丢弃参考图第一个植株，采用后面三个。成熟物品同步相应图案。
- 噬灵虫：导入原 BBModel 的 102 个自由网格、11692 个三角面及 9 张内嵌贴图。原文件没有动画；实现程序化待机、交替三足行走、触须、吸灵口器、攻击冲刺、受击、死亡翻转和饱灵腹部发亮。未把自由网格强行转成方块模型。
- 噬灵虫 AI：近距离攻击、受击唤醒附近同类、小概率侧闪；寻找生长灵植并吸灵 60 tick，降低一次 AGE，同株共享 600 tick 冷却，饱灵 900 tick、速度提高 10%，状态保存。关闭 mobGriefing 时不改植物。
- 噬灵虫自然生成：森林、桦木林、黑森林、平原与繁茂洞穴，低权重 6、每组 2–3，非和平且暗处、远离出生点并避开村庄；新增黑褐/青绿刷怪蛋。
- 两个素材：虫甲碎片、噬灵虫囊，使用用户参考图导入透明 32×32。虫甲 0–2；虫囊概率普通 15%、饱灵 40%；饱灵额外 15% 掉落既有灵液瓶。

## 资源与入口

原图和说明保存在 `source-assets/oct07-gameplay-references/`，模型原件在 `deliverables/噬灵虫模型/`。导入脚本为 `tools/import_oct07_pixel_references.py` 与 `tools/import_spirit_devourer.py`。预览为 `reports/spirit-devourer-20261007/pixel-import-preview.png`。

主要代码：`event/CultivationTicker`、`client/realmflight/RealmFlightVisuals`、`client/YujianRidingPose`、`client/MeditationModels`、`client/CultivationVisionPage`、`entity/SpiritDevourerEntity`、`entity/SpiritDevourerSpawns`、`client/SpiritDevourerRenderer`。网络协议 67。

## 验证与交付

完整构建成功；资源检查 13/13，专项境界御空/噬灵虫专服 GameTest 5/5。覆盖元婴与地仙补回权限和 Buff、模式排除、吸灵降阶、共享冷却、mobGriefing、饱灵存档。既有数值与动画边界检查通过。日志见 `reports/spirit-devourer-20261007/verify.log`。

本轮没有运行 Minecraft 客户端，动画、材质、界面和实际存档仍需实机验收；专项测试不代表全量通过。上一轮全量 149 项中既有御剑冲锋命中测试失败，本轮未声称修复该独立问题。

成品：`deliverables/wuxingxiantu-0.2-20261007-spirit-devourer-flight.jar`。
SHA256：`A28CB796A75C7EA015914E952BAA8DD2A2E0049EDA313A5F1A7E9857C6AB40D1`。
已安装到 `D:\MC\库\red.ghs.axolotl\profiles\测试 (1)\mods`，旧御空版本已备份并替换；安装证据 `reports/spirit-devourer-20261007/install.json`。重启游戏加载新版。
