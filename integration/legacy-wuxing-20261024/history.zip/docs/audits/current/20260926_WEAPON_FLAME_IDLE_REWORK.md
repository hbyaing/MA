# 异火缠绕返工：第一人称静止持剑

后续交付更新：用户随后要求构建和源码 ZIP，已于 2026-09-26 04:27:34 执行完整 `build` 成功，生成 `wuxingxiantu-1.0.0-r11-20260926-042720.jar`，对应源码为 `wuxingxiantu-source-20260926-042720.zip`。403 项既有回归、新增螺旋几何契约、11 项资源检查 PASS；没有重跑客户端或 GameTest。下文“未构建/未打包”描述的是本报告原先的实现阶段，最新交付与验证状态见根目录 `REPAIR_STATUS.md`。

2026-09-26，样板为玄铁剑 `dark_iron_sword` + 赤流焰 `red_flow`。本轮修改、编译并实际启动 Forge 1.20.1 客户端多次，保留旧效果基线和最终 6 张截图。没有执行发布用 `build`、打包新 JAR 或运行 GameTest 服务器。Gradle 的 `BUILD SUCCESSFUL` 来自文末列出的任务，不等于执行了 `build`，也不等于最终美术验收通过。

用户已明确选择保留原握持位置，允许额外广角截图检查完整路径。模型、模型材质、握持变换、第三人称大小均未改。只针对静止持剑返工，没有继续完善攻击拖尾、命中特效、防具特效或逐一调九种异火。

## 返工前实现定位

入口为 `WeaponFlameRenderer.afterItem`，CoreMod 在最终 `ItemRenderer` 矩阵内调用。导入剑走 BEWLR 的内层模型调用，外层 `model.isCustomRenderer()` 返回，避免重复绘制。

旧实现确实存在 segmented ribbon mesh，并非全由粒子伪造。但几何和提交顺序有错误，实机主要露出了辅助贴片。

| 旧参数：玄铁剑 + 赤流焰 | 实际值 |
| --- | --- |
| 节点/段数 | 29 节点、28 段；第 9、18、27 段不绘制 |
| hiltAnchor | `(0.675, 0.5, 0.5)` |
| tipAnchor | `(0.012, 0.5, 0.5)` |
| blade local axis | `(-1, 0, 0)` |
| widthAxis / depth | `(0, 0, 1)` / `(0, 1, 0)` |
| bladeWidth / bladeThickness | `0.071484375` / `0.01703125` |
| coilRadius | JSON 为 `1.28`，含义是矩形半截面倍率，**不是**圆形螺旋半径；宽/厚方向轴端距离约 `0.04575` / `0.01090` |
| coilTurns | `1.15`；路径另外叠加正弦扰动，取 `t=0.04..0.95` |
| ribbon width | 第一人称主体传入半宽 `B × 0.28 × 0.72 = 0.014414`，名义全宽约 `0.028829`；但宽向量错误地用了剑轴 |
| RenderType | `entityTranslucentEmissive`，标准透明混合、NO_CULL、COLOR_WRITE、不写深度、默认 LEQUAL 深度测试、排序四边形 |

`weapon_flame.png` 是 64×32 横排四帧白色火舌图集。旧待机在三处区域放了 **6 个 FlameAttachment，每个 3 层 quad**，另被旧残焰、命中剥离与火星方法共用。主 ribbon 使用另一张 32×8 `weapon_flame_band.png`。

旧基线截图中的红色竖片来自 **FlameAttachment 层的纹理 quad**，不是自然粒子，也不是可辨认的完整螺旋带。`quad` 是这个附着层的几何图元，因此这两个名称不是互斥分类。

## 根因与修正

1. 旧带宽沿剑轴，与螺旋切线近乎平行，带面有效面积被压缩。现在从解析切线求 `side = normalize(radial × tangent)`，带宽真正横跨路径。
2. 旧截面厚度远小于宽度，前后半径约只有 `0.01090`，螺旋被压扁。现在按 bladeWidth 构造圆形截面，两局部基向量同半径。
3. 剑身进入固定 BufferSource 批次，火带进入即时切换的透明批次。旧火带不写深度，先画的前半圈随后也被延迟绘制的剑身覆盖。现在先提交当前模型各 render pass 及 glint，再提交火带；仍保留深度测试，后半圈正常被剑挡住。
4. Minecraft 1.20.1 的 `rendertype_entity_translucent_emissive.vsh` 仍调用 `minecraft_mix_light`，固定法线让火焰被方向光压暗。本轮独立的局部火带 shader 直接使用顶点颜色，不受方向光压暗，保留距离淡出。
5. 火舌从 6 处减为 3 处，长度按剑宽计算，不再按整剑长度拉成长竖片。64×32 图集字节不变，当前仅供 attachment 使用。为遵守此约束，旧战斗 wisp/spark 的共用绘制方法改用 band 蒙版并同步其 batch flush；没有新增或调优战斗形状/轨迹。

## 当前局部螺旋

`WeaponFlameHelix` 生成 **49 节点、48 段**，依据原有武器锚点：

```text
axis       = normalize(tipAnchor - hiltAnchor)
localRight = normalize(widthAxis - axis * dot(widthAxis, axis))
localUp    = normalize(axis × localRight)
center(t)  = lerp(hiltAnchor, tipAnchor, t)
theta(t)   = phase + t * coilTurns * 2π
position   = center + radius * (localRight*cos(theta) + localUp*sin(theta))
```

局部基向量和节点经过与剑相同的最终物品矩阵；没有世界 Y 或摄像机 billboard 螺旋。第一/第三人称使用同一锚点与同一算法。

| 当前赤流焰参数 | 数值 |
| --- | --- |
| 锚点、axis | 与上表一致 |
| coilTurns | `1.05` |
| coilRadius | `0.86 × B`，第一人称乘 `1.10`，即 `0.946 × B ≈ 0.067624` |
| ribbon width | 名义全宽 `0.35 × B`，第一人称乘 `1.08`，即 `0.378 × B ≈ 0.027021`；沿路轻微变化、两端收束 |
| 主体网格 | 每段 5 个相邻宽度色带，共 240 个 quad；焰心、焰体、透明深色边缘共享边界，不用共面叠加冒充宽度 |
| 辅助火舌 | 节点 `5、23、41`，即约剑身 `10%、48%、85%`；共 3 处，每处保留图集的 3 层配色 |
| 火舌尺寸 | 基础长度 `0.7 × B`，半宽 `0.12 × B`，第一人称半宽乘 `1.08` |
| phase / flow | `time × 0.045 × coilSpeed`；UV 沿路径流动，不改变局部轴 |
| 主 RenderType | `WeaponFlameRenderTypes.BAND` / `weapon_flame_band`，自定义 `wuxingxiantu:weapon_flame` shader |
| 附着 RenderType | `WeaponFlameRenderTypes.ATTACHMENT`，原版 POSITION_COLOR_TEX unlit shader |
| 深度/混合 | 两者均 LEQUAL、COLOR_WRITE（深度写入关闭）、SRC_ALPHA / ONE_MINUS_SRC_ALPHA、NO_CULL、排序 quad |

带宽与透明度随路径变化；亮芯随流动分段变亮，避免连续激光芯。shader 进一步侵蚀边缘、形成局部缺口。保留 32×8 band 蒙版，修正其 clamp 元数据以允许 UV 流动重复采样。没有增加大团粒子或复制大量火舌来填满剑身。

`red_flow.json` 升级为 schemaVersion 2，尺寸含义统一为剑宽倍率。其余 8 份 JSON 未逐一调参；加载器兼容旧倍率并转换为新几何范围，它们尚未完成实机美术验收。生成脚本同步了赤流焰的新参数，未重新生成或覆盖所有剑资源。

## 实机截图与观察

截图来自 Minecraft `Screenshot.takeScreenshot(mc.getMainRenderTarget())`，不是外部模拟渲染、拼接示意或 AI 图。环境：Java 17、Forge 47.4.10、NVIDIA RTX 4060 Ti / OpenGL 4.6、1280×720、新建隔离测试世界。三张正常视角、三张诊断广角，均为静止持剑的不同时刻，未攻击。

- 旧正常视角：`reports/weapon-flame-idle/before-normal.png`。
- 新正常视角：`reports/weapon-flame-idle/normal-0.png` 至 `normal-2.png`。使用原握持和默认手部 FOV 70，原有大剑仍部分伸出画面。
- 新广角诊断：`reports/weapon-flame-idle/wide-0.png` 至 `wide-2.png`。仅测试源集通过 ComputeFov 将手部 FOV 设为 140，以露出完整剑尖；没有改动剑模型、握持变换或生产环境的 FOV。
- 广角图可辨认从护手区域起的带、横跨剑面的前侧，以及在剑后被遮挡后从另一侧出现的部分；不同时刻位置沿剑轴旋转。剑本身保持可辨认。
- 64×32 火舌仅作少量辅助，主要可见面积来自螺旋带。视觉占比没有被当成严格像素百分比的自动化 PASS。

本轮已观察并修正静止样板的结构问题，**最终火焰观感仍交由用户看截图验收，不标注“所有异火视觉验证完成”**。普通视角因原握持尺寸不能单图完整展示整剑；用户已确认用广角辅助验收。尚未验收攻击、命中、左手、多人、第三人称、其余剑/异火组合及外部光影兼容。

## 实际验证

最后一轮客户端于 2026-09-26 04:17:15（Asia/Shanghai）正常退出，Gradle 退出码 0，用时 58 秒。执行的是 `regressionTest validateResources runClient`，**没有执行完整 `build` 或 GameTest**。

- 主源码编译、可选客户端夹具编译：PASS。
- 403 项既有平衡/动画边界检查：PASS。
- 新螺旋数值契约：PASS，覆盖 49 节点的恒定圆半径、锚点轴投影、带宽单位向量、切线正交性、整体旋转等变性、1.05 圈累计角度和基向量退化后备处理。
- 通用资源检查：11/11 PASS。
- 武器特效资源检查：5/5 PASS。
- 真实客户端 shader 加载和 6 张截图采集：成功；截图结果文件明确写的是人工视觉验收，未当作自动视觉 PASS。
- 新 JAR、源码 ZIP：本轮没有打包。旧交付不含本轮返工。

日志：`reports/weapon-flame-idle-final-client.log`；采集结果：`build/weapon-flame-client/idle-final-result.txt`。中间迭代日志及截图仍保留，不能用早期未达标画面代表最终效果。

```powershell
$env:JAVA_HOME='C:/tmp/temurin17/jdk-17.0.20.1+1'
$env:Path="$env:JAVA_HOME/bin;$env:Path"
$env:JAVA_TOOL_OPTIONS='-Djdk.net.unixdomain.tmpdir=C:/tmp'
$nativeDir=Join-Path (Get-Location) 'build/weapon-flame-natives'
.\gradlew.bat --offline --no-daemon --console=plain -PweaponFlameTests `
  -PflameCapture=idle-final "-PflameNativePath=$nativeDir" `
  '-PpythonExecutable=C:/Users/Nostzephert/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' `
  regressionTest validateResources runClient
```

客户端夹具位于 `src/weaponflametest/java/`，只有传 `-PweaponFlameTests` 才加入开发运行，普通生产 JAR 不包含它。此机器的 Gradle 缓存原有 Linux native，因此测试把缓存中 Windows DLL 提取至上述 build 目录，通过 LWJGL 的 librarypath 指定；没有修改发布依赖。

关键原图 SHA256：

```text
before-normal.png 6C7F942E020203A0F1B375188EF74E4DCD0362BB90B6B54512F0931D2BDB5B48
normal-0.png      D9F9C59C10906ED4A387BD3E620B1D8491147B2F879540B0894F4D29F8218970
wide-2.png        183AB9D5BB4CFE7B62C644B51033E7B37FF71A57F42B0C7868BADEF65AB19CD0
weapon_flame.png  20F7F6506B50370661D5B84C69A9B1D2DD3213927874C5FEF0ACE25194F20621
```
