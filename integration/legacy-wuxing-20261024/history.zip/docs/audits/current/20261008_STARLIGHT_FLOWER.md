# 星辉花原图接入

用户透明原图左中右分别接入幼苗、生长、成熟阶段；成熟裁片作为物品图标。原始裁片不重采样，透明画布使用紧凑 UV，保持现有模型各阶段尺寸与地面基准。原图、裁片、预览及坐标保存于 source-assets/starlight_flower-20261008，导入脚本 tools/import_flower_vine_references.py。

保留此前七种灵植及玄水藻 v2 素材。注册 ID、方块状态、生长、掉落、配方及存档字段不改。完整构建与资源检查通过；成品 wuxingxiantu-0.2-20261008-starlight-flower.jar 安装到指定测试目录，实机由用户确认。
