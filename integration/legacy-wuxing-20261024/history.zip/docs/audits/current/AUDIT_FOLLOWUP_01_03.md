# 01 / 03 审计整改交接（源码阶段，未构建）

依据用户提供的 `01_BUG审计.txt`、`03_优化事项.txt`（均审计 2026-09-28 burn-anchor 源码包）。原文位于用户 Downloads，保留原始结论；本文件记录后续整改，不覆盖原始审计。

**本轮不运行 Gradle、不构建模组、不启动 Minecraft、不发布新 JAR 或源码 ZIP。** 下文“已实现”仅表示已写入源码并静态复核，除明确列出的脚本结果外，均尚待编译和动态验收。

工作目录为 `E:\五行仙途`，本目录没有 `.git`，无法提供 Git diff；接力使用本文列出的入口，不扫描历史聊天、截图、日志或整个项目。异火点燃原点修复和退役外观保持上一轮状态。

## 用户确认

炼丹、炼器保持公共领取，附近玩家均可领取。沿用现有距离、存活状态、菜单和服务端会话校验，不添加 OWNER_ONLY / TEAM 锁，也不因审计建议擅自更改玩法。任务中的 owner 用于额度、通知、退款和自助查询，不代表成品独占权。

## BUG 整改矩阵

| 项目 | 源码状态 | 实现与验证边界 |
|---|---|---|
| B-01 渡劫丢失 | 已实现，待动态验收 | `TribulationState` 保存 Trial；玩家 NBT 保存同一检查点，离线暂停。登录以玩家检查点重建世界索引，避免把较旧世界记录强加到较新玩家存档。正常存档恢复不再依赖静态 Map。 |
| B-02 跨维度绕过 | 已实现，待动态验收 | Trial 固定 start dimension；跨维度事件取消并提示。绕过前置事件的维度变化走失败结算；鬼仙身份使用起始维度。 |
| B-03 坑洞无法恢复 | 已实现，待动态验收 | 保存 dimension / pos / 原 BlockState / restoreAt；读档重建去重表和到期队列；未加载区块每 200 tick 重试；仅覆盖仍为黑色混凝土的位置。 |
| B-04 心剑检查缺输入 | 隔离资源检查通过 | 固定契约移到 `source-assets/contracts/heart_sword_v2_import.json`；生成的 reports 预览图不再进入必需哈希表。11 个源输入在无 reports/build 的临时目录执行 4 项检查，全部通过。尚未生成新 ZIP 或运行其完整 verifyFull。 |
| B-05 旧炉锁住玩家 | 已实现，待动态验收 | 任务以维度＋位置为主键；owner 索引管理额度；到期后即为 READY，不占进行中额度，即使区块尚未加载。旧炉任务仍保留以便后续结算。 |
| B-06 丹成展示跳过 | 已实现，待动态验收 | `CompletionTick` 写入磁盘 NBT；同步 tag 复用保存逻辑。旧存档原本缺失该字段，无法逆推出旧展示时长，仍沿用旧兼容回退。 |
| B-07 公共领取 | 用户确认，保留现有规则 | 无独占权；附近符合现有交互条件的其他玩家可领。多人同时领取是否恰好一次仍列入实机回归。 |
| B-08 心剑预扣灵力 | 已实现，待动态验收 | 预扣额写入玩家 NBT；成功完成移除标记，停服取消退款，登录恢复遗留退款。死亡沿用原有不退款规则，退款仍受灵力上限约束。 |

## 优化整改矩阵

| 项目 | 状态 | 本轮范围 / 下一步 |
|---|---|---|
| O-01 持久状态机 | 已实现 | `COUNTDOWN → STRIKING → SUCCESS/FAILURE → SETTLED`；试炼和坑洞统一存储；待存档生命周期回归。 |
| O-02 位置任务＋owner 索引 | 已实现 | schema 2；读取 schema 1 原列表的 owner / dimension / pos 重建索引，不要求手动清旧任务。 |
| O-03 到期调度 / 退款 | 已实现 | 有序到期集合＋任务调度索引，不再每 tick 全表扫描任务；每 tick 最多处理 256 个到期项。登录和现有每 20 tick 在线玩家循环尝试退款，未能入账余额持久保留。 |
| O-04 版本号与指标 | 已实现，收益未测量 | stable / divine 两类版本号减少普通 vitals flush 的慢字段数组读取；保留深比较和 200 tick 全量心跳。增加快照分配量和每玩家分钟包数 / 字节数。 |
| O-05 来源提供者 | 架构与首批来源已实现，覆盖未完成 | `SourceEvidence`、`AcquisitionSourcesEvent`、`EvidenceTrade`；固定交易共用玩法定义，登记宝箱脚本、铁砧月币、灵液转换、心剑召唤。随机道士交易、其他实体 / Boss / 心境等来源仍待逐项登记；不随机抽样伪造穷举证据。 |
| O-06 丹炉复核降频 | 已实现，待性能与结构回归 | 放置 / 邻居变化标记 dirty，下 tick 复核；200 tick 错峰兜底；开炉前完整检查。拆除即时路径保留。 |
| O-07 炼器同步范围 | 已实现，待客户端回归 | 显式方块实体数据包仅发给追踪该区块的客户端，移除全服玩家遍历；保留 block update 和补发包以维护已有清屏行为，尚未去掉重复包路径。 |
| O-08 灵液分桶 | 按审计要求等待测量 | 本轮不改扫描频率；先测 100 / 500 / 1000 个 ItemEntity 的耗时和转换延迟，再决定分桶。 |
| O-09 司南类型索引 | 按审计要求等待测量 | 保留已有持有、冷却、距离与落点校验；高密度实体场景确认热点后再加索引。 |
| O-10 可复现源码验证 | 部分完成 | 必需契约归入源码；隔离资源检查接入 CI / specialistChecks；打包脚本可只打源码并逐条验证 SHA256。警告预算调整为历史全编译基线 74；当前编译和实际 ZIP 解压 verifyFull 尚未运行。 |
| O-11 真实性能基线 | 验收方案已列出，数据未采集 | 本轮不启动游戏；下节定义场景和指标，不填写虚构改善比例。 |
| O-12 大类拆分 | 本轮限于相关职责 | 提取 `TribulationState`、来源 evidence 类与恢复命令。人皇幡 / ModClientEvents / 内视大类尚未拆分，应独立确定边界后处理。 |
| O-13 渡劫旧心魔分支 | 已清理 | 删除无有效赋值路径的 demonId / awaitingDemon 及其分支；心魔只走 MindscapeManager。origin 现为持久诊断起点，不用于恢复旧刷怪状态机。 |
| O-14 工作台权限 | 公共规则确认；扩展框架未引入 | 本轮没有私有 / 队伍需求，不添加统一可配置权限框架。未来扩展时需同时覆盖 GUI、材料操作、领取和取消。 |

## 关键入口与存档语义

Java 路径均相对 `src/main/java/cn/blockforge/generated/generatedmod/`：

- 渡劫：`TribulationState.java`、`TribulationManager.java`、`event/PlayerLifecycleEvents.java`、`Network.java`。
- 炼制：`network/service/CraftingJobs.java`、`AlchemyService.java`、`CraftingRecoveryCommands.java`；两种炉子的 BlockEntity / Structure、`RefiningForgeBlock.java`、`event/AlchemyEvents.java`、`event/ServerTickEvents.java`。
- 灵力恢复与同步：`HeartSwordSystem.java`、`CultivationDataImpl.java`、`network/CultivationSync.java`、`network/SyncMetrics.java`。
- 获取来源：`AcquisitionCatalog.java`、`acquisition/`、`SpiritTradeEvents.java`、`event/WorldEvents.java`，及上述 ServerTickEvents / HeartSwordSystem 提供者。
- 额度配置：`balance/GameplayConfig.java`，世界配置 `maxActiveAlchemyJobsPerPlayer` / `maxActiveRefiningJobsPerPlayer`，默认分别为 1，范围 1–64。

渡劫 SavedData 名为 `wuxingxiantu_tribulations`，玩家检查点键为 `wuxingxiantu_active_trial`；旧版纯内存 Trial / 坑洞信息若已丢失无法事后恢复。离线暂停的是渡劫倒计时和落雷间隔，不暂停已生成坑洞的恢复期限。

炼制保留 SavedData 名 `wuxingxiantu_crafting_jobs`；到期状态由 finishTick 判定。恢复命令 `/wuxing recover crafting` 只查询自己的任务、请求重试并尝试入账退款，不强制加载区块、不取消他人任务。返回原炉附近加载区块后，任务才能实际把产物写回方块实体。原版各维度共享 gameTime；改变维度时钟语义的其他模组需要另行兼容验证。

**保存边界：**玩家检查点与玩家能力 / 背包随同一玩家存档保存，缩小费用和状态分离的窗口；这不是磁盘事务日志。区块、玩家、SavedData 仍分开保存，不能承诺断电 / 文件损坏时零回滚、绝无重复结算。心剑退款是原有上限内恢复，不是超上限的长期欠款账户。

## 本轮实际检查

| 检查 | 实际结果 | 不代表什么 |
|---|---|---|
| `java tools/CheckJavaSyntax.java <25 个改动 Java 路径>` | 25 文件、0 语法错误 | 只调用 JavacTask.parse，不做符号 / 类型分析，不生成模组 class，不代表编译通过 |
| `python tools/check_source_package.py` | PASS；11 个输入、4/4 心剑断言 | 只验证必需资源输入隔离自洽，不是全源码 ZIP / 完整 CI 验证 |
| `python tools/check_audit_contracts.py` | PASS；67 个有方向的网络 ID | 不证明客户端联机或运行时协议交换通过 |
| Python AST 解析 | 4 个改动 Python 脚本通过 | 不执行导入器，不重写任何模型或贴图 |
| PowerShell Parser | `tools/package_source.ps1` 无语法错误 | 本轮没有执行打包 |
| 本地映射 JAR 的 javap | 确认 chunk tracking、BasicItemListing、VillagerTradesEvent 的使用签名 | 只读已有依赖，不替代完整类型检查 |

隔离检查最初发现契约仍把 `reports/heart_sword_v2_preview.png` 当必需哈希输入；已从新的固定契约与导入器输出哈希列表排除，修正后复跑通过。旧 reports JSON / 预览图保留历史用途。未重新执行美术导入器。

警告预算 74 来自此前记录的完整编译；本轮没有测出新警告总数。新基线不可作为继续增加警告的理由，下次编译需按真实日志验收。

## 下次允许构建后的验收清单

先备份测试世界。以下均尚未执行；不要在交接时改标为 PASS。

1. 在干净目录解压新的源码包，检查不存在 reports/build 依赖；依赖齐备时执行 `verifyFull` 和警告预算脚本。确认 0.2 / 协议 63 的兼容边界和新源包包含固定契约。
2. 渡劫分别在倒计时、首次落雷和最后一次落雷附近测试退出重登、正常停服重启、保存后强制中断；核对内丹、次数、生命、旧灵力上限与阶段。离线不推进，已结算不重复奖励 / 惩罚。
3. 渡劫中进入下界门 / 末地门及其他传送入口应被阻止；可绕过前置事件的入口应失败结算；测试死亡和复活不残留试炼；鬼仙判定依照起始维度。
4. 坑洞生成后保存并停服，重启至到期恢复；包括未加载区块、同坐标重复落雷、玩家换成其他方块。后续玩家重新放置的同种黑色混凝土无法与原劫痕区分，是现有识别边界。
5. 从旧 schema 1 存档迁移，分别创建炼丹 / 炼器任务并卸载区块；到期后另一处可开新炉；回旧炉只结算一次。未到期遵守配置限额，忙提示包含维度 / 坐标；恢复命令不强载区块。
6. 测试拆炉、换异火瓶、取消、掉线退款、灵力满额时欠款保留；空闲炉残留旧位置任务时不可先扣材料和灵力再抛异常。服务器重启不重复材料返还或发放成品。
7. 丹成展示中保存重进，展示剩余时间连续；两人靠近丹炉 / 同时操作炼器领取，只发放现有总量且允许非投入者领取。满背包、旁观者、远距离和失效会话沿用已有校验。
8. 心剑 SUMMON / FORGE 读条中正常停服和保存后中断，重登返还一次；成功完成无遗留退款，死亡不额外退款；检查上限变化时的退款行为。
9. 联机校验所有慢字段、学习列表、神通与异火变化及时刷新；普通灵力变化只走 vitals；登录 / 复活 / 换维度与 200 tick 心跳正常。炼器开始、完成、领取时悬浮物与按钮及时更新，远处追踪玩家也能刷新。
10. `/wuxing audit acquisition` 导出 Markdown 和 `acquisition-evidence.json`；核对真实固定交易、灵液、铁砧、宝箱和心剑证据；缺失来源继续标为待审计，不判定为不可获得。

## 性能基线方案（无实测数据）

固定相同硬件、Java 参数、模组列表、测试存档、视距与模拟距离；每个场景预热 2 分钟、采样 10 分钟，修改前后各至少 3 次。保留原始 profiler / GC / 网络日志，记录平均与 P95 MSPT、TPS、GC 停顿 / 分配、在线人数、实体数、任务数与同步负载。

| 场景 | 负载 | 关注点 |
|---|---|---|
| A 正常游玩 | 单人 10 分钟 | 基础成本；另记录至少 20 个正常修炼样本，不以创造模式代替进度体验 |
| B 多人炼制 | 10 玩家，20 个炼丹 / 炼器任务 | 空闲 tick / 到期 / 卸载区块重试、炉体刷新与同步 |
| C 魂仆 | 20 / 50 / 100 个 | AI、实体数、主线程 MSPT |
| D 组合战斗 | 渡劫＋异火点燃＋心剑＋御剑 | 同步峰值、渲染及服务端耗时；当前没有退役武器缠绕 |
| E 灵液 | 100 / 500 / 1000 个 ItemEntity | 候选扫描耗时、处理延迟、漏转与重复转换 |
| F 司南 | 固定高密度生物区域，合法冷却内查询 | 名称匹配 / 附近搜索占比，是否值得加类型索引 |

使用 `-Dwuxingxiantu.profileSync=true` 开启统计。当前统计仅含 cultivation full / vitals 序列化负载和完整快照分配；不含神通等其他消息、通道封装、压缩或全服总带宽。不要把这一局部指标标为网络总流量。

## 接力顺序

1. 只读 `CURRENT_STATUS.md`、`AI_SOURCE_MAP.md` 和本文即可恢复；按具体待验收项读取上述对应源码。
2. 本轮用户未要求构建，因此停止于源码整改和静态检查。后续先按新请求决定是否进入构建 / 实机阶段。
3. O-05 后续来源覆盖、O-08/O-09 测量、O-11 基线和 O-12 大类拆分分别推进，不机械重做已有正确修改。
