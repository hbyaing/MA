# 异火模块贴图实装

2026-09-28。Minecraft 1.20.1 / Forge 47.4.10 / Java 17 / GeckoLib 4.8.4，版本 0.2、网络协议 63。

## 实现

四张上一轮生成的透明 PNG 已逐字节复制到 `src/main/resources/assets/wuxingxiantu/textures/effect/modular_v1/`。分别为 `main_arc`、`transition_arc`、`tail_fragment`、`scatter_particle`；各自关闭模糊并启用边缘钳制。有效 UV 来自原素材 manifest，避开大面积透明留白，不改动原图像素。

- `WeaponFlameModules` 定义模块 UV、可见宽高比与排列规则。主体、较窄过渡、尾端按物理路径距离排列，间隙不生成面片；跨模块边界时切分几何，避免每个网格片重复整张贴图。支持负相位，并限制异常超长路径。
- `PixelFlameMesh` 输出模块面片，保持片段比例，并复用现有异火配色 shader。散射块按确定性种子旋转。
- `WeaponFlameRenderer` 将剑身螺旋与三条挥剑路径切换至模块片段，按实际路径长度计算 UV；轨迹低透明度阶段使用较小尾端块，脱落余烬使用散射贴图。
- `WeaponFlameHitEffects` 将命中脱落块接入散射贴图，后期切换尾端块。仍限制 48 组、12 tick，保留距离和视锥剔除。
- 未修改伤害、网络、物品锚点和怪物后续燃烧实现。截图中怪物身上的既有持续火焰不代表本轮新增内容。

## 验证

- `build` 成功：`reports/build-20260928-modular-v1.log`。Boss 224 项、数值/动画 411 项、螺旋回归及新增模块布局行为回归通过；异火资源 7 项、通用资源 11 项及其余专项检查通过。
- 新增布局回归比较整条与 108 段路径的模块选择、间隙及 UV，另验证宽高比、负相位、衰减、无效输入与几何数量边界。
- 新增资源检查核对原图 SHA256、运行资源元数据、有效 UV 和透明边距。
- 独立客户端 `modular-v1-final` 完成 20 帧采集并正常保存退出。已查看诊断全剑、侧面待机、真实挥剑/命中及衰减帧，未见缺失贴图或不透明背景。该轮素材板被 GUI 缩放裁边，随后修复测试夹具的自适应布局。
- 测试夹具增加首次启动引导处理，仅属于 opt-in 测试源集。正式 JAR 不包含采集类或 GeckoLib 编译桩。
- 最终 `modular-v1-accepted` 再次完成 20 帧并正常保存退出；四类素材板完整显示，无 HUD 遮挡和屏幕裁边。日志 `reports/flame-client-modular-v1-accepted.log`，精选 8 帧与采集结果保存在 `reports/weapon-flame-modular-v1/`。
- JAR 内容和压缩完整性检查通过，四张 PNG 与源素材哈希一致。

## 产物和边界

`deliverables/wuxingxiantu-0.2-20260928-modular-v1.jar`，37,866,043 字节。

SHA256：`7e062ea2b96789330f0027c670db9008a4232eb0e292420d258f64c083d280bd`。

本轮通过独立开发客户端验证；没有替换任何已有 AXO 实例的 JAR，也没有重启用户现有客户端。尚未逐项验证九种配色、全部武器、左右手、光影兼容或多人压力。没有运行完整服务端 GameTest / verifyFull；既有弃用警告仍存在。

本轮使用原始高分辨率图，四张纹理无 mipmap 的 RGBA 解码合计约 24 MiB；未声称完成低分辨率资源优化或性能基准。旧 0.2 JAR 和旧素材资源保留用于回退。源码 ZIP `010745` 属于本次实装前版本，应以当前源码目录和本轮 JAR 为准。
