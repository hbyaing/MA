# 0.2 封面与异火接力记录

更新：2026-09-28。平台保持 Minecraft 1.20.1 / Forge 47.4.10 / Java 17 / GeckoLib 4.8.4，网络协议 63。

## 恢复的任务与边界

旧会话“0”要求修复未显示的模组封面，先按参考图制作正确的异火材质再接入模组，并将版本从 1.0.0-r11 改为 0.2。旧会话“1”追加提高清晰度、层次感，最后明确暂不制作怪物身上的新点燃效果。

本目录及其父目录没有 Git 元数据，`git status` 返回 not a git repository，无法给出真实 Git diff。仅读取根导航、当前审计、这两个会话末尾及封面/异火相关代码和资源；未重新扫描全部源码，原有修改全部保留。

根状态文档此前停留在 9 月 27 日，但磁盘中已有 9 月 28 日 00:12 的 0.2 JAR，随后还修改过材质、着色器、渲染器及采集夹具。旧 JAR 不能代表恢复时最新源码。

## 上一会话已实际完成

- `build.gradle` 版本已改为 `0.2`。
- `META-INF/mods.toml` 已使用 `logoFile="logo.png"`、`logoBlur=false`。722,575 字节的 `logo.png` 在根资源目录，2,761,375 字节的原图仍为 `pack.png`。
- 四种碎焰、余烬和 384×80 火带从 `reference_assets/weapon-flames-0.2/reference-original.png` 提取；脚本为 `tools/extract_weapon_flame_reference.py`，区域及原图哈希见 `extraction.json`。
- `PixelFlameMesh` 已接入透明 atlas 与连续 U 火带；`WeaponFlameRenderTypes` 和 `weapon_flame_reference` shader 已注册，增强亮芯、暗边与透明轮廓，其他异火继续使用各自配色。
- 命中碎焰已调整大小、间距，仍限制 48 组、12 tick，保留距离和视锥剔除。
- `check_weapon_flames.py` 已检查参考材质留白、透明度、源像素颜色；`package_source.ps1` 已要求明确 JAR，逐文件验证源码 ZIP。
- 独立客户端 `reference-06` 已采集 20 帧，封面及 0.2 版本在 Forge 模组列表中实际可见，这些改动不必重做。

## 本次继续实施

生产代码只修改 `client/weaponflame/WeaponFlameRenderer.java` 的火带尺寸与挥剑 UV：

- 待机火带宽度乘数由 2.8 调整为 3.8，使原图的亮芯、火焰主体和暗边更易区分。
- 三条挥剑轨迹分别累计实际移动距离，依 384:80 材质比例计算 U，避免以采样时间映射时出现拉伸；保持独立相位、透明衰减和历史样本上限。
- 挥剑三层宽度适度增加，保留剑身可见区域。没有改动伤害、网络、怪物身上的点燃逻辑或该燃烧渲染器。

同时更新 README、AI_SOURCE_MAP、CURRENT_STATUS 与本记录，归档实机截图，重新构建并打包。

## 封面原因与验证

AXO 上游 `packages/app-lib/src/mod_metadata/icon.rs` 的 `MAX_ICON_BYTES` 为 2 MiB，优先读元数据指定图标，再尝试 `pack.png`；原图超过此限制。现有 `logo.png` 小于限制且被 Forge 元数据明确引用。

本轮核对上游读取规则，查看 `reference-07-19.png`：Forge 显示封面、五行仙途和 Version 0.2。JAR 检查确认 logo 与源码一致且小于 2 MiB。AXO 当前安装版本的模组列表没有重新进行 GUI 验收，不把上游源码检查写成该界面的实测结果。

上游依据：https://github.com/Mystic-Stars/Axolotl/blob/main/packages/app-lib/src/mod_metadata/icon.rs

## 验证与产物

- `runClient -PweaponFlameTests -PflameCapture=reference-07` 成功，20 帧采集完成，临时客户端正常保存并退出；日志 `reports/flame-client-07.log`。
- 查看第一人称诊断全剑、侧面待机、真实攻击/命中、素材板及 Forge 封面帧。精选原始 PNG 位于 `reports/weapon-flame-0.2/`；其中 `reference-07-2.png` 使用采集夹具的诊断 FOV，不是默认视角。
- `build` 成功，18 秒；日志 `reports/build-20260928-0.2-final.log`。224 项 Boss、411 项数值/动画边界、螺旋几何回归、6 项异火资源检查及其余已有专项/资源检查通过，GameTest 源码编译通过。
- 直接检查 JAR：版本为 0.2，封面和当前贴图/着色器与源码一致；不包含客户端采集夹具、入档 GameTest 类或 GeckoLib 编译桩。
- JAR：`deliverables/wuxingxiantu-0.2-20260928-010745.jar`，36,536,926 字节。
- JAR SHA256：`57606ab647c7f56d33552a825f6938f1cb7d6b9adb3873d52e0cc1b41dcbee13`。
- 源码：`deliverables/wuxingxiantu-source-20260928-010745.zip`；打包脚本逐文件校验 ZIP 内容 SHA256，日志 `reports/package-20260928-0.2.log`。

构建复用本地缓存，命令级使用 `--offline -Dnet.minecraftforge.gradle.check.certs=false` 处理本机既有 ForgeGradle 远程证书预检问题；没有改动项目 TLS 设置。

## 实例与后续边界

`axolotl-launcher` PlanOnly 确认 ASTRA-TEST 已在运行。MCP-HELPER test18 返回 HTTP 200，实时世界名为 ASTRA_VFX_TEST。实例的 `mods/wuxingxiantu-0.2.jar` 仍为 00:12 构建的 38,300,156 字节旧产物；本轮保留运行状态，没有替换正在使用的文件。需要退出实例后用最新交付 JAR 替换旧 0.2，再启动。

本次未新增怪物点燃效果；截图中目标上的既有效果不代表本轮新增内容。未逐一验收九种异火、所有武器、左右手、光影兼容和多人同步，也未运行完整 verifyFull 或警告预算。此前 74 条全量弃用警告问题仍保留，不宣称 CI 已通过。

后续从 CURRENT_STATUS 进入即可，无需重读完整旧会话。若继续外观调整，优先查看原图、reference-07 截图及三个武器渲染入口；若只更新实例，则使用已验证交付 JAR，无需再次制作素材。
