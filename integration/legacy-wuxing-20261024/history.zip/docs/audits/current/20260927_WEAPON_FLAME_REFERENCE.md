# 异火参考图优化与 ASTRA 实例记录

## 实例安装与进入世界

- 实例：`D:/MC/库/red.ghs.axolotl/profiles/ASTRA-TEST`。
- 安装：`wuxingxiantu-1.0.0-r11-20260927-101800.jar`、`geckolib-forge-1.20.1-4.8.4.jar`。
- 本 mod SHA256：`E59F46D2E977793D03797D5C1480EFE3DF49367FE1314077AAC2627702B06B89`。
- GeckoLib SHA256：`33765775385857E7BE6DCA712D37F1CF05B48D052B86A8453C93631009EA1106`。
- 启动前备份：实例 `backups/ASTRA_VFX_TEST-before-wuxingxiantu-20260927-223027.zip`，13278761 字节。
- 使用 axolotl-launcher 技能启动指定实例并 quick-play。MCP `get_world_info` 实时返回 `world_name=ASTRA_VFX_TEST`，后续再次查询仍为该世界；不是仅确认进程或标题界面。
- MCP-HELPER：`0.6.0-r18-photon-test18`，HTTP 200；Photon：1.1.17。通过 API 操作，没有使用鼠标键盘自动化。
- 当前游戏保留运行。已结束本轮临时 Photon 回放，运行状态 stopped、粒子数 0。

## 源码修改

参考：用户的 `download.png`，四阶段为贴剑待机、分段挥剑、命中飞散、身体余火。

| 阶段 | 改动 |
|---|---|
| 待机 | 收窄主火带；火舌改为分层阶梯像素火片；沿剑身产生少量方形余烬；赤流火 1.45 圈、橙金主体与亮色火芯 |
| 挥剑 | 使用已有 16 份真实持剑矩阵历史，改为三条有断口的分段弧线，避免整面扇形铺满；切换武器/异火、瞬移、时间跳变仍重置历史 |
| 命中 | 碎焰在命中位置脱离目标，12 tick 内向外散开、减速下落和淡出；最多 48 组，48 格外不绘制 |
| 持续 | 取消世界视图的整片叠层火墙，替换为围绕身体分布的火簇和余烬；按距离降为 12/8/5 簇，64 格裁剪，每帧最多 64 个目标 |

共享像素几何：`client/weaponflame/PixelFlameMesh.java`。主入口为 `WeaponFlameRenderer`、`WeaponFlameHitEffects`、`ExoticBurnRenderer`。没有新增原版粒子、实体或伤害逻辑；燃烧仍由既有服务端状态和同步控制，第一人称着火遮罩保持原入口。

使用既有独立渲染管线接入实际战斗。Photon 工程用于素材制作/预览，未把 Photon 变成本 mod 的强制运行依赖。

## Photon 素材回放

- 工程与资源：`reference_assets/weapon-flames-photon-r2/revision/` 内含 `project.fxproj`、`project.snbt`、`runtime.fx`、`runtime.snbt`、贴图及哈希清单。
- 素材来自项目原有四帧像素轮廓重新着色，没有调用生图服务；工具为 `tools/author_weapon_flame_preview.py`，使用已安装技能的 prepare/deploy/snapshot/capture 流程。
- 资源 ID：`wuxingxiantu_preview:segmented_flame_r2`。两个发射器均绑定自定义纹理，原生模板默认的 Minecraft 粒子纹理已被替换。
- 采集：24 帧，实际约 5.80 FPS，全部帧哈希不同。检查 contact.png 可见橙金火片生成、上浮及消散。两个原生发射器有活动粒子和渲染回调；回放结束后已停止并清空。
- 证据：`reference_assets/weapon-flames-photon-r2/capture/` 的原始 PNG、contact.png、preview.gif、report.json。
- r1 是失败的准备记录：Helper 的 speed 简写只接受整数。r2 改用原生 startSpeed 浮点配置并成功导出、回放；未改动 Helper 或技能。

## 验证边界

**本次没有构建或编译 Java，也没有运行自动测试。** 实例安装的是历史已构建 JAR，不含上一轮审计修改或本轮新的 Java 特效修改。

已验证的是 mod 安装后进入指定世界、Photon 接口和自定义素材连续回放。Photon 素材演示不是新版持剑/挥剑/命中/持续效果的整体验收；这些源码必须构建并更新实例后，再检查第一/第三人称、左右手、九种异火、目标移动和光影兼容性。
