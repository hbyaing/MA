# 玄水藻原图接入

后续用户更新参考图，已替换为 v2 三阶段和物品图标；归档位于 source-assets/dark_water_weed-20261008-v2，旧原图归档保留。新成品 wuxingxiantu-0.2-20261008-dark-water-weed-v2.jar。继续保持机制与存档字段一致。

用户透明原图左中右分别接入幼苗、生长、成熟模型，保留藻叶及原图气泡。原始裁片不重采样，透明画布紧凑 UV，保留原阶段模型尺寸。成熟裁片作为物品图标。原图、裁片、预览及坐标保存于 source-assets/dark_water_weed-20261008，可复现脚本 tools/import_flower_vine_references.py。

原水生种植、生长、掉落、配方、注册 ID 与方块状态不改；保留此前五种灵植素材。资源检查更新玄水藻预期纹理尺寸。完整构建与资源检查通过，成品 wuxingxiantu-0.2-20261008-dark-water-weed.jar 安装至指定测试目录，实机由用户确认。
