# 点燃定位修复与旧缠绕外观退役

日期：2026-09-28。项目：E:\五行仙途。Minecraft 1.20.1 / Forge 47.4.10 / Java 17 / GeckoLib 4.8.4；版本 0.2，协议 63 不变。

## 用户要求与结果

修复异火点燃随视角偏移，删除当前缠绕外观，为未来重做留出空间。已移除剑身螺旋、外围碎弧、挥剑拖尾、命中和脱落碎焰；附魔资格、伤害、独立燃烧计时、快照同步、异火配色及第一人称受燃覆盖层保留。心剑自身外观不属于删除范围。

## 点燃定位

- 旧实现位于 AFTER_PARTICLES，自行插值实体位置、扣除相机位置并使用世界事件矩阵。本轮删除这条独立定位路径。
- 新增 coremods/exotic_burn_anchor.js：只在 EntityRenderDispatcher 调用实体渲染器返回后追加 renderAtEntity，使用分发器已经定位的实体局部矩阵与同一缓冲源。没有替换原版火焰方法、着火判断、计时器或屏幕覆盖层。
- 注入按方法描述符和被调用类匹配，并要求恰好一个入口；普通生物、玩家以及绕过 LivingEntityRenderer 的自定义渲染器都可进入同一位置。局部变换以 try/finally 恢复。
- 继续使用原版 FIRE_0/FIRE_1 动画和堆叠形状，颜色来自受击快照的 sourceFireId。材质移为 ExoticBurnRenderType 与 shaders/core/exotic_burn.*，不依赖退役的武器效果。
- 未在用户原整合包中复现并锁定造成旧全局路径偏移的具体渲染器组合；本次验证的是新入口在独立客户端中的视角与实体定位稳定性。

## 旧外观退役

- WeaponFlameRenderer 仅保留物品渲染上下文桥接，继续调用 HeartSwordEffects；旧历史轨迹、螺旋和碎焰绘制已删除。
- WeaponFlameHitEffects 保留无状态的包接收方法，协议 ID 与服务端行为不变。
- 旧 PixelFlameMesh、WeaponFlameHelix、WeaponFlameModules、WeaponFlameRenderTypes、专用 shader/贴图及对应几何测试移至 source-assets/retired-weapon-flame-20260928，不再编译或打包。
- 原始贴图、提示词仍在 source-assets/weapon-flame-modules-v1；旧 layered-v2 JAR 保留回看。未来重做可沿用物品局部渲染入口和配色/锚点数据，不应恢复旧世界阶段点燃定位。

## 验证

- reports/build-20260928-burn-anchor-final.log：BUILD SUCCESSFUL，14 秒。Boss 224 项、平衡/动画边界 411 项、异火资源 7 项、燃烧架构 7 项、通用资源 11 项及其他专项通过。
- 最终客户端采集：burn-anchor-final-red（原版 Husk 渲染器）、burn-anchor-final-blue（测试专用自定义 EntityRenderer，不继承 LivingEntityRenderer）。每轮 15 帧，合计 30 帧，正常保存并退出。
- 真实攻击验证附魔火源同步、点燃颜色来源、原版着火标志保持 false。随后仅在隔离测试世界延长燃烧，完成一整圈相机旋转、上下俯仰和目标位移；燃烧到期后状态确实清除。
- 蓝色结果 customRenderer=true、livingEvents=0，且环绕期间燃烧绘制计数持续增长，确认点燃不依赖普通生物事件。自定义模型仅用于验证渲染路径，不冒充截图中的训练假人模组。
- 已查看两种颜色各 8 个方向的全景与目标裁剪图，火焰贴合目标；剑身无旧螺旋/拖尾。截图中的绿色框为离线审阅标记，不属于游戏效果。
- 精选证据：reports/exotic-burn-anchor。原始最终帧：build/weapon-flame-client/captures/burn-anchor-final-{red,blue}-*.png。较早 burn-anchor-red / burn-anchor-custom-blue 为中间验证，不作为最终截图依据。
- ZIP 完整性通过；已核对打包的定位 hook 和 shader 与源码一致、退役几何/贴图与测试夹具均不在 JAR 中、心剑类保留。记录见 artifact-verification.json。

## 产物与边界

成品：deliverables/wuxingxiantu-0.2-20260928-burn-anchor.jar

大小：36,387,335 字节。SHA256：1bb7cb0a0d54fcc63dbf1661385183a16fd391f744ba42d74eb5633e1043fc72

未替换或重启用户现有启动器实例。使用时退出实例，替换旧五行仙途 JAR 后重启；不要同时加载多个 0.2 成品。本轮未重新运行完整服务端 GameTest、全部异火/武器/光影组合或用户截图的完整整合包。当前源码以本目录为准，旧源码 ZIP 不含本轮修改。
