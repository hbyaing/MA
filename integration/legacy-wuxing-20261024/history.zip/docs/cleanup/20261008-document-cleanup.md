# 2026-10-08 过时资料清理

README 更新过期最新版指向，CURRENT_STATUS 改为当前安装、实现、约束和验证边界，保留未验收事项。

已归档三份被后续 UI 尺寸恢复与 JEI 兼容取代的审计：20261007_UI_JEI_SPACING.md、20261007_UI_COMPACT_PASSIVE_THUNDER.md、20261007_REFERENCE_BORDERS_UI.md。位置 docs/archive/20261008-document-cleanup；明确 Markdown 路径已修正。

清理前 README/CURRENT_STATUS 保存为同目录的 *.md.before-cleanup，复制回根目录即可恢复。审计移动清单见 manifest.json。

没有删除源码、纹理、原始参考、工具、报告、JAR 或安装备份，没有构建或替换实例。
