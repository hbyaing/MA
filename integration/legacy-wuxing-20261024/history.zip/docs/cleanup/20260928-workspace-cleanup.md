# 工作区清理记录

更新时间：2026-09-28。本记录只追踪本次清理；不以项目体积推测 Codex 对话 payload。恢复会话时先读 `CURRENT_STATUS.md` 和具体任务引用的单份审计，不要一次性读取全部历史报告、截图或会话输出。

## 已移出项目

以下内容完整移动到独立恢复目录 `E:\五行仙途-recovery-20260928/`，没有删除：

- `build/`：671 MiB，可由 Gradle 重新生成；其中的测试世界、完整采集截图和中间产物也一并保留。
- `deliverables/wuxingxiantu-1.0.0-r11-20260927-120439.jar`：与 `wuxingxiantu-1.0.0-r11-20260927-101800.jar` 的 SHA256 完全相同（`E59F46D2E977793D03797D5C1480EFE3DF49367FE1314077AAC2627702B06B89`），只保留一份历史副本。

最初隔离时已确认目标位于 workspace 外且不存在；项目迁移时再次确认没有 Gradle/Minecraft 进程从项目目录运行。恢复目录与项目分开放置。

恢复时执行 PowerShell：

```powershell
Move-Item -LiteralPath 'E:\五行仙途-recovery-20260928\build' -Destination 'E:\五行仙途\build'
Move-Item -LiteralPath 'E:\五行仙途-recovery-20260928\deliverables\wuxingxiantu-1.0.0-r11-20260927-120439.jar' -Destination 'E:\五行仙途\deliverables\'
```

## 保留在项目中

- 最新 JAR 与源码 ZIP，以及每个仍被文档引用的历史交付。
- `docs/` 审计、`reports/` 日志及精选截图、`reference_assets/` 与 `source-assets/` 原始材料。
- `.gradle/` 依赖缓存，缩短后续构建准备时间。

报告目录有 94 个文件，很多是逐次构建、客户端验证和截图证据。它们体积约 19 MiB，尚有历史文档引用；无需为本次空间清理改写或删除审计。以后只在某个旧产物不再被任何文档/流程需要且已归档时，才移走对应单个文件。

本次移动后，项目常驻文件约减少 703 MiB：671 MiB 的生成目录和约 31.4 MiB 的重复 JAR。`build/` 和 wrapper/依赖缓存可由后续 Gradle 工作重新生成或复用；旧测试世界仍能按上述方法恢复。
