# 心剑 2.0 模型与特效

## 导入资源

输入模型为用户提供的 `心剑2.0_优化版.bbmodel`，参考图为 `心剑2.0.png`。当前模型源保存在 `source-assets/heart_sword.bbmodel`；导入工具为 `tools/import_heart_sword_v2.py`。模型包含 30 个网格、9,646 个顶点、9,348 个原始面，渲染三角面数为 18,408。

四张内嵌 PNG 按原字节导出，依次为 `heart_sword.png`、`heart_sword_crystal.png`、`heart_sword_light.png`、`heart_sword_gem.png`，均为 256×256。OBJ 保留材质索引、UV 和细节；导出的 UV 使用 OBJ 向上的 V 轴，Forge 模型 JSON 设置 `flip_v:true`。

源握点 `(0,-2.75,0)` 映射到运行时 `(0,-0.2,0)`，模型总长归一为 1.875 格；剑尖朝 +Y，宽度沿 X，正反面沿 Z。现有第一人称缩放 `0.746666667`、第三人称缩放 `0.970666667` 与左右手角度继续使用。几何边界、材质摘要和锚点记录在 `reports/heart_sword_v2_import.json`。

物品栏使用从新模型及四材质渲染的 64×64 独立图标。`reports/heart_sword_v2_preview.png` 展示静态素材，不代表游戏内动态效果。旧模型、贴图与旧图标已归档到 `source-assets/archive/heart_sword_v1/`，两个旧版单材质工具在写入前拒绝处理新版。

## 材质与效果

`HeartSwordInventoryModel` 将世界模型包装为 `HeartSwordMaterialModel`，分为晶体透明层和自发光层。原光丝与宝石 PNG 的 alpha 分别只有 10/255 与 24/255，专用 `heart_sword_emissive` shader 放大其可见度并保留冰蓝颜色，原始 PNG 不重绘。两个材质层保留场景深度测试，只写颜色；遁虚状态继续使用专用材质并叠加透明度。

`HeartSwordVfx` 在剑体局部坐标绘制：

- 剑身三道渐变光丝，光脉由护手向剑尖流动。
- 三处剑身心核、护手中央心核和剑首心核的缓慢呼吸光。
- 两侧悬浮弧形护手的流动光纹。
- 剑尖收束光线与四枚沿剑身缓慢移动的微小晶屑。

特效全部使用自定义几何和 shader，不发射原版粒子。晶屑数量固定、不在世界粒子系统中累积。第一人称光效强度为其他视角的 82%。自发光与几何特效 shader 使用场景的 FogShape 和雾距离。

## 接入与调参

Java 根包为 `src/main/java/cn/blockforge/generated/generatedmod/`。

| 内容 | 入口 |
| --- | --- |
| 材质分层及静态面缓存 | `client/heartsword/HeartSwordMaterialModel.java` |
| 晶体、自发光材质状态 | `client/heartsword/HeartSwordMaterialRenderTypes.java` |
| 最终剑体矩阵内的特效接入 | `client/heartsword/HeartSwordEffects.java`，由 `client/weaponflame/WeaponFlameRenderer.afterItem` 调用 |
| 光丝速度、核心大小、颜色与晶屑路径 | `client/heartsword/HeartSwordVfx.java` |
| 特效材质及 shader 注册 | `client/heartsword/HeartSwordRenderTypes.java` |
| 模型边界及光核位置 | `client/heartsword/HeartSwordModelGeometry.java` |
| 召剑/散剑显形裁剪 | `client/HeartSwordClippedModel.java`、`client/HeartSwordPose.java` |

普通握持、左右手、第一/第三人称和召剑/散剑使用同一最终物品矩阵；掉落和固定展示也走同一渲染入口。GUI 使用独立图标。召剑/散剑时，材质分层保留，模型和光效按同一 Y 边界裁剪，未显形部分不绘制。原普通灵剑心铸特效继续使用已有模组资源。

## 当前状态

2026-09-27 09:09 按用户要求完成一次完整 `build`，编译、构建内置回归与资源检查通过。交付 `deliverables/wuxingxiantu-1.0.0-r11-20260927-090800.jar`，日志 `reports/build-20260927-090800.log`。本次未启动客户端或 GameTest 服务器，视觉与运行时 Shader 加载仍待确认。

以下为实现阶段记录：

2026-09-27 已完成源码与资源修改，仅执行素材导入及源码阅读。未编译、构建、运行测试或启动游戏，未生成新的 JAR。亮度、透明排序、左右手姿态、动作衔接及外部光影兼容性尚待实机确认；历史截图和构建不构成本轮验证。
