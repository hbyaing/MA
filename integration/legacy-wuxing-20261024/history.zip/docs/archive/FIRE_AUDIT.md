# 第五批异火审计

## 数据归属

Forge 1.20.1 使用 ItemStack NBT，九个原有 FireSeedItem 注册 ID 保留，装火瓶 stacksTo(1)。
空瓶 stacksTo(16)，不携带火与药力。内容以 NBT 为准；进化后 Item 注册可仍是原瓶，名字、颜色和炉中阶位按 fire_id 读取。

```text
ItemStack.tag.FireCultivation
  fire_id: "wuxingxiantu:red_flow" 等
  metal_essence / wood_essence / water_essence / fire_essence / earth_essence
  yin_essence / yang_essence / soul_essence: double
  total_essence: double
  evolution_flags: int[]
  evolution_ready: boolean
  BottleId: UUID
  last_formula / last_dimension / last_brew_tick / repeat_count
```

每项药力上限 1,000,000，非法数值读作 0。捕获新瓶八项药力均为 0，历史为空。
没有玩家药力表、同类火全局经验或 Item 单例上的培养字段。
两个相同注册的瓶子可以有不同 NBT；箱子、掉落物、玩家交易和炉库存使用标准 ItemStack 序列化保留这些字段。
玩家只在持久 NBT 保存 discovered 掩码，原 CultivationData 继续保存 learnedFires / equippedFire。
死亡复制发现记录，正常持有/交易不自动增加掌握资格。

## 获取表

| 阶位 / fire_id | 名称 | 最低炼化/使用境界 | 类型与来源 |
| --- | --- | --- | --- |
| 1 red_flow | 赤炎流火 | 练气 | 主世界熔岩附近、下界荒地/玄武岩三角洲熔岩附近自然源 |
| 2 molten_gold | 熔金淬火 | 筑基 | 赤炎瓶蕴养蜕变 |
| 3 cold_ash | 枯骨冷火 | 金丹 | 灵魂沙谷魂沙/魂土上自然源 |
| 4 azure_wood | 青木灵火 | 元婴 | 古老桦木/松木/云杉森林树木附近自然源 |
| 5 cobalt_sea | 碧海沧火 | 化神 | 深海、冷深海、冻深海、温深海海底浸水自然源 |
| 6 violet_thunder | 紫霄雷火 | 炼虚 | 主世界雷暴，山地 Y≥120、露天自然雷击处 1/16 事件生成 |
| 7 sun_saint | 大日圣火 | 合体 | 熔金瓶火/阳蕴养后正午蜕变 |
| 8 nether_void | 九幽冥火 | 大乘 | 枯骨瓶阴/神魂蕴养后魂沙谷蜕变 |
| 9 nirvana | 涅槃神火 | 地仙 | 大日或九幽瓶，末地本人屠龙进度和龙息仪式 |

自然生成的尝试稀有度依次：赤炎主世界 1/2 区块、下界 1/3，枯骨 1/16，青木 1/32，碧海 1/48；
还必须找到合法地形，不能把此概率误读为每个符合生物群系的区块必定出源。
阶位、稀有度与获得类型在 FireCatalog 分开记录。新生成仅覆盖新生成区块，旧地图没有自动补源。

雷击事件排除引雷三叉戟的玩家 cause、从磁盘重载的闪电和本模组带人工标记的雷劫/技能/调试闪电。
未创建额外玩家受击次数或遍历玩家机制。管理员 /summon 或其他模组无 cause、无标记的闪电仍可能在满足环境时触发；
如需对第三方人工雷做精确分类，需要该模组协作标记。

## 天然源与封存

ExoticFireSourceBlock 是普通 Block，绝非 FireBlock；无燃烧、蔓延、伤害或随机熄灭回调。
WATERLOGGED 保留碧海水状态。硬度 -1、极高爆抗、无掉落表、无 BlockItem、阻塞活塞、拒绝实体破坏。
创造/管理员仍能移除源，但没有正常采集掉落路径。

空瓶右键由服务端核对当前源和玩家物品操作权限，setBlock 删除为水/空气成功后生成一个新鲜瓶。
物品生成被取消则恢复源，不消耗空瓶；成功则消耗一空瓶（创造免耗）并记录发现。
源先移除，后续重复请求无法再匹配它，正常流程一次源只产一瓶。新瓶出现在操作者处并设拾取归属。
普通打火石或瓶子点出的战斗火焰不能通过空瓶复制，只有天然灵源支持捕获。

## 正式炼化

原直接学习入口是 FireSeedItem.use 和 EternalSpiritCoalBlock.use；均已移除直接 learnFire。
旧按玩家所在维度/生物群系凭空填瓶的 detectTier 完全删除。
普通生存唯一 learnFire 调用在 FireRefinement.finish；CreationPill 的调试全解锁调用保留，仍无生存配方。
CultivationDataImpl 是底层记录方法，FireSelectPacket 只选择已掌握且有资格的火，不授予资格。

普通持瓶持续使用 100 tick。开始/完成核对本人境界、数据存在、单瓶数量、当前火阶。
中途要求同一只手里仍是同一 ItemStack、同维度、距原地不超过 0.5 格、玩家存活；
至少 2 点干扰伤害、放开使用、换物品、退出或死亡会取消。取消与成功都不吞瓶。
成功记录个人掌握；蜕变后的新火仍须再次炼化，不自动装备。

永燃煤交互读取瓶内实际 fire_id 并调用 canUseFire，只允许已有掌握且达到境界者点火，不消耗瓶。
战斗仍由一份 equippedFire 提供主要加成，瓶中异火与装备火不混用。

## 炼丹原瓶结算

炉体 ignitionTier 在开始前从第 8 号槽（独立第九槽）的 FireBottleData.tier 读取内容，要求数量恰好 1。
Network.AlchemyPacket 服务端检查真实操作者、菜单、距离、结构、忙碌状态、知识、境界、炉阶、火阶/指定火、
本人掌握、材料和灵力，全部通过后才初始化旧瓶 NBT、消耗材料、扣灵力、启动任务。

PendingAlchemy 保存炉体引用、同一个瓶引用、BottleId、火阶、产物快照、FormulaId、配方权重及实际消耗材料的药性贡献。
炉体和菜单同时锁住炼制中火瓶的放入/取出，快捷移动也检查 mayPickup。
完成时再次核对炉体存在且未更换、结构成型、操作者在线存活、原瓶引用/UUID/数量/阶位仍一致。
只有真实产物 ItemEntity 成功加入世界之后，FireBottleData.reward 才直接修改槽里的原 ItemStack，随后同步和存盘标记。
产物出现在炉顶，归属操作者拾取；不再在炉体已消失时空发背包产物。

开始失败完全不改材料、灵力或瓶子；途中失败不加药力。关服/重新载入后没有存续任务的炉会清理忙碌状态。
未完成炼丹不持久化恢复；区块卸载后重新创建的炉体会使旧任务失效。已消耗材料不返还，瓶本身保留已有药力。
当前系统无自动开炉入口，也未新增自动化培养。

## 唯一药性来源与衰减

AlchemyRecipe.consume 返回本次真正消耗的 ItemStack 数量快照，FireBottleData.medicinalEssence 读取
BlockItem → SpiritPlantBlock.definition.properties。没有 FireHerbProperty 或重复的药材属性表。
金刚藤补充 METAL 药性，其余药性仍用既有定义。

每株每个命中的核心药性贡献 1 单位乘数量，再乘配方权重和重复衰减。例如赤阳草贡献火/阳，
清心莲贡献水/神魂，蓝蘑菇贡献阴/神魂。风、雷、星、龙、血等标签不额外创建数值条。
下/中/上/极品权重为 0.5/1.5/3/5，修为丹另加 CultivationTier × 0.5。
同一瓶同一维度内，距上次不超过 12000 tick（十分钟）且 FormulaId 相同，收益乘
`1 / (1 + min(9, repeat_count))`，最低为首炉的 10%，不归零。不同等级的同类丹共享 FormulaId 衰减。
切换丹方或超时重置连续衰减，但高额多药性、境界与环境条件仍限制快速蜕变。

## 主动蜕变路线

集中配置在 FireEvolution.ROUTES。主手持瓶潜行使用；必须已掌握当前瓶中火，且满足目标火的境界。
界面只显示实际非零药力和通用 ready 提示，不直接剧透所有隐藏路线。
evolution_ready 仅表示药力达标，Tooltip 明确仍需境界和仪式条件，服务器总是重新计算。

| 路线 | 消耗 | 环境/额外条件 |
| --- | --- | --- |
| 赤炎 1 → 熔金 2 | 金 600、火 300 | 筑基以上，露天，脚下岩浆块或熔岩 |
| 熔金 2 → 大日 7 | 火 2400、阳 1800 | 合体以上，主世界游戏日时刻 5000–7000，晴天、露天、亮度≥12 |
| 枯骨 3 → 九幽 8 | 阴 2400、神魂 1800 | 大乘以上，下界灵魂沙谷 |
| 大日 7 / 九幽 8 → 涅槃 9 | 火 4000、神魂 3000、阳 2000 | 地仙，末地，本人 minecraft:end/kill_dragon 完成，副手一瓶龙息 |

同一 ItemStack 的 fire_id 原地更新，不创建第二瓶异火。对应药力先扣路线成本，再对八项余额统一保留 50%，
更新 total_essence 与 evolution_flags；无回退路线或额外首次奖励。
终局消耗 1 龙息并返还玻璃瓶（创造免耗），个人击龙进度不能由他人赠送龙息替代。
玩家已有旧火掌握记录保留；没有旧火瓶则不能用旧火炼丹，要重新寻找源。
所有路线所需药性已静态验证可由进化前的合法丹方积累，不形成火阶循环依赖。

## 战斗和兼容

火阶伤害倍率由旧 1.5–10 改为 1.05/1.10/1.15/1.20/1.25/1.30/1.35/1.40/1.50。
缠绕等级乘区 1/1.04/1.08/1.12/1.20；火阶与附魔基础最高合计 1.8 倍，九阶另有原特色 0.2 倍加伤。
七阶对亡灵的触发额外伤害由 2 倍降至 0.35 倍；燃烧每层每秒改为 0.5/0.65/0.8/1/1.2，层数上限 1/2/2/3/3。
保留破甲、减速、恢复、水寒、连锁雷击、削弱等既有特色，不把已掌握的九火被动全叠加。

旧没有 NBT 的九种装火瓶按原注册 ID 解码，首次炼化/合法开炉/蜕变时初始化；不会把药力存进注册对象。
已有玩家非法高阶学习记录保留，但装备、战斗、炼丹、炼器均经 ProgressionGate 按新境界再次检查。
FireSelectPacket 验证服务端发送者、tier 范围、掌握和境界；0 仍允许卸下。
通信版本升至 49，客户端和服务端不能混用旧版。

## 验证与文件

已静态检查所有新/修改 Java 语法、资源 JSON、世界生成引用、原子封存代码顺序、唯一生存 learnFire 入口、
同瓶引用/UUID 校验、产物成功后才奖励、药性来源、全部进化材料的可达性，以及缓存 Forge API 的关键方法签名。
这不是运行时验证：未实际进行双瓶独立培养、交易/箱子/重启往返、异常取消、多人赠送、爆炸/活塞/水中源、
雷击概率或完整 Forge 构建。按用户指示保留为源码交付，不声称已生成或测试 jar。

主要文件：fire 包八类、FireSeedItem、EternalSpiritCoalBlock、ProgressionGate、AlchemyRecipe、
AlchemyFurnaceBlockEntity/Menu、Network、ModFeatures、WuXingBlocks、ModTabs、ModClientEvents、
SpiritEnchantmentLogic、HerbProperty/SpiritPlantCatalog、天然源 worldgen/biome_modifier/blockstates、语言资源。
