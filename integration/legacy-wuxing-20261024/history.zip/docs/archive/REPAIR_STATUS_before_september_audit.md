# 历史记录：2026-09-26 新审计修改之前

本文件保留历史构建、失败诊断与复测证据，不代表后续源码状态。当前状态见根目录 REPAIR_STATUS.md。

## 最新交付：2026-09-26 当前源码构建成功

用户随后授权构建及交付源码 ZIP，本节覆盖下方“未构建”的历史描述。本次 `gradlew build` 已实际执行成功（32 秒），完成主源码编译、资源处理、JAR 和 reobfJar，227 项数值/动画边界检查与 11 项资源检查通过。存在 46 条弃用 API 编译警告，没有编译错误。

本次没有运行 GameTest、没有编译 gameTest 源集，也没有启动客户端。新增 SoulAppearanceGameTests、心铸/异火 GameTest 与四动作、灵魂半透明等实机观感仍待验证；不得写为“修复已验证完成”。

版本号沿用 `1.0.0-r11`，本次 `build/libs/wuxingxiantu-1.0.0-r11.jar` 已由当前源码重新生成，不再是下方历史记录中的旧 JAR。交付文件另加日期标识，源码 ZIP 包含 src、资源、Gradle wrapper、构建配置、工具及文档，不含 build、.gradle、.codex 和游戏存档。

环境记录：前两次在 Gradle 启动阶段遇到 `Unable to establish loopback connection` / `UnixDomainSockets Invalid argument`，尚未进入编译。设置 `JAVA_TOOL_OPTIONS=-Djdk.net.unixdomain.tmpdir=C:/tmp` 后成功。详细输出见 `reports/build-20260926-final.log`；该启动参数只作用于本次进程，没有改动项目构建配置。

## 最新：四动作、丹道贴图、移魂寄魄外观（未构建）

本节优先于后面的历史构建记录。按“不直接构建”要求，本批没有执行 Gradle、Java 编译、GameTest 或客户端，也没有更新 JAR。

- 心剑四动作：动画采用独立握点坐标，第一人称补偿手掌位置；凝剑先显示掌心光，延伸剑身后显示月牙护手；散剑从剑尖回退，最后收光。心铸/解心横举实体剑，左手和心焰正反向沿剑身移动；继续仅在服务端动作完成后写入/清除心铸状态，解心不删除实体剑。
- 七本丹道书及回灵丹丹方：重做 8 张互不相同的 32×32 RGBA 像素贴图并接入模型。回灵丹通过 FormulaId 对应的客户端物品属性单独选模型，其他丹方保留原图。生成脚本为 `tools/draw_alchemy_books.py`；预览为 `reports/alchemy_texture_preview.png`。
- 移魂寄魄：附身路径没有第二次创建 SoulBody，额外身体来自仍可见的玩家模型。使用现有同步效果的 amplifier 区分游离灵魂（0）与附身（1），转换保留剩余时间、不叠加隐藏效果。游离时绘制透明度 0.35 的皮肤投影与第一人称手臂；附身隐藏玩家投影；留守身体仍为发动时的同一实体。收束清除效果和留守身体，不改原版隐身状态。
- 实际执行通过：资源检查 11/11、心剑素材检查 3/3、异火架构检查 6/6，以及 `check_alchemy_art.py` 的 8 张贴图尺寸/透明通道/独立图案/模型引用/丹方分流检查。已检查贴图预览，并通过 javap 只读核对所用 Forge 接口。这些是静态/资源检查，不是运行验证。
- 新增 required GameTest：`SoulAppearanceGameTests.oneBodyAcrossPossessReleaseAndReattach`，覆盖发动、附身、重复附身拒绝、解除、再次附身、收束、身体数量与身份、效果阶段、持续时间。另补 2 条动画时序回归断言。均未编译、未运行，不标记 PASS。
- 需要实机验证：四动作第一/第三人称的手剑对齐、宽臂/细臂皮肤、各实体灵剑、左右手习惯和不同 FOV；移魂寄魄的多人可见性、宿主视角、透明度、退出/重连清理；丹方在背包/JEI 中的实际模型选择。本批不能表述为“修复已验证完成”。

## 最新：异火独立系统源码更新（未构建、未运行验收）

已按《异火独立.txt》迁移独立状态、计时伤害、同步、第三人称绘制和第一人称遮罩；删除 `exotic_burn.js`、`ignition_source.js` 和旧 `ExoticBurnSourceSync`。新增客户端 `/wuxingxiantu debug exoticburn`。没有重画异火，40 个贴图/动画元数据文件与 r11 已构建资源 SHA256 逐一一致。

实际执行通过：资源检查 11 项、心剑素材检查 3 项、异火架构检查 6 项。后者仅证明源码结构约束，不能证明游戏运行正常。新增 `ExoticBurnGameTests` 17 项 required 测试，更新可选客户端烟雾测试，并补上 `-PexoticBurnTests runClient` 入口；均未编译/未运行。

网络协议从 57 改为 58，新旧客户端不能混用。版本号及现有 r11 JAR 未更新；当前 JAR 不含心铸和异火新源码。异火端到端运行、普通火兼容、跨维度/重连/多人追踪以及画面均需后续验收，本批不能标记为“功能已验证完成”。详见 `EXOTIC_BURN_IMPLEMENTATION.md`。

## 同批前序：心铸机制与心剑视觉源码更新（未构建）

本节优先于下方所有历史结果。按用户“不直接构建”要求，本轮没有执行 Gradle、Java 编译、GameTest 或客户端，也没有生成或替换 JAR。`build/libs/wuxingxiantu-1.0.0-r11.jar` 不包含本轮修改，旧 49/49 GameTest 和 225 项检查不能作为当前源码已验证的证据。

- 已修改源码：统一心剑/心铸成长与 Traits、单次主攻击真实伤害、原剑/心剑投影取高、动态提示和内视攻击数值；创造丹修复道心通明；右侧三格同列等距。
- 已修改视觉资源：心剑晶质贴图、第一人称倾角与握点补偿；Blockbench 内嵌贴图已同步，第三人称 display 参数未变。
- 本轮实际执行：`tools/check_resources.py` 11/11 PASS；`tools/check_heart_sword_assets.py` 3/3 PASS；两份改动 coremod 的 `node --check` 通过。读取现有 Forge 字节码与 SRG 映射核对接口和挂钩位置，未编译项目。
- 新增 21 个 `HeartSwordCombatGameTests` required 测试，以及 `RecheckGameTests.heartTruePhaseTwoKillCompletesChallenge`。这 22 个测试均为“已编写，未运行”，不是 PASS；原有测试也未在当前源码重新运行。
- 尚需运行验证：Forge coremod 加载、伤害全链路、心魔阶段/结算、创造丹、装备槽实际操作。第一/第三人称及四动作观感、不同 GUI 比例需要实机验证。

详细公式、文件入口、边界和测试清单见 `HEART_FORGING_IMPLEMENTATION.md`。本轮不能表述为“修复已验证完成”。

## r11 实机反馈修正（历史构建，23:10）

成品 `build/libs/wuxingxiantu-1.0.0-r11.jar`。本轮 `build runGameTestServer` 成功，49/49 required GameTest PASS，225 项预发布检查及 11 项资源检查通过。最终日志 `build/audit/interaction-r11.log`：第 31、52、148、170 行。SHA256：`CD7CFA21F89033172FE14888D71D2AE4C102ECA1363FCB6C234C2D1B7726E0DE`。

| 用户反馈 | 修改与实际验证 |
| --- | --- |
| 连续下蹲右键打坐卡入下方，不改坐姿位置 | 下蹲交互只退出、不重新入座；下座立即清除打坐状态、重置速度并向客户端同步站立落点。保留原坐姿 `seatY - 0.5` 和三种坐面高度。`repeatedSneakUseKeepsMeditationSurface` 对蒲团、灵蒲团、打坐台各连续操作 20 次，检查原坐姿高度、下座不碰撞及无残留状态，PASS。真实客户端快速连按仍需确认。 |
| `/kill` 显示已杀死但玩家不死 | 读取运行实例的整合包，发现 `nine-words-seven-stars-1.0.0-r82` 的 `ModEvents.onLivingAttack` 九星免伤直接取消攻击，`onLivingDamage` 启动保命，未排除 generic_kill；`wuxingchuangshi` 世界免伤也有无此排除的取消路径。这是实际存在的兼容拦截，未读取玩家技能状态，不能声称已确认当时是哪一个效果触发。新增 `ForcedPlayerDeath` 在 LOWEST、receiveCanceled 下仅恢复原版 `GENERIC_KILL` 强制死亡语义，不取消普通伤害的保护。模拟外部攻击取消、伤害归零、死亡取消并回满血的测试 PASS，普通保护仍生效。满境界满血、创造丹祝福、吸收护盾执行裸 `kill` 后 40 tick 持续死亡测试 PASS。完整整合包尚未用新 JAR 实机复测。 |
| 神通按钮误开 JEI | 原版 InventoryScreen 的 JEI 合成点击区域继承到了自定义界面，面板原点又被错误报告为背包原点。改回真实背包原点，保持外框右/下边界；自定义页和导航在高优先级处理点击，隐藏页不显示继承的 JEI 配方提示。编译通过，JEI 实机点击及提示需要验证。 |
| 心剑四个动作位置错误 | 四个动作共用正常模型手持变换：第三人称补齐 Y 轴 180 度和原版右手握点偏移，取消 NONE 上的二次手动偏移/旋转；第一、第三人称使用各自模型 display 变换；特效复用相同模型坐标。召出、收回、心铸、解除心铸均走修正后的共用路径。编译通过；两种视角的最终画面需要实机验证，未宣称视觉 PASS。 |

额外修复：延长死亡观察曾在 `interaction-baseline.log` 复现 `ServerTickEvents -> Network.sendTribulationState -> MindscapeManager.hasBoundDemon` 读取已失效能力导致 NPE。在线列表中的死亡/已移除玩家不再运行正常修炼及状态同步，hasBoundDemon 对无效玩家返回 false。该异常与上述整合包免伤是两条不同路径。

中间运行 `interaction-fixes.log` 的 48 项中，新增两项通过，但旧 `importedIslandPreservesMerchants` 因反复使用的测试世界已被岛屿占满而失败，未忽略它。保留旧测试世界为 `build/gametest-run/world-before-interaction-fix`，在新建测试世界中全套 49 项通过（`interaction-final.log`）；扩展三种打坐方块并完成 r11 最终改动后再次 49/49 PASS（`interaction-r11.log`）。版本检查线程仍有已知 loopback 警告，不影响 required 测试成功退出。

没有修改或替换用户正在运行的游戏实例。安装时用 r11 替换 r10 并重启，不能同时加载两个五行仙途 JAR。以下保留 r10 的历史审计与原 7 项失败诊断，历史数量不代表 r11 最新结果。

## r10 历史验证

**2026-09-25 22:16（Asia/Shanghai）最新实测：build 成功；225 项预发布检查、11 项资源检查通过；46 项 required GameTest 连续两轮全部 PASS，0 项失败，未使用 optional/non-blocking 掩盖失败。** 其中 `RecheckGameTests` 为原 11 项回归加 1 项夹具生命周期检查。仅下文实际覆盖的服务端断言标为已验证，不代表所有实机问题已验证完成。`build/libs/wuxingxiantu-1.0.0-r10.jar` 已在本轮重新构建；旧 Downloads 源码压缩包没有同步更新。

输入文档保存在 `docs/audits/recheck-20260925/`。文档是问题线索，实施时以当前源码和用户答复为准。

## 已实施的 Bug 修复

| 项目 | 当前处理 |
| --- | --- |
| 默认免死护盾 | 删除“所有玩家自动花 20% 灵力剩 1 血”的逻辑。保留主动吸收效果和其他正常减伤；旧 shieldCooldown 存档字段保留兼容，但不再触发救命。 |
| 强制死亡 | CombatEvents 普通免疫/时停/减伤处理跳过 BYPASSES_INVULNERABILITY；心魔强制死亡跳过阶段转换及转阶段无敌；心境隔离规则允许强制伤害。真实 ServerPlayer 执行 `kill @s` 的 GameTest 已 PASS；真人客户端复活流程不在此测试范围内。 |
| 心魔和管理员结算 | 保留普通一阶段致死转二阶段；新增 OP2 `/wuxingxiantu mindscape force_complete [player]`，使用有效 session、Boss 绑定检查与原有幂等恢复流程。仅移除 Boss 不授予胜利，既有周期校验中止失效 session。 |
| 第 9、10 场 | **用户选择正常连续挑战**。普通入侵会为所有十场建立 pending，删除只允许前八场的限制和错误注释。保留显式指定挑战接口。 |
| 修为清零 | **用户选择保留突破归零**。渡劫、小突破丹、标准突破丹成功时提示“本阶段修为重新积累，进入心境不会清空修为”。没有更改心境进出中的修为。 |
| 心魔入侵 HUD | 状态及相关丹药文案统一为心魔入侵；入侵/入境打坐 HUD 改猩红。兼容字段/方法 ID 保留，旧中文状态注释同步更新。 |
| 遁虚废弃标签 | 删除 DUNXU_PASSABLE 常量和 dunxu_passable.json，消除旧 #minecraft:concrete 引用。黑名单穿墙规则不变。 |
| 闪步 | 新增 FlashStep：逐段扫过玩家碰撞箱，只访问已加载区块，检查边界、高度、液体、地面和常见危险方块；停在最远连续安全落点；没有可移动安全点时不收费、不触发冷却。保守地不跨越无支撑空隙。 |
| 灵力消耗展示 | 四个功法/剑技 UI 共用 manaCostDescription；显示固定、百分比、最终值。SwordNurture 的资格/实际扣费也使用 finalManaCost，避免只改 UI。御剑说明删除“无持续消耗”。 |

## 已实施的有限性能优化

- 异火后台清理/永燃维护由 2 tick 调整到 5 tick；移除对返回空集合的 inheritNearbyFires 的无效调用。实际扩散已由 ExoticFireBlock 原生 tick 继承，不将其误写为新实现。
- 异火快照按玩家、维度和内容比较，内容不变不发重复包；新玩家/维度变化仍同步。
- 心境背包以变化计数、选择槽和装备变化驱动检查，保留 10 tick 完整兜底。拾取、丢弃、使用/攻击阻断保持即时，异常容器仍每 tick 关闭。外部 Mod 绕过变化标记的直接 NBT 写入最多延迟 10 tick 校验。
- 渡劫状态使用 Trial/session 中绑定的 Boss UUID，去掉每玩家每秒范围查实体。
- 正式心魔 BossBar 直接绑定 owner；测试 Boss 的距离成员检查为 10 tick，血量更新不降频。
- 心剑每 5 tick 单次扫描同时验证心剑和心铸所有权；当帧维护直接使用结果，未引入跨 tick 物品引用缓存。
- 装备周期同步只在内容或锁定状态变化时发送；登录、重生、切维度、开始追踪仍显式同步。
- 魂仆已有 32 个活动上限和错峰寻敌；保持这些约束，跟随导航每 5 tick 错峰，治疗每 20 tick 错峰，粒子每 5 tick 错峰。未加入未经测量的空间索引。
- MAX_HEALTH 扩展记录最终共享上限；异常数值报错。
- 加入关闭为默认的 SyncPacket 大小诊断（`-Dwuxingxiantu.profileSync=true`）。每分钟记录包数、序列化字节均值/最大值和包频率，**不是实际线路压缩后流量**。未测量前不拆复杂 delta 协议。

## 原 7 项失败的完整名称与诊断

原始证据为 `build/audit/recheck-gametest.log`。以下行号对应当时源码，不能拿来定位当前已修改文件。GameTest 断言类型是 `GameTestAssertException`，不是 Java `AssertionError`。原日志没有为三个伤害断言输出完整堆栈，以下明确标注为源码断言位置，不补造历史堆栈。

1. `cn.blockforge.generated.generatedmod.RecheckGameTests.removedBossDoesNotLeaveBrokenSession`
   - 断言：`Cannot enter challenge`；底层异常：`IllegalStateException: Boss spawn rejected`。
   - 堆栈核心：`RecheckGameTests.java:96 -> MindscapeManager.enter(MindscapeManager.java:148)`，原日志第 84-105 行。
   - 分类：夹具注册失败。旧玩家只加入 Level，没有进入 PlayerList 的 UUID 索引；正式 orphan 检查找不到 owner，合法拒绝 Boss。修正后此测试 PASS。
2. `cn.blockforge.generated.generatedmod.RecheckGameTests.phaseTwoPlayerKillCompletesChallenge`
   - 断言：`Cannot enter heart demon challenge`；底层同为 `Boss spawn rejected`。
   - 堆栈核心：`RecheckGameTests.java:78 -> MindscapeManager.enter(MindscapeManager.java:148)`，原日志第 106-127 行。
   - 分类：夹具注册失败，依据同第 1 项。此前没有执行到两个阶段的断言；新夹具中两个阶段及击杀结算均 PASS。
3. `cn.blockforge.generated.generatedmod.RecheckGameTests.forcedKillBypassesManaAndAbsorption`
   - 断言：`Forced kill must not leave one health`；源码断言位置 `RecheckGameTests.java:41`，原日志第 129 行，无完整断言堆栈。
   - 分类：夹具类型错误。Forge FakePlayer 明确将 `die(DamageSource)` 实现为空，并将 `isInvulnerableTo` 固定返回 true；不是已证实的随机生命周期不稳定。换真实 ServerPlayer 后实际 `kill @s` 命令与死亡断言 PASS。
4. `cn.blockforge.generated.generatedmod.RecheckGameTests.activeAbsorptionStillProtectsOrdinaryDamage`
   - 断言：`Explicit absorption shield stopped working`；源码断言位置 `RecheckGameTests.java:50`，原日志第 130 行，无完整断言堆栈。
   - 分类：夹具类型错误。FakePlayer 的固定无敌使普通伤害无法进入吸收结算。真实玩家保持 10 血且吸收值减少的原严格断言 PASS。
5. `cn.blockforge.generated.generatedmod.RecheckGameTests.directMindscapeEnterAndAdminCompletionPreserveCultivation`
   - 断言：`Could not enter test challenge`；底层 `Boss spawn rejected`。
   - 堆栈核心：`RecheckGameTests.java:111 -> MindscapeManager.enter(MindscapeManager.java:148)`，原日志第 131-152 行。
   - 分类：夹具注册失败，依据同第 1 项。新版执行 OP2 的实际 `wuxingxiantu mindscape force_complete @s` 命令；进入前后及完成后 cultivation=123456、解除封存和不重复结算均 PASS。
6. `cn.blockforge.generated.generatedmod.RecheckGameTests.directMindscapeForceRestorePreservesCultivation`
   - 断言：`Could not enter test challenge`；底层 `Boss spawn rejected`。
   - 堆栈核心：`RecheckGameTests.java:122 -> MindscapeManager.enter(MindscapeManager.java:148)`，原日志第 153-174 行。
   - 分类：夹具注册失败，依据同第 1 项。新版进入后调用 forceRestore，恢复且 cultivation 保持的断言 PASS。
7. `cn.blockforge.generated.generatedmod.RecheckGameTests.ordinaryLethalDamageWithoutShieldDies`
   - 断言：`Mana alone must not grant a death-prevention passive`；源码断言位置 `RecheckGameTests.java:31`，原日志第 177 行，无完整断言堆栈。
   - 分类：夹具类型错误。FakePlayer 固定无敌，无法用于普通死亡回归。真实玩家满灵力、无主动护盾接受普通致死伤害后的死亡断言 PASS。

因此用户重点问题中，`/kill`、心魔二阶段死亡、管理员完成和 cultivation 保持的集成测试都属于原 7 项失败。独立的一阶段转换测试不在原 7 项中，但集成的 `phaseTwoPlayerKillCompletesChallenge` 当时未执行到阶段转换；本轮两种路径都已 PASS。

## Forge 1.20.1 玩家夹具

代码：`src/gametest/java/cn/blockforge/generated/generatedmod/fixtures/GameTestPlayer.java`，仅属于 gameTest 源集，不进入发布 jar。

- 使用真实 ServerPlayer、生存模式和独立 UUID。只替换网络发送为无客户端接收端，不覆写 hurt、die、isAlive 或伤害免疫；清除登录保护时间，使测试从可受伤状态开始。
- 同时注册 PlayerList 的玩家列表、UUID 索引和 ServerLevel。Forge 的 getPlayers() 返回只读视图，所以版本专属反射访问真实列表；映射变化立即报错，不静默回退。
- 在世界 tick 中补上通常由网络监听器调用的 doTick，真实触发玩家事件。新增 `playerFixtureTicksAndUnregisters` 验证 tick 进展、三个查询入口一致及幂等注销。
- 注册 GameTest 成功/失败监听器，覆盖超时清理并打印失败堆栈；close 注销玩家、移除实体、释放本夹具持有的区块票据。测试回调清理心境会话及临时实例租约。
- 心境测试先预留候选槽位，等待竞技场区块达到实体 ticking 且实体存储加载完成，再调用正式 enter；随后等待 Boss 真正可查询。Boss 通过正式绑定检查后直接加入 Level，没有自然生成条件，也没有修改正式 orphan 限制。
- 二阶段测试等待真实 Boss tick 达到转阶段保护期，再施加普通致死伤害；没有手动清零无敌时间。移除旧测试 tag 绕过及玩家查找回退，恢复正式玩家、session、Boss 绑定检查。

调试中间结果保留在 `build/audit/stable-player-1.log` 至 `stable-player-8.log`：只读玩家列表曾导致 UnsupportedOperationException；注册修正后出现异步区块实体不可见、Boss 不 tick、每 20 tick 会话检查先于区块就绪而中止挑战的问题。`stable-player-7.log` 明确记录等待时玩家已回主世界、快照已恢复。预加载夹具解决了这些测试前置条件，不能由此断言正式玩法中首次进入未加载竞技场的时序也已经验证。

## 最新执行证据与边界

| 执行 | 实际结果 | 证据 |
| --- | --- | --- |
| 最终夹具第一次 GameTest | 46/46 required PASS，0 失败 | `build/audit/stable-player-8.log:88` |
| 重复运行 build + runGameTestServer | BUILD SUCCESSFUL，46/46 required PASS，0 失败 | `build/audit/stable-player-final.log:128`、`:150` |
| 预发布检查 | 225 项 PASS | `build/audit/stable-player-final.log:17` |
| 资源检查 | 11 项，OK | `build/audit/stable-player-final.log:38`、`:40` |

运行环境：Java 17.0.20.1、Gradle 8.8、Forge 47.4.10 / Minecraft 1.20.1。最终执行任务为 `build runGameTestServer --offline --no-daemon -Dorg.gradle.jvmargs=`，通过 `-PpythonExecutable=...` 指向可用 Python。Forge 版本检查线程仍记录本机 loopback 连接异常；它不属于 GameTest 用例，以上结论基于完整 required 测试汇总和成功退出，不把日志说成完全无警告。

已验证范围限于上述服务端断言，包括原 7 项、独立心魔一阶段及强杀、第 9/10 场连续 pending、闪步墙体安全和夹具生命周期。所有 Recheck 注解均为默认 required=true。

**需要实机验证**：首次进入未加载竞技场的正式流程、真人连接及传送确认/复活、客户端 HUD/贴图/打坐位置、JEI、多玩家与外部战斗 Mod 兼容。预加载的无客户端 GameTest 不代替这些验证。大型重构、完整网络差量同步、空间索引及深度性能优化仍未实施，按 `docs/PROFILING.md` 先采集负载数据。
