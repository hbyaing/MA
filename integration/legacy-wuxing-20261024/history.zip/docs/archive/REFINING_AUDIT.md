# 第十批炼器审计

当前平台 Forge 1.20.1 / 47.4.10、Java 17。本批没有构建和实机验证。

`RefiningForgeScreen` 删除 drawTemperatureArea、drawPointer、温度条/渐变/标尺/数字和全部相关布局状态。面板高度从 336 收至 282，开始/领取操作区上移，改为实际异火名与当前/所需火阶。此屏幕原本没有玩家调温按钮或调温数据包，未新增隐藏控件。

`RefiningRecipe.temperature` 只保留 legacy/internal fire-tier proxy，JSON 和网络序列化不改。`requiredFireTier()` 将代理值换算为最低火阶，至少为 1；客户端与 `Network.RefiningPacket` 一致使用该值。实际火阶仍由 `RefiningForgeBlock.fireTier` 检查核心上方真实永燃灵煤块及其上真实异火。炼器境界门槛继续使用原有代理值计算，不改配方或境界平衡。

温度语言键删除；失败提示改为火阶不足。现有材料、消耗、炼制时间、领取流程与火焰特效保留。玩家拆除煤/火的炼制中处理沿用既有任务流程，没有以虚拟温度代替现场火源。

待实机：无煤、无火、低火阶、正确火阶；材料不足；开始/进行中/领取；小窗口排版及与服务端状态同步。
