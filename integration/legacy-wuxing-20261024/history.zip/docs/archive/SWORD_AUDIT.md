# 第七批：灵剑、剑诀、御剑与测试蛋审计

当前已追加第十批 V2 和修复批 B。持续御剑改为独立 `yujian_stack`，不再持续依赖主手；养剑界面也可访问该槽。本文是第七批历史审计，当前规则与未执行的实机检查见 `BATCH_B_REPAIR_REPORT.md`。

平台：Minecraft 1.20.1 / Forge 47.4.0 / Java 17。基于第六批源码继续修改，网络版本 51。

用户直接要求“不直接构建”继续有效。本批未运行 Gradle、Java 编译、Minecraft、mc_build，也没有生成 Jar。下文“通过”均指源码、资源和 API 元数据静态检查，不代表游戏实测。附件中的构建要求不覆盖此限制。

## 正式灵剑清单

实际注册共 **8 把**，均通过 `WuXingItems.sword()` 创建 `SpiritSwordItem`；`PeachSwordItem` 仅是兼容旧类名，当前没有独立重复注册。命名空间均为 `wuxingxiantu:`，中文名取当前 zh_cn。

| ID | 中文名 | 可御剑 | 飞行定义 | 基础/冲刺速度 | maxSpirit | spiritCost | 穿透参数 | 剑蕴上限/配置槽 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `peach_sword` | 桃木剑 | 否 | 不需要 | 无 | 128 | 5 | 2 | 2/1 |
| `dark_iron_sword` | 玄铁剑 | 是 | 专属显式定义 | 0.58/1.10 | 256 | 8 | 3 | 4/2 |
| `azure_steel_sword` | 明玦剑 | 是 | 导入模型显式定义 | 0.58/1.08 | 512 | 12 | 3 | 5/3 |
| `tiangang_sword` | 青冥剑 | 是 | 导入模型显式定义 | 0.58/1.08 | 1024 | 18 | 4 | 6/4 |
| `big_dipper_sword` | 玄霄剑 | 是 | 导入模型显式定义 | 0.58/1.08 | 2048 | 25 | 4 | 7/4 |
| `demon_slayer_sword` | 无相剑 | 是 | 显式继承原默认参数 | 0.58/1.08 | 4096 | 35 | 5 | 8/5 |
| `pure_yang_sword` | 归元剑 | 是 | 显式继承原默认参数 | 0.58/1.08 | 8192 | 50 | 6 | 9/6 |
| `xuanyuan_sword` | 天阙剑 | 是 | 显式继承原默认参数 | 0.58/1.08 | 16384 | 80 | 99 | 10/6 |

速度单位为现有控制器参数，实际移动仍受服务器倍率、冲刺、翻滚及碰撞影响。未重新设计速度曲线。新剑缺少 swordSpirit 时初始化为 maxSpirit；旧剑读取各自当前数值，不能用本表推断旧存档余量。

近战基础伤害依次为 6、7、8、9、10、11、12、14。保留养剑经验、洞察、剑蕴、五类剑诀、附魔和剑灵力条。`techniquePierceCount` 及 `attackDamage(亡灵目标)` 在当前源码中是保留参数/方法，没有在控制器中找到对应调用；不把 tooltip 中的穿透与亡灵增伤当作本批已验证的新能力。

桃木剑沿用 `recipes/peach_sword.json` 工作台配方。其余七剑各有原有同名配方与 `refining_<剑ID>.json` 炼器配方；本批逐字节保留。炼器仍依赖多方块、永燃灵煤及真实异火，设施可共用。`temperature` 继续作为火阶/火候代理值，不改异火瓶槽，不迁移配方，不记录炼制者或炼制火绑定。

## 飞行资格与资源

`SwordProfile.flightCapability` 与 `FlyingSwordRegistry` 必须同时允许。桃木剑和未知品阶 profile 为 false。`get()` 查不到定义返回 null，`visual()` 才提供 DEFAULT_VISUAL。普通 SwordItem 即使在其他模组中注册也不能仅靠类型进入系统。创造模式不能绕过剑种和定义检查。

召剑只认主手合法飞剑，还须学会 `art_sword_flight`、满足现有 ProgressionGate、状态、灵力及冷却要求。功法入口、旧切换包及按键召剑统一进入原控制器，成功生成飞剑后扣 8 点玩家 Aura；基础冷却沿用 Art 的 160 tick，熟练度达到 60 时为 144 tick。收剑不收费。此前存在按键免费、功法入口先扣费且未正确召剑的不一致，现已收口。

当前基础御剑没有持续资源扣减，原“每秒 2 点灵力”的说明已纠正。本批没有新建持续消耗体系。`swordSpirit / maxSpirit / spiritCost` 全部保留；现有灵汲附魔先补剑灵力，溢出补玩家 Aura。本控制器当前不扣 swordSpirit，spiritCost 作为原剑体成本参数保留，不再错误标作本剑的御剑启动收费。

原召剑、轨道、骑乘、飞行、下剑状态机及速度、冲刺、roll/bank、碰撞公式保留。主手换成桃木剑、普通剑、未登记灵剑、非剑物品或另一把剑时，按原 stop 清理状态与飞剑实体，不删除物品。原死亡、退出、换维度、重连、停服清理路径保留。TP 的游戏回归仍待执行。本批没有实现高级御剑阶段。

## 取消耐久与旧数据

移除注册时的 `durability(700)`。因为 SwordItem 的 TieredItem 父类仍可能提供品阶耐久，额外覆盖 Forge 的逐栈 `getMaxDamage=0`、`isDamageable=false`、`setDamage`，并覆盖 `mineBlock`，不只修改注册属性。

普通攻击不再调用 `super.hurtEnemy`；御剑冲撞、剑诀命中和护剑格挡三个 `hurtAndBreak` 入口已移除。泛用附魔对物品的伤害也受到逐栈不可损坏钩子保护。其他工具、墨锭、打火石的耐久不变。

首次物品处理、界面操作或施法时，直接从原 ItemStack 的 tag 移除旧 Damage，不重建 Stack。名字、附魔、剑灵力、剑蕴、SwordUuid、原飞剑关联 UUID 及其他 NBT 保留。已有 SwordUuid/飞剑关联仅识别具体物品，并非所有者或绑定锁。

## 玩家知识与每剑配置

玩家 capability 在 `known_sword_techniques` 字符串列表保存战斗剑诀。服务器读写，随 capability 序列化、Clone 复制、重连加载，重生及同步包发送给客户端。秘籍与原洞察学习入口均授予玩家知识。已经学会时不重复消耗秘籍或洞察。

剑在 `WuxingSwordNurture.equipped_sword_techniques` 保存配置。旧 `EquippedTechniques` 懒读取并写入新键；写回从旧 compound 的副本开始，保留无关嵌套字段和原配置顺序。迁移不按新知识清空借用剑配置。

一次性迁移流程：登录处理随身物品、物品首次 inventoryTick 或剑页/施法入口，读取未标记旧剑的 `UnlockedTechniques`，仅合入注册的五种战斗剑诀，随后清除旧知识字段并写 `SwordKnowledgeMigrated=true`。已迁移剑交给第二人不再传授。旧玩家 `LearnedArts` 中的战斗剑诀在读取时进入知识集合；`SwordLegacyTechniques` 待迁移数据在登录时回收，即使玩家暂时没有剑。不会扫描箱子或世界区块。

`art_sword_flight` 不在战斗剑诀注册表中，仍留在 LearnedArts。若更早版本已从存档完全删掉该功法且没有备份，本批不能从无记录状态推断并恢复；再次使用现有秘籍可重新学习。

实际施法统一检查：本人知识、当前具体剑的配置、可用槽位、剑种品阶与剑蕴、本人境界、存活/神通状态、Aura、该玩家该剑诀的冷却。全部通过并生成实体后才扣灵力和设置冷却；移除失败后直接调用控制器的备用路径。借用者本人也已学会且满足条件时可以直接施展，无需重新配置、认主或亲自炼制。

| 剑诀 ID | Aura/次 | 基础冷却 | 最低剑阶/剑蕴 | 洞察学习成本 |
| --- | --- | --- | --- | --- |
| `art_sword_pierce` | 12 | 100 tick | 0/0 | 1 |
| `art_sword_sweep` | 18 | 160 tick | 1/0 | 1 |
| `art_sword_guard` | 20 | 160 tick | 1/1 | 2 |
| `art_sword_array` | 48 | 400 tick | 2/2 | 3 |
| `art_myriad_swords` | 48 | 400 tick | 5/4 | 5 |

沿用原 Art 实际收费和熟练度冷却，避免 UI 使用另一组旧小数值；达到 60 熟练度冷却为基础值的 90%。扣费不再先后发生两次余额判定。万剑诀原先缺少实体执行分支，本批接入既有区域落剑分支，并使用其原有影剑数量上限，没有新造第二套剑阵系统。

灵剑页读取同步的玩家知识，保留已装备但本人未学的显示，并有施展入口；释放轮盘新增剑诀标签，读取主手具体剑的配置。实际操作以服务器复核为准。

## 10 个 Boss 创造测试蛋

所有下列蛋仅供开发及创造测试，同时属于代码 `CREATIVE_TEST` 集合和 `#wuxingxiantu:creative_test` tag。没有生存配方、交易、Loot 或自然获取链。当前没有独立测试 Tab，十蛋按下表顺序集中放在既有创造页末尾。正式心境 Boss 来源仍待后续心境流程/结构/主线实现。

| 物品 ID | 实体 ID | 分类 |
| --- | --- | --- |
| `wuxingxiantu:muyan_spawn_egg` | `wuxingxiantu:muyan` | 六贼 |
| `wuxingxiantu:ermei_spawn_egg` | `wuxingxiantu:ermei` | 六贼 |
| `wuxingxiantu:bichen_spawn_egg` | `wuxingxiantu:bichen` | 六贼 |
| `wuxingxiantu:shetao_spawn_egg` | `wuxingxiantu:shetao` | 六贼 |
| `wuxingxiantu:shenyin_spawn_egg` | `wuxingxiantu:shenyin` | 六贼 |
| `wuxingxiantu:yihuo_spawn_egg` | `wuxingxiantu:yihuo` | 六贼 |
| `wuxingxiantu:pengju_spawn_egg` | `wuxingxiantu:pengju` | 三尸独立实体 |
| `wuxingxiantu:pengzhi_spawn_egg` | `wuxingxiantu:pengzhi` | 三尸独立实体 |
| `wuxingxiantu:pengjiao_spawn_egg` | `wuxingxiantu:pengjiao` | 三尸独立实体 |
| `wuxingxiantu:heart_demon_spawn_egg` | `wuxingxiantu:heart_demon` | 心魔，复用旧蛋 |

九个新蛋使用 ForgeSpawnEggItem 及延迟 supplier 分别指向实际实体；心魔保留旧注册与外观绑定逻辑，默认 PHASE_1，不注册第二阶段蛋。原开发 phase 命令继续切换第二阶段。中英文名均走 lang，颜色取各模型主色近似，模型复用原版 template_spawn_egg，无新增贴图。第六批 10 个 Boss、11 种血条资源与动画保持。

## 检查与未实测项目

本批完成 72 项静态检查：旧问题/第三批 26 项、第四五批 16 项、第六批 Boss 15 项、第七批 15 项。全部通过，覆盖 25 个本批变化 Java 文件的解析和 1002 个资源 JSON 解析。使用本机 Forge 1.20.1 映射 JAR 的类元数据核对逐栈耐久、采掘与 NBT copy 签名，未执行编译。

对第六批源码包逐字节比较确认：炼丹、异火、炼器配方、世界生成、Boss 模型/动画/血条保持；控制器移动、召剑轨道、上剑、下剑、方向计算及 roll 配置公式保持。静态检查验证失败返回位于扣费前、迁移标记与复制写回、蛋与实体一一对应、普通剑/桃木/未登记剑拒飞条件。

游戏内验收仍待执行：

1. A-D：学习御剑后用桃木、铁剑、合法飞剑及未登记 SpiritSword 分别尝试；前三种拒绝/成功结果应符合资格表。
2. E-G：多次攻击、采掘、剑诀、格挡与御剑碰撞；旧 Damage>0 且带名字/附魔/剑蕴/自定义 NBT 的剑不损坏、不丢数据。
3. H-J：学习后换剑、两玩家借剑、首次旧剑迁移、再次转交、死亡重生及重连，知识归属与配置各自保持。
4. 扣费边界：余额恰好等于费用可成功一次；少于费用、冷却中、低境界、未学或不兼容配置均无扣费/新冷却；御剑各入口收费一致，收剑免费。
5. K-M：十蛋逐个召唤，核对六贼、三尸各自模型/动画/血条，心魔默认第一阶段，开发命令切第二阶段。未宣称实际召唤已测。
6. N：生存配方、交易、Loot 与自然来源不包含十蛋；创造页顺序、语言与颜色仍需游戏展示确认。
7. 飞行中换桃木、普通剑、非剑、另一飞剑，以及死亡、断线、换维度、TP 的安全退出；GUI 不同缩放、多人同步和专用服务器启动。

README、AI_SOURCE_MAP、BOSS_AUDIT 已更新。mc_check 专用工具当前不可用，以上为本地离线等价静态检查。完整 Forge 构建未执行，最终 Jar 名称：无。交付源码包及检查证据，原始附件与此前源码包保持不变。
