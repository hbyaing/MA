# 第六批 Boss 视觉接入审计（第七批补测试蛋）

## 第十批 V2 当前修复（未构建、未实机）

- 同一 HeartDemonEntity、UUID 与 ServerBossEvent：在 actuallyHurt 内 setHealth 看到最终致死血量时转阶段，早于 super.hurt 的 die / Forge LivingDeathEvent；die 只作为直接死亡调用的兜底。
- transitionToPhase2 清导航、目标、运行 Goal、翻滚/动画预览、效果、装备及镜像属性；沿用原基线定义阶段二 200 HP / 30 攻击 / 0.25 移速 / 0 护甲，补满一次，保护 20 tick。后续阶段二不再 copyPlayerState。未做正式 Boss 数值平衡。
- Phase 经 SynchedEntityData 同步、BossVisualPhase NBT 保存；重载应用独立属性并保留已损失生命，不补满。客户端已有 HeartDemonRenderer / BossGeoRenderer / AutoGlowingGeoLayer 和血条注册按 phase 切换。
- 原镜像 MAX_HEALTH=max(20,owner.maxHealth×10)、ATTACK_DAMAGE=max(3,owner.finalAttackAttribute×10) 保留。原始备份每 20 tick 更新，按 Boss 剩余血量比例保持伤势；本批没有改成每 tick 回满。装备与效果复制语义保留，增加非有限值保护和读档初始化标记。
- 心魔蛋 / 心境心魔恢复真实绑定与 AI，/summon 自动绑定附近玩家；另外九种测试 Boss 仍不启用正式战斗。`boss_bind` 可显式切为静态视觉预览；旧存档显式 BossVisualTest=true 继续保持测试用途。
- 原始备份有 FlyingMoveControl、FlyingPathNavigation、noGravity，但仅视觉绑定和 NoAI 跳过战斗，地面 MeleeAttackGoal 也无法可靠追击悬空目标。保留原组件，增加直线空中追击与有限近战检查。
- 现有备份未找到战斗瞬移，不能声称恢复了原参数。补回 100 tick 冷却、16–32 格触发、单次不超过 32 格、玩家背后优先半径 3 格的 8 个候选；区块、碰撞、液体、高度、边界检查，服务端发位置/粒子/声音。
- 心境和旧渡劫死亡结算额外检查 phase2，转阶段不走事件链。两名玩家镜像数值、飞行、瞬移、转阶段、保存重载与最终结算均待实机验证。

以下为第六/七/九批历史记录，不代表第十批源码已经编译或实机通过。

本批在第三至第五批修改后的源码上继续完成。平台保持 Minecraft 1.20.1、Forge 47.4.0、Java 17。

**历史批次状态：第六批接入时按当时要求只做源码、资源和静态检查。** 用户随后允许构建，当前合并源码已完成完整 Forge 构建与 GeckoLib 依赖升级；下文第六批静态检查记录不代表 Boss 战斗与模型已完成游戏内验收。

## 范围与依赖

六贼 6 个独立实体、三尸 3 个独立实体、心魔 1 个实体，共 10 个 Boss。心魔两阶段共用既有 `wuxingxiantu:heart_demon` 注册身份及同一个 ServerBossEvent，合计 11 种血条外观。

当前使用 GeckoLib Forge 1.20.1 **4.8.4**，构建坐标 `software.bernie.geckolib:geckolib-forge-1.20.1:4.8.4`，版本由 `gradle.properties` 提供。引入原因：项目原有 ModelPart 工具只服务少数静态模型，本批资源有 7,522 个立方体、逐面 UV、任意枢轴和 57 条曲线动画，且心魔二阶段资源明确按 GeckoLib 4 格式导出。采用现成解析和动画管线避免另写复杂几何转换器。

客户端和专用服务器都需要安装该前置；`mods.toml` 从属性展开版本范围 `[4.8.4,5)`，实际编译依赖为 4.8.4。不启用 Jar-in-Jar、不内嵌 GeckoLib、不提供其二进制。启动器须选择 Forge 1.20.1 对应版本，不能使用 Fabric/NeoForge 包。源码包中的 `build.gradle` 已配置受 group 限定的 Cloudsmith Maven 仓库。依赖解析及完整 clean build 已验证通过。

第六批通信版本从 49 更新到 50；第七批因玩家剑诀知识同步进一步更新到 51。没有新增自定义生命值同步包。客户端与服务器必须使用同批源码对应的产物。

## 接入与兼容

- `boss/BossVisualRegistry.java` 从类路径 `data/wuxingxiantu/boss_visuals.json` 加载统一视觉参数。该文件用于启动配置，尺寸修改需要重启；不是可热重载的玩法数据包。
- 9 个新增类型共用 `VisualBossEntity` 最小行为：持久化、看向玩家、地面游走或悬浮移动、受伤、死亡。没有攻击目标或正式技能。属性生命值 200 是临时视觉测试值。
- 第七批为 9 个新实体补齐测试蛋，仍支持原版 `/summon`。没有自然生成、生存配方、交易或掉落来源。复用现有 `heart_demon_spawn_egg`，生成的心魔默认 PHASE_1，只绑定使用者皮肤，不启动渡劫战斗。第二阶段继续使用开发命令，不新增蛋。

## 第七批测试蛋

全部 ID 使用 `wuxingxiantu:` 命名空间：

| 测试蛋 ID | 对应独立实体 |
| --- | --- |
| `muyan_spawn_egg` | `muyan` |
| `ermei_spawn_egg` | `ermei` |
| `bichen_spawn_egg` | `bichen` |
| `shetao_spawn_egg` | `shetao` |
| `shenyin_spawn_egg` | `shenyin` |
| `yihuo_spawn_egg` | `yihuo` |
| `pengju_spawn_egg` | `pengju` |
| `pengzhi_spawn_egg` | `pengzhi` |
| `pengjiao_spawn_egg` | `pengjiao` |
| `heart_demon_spawn_egg` | `heart_demon`，默认 PHASE_1 |

全部为 `CREATIVE_TEST`，同时列入代码分类和物品 tag，仅开发和创造测试使用。当前项目没有独立测试 Tab，按上表顺序集中放在既有创造页末尾。九个新蛋使用 ForgeSpawnEggItem、原版蛋模型和对应模型主色近似；中英文名走 lang。正式心境流程/结构/主线来源不由测试蛋替代。

第七批静态检查确认实体 supplier 一一对应、三尸互不混用、心魔只有一个蛋；第六批模型、动画、血条、Boss UUID 关联源码逐字节保留。未启动游戏，不能把这些检查称为使用蛋召唤后的画面或性能实测。完整验收见 `SWORD_AUDIT.md`。

### 原有接入说明（续）
- 心魔第一阶段保留 PlayerModel、粗细手臂与玩家皮肤查找。无主测试心魔在附近玩家出现后自动绑定其外观；可用 `boss_bind` 明确指定。玩家皮肤不在客户端已加载玩家列表中时仍回退到原有默认皮肤逻辑。
- 心魔第二阶段使用 `xinmo_wuxiang` 原模型、主贴图和 glow；使用实体透明材质及局部全亮 eyes layer，不制造世界光源，也不实现镜面反射或新 Shader 管线。
- `BossVisualPhase`、`BossVisualTest` 保存到实体 NBT；旧含 Owner 的心魔存档继续作为原有战斗实体。旧 `create`、`bindToOwner`、`bindToServantOwner` 和玩家状态复制流程保留。没有自动按生命值切阶段。
- 新增 Boss 及测试心魔死亡时跳过既有击杀奖励入口，不产出修为、灵力球、随机内丹、灵晶或渡劫奖励。旧正式心魔继续走原有流程。
- 每个实体同步自己的原生 BossEvent UUID，客户端用 UUID 关联外观；名称、可见性和生命比例仍由 ServerBossEvent 控制。新实体只向正在追踪且 64 格内的玩家显示血条，移出追踪、死亡和移除均清理；旧心魔保留其 64 格可见逻辑及魂仆隐藏逻辑。

## 资源处理

已实际递归展开 10 个嵌套模型压缩包。完整来源、字节数、SHA256、PNG 尺寸、预览、粒子和模型映射记录在 `reference_assets/boss/asset_manifest.json`。每个 Boss 的原始 bbmodel、说明、预览和粒子资源保存在 `reference_assets/boss/<id>/`，不会被 Gradle 自动打进资源目录。

模型几何总计 7,522 个立方体，全部保留。除身淫重名骨骼外，运行几何文件逐字节复制。身淫的 1 个重复 `floating_hip_shard` 和 5 个重复 `shoulder_blade` 追加数字后缀；这些重名节点没有被动画或子节点按名称引用。所有立方体、UV、旋转、枢轴和父子关系保持，原始工程仍原样归档。

所有主贴图、心魔 glow、57 条动画均逐字节复制。粒子 JSON 是 Bedrock 格式，仅归档，未错误地注册为 Forge 粒子，未激活场地毒雾或技能弹幕。

三尸血条依据当前实际文件名 `三尸/pengju.png`、`三尸/pengzhi.png`、`三尸/pengjiao.png` 映射。心魔使用本次包的 `心魔/1.png`、`心魔/2.png`。六贼原图 UUID 文件名按所属中文目录对应，具体路径见下表。心魔一期原图含透明背景，不抠图、不改色、不替换。

11 张原始血条都作为 `textures/gui/boss/<visual>_original.png` 原样保留。原图约含 70%～80% 示意血量：导入工具识别每张实际槽位，用原图已有空槽的 24 列像素平铺生成槽背景，用原有填充像素最近邻扩展为满槽，再由运行时按生命比例裁切填充宽度。这是从原像素重组的技术拆层，非重绘；填充矩形外每个装饰像素都经检查与原图一致。新派生层为 `_frame.png`、`_fill.png`。名称由 Minecraft 文本单独绘制，不写入图片。

## 动画与尺寸的边界

全部模型均按源文件 16 单位等于 1 格保留 scale=1。每个实体设置独立主体碰撞箱、眼高和阴影；四个地面类型及身淫用静态骨骼旋转后最低点校正脚底，悬浮模型保留原设计高度。扩展裁剪边界容纳镜轮、巨舌、触手和环绕外观；这些突出部分没有独立伤害盒。

所有模型已有的待机循环已选择接入，多控制器只同时播放互不冲突的骨骼通道。身淫移动时使用现有 `tendril_crawl`；其余模型没有明确独立 MOVE 动画，移动时保留待机姿态。所有十套 geo 模型都缺专用 HURT 和 DEATH 动画，使用引擎受伤变色和死亡翻倒；没有把攻击动作冒称受伤/死亡。心魔一期仍使用原有玩家模型的移动表现。

`boss_animation` 可单次播放当前模型的任意现有动作，循环动作也仅播放一个周期；结束或 stop 后恢复待机。不执行动作名对应的伤害、粒子、召唤物或阶段机制。原始片段和缺项逐项列在下表。

尺寸来自实际几何和视觉主体选择，**未在 Minecraft 内校准**。下表给出的总几何边界含装饰、轮盘和粒子预览几何，不能直接当作身体碰撞箱。彭矫 2,873 个立方体、彭质 1,568 个立方体是主要潜在渲染负载，尚无 FPS 测量结果。

## HUD 布局

Forge BossEventProgress 只截获已映射 UUID 的这些 Boss。原版 Boss 和 `/bossbar` 继续使用原绘制。自定义条目按原版遍历顺序收集，在原版条目下方纵向绘制，保留原生生命平滑插值。图片按透明内容范围等比显示，目标宽度 260 GUI 像素，依据剩余高度和条数缩小，名字占独立一行。

已离线检查 GUI Scale 1、2、3、4、Auto，1920×1080、2560×1080、1280×720、854×480 窗口，以及 1/3/10 条自定义血条和 0/1/3 条原版血条组合的边界。小窗口同时 10 条时每条会明显缩小；可逐个召唤观察细节。若大量原版条目先达到原版屏幕三分之一截断线，后续条目仍遵循原版可见上限。其他修改 BossBar HUD 的模组兼容性尚未测试。

## 测试命令

需要管理员权限 2。建议在空旷测试世界逐个召唤，以下命令均已写入源码入口，但本次没有在游戏执行。

```mcfunction
/summon wuxingxiantu:muyan ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:ermei ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:bichen ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:shetao ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:shenyin ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:yihuo ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:pengju ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:pengzhi ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:pengjiao ~ ~ ~ {Tags:["boss_visual_test"],NoAI:1b}
/summon wuxingxiantu:heart_demon ~ ~ ~ {Tags:["boss_visual_test","heart_preview"],NoAI:1b}
/wuxingxiantu boss_bind @e[tag=heart_preview,sort=nearest,limit=1] @s
/wuxingxiantu boss_phase @e[tag=heart_preview,sort=nearest,limit=1] 2
/wuxingxiantu boss_phase @e[tag=heart_preview,sort=nearest,limit=1] 1
/wuxingxiantu boss_health @e[tag=boss_visual_test,sort=nearest,limit=1] 50
/wuxingxiantu boss_health @e[tag=boss_visual_test,sort=nearest,limit=1] 100
/wuxingxiantu boss_animations @e[tag=boss_visual_test,sort=nearest,limit=1]
/wuxingxiantu boss_animation @e[type=wuxingxiantu:muyan,sort=nearest,limit=1] animation.muyan.gaze_charge
/wuxingxiantu boss_animation @e[tag=boss_visual_test,sort=nearest,limit=1] stop
/data merge entity @e[tag=boss_visual_test,sort=nearest,limit=1] {NoAI:0b}
/wuxingxiantu boss_health @e[tag=boss_visual_test,sort=nearest,limit=1] 0
```

可按 F3+B 检查碰撞箱；动画名支持命令补全。对新召唤的心魔，`BossVisualPhase:2` NBT 也可直接选择二期。生命值与动画命令仅接受视觉测试实体；`boss_phase` 也可切换旧正式心魔的视觉阶段，但不改变它的战斗或奖励身份。

后续实机验收：分别召唤六贼；三尸同时存在；心魔玩家皮肤和双向阶段切换；伤害和 0 血消失；移动/受伤/死亡回退；三条以上血条和原版 Boss 混排；保存重进和跨维度；专用服务器；白天、洞穴及 Shader 开关；单只及至少三只不同 Boss 的 FPS。**这些实机项目全部尚未执行**。

## 验证记录

已通过 26 项初始修复/第三批检查、16 项第四五批检查、15 项本批检查，共 57 项静态检查。解析 56 个相对原始源码改动的 Java 文件和 993 个运行资源 JSON；检查注册数量、资源路径、骨骼唯一性和环、动画引用、UV/几何完整性、像素保真、血条布局、测试奖励隔离及旧心魔入口。丹药、异火、配方和世界生成文件与第五批交付逐字节一致。

第六批接入时读取本机缓存 Forge 类元数据及 GeckoLib 源码核对涉及的 API；当时仅做签名检查。当前合并源码已使用 GeckoLib 4.8.4 完成编译与重混淆。未发现可用 `mc_check`，未以其他名称代称游戏实测；Boss 战斗和专用服务器仍需专项运行验收。

以下数据由导入清单机械生成，与统一定义表一致。

<!-- GENERATED_BOSS_TABLES -->

## 模型与碰撞箱

| ID / 阶段 | 名称 | 骨骼 / 方块 | 移动 | 宽×高 | 眼高 | 阴影 | Y 偏移 |
|---|---|---|---|---|---|---|---|
| muyan | 观色魔·目魇 | 63 / 348 | 悬浮 | 2.4×3.9 | 2.25 | 1.08 | 0.0000 |
| ermei | 闻声魔·耳魅 | 21 / 297 | 地面 | 1.5×4.85 | 4.2 | 0.68 | -0.0313 |
| bichen | 嗅香魔·鼻嗔 | 39 / 405 | 地面 | 2.7×4 | 3.25 | 1.22 | -0.0156 |
| shetao | 贪味魔·舌饕 | 49 / 648 | 地面 | 2.8×3.2 | 2.65 | 1.26 | 0.0356 |
| shenyin | 触欲魔·身淫 | 136 / 386 | 地面 | 2.35×4.1 | 3.5 | 1.06 | -0.0660 |
| yihuo | 妄意魔·意惑 | 146 / 158 | 悬浮 | 3.5×3.7 | 2.125 | 1.57 | 0.0000 |
| pengju | 彭倨·天嗔之相 | 49 / 348 | 悬浮 | 3.7×8.2 | 4.5 | 1.67 | 0.0000 |
| pengzhi | 彭质·腹欲之魔 | 119 / 1568 | 地面 | 3.8×6.45 | 5.8 | 1.71 | 0.0000 |
| pengjiao | 彭矫·足欲之邪 | 140 / 2873 | 悬浮 | 4.3×8.25 | 4.1 | 1.94 | 0.0000 |
| heart_demon_phase2 | 心魔·无相魔躯 | 71 / 491 | 悬浮 | 1.6×4 | 3.45 | 0.72 | 0.0000 |
| heart_demon_phase1 | 心魔 | 原版玩家模型 | 悬浮 | 0.6×1.95 | 1.74 | 0.50 | 0.0000 |

## 血条映射与填充区域

坐标单位为原 PNG 像素；右边界和下边界不包含在矩形中。显示宽度目标均为 260，名称偏移为 0。

| 视觉 ID | boss.zip 内原图 | 原图尺寸 | 填充 (x,y,w,h) |
|---|---|---|---|
| muyan | 六贼/眼/9fc75a2b-1d8c-4532-948e-53816ae956aa.png | 2137×736 | 380, 312, 1470, 65 |
| ermei | 六贼/耳/79a914d5-f5f5-44e8-a62b-c5987a69a945.png | 2138×736 | 385, 317, 1435, 75 |
| bichen | 六贼/鼻/1f2d1b98-6405-4b0d-addd-ee727d8ab7aa.png | 2137×736 | 380, 322, 1470, 65 |
| shetao | 六贼/舌/759ddd48-253e-4a94-b60a-3d8c31b43e5d.png | 2137×736 | 380, 300, 1430, 69 |
| shenyin | 六贼/身/e9283125-9824-4543-b22f-368460a653c1.png | 2172×724 | 350, 331, 1490, 65 |
| yihuo | 六贼/意/a936d3d2-2653-4843-b5bb-fa0c92264a96.png | 2138×736 | 385, 301, 1435, 67 |
| pengju | 三尸/pengju.png | 2135×736 | 345, 331, 1565, 76 |
| pengzhi | 三尸/pengzhi.png | 2135×736 | 373, 325, 1467, 72 |
| pengjiao | 三尸/pengjiao.png | 2138×736 | 385, 338, 1485, 70 |
| heart_demon_phase2 | 心魔/2.png | 2172×724 | 408, 356, 1502, 68 |
| heart_demon_phase1 | 心魔/1.png | 2172×724 | 408, 333, 1567, 89 |

## 模型源与原始动作

运行时统一路径：`assets/wuxingxiantu/geo/boss/<modelId>.geo.json`、`animations/boss/<modelId>.animation.json`、`textures/entity/boss/<modelId>.png`。以下来源路径相对展开后的 boss.zip，`.zip.unpacked/` 表示真实打开的嵌套包内容。完整 preview、particle_json、particle_texture、glow 来源及哈希见归档清单。

### muyan

- bbmodel：`六贼/眼/muyan_assets.zip.unpacked/muyan.bbmodel`
- geo：`六贼/眼/muyan_assets.zip.unpacked/bedrock_source/muyan.geo.json`
- animation：`六贼/眼/muyan_assets.zip.unpacked/bedrock_source/muyan.animation.json`
- 贴图：`六贼/眼/muyan_assets.zip.unpacked/muyan_atlas.png`
- Glow：无
- 静态总边界（格）：-2.367, -0.248, -1.100 至 2.475, 4.809, 1.717
- 自动待机：`animation.muyan.idle`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.muyan.idle | 6 | 待机循环 |
| animation.muyan.gaze_charge | 1.2 | 仅开发命令单次预览 |

### ermei

- bbmodel：`六贼/耳/ermei_boss_assets.zip.unpacked/ermei.bbmodel`
- geo：`六贼/耳/ermei_boss_assets.zip.unpacked/bedrock_source/ermei.geo.json`
- animation：`六贼/耳/ermei_boss_assets.zip.unpacked/bedrock_source/ermei.animation.json`
- 贴图：`六贼/耳/ermei_boss_assets.zip.unpacked/ermei_atlas.png`
- Glow：无
- 静态总边界（格）：-1.814, 0.031, -1.814 至 1.814, 4.841, 1.814
- 自动待机：`animation.ermei.idle`、`animation.ermei.soundmark_vibration`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.ermei.idle | 3 | 待机循环 |
| animation.ermei.sonic_ripple | 3 | 仅开发命令单次预览 |
| animation.ermei.prelude_cast | 1.8 | 仅开发命令单次预览 |
| animation.ermei.soundmark_vibration | 0.6 | 待机循环 |

### bichen

- bbmodel：`六贼/鼻/bichen_boss_assets.zip.unpacked/bichen.bbmodel`
- geo：`六贼/鼻/bichen_boss_assets.zip.unpacked/bedrock_source/bichen.geo.json`
- animation：`六贼/鼻/bichen_boss_assets.zip.unpacked/bedrock_source/bichen.animation.json`
- 贴图：`六贼/鼻/bichen_boss_assets.zip.unpacked/bichen_atlas.png`
- Glow：无
- 静态总边界（格）：-2.094, 0.016, -2.190 至 2.094, 3.962, 2.058
- 自动待机：`animation.bichen.idle`、`animation.bichen.glands_pulse`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.bichen.idle | 4 | 待机循环 |
| animation.bichen.glands_pulse | 3 | 待机循环 |
| animation.bichen.venom_exhale | 1.8 | 仅开发命令单次预览 |
| animation.bichen.venom_drip | 2 | 仅开发命令单次预览 |

### shetao

- bbmodel：`六贼/舌/shetao_boss_assets.zip.unpacked/shetao.bbmodel`
- geo：`六贼/舌/shetao_boss_assets.zip.unpacked/bedrock_source/shetao.geo.json`
- animation：`六贼/舌/shetao_boss_assets.zip.unpacked/bedrock_source/shetao.animation.json`
- 贴图：`六贼/舌/shetao_boss_assets.zip.unpacked/shetao_atlas.png`
- Glow：无
- 静态总边界（格）：-1.503, -0.036, -3.078 至 1.503, 3.033, 1.075
- 自动待机：`animation.shetao.idle`、`animation.shetao.hungry_chew`、`animation.shetao.tongue_core_writhe`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.shetao.idle | 3 | 待机循环 |
| animation.shetao.hungry_chew | 1.2 | 待机循环 |
| animation.shetao.drool_and_crumbs | 2 | 仅开发命令单次预览 |
| animation.shetao.tongue_core_writhe | 4 | 待机循环 |
| animation.shetao.tongue_lash | 1.6 | 仅开发命令单次预览 |

### shenyin

- bbmodel：`六贼/身/shenyin_boss_assets.zip.unpacked/shenyin.bbmodel`
- geo：`六贼/身/shenyin_boss_assets.zip.unpacked/bedrock_source/shenyin.geo.json`
- animation：`六贼/身/shenyin_boss_assets.zip.unpacked/bedrock_source/shenyin.animation.json`
- 贴图：`六贼/身/shenyin_boss_assets.zip.unpacked/shenyin_atlas.png`
- Glow：无
- 静态总边界（格）：-1.974, 0.066, -1.818 至 1.974, 4.095, 1.818
- 自动待机：`animation.shenyin.idle`、`animation.shenyin.core_and_node_pulse`
- MOVE：`animation.shenyin.tendril_crawl`；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.shenyin.idle | 4 | 待机循环 |
| animation.shenyin.core_and_node_pulse | 2 | 待机循环 |
| animation.shenyin.tendril_crawl | 4 | 移动 |
| animation.shenyin.grasp | 2 | 仅开发命令单次预览 |
| animation.shenyin.core_exposed | 2.4 | 仅开发命令单次预览 |

### yihuo

- bbmodel：`六贼/意/yihuo_boss_assets.zip.unpacked/yihuo.bbmodel`
- geo：`六贼/意/yihuo_boss_assets.zip.unpacked/bedrock_source/yihuo.geo.json`
- animation：`六贼/意/yihuo_boss_assets.zip.unpacked/bedrock_source/yihuo.animation.json`
- 贴图：`六贼/意/yihuo_boss_assets.zip.unpacked/yihuo_atlas.png`
- Glow：无
- 静态总边界（格）：-1.936, 0.513, -1.141 至 2.051, 3.660, 1.061
- 自动待机：`animation.yihuo.formless_drift`、`animation.yihuo.memory_flicker`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.yihuo.formless_drift | 6 | 待机循环 |
| animation.yihuo.memory_flicker | 2 | 待机循环 |
| animation.yihuo.mirror_form | 5.8 | 仅开发命令单次预览 |
| animation.yihuo.familiar_echo | 5.8 | 仅开发命令单次预览 |
| animation.yihuo.mind_scatter | 1.5 | 仅开发命令单次预览 |

### pengju

- bbmodel：`三尸/pengju_boss_assets.zip.unpacked/pengju.bbmodel`
- geo：`三尸/pengju_boss_assets.zip.unpacked/bedrock_source/pengju.geo.json`
- animation：`三尸/pengju_boss_assets.zip.unpacked/bedrock_source/pengju.animation.json`
- 贴图：`三尸/pengju_boss_assets.zip.unpacked/pengju_atlas.png`
- Glow：无
- 静态总边界（格）：-3.035, 0.700, -1.788 至 3.035, 8.200, 1.872
- 自动待机：`animation.pengju.sovereign_hover`、`animation.pengju.shield_orbit`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.pengju.sovereign_hover | 6 | 待机循环 |
| animation.pengju.shield_orbit | 12 | 待机循环 |
| animation.pengju.wrath_roar | 2 | 仅开发命令单次预览 |
| animation.pengju.crushing_lunge | 1.8 | 仅开发命令单次预览 |
| animation.pengju.shield_shatter | 2.6 | 仅开发命令单次预览 |
| animation.pengju.falling_gold | 4 | 仅开发命令单次预览 |

### pengzhi

- bbmodel：`三尸/pengzhi_boss_assets.zip.unpacked/pengzhi/pengzhi.bbmodel`
- geo：`三尸/pengzhi_boss_assets.zip.unpacked/pengzhi/bedrock_source/pengzhi.geo.json`
- animation：`三尸/pengzhi_boss_assets.zip.unpacked/pengzhi/bedrock_source/pengzhi.animation.json`
- 贴图：`三尸/pengzhi_boss_assets.zip.unpacked/pengzhi/pengzhi_atlas.png`
- Glow：无
- 静态总边界（格）：-3.896, 0.000, -3.831 至 3.814, 6.438, 2.205
- 自动待机：`animation.pengzhi.heavy_breath`、`animation.pengzhi.tentacle_hunger`、`animation.pengzhi.maws_and_drool`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.pengzhi.heavy_breath | 4 | 待机循环 |
| animation.pengzhi.tentacle_hunger | 4 | 待机循环 |
| animation.pengzhi.maws_and_drool | 2 | 待机循环 |
| animation.pengzhi.devour | 2.6 | 仅开发命令单次预览 |
| animation.pengzhi.tentacle_slam | 1.8 | 仅开发命令单次预览 |
| animation.pengzhi.wine_frenzy | 3 | 仅开发命令单次预览 |

### pengjiao

- bbmodel：`三尸/pengjiao_boss_assets.zip.unpacked/pengjiao/pengjiao.bbmodel`
- geo：`三尸/pengjiao_boss_assets.zip.unpacked/pengjiao/bedrock_source/pengjiao.geo.json`
- animation：`三尸/pengjiao_boss_assets.zip.unpacked/pengjiao/bedrock_source/pengjiao.animation.json`
- 贴图：`三尸/pengjiao_boss_assets.zip.unpacked/pengjiao/pengjiao_atlas.png`
- Glow：无
- 静态总边界（格）：-4.804, 0.101, -3.109 至 4.531, 8.209, 3.418
- 自动待机：`animation.pengjiao.prismatic_core`、`animation.pengjiao.fivefold_orbit`、`animation.pengjiao.restless_desire`、`animation.pengjiao.ghost_shroud_drift`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.pengjiao.prismatic_core | 8 | 待机循环 |
| animation.pengjiao.fivefold_orbit | 18 | 待机循环 |
| animation.pengjiao.restless_desire | 4 | 待机循环 |
| animation.pengjiao.split_manifest | 4 | 仅开发命令单次预览 |
| animation.pengjiao.fivefold_assault | 2.4 | 仅开发命令单次预览 |
| animation.pengjiao.mirage_convergence | 4 | 仅开发命令单次预览 |
| animation.pengjiao.severed_illusion | 4.5 | 仅开发命令单次预览 |
| animation.pengjiao.ghost_shroud_drift | 4 | 待机循环 |

### heart_demon_phase2

- bbmodel：`心魔/xinmo_wuxiang_phase2_assets.zip.unpacked/xinmo_wuxiang/xinmo_wuxiang.bbmodel`
- geo：`心魔/xinmo_wuxiang_phase2_assets.zip.unpacked/xinmo_wuxiang/forge_assets/assets/cultivation/geo/xinmo_wuxiang.geo.json`
- animation：`心魔/xinmo_wuxiang_phase2_assets.zip.unpacked/xinmo_wuxiang/forge_assets/assets/cultivation/animations/xinmo_wuxiang.animation.json`
- 贴图：`心魔/xinmo_wuxiang_phase2_assets.zip.unpacked/xinmo_wuxiang/forge_assets/assets/cultivation/textures/entity/xinmo_wuxiang.png`
- Glow：`textures/entity/boss/xinmo_wuxiang_glow.png`
- 静态总边界（格）：-2.281, 0.412, -0.381 至 2.318, 5.114, 1.091
- 自动待机：`animation.xinmo_wuxiang.suspended_idle`、`animation.xinmo_wuxiang.heart_pulse`、`animation.xinmo_wuxiang.heart_turn`、`animation.xinmo_wuxiang.heart_wheel_orbit`
- MOVE：缺专用片段，保留待机；HURT：缺，受伤变色；DEATH：缺，引擎翻倒。

| 完整动画名 | 秒 | 默认播放 |
|---|---|---|
| animation.xinmo_wuxiang.suspended_idle | 4 | 待机循环 |
| animation.xinmo_wuxiang.heart_pulse | 1.6 | 待机循环 |
| animation.xinmo_wuxiang.heart_turn | 12 | 待机循环 |
| animation.xinmo_wuxiang.heart_wheel_orbit | 24 | 待机循环 |
| animation.xinmo_wuxiang.face_rift | 2 | 仅开发命令单次预览 |
| animation.xinmo_wuxiang.heart_exposed | 3 | 仅开发命令单次预览 |
| animation.xinmo_wuxiang.delusion_chains | 3.2 | 仅开发命令单次预览 |
| animation.xinmo_wuxiang.mirror_flower | 3.6 | 仅开发命令单次预览 |
| animation.xinmo_wuxiang.karma_reversal | 3 | 仅开发命令单次预览 |
| animation.xinmo_wuxiang.all_thoughts_ash | 4 | 仅开发命令单次预览 |
| animation.xinmo_wuxiang.phase_two_unmask | 3.8 | 仅开发命令单次预览 |
| animation.xinmo_wuxiang.echo_weapon_slash | 1.5 | 仅开发命令单次预览 |
