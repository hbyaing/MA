# 第九批：心境主线骨架审计

平台：Minecraft 1.20.1 / Forge 47.4.0 / Java 17。当前协议 53。

用户追加要求“这次可以直接构建”后，已完成 Java 17 / Gradle 8.8 / Forge 47.4.0 的完整 build，包含 compileJava、资源处理和 reobfJar。交付修改后源码与单独的成品 JAR；构建成功不等于游戏闭环已实测。

## 主线与修为锁

1. `CultivationDataImpl.daoHeartUnstable` 为主线状态，NBT 使用 `dao_heart_unstable`；读取兼容旧 `DaoHeartUnstable`。
2. `TribulationManager.finishSuccess` 先执行境界提升、阶段重置和当前修为归零，再调用 `MindscapeManager.markUnstable`。渡劫仍完成原有结算；取消最高境界在升境界前等待心魔死亡的旧流程。
3. `wuxingxiantu$setCultivation` 是最终防线：锁定且新值大于当前值时拒绝。降低/清零不受影响，存档恢复直接恢复保存值。`canGain(player,data,notify)` 为消耗资源前的统一校验与提示入口。
4. 正常打坐、战斗及事件奖励共用 `CultivationLogic.gainCultivationAndAura`，锁定修为但仍可恢复 Aura。所有直接 setter 路径也受最终防线保护。创造丹和 OP 设置也不能靠修为 setter 绕过主线锁；没有静默清锁接口。
5. `BasePillItem.use/finishUsingItem` 在食用开始与完成各检查一次修为丹资格，拒绝时不扣丹药或灵力。`PillEffects`、旧 `EffectPillItem`、`CultivationInsightItem` 和小突破丹补充同样的提前校验。
6. 清心、镇心、净神、DaoXin 数值、普通 removeEffect 与灵力恢复不触碰主线标记。服务端源码唯一 `setDaoHeartUnstable(false)` 位于通过会话检查的成功结算。
7. 主线锁不禁止探索、战斗、种植、炼丹、炼器、交易、御剑或普通物品使用。

## 状态与入定

`MindscapeState`：NONE、UNSTABLE、MEDITATING、ENTERING、IN_MINDSCAPE、CHALLENGE_ACTIVE、COMPLETED、RETURNING。

- 复用原蒲团 / 灵蒲团 / 悟道台的 `CultivationBlock` 和 `MeditationSeatEntity`。普通稳定打坐行为保持；仅道心不稳时由 `MindscapeManager` 服务端每 tick 累计 300 tick。
- 与预期蒲团座位绑定，检查维度、座位 UUID、实际位移、横移输入、飞行与睡眠。旋转视角不影响计时。
- 移动、跳跃、Shift 离座、受伤、换座、普通骑乘、死亡、换维度、退出和取消都会中断。客户端仅发送取消意图，不能发送完成时间或强制进入心境；服务端实体状态仍检查实际动作。
- HUD 每秒更新轻量入定秒数和状态，不新增大型心境 GUI。

## 会话与测试空间

- 维度固定为 `wuxingxiantu:mindscape`，配套 `dimension/mindscape.json` 与 `dimension_type/mindscape.json`。空白基础世界，仅进入的测试区域铺设 33×33 石台、边界与顶界。
- `MindscapeInstances` 为该维度 SavedData；最多 64 个区域，8×8 固定网格，间距 128 格，有限范围、无随机远坐标、无动态注册维度。间距也隔离相邻挑战的 64 格 Boss 血条范围。
- 每次生成新的随机 session UUID，租约对应 owner UUID。准备场地仅涉及本区域的有限区块，不注册强制区块 ticket。
- `CultivationDataImpl.mindscape` 存 owner、session、slot、challenge、boss UUID、boss_entity_id、is_final、boss_completed、state；另存原 dimension、x/y/z、yaw/pitch。返回点不使用或改写床重生点。
- Challenge JSON 字段包含 `challenge_id`、`boss_entity_id`、`required_realm`、`trigger_stage`、`arena_id`、`is_final`，由资源重载统一验证。
- 当前 `dev_visual_trial` 用目厌，trigger 为 `post_tribulation_test`、门槛 0，只是所有境界均可测试的默认占位；`dev_heart_trial` 用一期心魔、is_final=true，仅手动测试。**没有规定正式境界与六贼/三尸/Boss 的映射。** 可通过数据包修改测试定义。
- 测试 Boss 沿用现有实体、模型与血条，关闭 AI，不制作正式攻击、阶段或战斗奖励。进入测试空间不会被当作正式 Boss 技能验收。
- 普通维度旅行拒绝外部玩家进入；命令绕过旅行事件仍由维度变更与 tick 检查安全退回。玩家被限制在自己的区域，地形破坏、放置和爆炸受到测试空间保护。

## 成功、死亡与异常

- Boss 持久化绑定 `MindscapeOwner`、`MindscapeSession`、`MindscapeChallenge`。结算同时验证玩家、会话、租约、Boss UUID、实体类型及挑战 ID；普通路径还要求死亡伤害归属该玩家。
- 其他玩家不能伤害该会话 Boss，心境内 PVP 被拒绝；错误 Boss、同类型刷怪蛋、普通外界 Boss、其他会话或清理移除不会结算。
- 先写唯一 `boss_completed` 标记和 COMPLETED 状态，再记录 `completed_challenges`、`completed_stage`（及最终测试完成标记），然后清除道心不稳。重复回调不能重复结算，不自动再升境界。
- 已完成记录不会阻止以后再次渡劫或测试挑战。`is_final` 当前只是完成记录，不新增心魔正式二阶段技能。
- 成功和中止都释放实例；安全返回时检查世界边界、碰撞、液体、落脚面及常见危险地面，优先原位置附近，缺少原维度则回主世界出生点附近。
- 所有返回位置都无效时保留 RETURNING 与返回数据并断开连接，管理员恢复正常出生空间后重连恢复；不默认为成功，不把玩家留在无效维度继续运行。
- 死亡失败保留道心不稳，Clone 复制会话返回数据，Respawn 后安全返回；不改写世界 keepInventory 规则。keepInventory=false 时正常死亡掉落（包括法衣）在可用返回点生成，便于重新拾取；不能迁移的掉落仍保留原死亡事件列表。
- 断线采用明确的“安全中止”策略：释放 Boss/租约，保留返回数据，重连回正常世界且仍需重试。服务器重启回收旧租约防止固定池耗尽；玩家能力中的返回信息仍保留，登录走同样中止路径。旧 Boss 在加载时按 owner/session 检查清除。
- 进入前拒绝冲突神通，清理御剑根实体、骑乘与速度；返回时收束当前临时神通的投影/变身/镜头状态和御剑，再站立返回。普通丹药 Buff、装备、异火、背包和法衣不被无理由清空；不自动重新上剑。

## 开发命令

仅权限等级 2 及以上：

- `/wuxingxiantu mindscape status`：当前主线状态和保存的会话/完成记录。
- `/wuxingxiantu mindscape start_test wuxingxiantu:dev_visual_trial`：直接进入测试，会设置道心不稳；不绕过实例、存活或冲突状态校验。
- `/wuxingxiantu mindscape start_test wuxingxiantu:dev_heart_trial`：一期心魔最终标记测试。
- `/wuxingxiantu mindscape complete_test`：通过会话校验后走成功结算，显式开发例外。
- `/wuxingxiantu mindscape reset`：中止当前会话并回到道心不稳，可重新测试；保留永久完成记录。

## 验证与限制

本批 21 项静态检查覆盖解析、主线操作顺序、统一修为锁、丹药消费顺序、唯一清锁点、保存字段、实例几何、会话绑定、异常返回、法衣及 API。历史 26+16+15+15 项静态检查也通过，总计 93 项。涉及第八批允许改动的旧不变性断言已更新到第八批独立快照。

完整 Forge 构建成功，编译 0 错误、88 条警告（主要为弃用 API，另有既存未检查操作提示）。标准 test 任务为 NO-SOURCE，没有运行测试用例。未执行：mc_check（无可用工具）、mc_build、启动游戏、客户端截图或多人运行测试。自制静态检查不是 mc_check，不能据此宣称无复制、零延迟或已完整游戏验收。

后续实测应按附件 A-K：实际渡劫、全部修为来源、修为丹不耗、普通清心不解锁、15 秒与全部中断条件、心境死亡、对应 Boss 成功、两玩家隔离、退出重进和服务端重启。
