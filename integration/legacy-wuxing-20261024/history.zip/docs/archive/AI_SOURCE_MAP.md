# 五行仙途 AI 源码导航（AI_SOURCE_MAP）

## 新增修复批 A V2（协议 55，已完整构建与隔离实机验证）

- `AlchemyFurnaceVisualLayout` 集中新模型坐标；`AlchemyFurnaceCollision` 加载简化四向碰撞，`furnace_shapes.json` 是预处理缓存。
- `AlchemyFurnaceBlockEntity` 保存锁定素材、实际 `activeFireId`、唯一 `completedResult`；`Network` 交付 BE 结果，服务端每 8 tick 进行部分入包事务。
- `AlchemyFurnaceBlockEntityRenderer` 绘制真实材料与成丹物品；`AlchemyFurnaceEffects` 独立 shader 兼容几何缓冲，复用现有深度桥。
- 原 bbmodel 位于 `source-assets`。导出 UV 已是上缘为 0，模型配置必须 `flip_v:false`，否则绿色侧壁会误采样金色材质。
- 累计源码首次编译同时将 `LegacyStackMigration` 的非公开 `mapping.key` 改为公开 `mapping.getKey()`。
- 交付要求、验证证据与保留警告见 `BATCH_A_REPAIR_REPORT.md`。

## 新增修复批 B（当前协议 55，仅源码与静态验证）

- `robe/YujianSlot` 定义持久御剑槽、自动移入、养剑入口和锁。能力 NBT `yujian_stack`；原 RobeSyncPacket 扩展为双装备及飞行锁，RobeMenu 共 38 槽。
- `YujianController` 飞行只读取 activeFlyingSword；`SwordNurture` 区分手持战斗剑和飞剑，`CultivationSwordPage` 包含独立槽。
- `BossBarHud` 测量完整条目，`BossVisualDefinition.Bar` 提供标题参数；新增 `_hud_frame/_hud_fill` 资源，原画保留。
- `MeditationSeatEntity` 同步打坐进度与实际修为反馈；`MeditationAura` 复用 TrailShaderBridge，独立 mesh，不再在光影合成前直接绘制主体。
- 详细边界与 18 项答复见 `BATCH_B_REPAIR_REPORT.md`。

## 第十批 V2（当时协议 54，仅源码与静态验证）

- `yujian/YujianController` 在现有速度目标上加入 16 tick 翻滚脉冲，40 tick 冷却；`FlyingSwordConfig` 集中倍率和巡航余量。`InterpolatedFlyingSwordTransform` 从同步角速度计算螺旋强度；`YujianWindSound` 播放本地风声，沿用原拖尾和镜头链。
- `alchemy/LegacyStackMigration` + `coremods/legacy_stack_migration.js` 在 `ItemStack(CompoundTag)` 查表前迁移旧丹药与移除凌空附魔；Forge MissingMappings 仅负责注册映射。`WuXingItems` 删除 40 个品质/五行旧注册，17 类生存丹药都由 UnifiedPillItem 承载。
- `RefiningForgeScreen` 删除温度区，改为真实火阶。`RefiningRecipe.requiredFireTier()` 解释 legacy `temperature`；`Network.RefiningPacket` 核对真实煤块与异火的阶位。
- `assets/wuxingxiantu/models/block/<plant>{,_low,_mid}.json` 共 42 个：particle、无 AO/面阴影、幼苗等比缩放，保留手持模型与纹理。
- `AlchemyScreen` 不再缩放 `super.render` 或改写输入坐标；`AlchemyUiLayout` 是 308×232 原生容器布局。纹理 `background_compact.png` 从原画重排，`page_arrows.png` 为四状态箭头；菜单服务端禁止翻页越界。
- `SpiritSwordItem` 恢复无耐久附魔资格；`items/SpiritSwordAnvil` 仅补原版拒绝的双无耐久灵剑合并，书走 Forge 原生路径。异火联动保持。
- `HeartDemonEntity.actuallyHurt/setHealth` 在真实扣血点拦截致死，统一 `transitionToPhase2()`；NBT 保存镜像初始化、阶段与冷却。阶段二不再刷新玩家镜像，模型/glow/血条沿用已有同步 phase。
- `BATCH10_REGRESSION_REPORT.md` 回答文档 35+15 项。未构建、未启动 Minecraft，历史构建记录不代表本批验证。

## 第九批历史增量（当时协议 53）

- `mindscape/MindscapeManager` 是唯一会话状态机：入定 300 tick、进入、匹配 Boss 结算、异常返回；`MindscapeState` 是枚举。`MindscapeChallenges` 加载数据包 `mindscape_challenges/*.json`，不写死正式境界映射。
- `CultivationDataImpl` 保存 `dao_heart_unstable`、`mindscape` 和 `robe_stack`；旧 `DaoHeartUnstable` 只作为迁移读取。修为 setter 拒绝锁定时增加，`MindscapeManager.canGain` 提供物品消耗前提示。
- `TribulationManager.finishSuccess` 先升境界，再 `markUnstable`；旧的最高境界“先打心魔再升境界”分支已移出渡劫。`BasePillItem`、`PillEffects`、旧丹药、心得及通用修为入口接入锁。
- `MindscapeInstances` 使用维度 SavedData 管理固定 64 个互不重叠区域，间距 128；重启回收租约，玩家重连按能力数据安全退出并保留未完成状态。
- `robe/RobeSlots` 是公共装备 API；`RobeContainer` 直接引用能力数据，`RobeMenu` 使用原生 Slot 与 shift-click；`GeneratedMod.clonePlayer` 配合死亡掉落避免复制。
- `client/RobeScreen` 是轻量装备面板；`CultivationMainScreen` 提供背包入口。`RobeClient` 按 UUID 存观察者同步；`RobeLayer/RobeRenderProfile/RobeArmorLayer/RobeRenderEvents` 是纯客户端渲染接口。
- 新包：`MindscapeStatePacket`、`MindscapeCancelPacket`、`RobeSyncPacket`、`OpenRobePacket`。S2C 通过 `ClientPacketSink` 隔离专服类加载；法衣只在变更、登录、追踪、重生与维度变化时同步。
- 审计：`MINDSCAPE_AUDIT.md`、`ROBE_AUDIT.md`。用户追加允许构建后，Java 17 / Gradle 8.8 完整 build（含 compileJava、reobfJar）成功；编译 0 错误、88 条警告。GeckoLib 升级后再次 clean build 通过，并在 Forge 47.4.10 / GeckoLib 4.8.4 独立客户端确认启动至主菜单。标准 test 任务为 NO-SOURCE，未执行玩法测试；未调用 mc_build，mc_check 不可用。

## 第八批增量（协议 52）

`YUJIAN_ADVANCED_AUDIT.md` 为高级御剑现行规则。`YujianPhase/YujianTuning` 集中配置，`YujianController.tickAdvanced` 控制阶段与持续 Aura 消耗，`FlightCollision` 处理加载围栏和扫掠碰撞。合法换剑复用实体并降级；旧版“无持续消耗、换剑必收剑”描述仅适用于第七批快照。`YujianCommands` 提供 OP 调试，客户端同步意图并显示权威阶段。

> **用途**：这不是玩家 README，而是专门给 Codex / GPT / 其他代码 AI 使用的源码路由表。目标是让 AI 在处理任务时先定位系统，再只读取少量相关文件，避免每次重新扫描整个工程。
>
> **源码快照**：依据当前聊天中 `将源码构建为jar.zip` 解压后的工程生成。Minecraft 1.20.1 / Forge 47.4.0 / Java 17；模组 ID `wuxingxiantu`；主包 `cn.blockforge.generated.generatedmod`。
>
> **第三至第七批历史增量**：加入灵蕴台转换、`alchemy/` 丹药与丹方、`fire/` 独立火瓶生态、`boss/` Boss 视觉测试、玩家剑诀知识与 10 个测试蛋，当时未构建、协议 51。审计见 `PILL_AUDIT.md`、`PILL_RECIPE_AUDIT.md`、`FIRE_AUDIT.md`、`BOSS_AUDIT.md`、`SWORD_AUDIT.md`。当前完整交付含第八、九批，构建已通过，协议 53；前置 GeckoLib Forge 1.20.1 4.8.4。`gradle.properties` 集中管理编译版本与 `[4.8.4,5)` 加载范围，`build.gradle` 使用属性声明依赖并展开 `mods.toml`。

## 第七批灵剑与剑诀路由

- 八把正式灵剑以 `WuXingItems.java` 注册为准；中文名以 lang 为准。`SwordProfile` 的历史品阶显示名不是物品名。桃木剑不可飞，其余七把显式登记飞行定义。
- `FlyingSwordRegistry.get()` 是可空的权限查询；`visual()` 只供显示兜底，不可作为许可。`ProgressionGate.canYujian()` 在创造豁免前核对灵剑类型、配置与登记。
- `YujianController` 保留原有移动状态机；启动入口共享 Art 的 8 点 Aura 成本和冷却，成功生成实体后扣费。当前无持续御剑消耗；切离原手持飞剑时走 `stop()`。
- `SpiritSwordItem` 覆盖 Forge 逐栈耐久钩子、攻击和采掘，原栈移除 `Damage`；剑灵力与现有附魔补充路径保留。
- 玩家知识：`CultivationData/Impl` 的 `known_sword_techniques`；`GeneratedMod.clonePlayer/playerRespawn/playerLogin` 保存复制与同步；`Network.SyncPacket` 同步到 `WuXingClientPackets`。
- 每剑配置：`NurtureData` 的 `WuxingSwordNurture.equipped_sword_techniques`。旧 `UnlockedTechniques` 只由 `SwordNurture.migrate` 一次性合入首次持有者，之后清除并标记。写回复制旧 compound，保留其他字段。
- 剑诀施展：`SwordNurture.canCast/cast` 是统一校验与扣费入口，`YujianController.executeTechnique` 仅包内执行。本人所学、当前剑配置、品阶剑蕴、境界、Aura、冷却均通过后执行；失败不扣费。没有主人绑定。
- UI：`CultivationSwordPage` 学习、装备、施展；`ArtRadialScreen` 的剑诀标签读取主手配置，发送原有 `SwordNurtureActionPacket` 的 action 5。御剑凌霄诀仍属 Art。
- 测试蛋：`WuXingItems.BOSS_TEST_EGGS` 按六贼、三尸、心魔排序，`WuXingItemSources` 与 `creative_test.json` 标识测试用途。当前仅一个创造页，集中放在末尾；无生存来源。
- 炼器 `temperature` 仍为既有火阶/火候代理字段，不是新温度模拟，配方及现场异火系统未迁移。

## 第六批 Boss 路由

- 视觉定义：`boss/BossVisualDefinition.java`、`BossVisualRegistry.java`，唯一参数表 `data/wuxingxiantu/boss_visuals.json`。按类路径载入，改变尺寸后需要重启，不能仅用 `/reload`。
- 9 个独立测试实体：`registry/ModEntities.java` 的 `VISUAL_BOSSES`、`boss/VisualBossEntity.java`。六贼 6 个，三尸 `pengju / pengzhi / pengjiao` 各 1 个，禁止合并为一个三尸实体。
- 第 10 个 Boss：既有 `HeartDemonEntity.java`、`client/HeartDemonRenderer.java`。PHASE_1 玩家镜像，PHASE_2 `xinmo_wuxiang`；同一个实体与 ServerBossEvent，阶段和视觉测试标志保存到 NBT。
- 统一模型与 glow：`client/boss/BossGeoModel.java`、`BossGeoRenderer.java`；基础动画及临时动作：`boss/BossAnimations.java`。客户端类只由客户端注册入口载入。
- 血条：`client/boss/BossBarHud.java`，使用原版 BossEvent 的 UUID、名称和生命比例；UUID 通过实体数据关联外观，不另建血量网络协议。自定义血条按原版遍历顺序在原版血条下方堆叠。
- 开发命令：`boss/BossTestCommands.java`，根命令 `/wuxingxiantu`，权限 2。测试击杀在 `GeneratedMod.java` 排除奖励，旧心魔渡劫逻辑继续走原流程。
- 原始资产和导入证据：`reference_assets/boss/asset_manifest.json` 及各 Boss 子目录。Bedrock 粒子仅归档，未直接放进 Forge 粒子注册，也未触发技能粒子。
- 不引入正式技能、心境场地、自然生成或新的生存刷怪蛋来源。缺 MOVE/HURT/DEATH 动画的事实记录在 `BOSS_AUDIT.md`，不可宣称已补齐原生动画。

---

## 0. AI 使用规则（先读这里）

**不要把本文件从头到尾全部塞进上下文。** 推荐工作方式：

1. 首先只读本节与“1. 极速任务路由”。
2. 根据任务关键词，在本文件中搜索对应二级标题，例如 `御剑`、`炼丹`、`心魔`、`符箓`。
3. 只读取该系统列出的 **核心文件**；优先看服务端权威逻辑，再看客户端表现。
4. 只有核心文件不足时，才用 `rg`/IDE 查引用；不要先全量扫描 `src/main`。
5. 不要优先扫描 `build/`、`source-reference/`、`shader-reference/` 或测试源集，除非任务明确涉及它们。
6. 修改玩家数据时，优先检查 `CultivationData` → `CultivationDataImpl` → `Network.SyncPacket` 的同步链。
7. 修改 GUI/渲染时，先判断是**纯客户端表现**还是**服务端规则**；客户端类不应成为权威判定来源。
8. 新增注册内容时，从对应 Registry/WuXing 注册类进入，不要直接搜索所有 JSON。
9. 修改完若增加/删除类、重命名系统入口或改变关键调用链，应同步更新本导航。
10. 本导航用于“在哪里改”；玩家玩法与获取方式请看 `README_五行仙途_源码审计版.md`。

### 推荐给 Codex 的固定开场指令

```text
先读取 AI_SOURCE_MAP_五行仙途.md 的“0. AI 使用规则”和“1. 极速任务路由”。
根据本次任务只读取对应系统章节列出的核心文件；不要无目的全量扫描 src、build、测试目录或 reference 目录。
若导航信息不足，再用 rg 局部追踪调用关系。修改完成后，如果架构入口发生变化，同步更新 AI_SOURCE_MAP。
```

---

## 1. 极速任务路由

| 想做什么 | 首先看 | 通常还要看 | 不要先看 |
|---|---|---|---|
| 修改境界、修为、灵力数值 | `items/CultivationLogic.java` | `CultivationData.java`, `CultivationDataImpl.java`, `GeneratedMod.java` | UI |
| 修改玩家存档字段 | `CultivationData.java` + `CultivationDataImpl.java` | `Network.java` 的 `SyncPacket` | 所有物品类 |
| 修改任何境界门槛/使用资格 | `ProgressionGate.java` | 对应系统的 Item/BlockEntity/Event 调用点, `message.wuxingxiantu.gate.*` lang 键 | 各物品类里的境界数字（已集中，禁止再散落硬编码） |
| 修改灵根/领域 | `items/CultivationLogic.java` | `ModEffects.java`, `Network.java` 的五行 Domain 包, `client/InnerVisionScreen.java` | 世界生成 |
| 修改灵植/灵壤/灵肥/药材掉落 | `plants/SpiritPlantCatalog.java` | `plants/SpiritPlantDefinition.java`, `plants/SpiritPlantRegistry.java`, `data/.../worldgen` + `loot_tables` + `tags`（见 §16.5） | 炼丹炉 |
| 修改体质 | `PhysiqueType.java`, `items/PhysiqueLogic.java` | `items/PhysiqueResetPillItem.java` | 炼丹炉 |
| 修改打坐/洞府 | `CultivationBlock.java`, `CaveTokenLocations.java` | `MeditationSeatEntity.java`, `client/Meditation*` | `Network.java` 全文件 |
| 修改灵蕴台蕴养 | `SpiritPlatformConversions.java`, `SpiritPlatformBlockEntity.java` | `SpiritPlatformBlock.java`, `client/PedestalFloatingRenderer.java`（见 §5） | GUI / RecipeType / 新能源系统 |
| 修改炼丹 | `AlchemyFurnaceBlockEntity.java`, `AlchemyRecipe.java` | `AlchemyFurnaceStructure.java`, `Network.AlchemyPacket`, `client/AlchemyScreen.java`, `data/.../recipes` | 炼器 |
| 修改炼器/飞剑武器配方 | `RefiningForgeBlockEntity.java`, `RefiningRecipe.java` | `RefiningForgeStructure.java`, `Network.RefiningPacket`, `data/.../recipes/refining_*` | 普通合成全表 |
| 修改御剑飞行 | `yujian/YujianController.java` | `yujian/FlyingSwordConfig.java`, `yujian/FlyingSwordRegistry.java`, `client/YujianClientController.java`, `Network` 御剑包 | `GeneratedMod.java` 全量 |
| 修改飞剑模型/姿态/拖尾 | `client/ControlledSwordRenderer.java`, `client/FlyingSwordItemRenderer.java` | `client/SwordHeldTransforms.java`, `client/FlyingSwordEffects.java`, `client/TrailShaderBridge.java`, `assets/.../shaders` | 服务端修炼逻辑 |
| 新增一把可御剑的剑 | `WuXingItems.java` + `items/SpiritSwordItem.java` | `yujian/FlyingSwordRegistry.java`, `yujian/SwordProfile.java`, 模型/语言/配方 | 所有御剑类 |
| 修改功法 | `ArtCatalog.java` | `Network.executeArt`, `items/ArtManualItem.java`, `client/Art*Screen.java` | 神通状态机 |
| 修改神通 | `DivineArtCatalog.java`, `DivineArtLogic.java` | `TransformAbilityRegistry.java`, `TimeStopManager.java`, `Network` Divine/Transform 包 | 普通功法实现 |
| 修改筋斗云体积特效 | `client/JindouCloudRenderer.java`, `client/JindouCloudShader.java` | `client/JindouCloudRenderState.java`, `client/JindouCloudTrailCache.java`, `client/JindouCloudPlayerPose.java`, `JindouCloudConfig.java`, `assets/wuxingxiantu/shaders/core/jindou_cloud.*` | 飞行规则、御剑 Roll/Bank、Photon 全管线 |
| 修改七十二变/移魂寄魄 | `TransformAbilityRegistry.java`, `DivineArtLogic.java` | `client/ModClientEvents.java`, `client/TransformSelectionScreen.java`, `PossessionGroundMovement.java` | 炼丹 |
| 修改时间停止 | `TimeStopManager.java` | `DivineArtLogic.java`, `client/TimeStopOverlay.java`, `assets/.../shaders/post/time_stop.json` | 世界生成 |
| 修改渡劫 | `TribulationManager.java` | `HeartDemonEntity.java`, `Network.Tribulation*`, `advancements/tribulation_failure.json` | 炼器 |
| 修改心魔 | `HeartDemonEntity.java` | `TribulationManager.java`, `client/HeartDemonRenderer.java`, `registry/ModEntities.java` | 普通怪物刷怪表 |
| 修改异火瓶与培养 | `fire/FireBottleData.java`, `fire/FireEvolution.java`, `fire/FireRefinement.java` | `fire/FireCatalog.java`, `Network.tickAlchemy`, `items/FireSeedItem.java` | 玩家全局药力字段 |
| 修改天然异火源 | `fire/ExoticFireSourceBlock.java`, `fire/ExoticFireSourceFeature.java`, `fire/FireLightningEvents.java` | `registry/ModFeatures.java`, `fire_source_*` 数据 | 普通 `FireBlock` |
| 修改灵力附魔 | `SpiritEnchantment.java`, `SpiritEnchantmentLogic.java` | `GeneratedMod.java` 相关事件钩子 | UI |
| 修改魂珠/拘魂珠 | `SoulPearlData.java` | `items/Soul*PearlItem.java`, `SpiritMerchant.java`, `SoulTrade*` | 人皇幡渲染 |
| 修改人皇幡 | `items/HumanEmperorBannerItem.java` | `HumanEmperorBannerMenu.java`, Stand 方块/BE, `Network` Banner 包, `client/HumanEmperorBanner*` | 普通剑逻辑 |
| 修改炼魂炉/化魄炉 | `SoulFurnaceBlockEntity.java` | `SoulFurnaceBlock.java`, `SoulFurnaceMenu.java`, `client/SoulFurnaceScreen.java` | 炼丹炉 |
| 修改愈魂室 | `SoulHealingRoomBlockEntity.java` | Block/Menu/Screen 对应类 | 炼魂炉内部 |
| 修改符箓 | `TalismanCatalog.java`, `TalismanPlatformBlockEntity.java` | `TalismanData.java`, `TalismanKnowledge.java`, `Network.Talisman*`, `client/TalismanPlatformScreen.java` | 普通配方全表 |
| 修改村民职业/交易 | `WuXingProfessions.java`, `SpiritTradeEvents.java` | `TaoistEvents.java`, `SpiritMerchant.java` | 世界生成 |
| 修改灵岛/灵祠 | `SpiritShrineManager.java` | `SpiritShrineLocations.java`, `structures/spirit_shrine_island.nbt`, `ModCommands.locateSpiritShrine` | Forge structure_set（这里不是标准结构集） |
| 修改矿物/龙鳞草/灵液湖生成 | `data/wuxingxiantu/worldgen/*` | `data/wuxingxiantu/forge/biome_modifier/*`, `registry/ModFeatures.java`, `SpiritLiquidLakeFeature.java` | 灵祠 NBT |
| 修改灵液 | `registry/ModFluids.java`, `SpiritLiquidBlock.java` | `WuXingFluids.java`, 灵液容器 Item, `SpiritLiquidLakeFeature.java` | 异火 |
| 修改交易/掉落/获取方式 | `GeneratedMod.java` 事件 + `SpiritTradeEvents.java` + `data/.../loot_tables` + `data/.../recipes` | 具体物品类 | 客户端 |
| 修改主修仙 UI | `client/CultivationMainScreen.java`, `client/CultivationPageRegistry.java` | `CultivationVisionPage`, `CultivationArtsPage`, `CultivationSwordPage`, `CultivationUi` | 服务端大文件 |
| 修改 HUD | `client/WuXingClient.java`, `HudConfig.java` | `client/CultivationUi.java` | Network 全文件 |
| 修改按键 | `client/WuXingKeybinds.java` | `Network.java` 对应包, `client/YujianClientController.java` | 注册物品 |
| 新增网络包 | `Network.java` 的 `register()` | `client/WuXingClientPackets.java`（S2C） | 先改 UI |
| 查管理员测试指令 | `ModCommands.java` | 对应系统类 | 数据包 |
| Jade 显示 | `src/jade/.../CauldronJadePlugin.java` | `build.gradle` 中 Jade sourceSet | 主资源 |

---

## 2. 工程骨架与权威入口

### 2.1 基本工程

- Gradle：`build.gradle`
- 版本：`1.0.0-r3`（build.gradle `version`，平台每轮递增 `-rN` 后缀）
- Forge：`net.minecraftforge:forge:1.20.1-47.4.0`
- Java：17
- Mod ID：`wuxingxiantu`
- 主包：`cn.blockforge.generated.generatedmod`
- 主类：`src/main/java/cn/blockforge/generated/generatedmod/GeneratedMod.java`
- 元数据：`src/main/resources/META-INF/mods.toml`

### 2.2 `GeneratedMod.java` 什么时候读

这是**总事件入口**，但有 1563 行，不应每个任务都全读。只在以下情况打开对应方法附近：

- 注册/初始化：构造函数、`commonSetup()`
- 玩家能力挂载/克隆/登录：`attachCapabilities`, `clonePlayer`, `playerLogin`
- 方块放置触发多方块结构：`refiningForgePlace`, `alchemyFurnacePlace`, neighbor 事件
- 生物死亡/战利品/功德/修为：`livingDeath`, `replaceMonsterXpWithSpiritOrb`
- 箱子注入：`injectChestInsight`, `injectDivineInheritance`
- 五行材料来源：`fishing`, `smeltOre`, `breakBlock`
- 右键物品/方块/实体：`rightClickItem`, `rightClickBlock`, `rightClickEntity`
- 变身阵营与伤害：`transformedTargeting`, `livingAttack`, `attackEntity`, `transformDamageImmunity`
- 每服 Tick：`serverTick`, `tickPlayer`, `updateFlight`
- 灵液物品转换：`tickSpiritLiquidConversion`
- 灵潮/灵暴：`isSpiritTide`, `isSpiritStorm`

**原则**：若任务属于一个已有独立 subsystem（炼丹、御剑、魂魄等），先读 subsystem 类，只有发现它通过 Forge 事件接入时再来 `GeneratedMod`。

### 2.3 注册类

| 注册对象 | 权威文件 |
|---|---|
| Item | `WuXingItems.java` |
| Block + 大量 BlockItem | `WuXingBlocks.java` |
| EntityType | `registry/ModEntities.java` |
| BlockEntityType | `registry/ModBlockEntities.java` |
| MenuType | `registry/ModMenus.java` |
| Feature | `registry/ModFeatures.java` |
| Fluid / FluidType | `registry/ModFluids.java`（`WuXingFluids` 是兼容/转发层） |
| RecipeType / Serializer | `registry/ModRecipes.java`（`WuXingRecipes` 是兼容/转发层） |
| Creative Tab | `registry/ModTabs.java`（`WuXingCreativeTabs` 是兼容/转发层） |
| MobEffect | `ModEffects.java` |
| Particle | `ModParticles.java` |
| Sound | `ModSounds.java` |
| Enchantment | `SpiritEnchantment.java` |
| Villager POI/Profession | `WuXingProfessions.java` |

---

## 3. 玩家修炼数据：全项目最重要的数据源

### 核心链

`CultivationCapability` → `CultivationData`（接口） → `CultivationDataImpl`（存档实现） → `GeneratedMod.sync()` → `Network.SyncPacket` → 客户端 UI。

### 核心文件

- `CultivationCapability.java`：Forge Capability provider/instance。
- `CultivationData.java`：**所有玩家修炼字段的契约**；新增字段首先在这里定义。
- `CultivationDataImpl.java`：字段存储、校验、`serializeNBT()/deserializeNBT()`。
- `GeneratedMod.java`：能力挂载、死亡克隆、登录同步、服务端 Tick。
- `Network.java`：`SyncPacket` 编解码与同步；神通还有独立 `DivineSyncPacket`。

### 当前数据大类

`CultivationData` 当前覆盖：

- current/max mana（旧 aura 接口兼容）
- 境界、阶段、修为、功德、鬼仙状态、阳神纯度
- 五行灵根 mask + 五种品质
- 道心、修炼次数、灵气加成、心得
- 洞府位置/等级、交易次数
- 打坐位置/品级、经脉状态
- 渡劫次数/失败次数
- 混沌灵根、创造赐福
- 天雷灵根解锁/显化、异火灵根解锁/显化
- 五行领域开关与相关 cooldown
- 动物击杀统计
- 体质
- 心法（已学 + 当前）
- 普通功法（已学、8 槽、冷却、熟练度）
- 神通（已学、装备槽、活动神通、冷却、踏罡状态）
- 七十二变已收录形态/当前形态
- 已学习异火/当前装备异火

### 新增玩家永久字段时必须一起检查

1. `CultivationData` getter/setter。
2. `CultivationDataImpl` 字段与校验。
3. `serializeNBT()` / `deserializeNBT()`。
4. 若客户端要显示：`Network.SyncPacket` 的 record 字段、`encode/decode/handle`。
5. `GeneratedMod.clonePlayer()` 是否自动复制（当前整体 NBT 复制链通常会覆盖）。
6. UI 的 `ClientPacketSink` / 客户端缓存是否需要扩展。

---

## 4. 修炼、境界、灵力、灵根与体质

### 4.1 数值规则

**主文件：`items/CultivationLogic.java`**（约 727 行）。

关键入口：

- `baseAura()`：境界基础灵力上限表。
- `cultivationCap()` / `breakthroughRequirement()`：修为阶段需求。
- `breakthroughAuraCost()`：突破灵力成本。
- `gainCultivationAndAura()`：统一获得修为/灵力。
- `killCultivationReward()` / `killManaReward()`：击杀收益。
- `meditationCultivationReward()` / `meditationAuraReward()`：打坐收益。
- `unlockedArtSlots()`：普通功法槽位数。
- `daoXinMultiplier()`：道心倍率。
- `manaRegenPerSecond()` / `tickManaRegen()`：回灵。
- `applyHealthBonus()`：境界属性加成。
- `environmentMultiplier()`：洞府/阵法/环境修炼倍率。
- `refreshChaosRoot()` / `applyRootEffects()`：灵根状态。
- `refreshDomainBuffs()`：五行领域总入口。
- `addThunderStrike()`：木→天雷变异计数。
- `thunderDomain`, `exoticFireDomain`, `tideDomain`, `gravityDomain`：变异/五行领域效果。
- `tickWaterWalking()`：水领域水面行动。

### 4.2 体质

- `PhysiqueType.java`：八种体质枚举与 ID。
- `items/PhysiqueLogic.java`：属性 modifier、灵力倍率、回复倍率、每 tick 体质效果。
- `items/PhysiqueResetPillItem.java`：洗经伐髓丹随机重置入口。

### 4.3 灵根觉醒

- `alchemy/PillData.java`、`PillEffects.java`：单一灵根丹的 Element / Grade 解码与效果。
- `WuXingItems.java`：正式 `root_awakening_pill`；第十批已删除旧五行 × 4 注册，改由 NBT 读取前迁移。
- `data/wuxingxiantu/recipes/alchemy_root_*`：20 个炼丹配方。
- `Network.RootFormPacket`：天雷/异火等形态切换。
- `Network.WoodDomainPacket` / `FireDomainPacket` / `GoldDomainPacket` / `WaterDomainPacket` / `EarthDomainPacket`：领域开关。
- `ModEffects.java`：领域 HUD/状态效果；数值仍由 `CultivationLogic` 驱动。

### 4.4 丹药公共逻辑

- `alchemy/PillCatalog.java`：17 个正式类型、使用门槛类别、知识来源。
- `alchemy/PillData.java`：Grade / Element / CultivationTier、旧 ID 解码与迁移。
- `alchemy/PillEffects.java`：统一且有界的栈级药效；原有类的兼容对象也走这里。
- `alchemy/FormulaKnowledge.java`、`FormulaItem.java`：个人持久化知识、进度解锁、丹方卷轴。
- `items/BasePillItem.java`：食用前和完成时二次服务端门槛、成功后才消耗。
- `items/HealingPillItem.java`、`SmallBreakthroughPillItem.java`、`EffectPillItem.java`：历史类定义；第十批正式丹药均改由 UnifiedPillItem 注册，不再创建旧品质对象。
- `items/BreakthroughPillItem.java`：妖兽内丹直接使用入口；引劫品阶与掉落共享 `TribulationManager.requiredCoreIndex`。
- `items/CreationPillItem.java`：创造丹特殊永久状态。

### 4.5 统一进度门槛（ProgressionGate）

**`ProgressionGate.java` 是全项目境界资格的唯一权威层**（375 行）。所有系统（功法、心法、丹药、灵根、异火、设施、灵剑、御剑、剑诀、符箓、魂魄）在使用时的境界判定都必须走这里，禁止在 Item/BlockEntity/Packet/Event 中重新硬编码境界数字。

设计原则（改动前先读类头 Javadoc）：

- **“获得”与“使用”分离**：高阶资源允许持有/收藏/交易/展示；只有实际动用时校验操作者本人进度。
- **只读判定、无副作用**：客户端可用于 UI 提示，但权威调用必须在服务端；不信任玩家输入。
- **旧存档兼容**：不删除已学/已掌握数据，仅使用时复核，条件恢复后自动生效（`effectiveHeartMethod` / `effectiveFire` 按“未装备”降级结算）。
- **创造模式旁路**：玩家形式接口可旁路境界；`canUseFire` 始终先验证本人学习记录。

集中配置表（品级→最低境界都在本类字段里，调数值只改这里）：

- 功法 `ART_TIER_REALM`（下标 1..4 = 黄/玄/地/天：练气/练气/筑基/金丹；`ART_OVERRIDES` 单独覆盖，如御剑凌霄诀=金丹）
- 心法 `HEART_METHOD_REALM`（10 部逐一列出）
- 灵根品质/丹药 `ROOT_QUALITY_REALM`（下品→极品对应练气→元婴）
- 异火 `fire/FireCatalog`（1-9 阶，练气→地仙），仍通过 ProgressionGate 对外检查。
- 炼丹炉 `FURNACE_TIER_REALM`；炼器台按火候折算 `requiredRealmForRefiningTemperature()`
- 灵剑 `SWORD_TIER_REALM`（tier 0-7）；御剑绝对门槛 `YUJIAN_MINIMUM_REALM=金丹` + 所执剑境界取大；近战直击伤害压制由 `GeneratedMod.applySwordSuppression` 在 `livingHurt` 复核
- 符箓 `TALISMAN_QUALITY_REALM`；魂魄 `SOUL_FEATURE_REALM`（capture/binding/utility/banner/furnace）
- 天雷灵根 `THUNDER_ROOT_*`、异火灵根 `EXOTIC_ROOT_*` 解锁/显化条件

异火实际使用统一走 `canUseFire(Player/CultivationData, tier)`：数据存在、合法品阶 1..9、
本人已学习、境界达标。`effectiveFire` 复用数据形式接口，战斗加成和打火石随之复核。
`canRefineFire` 走只检查品阶/境界的 `meetsFireRealmRequirement`，允许首次学习。
`AlchemyPacket`、`RefiningPacket`、`FireSelectPacket` 在消耗或状态变更前检查实际操作者，
`EternalSpiritCoalBlock.placeExoticFire` 也在服务端检查；失败由 `denyFireUse` 区分未掌握与境界不足。
其它拒绝提示走 `deny(player, MSG_*, requiredRealm)`；lang 键族 `message.wuxingxiantu.gate.*` 为中英双语。

---

## 5. 打坐、洞府、聚灵与灵蕴台

### 打坐/修炼方块

- `CultivationBlock.java`：聚灵、洞府标记、打坐类轻量功能方块；`startMeditation()/stopMeditation()`。
- `MeditationSeatEntity.java`：隐形座位实体。
- `client/MeditationSeatRenderer.java`：座位不画几何体。
- `client/MeditationModels.java`：打坐四肢模型替换。
- `client/MeditationAura.java`：程序化灵气圆盘/丝带表现。

### 洞府令牌

- `CaveTokenBlock.java`：令牌方块。
- `CaveTokenLocations.java`：**按维度 SavedData 存洞府令牌 + 强加载 + 刷怪保护查询**。
- `GeneratedMod.commonSetup()`：注册强加载 callback。
- `GeneratedMod.spawnCheck()`：洞府区域刷怪限制。
- `CultivationLogic.isInCave()/isWithinCave()`：修炼倍率读取洞府范围。

### 灵蕴台悬浮蕴养（第三批扩展）

- `SpiritPlatformBlock.java` / `SpiritPlatformBlockEntity.java`：吸收附近灵石块、积累 aura、转换浮动物品。
- `SpiritPlatformConversions.java`：轻量集中表，定义输入、输出、`requiredAura` 与完成特效。
  当前仅四项：骨粉→灵肥（8）、泥土→灵壤（24）、灵煤→永燃灵煤（99）、灵煤块→永燃灵煤块（99）。
  8/24 是临时平衡值，后续只在此调整；使用懒加载物品供应器，避免注册完成前取值。
- 没有 GUI：右键放入 1 个，悬浮旋转展示，再右键取出。`PedestalFloatingRenderer` 不变。
- 每 40 tick 吸收同高度 X/Z±3 格内灵石块，每块 1 灵气，成功替换为普通石头后才记账。
  有可蕴养材料时本次只吸收到该项所需灵气；空台/普通展示物保留原有蓄能，容量仍为 99。
  `MAX_AURA` 只是存储上限，转换按 `requiredAura` 扣费并保留余量。
- `Aura` / `FloatingItem` / `DisplayUUID` 存档键、旧 ItemDisplay 迁移、单槽存储和同步包保留。
  原永燃灵煤完成特效保留；骨粉和泥土使用附魔/蓝色灵气粒子与紫水晶音效。
- 灵液加工与灵蕴台蕴养并行：`GeneratedMod.tickSpiritLiquidConversion` 保留煤炭/煤炭块
  10 秒浸泡转灵煤/灵煤块，以及骨粉 3 秒、每源最多 8 份转灵肥的规则。
  两条灵肥路线都使用 `WuXingItems.SPIRIT_FERTILIZER`；没有新增灵壤等级。
- 后续配方仍可能调整，本轮没有新增 RecipeType、菜单、灵石物品槽或 FE/RF 能源。
- `ChenghuaPedestalBlock(.java/.BlockEntity.java)`：承华台/浮动物品基座。
- `FloatingItemHolder.java`, `PedestalContainer.java`：浮动物品与多基座容器抽象。
- `items/EternalSpiritCoalItem.java`, `items/EternalSpiritCoalBlockItem.java`：永燃灵煤燃料规则。

---

## 6. 炼丹系统

### 服务端权威链

`AlchemyFurnaceBlock` → `AlchemyFurnaceStructure` → `AlchemyFurnaceBlockEntity` → `AlchemyRecipe` → `Network.AlchemyPacket` / `Network.tickAlchemy()`。

### 文件职责

- `AlchemyFurnaceBlock.java`：炉阶、交互、打开菜单、放置/移除。
- `AlchemyFurnaceStructure.java`：**5×5×4 多方块蓝图**、匹配、隐藏/恢复组件、拆解。
- `AlchemyFurnacePartBlock.java` / `AlchemyFurnacePartEntity.java`：成型后隐藏材质方块并保存原状态。
- `AlchemyFurnaceBlockEntity.java`：8 材料槽 + 1 引火槽；炼制状态、开始/结束 Tick、引火品阶、库存。
- `AlchemyFurnaceMenu.java`：容器与同步数据；使用 `AlchemyUiLayout` 的逻辑像素坐标，向客户端同步炉阶、异火品阶、进度、配方索引和状态。
- `AlchemyRecipe.java`：自定义配方，含 formula_id、result_grade、minimum_realm、furnace_tier、min_fire_tier / required_fire、aura_cost、time、fire_essence_multiplier；消费返回实际材料快照。
- `registry/ModRecipes.java`：炼丹 RecipeType/Serializer。
- `Network.java`：`AlchemyPacket`, `PendingAlchemy`, `tickAlchemy()`, `cancelAlchemyAt()`。
- `client/AlchemyScreen.java`：参考图界面；背景、槽位皮肤、进度条和按钮分离，所有物品槽仍由原生 `Slot` 渲染，面板采用统一等比缩放。
- `AlchemyUiLayout.java`：炼丹炉界面逻辑坐标单一来源，供 Menu、Screen 和离线资源生成器共同校准。
- `client/AlchemyFurnaceBlockEntityRenderer.java`：炉体动态渲染。
- `client/CauldronStructureVisuals.java`：结构视觉辅助。

### 数据文件

- 自定义炼丹配方共 116 条，覆盖 17 类丹药；全表见 `PILL_RECIPE_AUDIT.md`。旧 breakthrough_pill_* 文件已改为炼丹炉配方。
- 普通炼丹炉本体合成仍在同一 recipes 目录，例如 `alchemy_furnace*.json`。

### 修改指引

- 改炼丹时间/灵力消耗/炉阶要求：优先改对应 JSON；不要硬编码到 Screen。
- 开始任务保存炉体、原火瓶引用、BottleId、fire_id 阶位和实际药性贡献；产物生成成功后才向同一瓶写回。任何失败不发药力。
- `AlchemyFurnaceMenu.clickMenuButton` 服务端处理配方切换；新增知识、境界及异火拒绝状态。不要依赖客户端按钮保障权限。
- 改输入槽数量：必须同时改 `AlchemyFurnaceBlockEntity`、Menu、Screen、Recipe 匹配逻辑。
- 改结构：只改模型没用，必须改 `AlchemyFurnaceStructure.expected()/accepts()`，并复核拆解恢复。
- 改客户端进度：服务端仍以 BE 的 start/finish tick 为真值。

---

## 7. 炼器系统

### 权威链

`RefiningForgeBlock` → `RefiningForgeStructure` → `RefiningForgeBlockEntity` → `RefiningRecipe` → `Network.RefiningPacket`。

### 核心文件

- `RefiningForgeBlock.java`：核心方块、温度、点亮状态、打开逻辑。
- `RefiningForgeStructure.java`：结构识别、成型 transform、还原 revert、塌陷。
- `RefiningForgeCornerBlock.java`, `RuneStoneBlock.java`：结构组件。
- `RefiningForgeBlockEntity.java`：炼制计时、待领取产物。
- `RefiningRecipe.java`：材料数量、`auraCost`、`craftTime`、`temperature`。
- `Network.RefiningPacket`：开始炼制；`CollectRefiningPacket`：领取产物。
- `client/RefiningForgeScreen.java`：主界面（当前较大，约 678 行）。
- `client/RefiningForgeBlockEntityRenderer.java`：结构渲染。

### 配方

`src/main/resources/data/wuxingxiantu/recipes/refining_*.json` 当前 7 个自定义炼器配方：

- azure steel sword
- big dipper sword
- dark iron sword
- demon slayer sword
- pure yang sword
- tiangang sword
- xuanyuan sword

### 新增炼器剑的最短路径

1. `WuXingItems.java` 注册剑（通常 `SpiritSwordItem`）。
2. 资源：语言、item model/texture。
3. 普通原料/设施配方（需要时）。
4. 新建 `refining_xxx.json`。
5. 若要支持御剑，继续登记 `FlyingSwordRegistry` / profile；见第 12 节。

---

## 8. 符箓系统

### 三台工作台

`TalismanPlatformBlockEntity.Kind`：`ENGRAVE`（镌印）、`DRAW`（绘制）、`RUB`（拓印）。

### 核心文件

- `TalismanCatalog.java`：**符箓图案、评分、品质阈值、灵力成本、效果实现的中心目录**；16×32 画布。
- `TalismanData.java`：符/印章 NBT 数据读写。
- `TalismanKnowledge.java`：玩家是否获得画符权限。
- `TalismanPlatformBlock.java`：三种平台方块逻辑。
- `TalismanPlatformBlockEntity.java`：三类工作台槽位布局与选中页。
- `TalismanPlatformMenu.java`：服务器容器槽位。
- `client/TalismanPlatformScreen.java`：绘制、拖动、画布与界面。
- `items/TalismanItem.java`：成品符箓使用。
- `items/SealItem.java`：印章。
- `items/CarvingKnifeItem.java`：刻刀。
- `items/WanfaGuizongItem.java`：《万法归宗》解锁画符。
- `Network.TalismanSubmitPacket` / `TalismanRubPacket` / `TalismanSelectPacket`：提交绘制、拓印、切页。
- `TaoistEvents.java`：道士出售随机符/印章，且防僵尸感染。
- `SpiritTradeEvents.addTaoistTrades()`：道士交易表。

### 新增一种符箓

优先在 `TalismanCatalog` 增加条目（ID、glyph、Effect、score/target），再补语言键。若使用现有六类 Effect，通常不需要新增网络包；若是全新行为，再扩 `effect()` 分支。

---

## 9. 普通功法、心法、剑技

### 普通功法

- `ArtCatalog.java`：普通功法 ID、品阶、类型、灵力成本、冷却、伤害/治疗、熟练度显示。
- `items/ArtManualItem.java`：右键学习并自动装备空槽。
- `Network.EquipArtPacket`：装备。
- `Network.ArtReleasePacket` + `Network.executeArt()`：**服务端实际释放普通功法**。
- `client/ArtWheelScreen.java`：配置轮盘。
- `client/ArtRadialScreen.java`：释放界面。
- `client/CultivationArtsPage.java`：修仙 UI 的功法页。

当前 `ArtCatalog` 还包含御剑剑系功法 ID；真正属于剑技/御剑动作的分支会转到 `SwordTechniqueManager` / `YujianController`。

### 心法

- `HeartMethodCatalog.java`：10 个心法 ID + 名称/描述键。
- `items/HeartMethodItem.java`：心法秘籍物品。
- `Network.SelectHeartMethodPacket`：切换当前心法。
- `client/HeartMethodScreen.java`：选择界面。
- 实际倍率通常回到 `CultivationLogic` 或具体系统查询当前心法。

### 剑技桥接

- `SwordTechniqueManager.java`：识别/释放剑技，桥到 `YujianController`。
- `yujian/SwordTechniqueRegistry.java`：剑技学习条件、剑品阶/剑蕴门槛。
- `yujian/SwordNurture.java`：当前选剑、战斗触发、释放、迁移旧数据。

---

## 10. 神通、七十二变、移魂寄魄、时间停止

### 神通目录与学习

- `DivineArtCatalog.java`：7 个神通及 requiredRealm/cooldown/itemId。
- `items/DivineManualItem.java`：传承物品学习入口。
- `DivineArtLogic.java`：**神通服务端状态机**，约 1085 行；处理释放、持续消耗、状态恢复、踏罡七星、元神、寄魄、七十二变等。
- `ModEffects.java`：法天象地、元神出窍、移魂寄魄等 MobEffect。
- `Network.EquipDivineArtPacket`, `DivineReleasePacket`, `DivineSyncPacket`, `DivineArtBannerPacket`。
- `client/DivineArtBanner.java`：发动文字提示。
- 筋斗云视觉链：`DivineArtLogic.emitCloud/stop` → `Network.CloudVisualPacket` → `ClientPacketSink` → `WuXingClientPackets` → `JindouCloudRenderState`。`JindouCloudRenderer` 在 AFTER_PARTICLES 保存正确世界矩阵，在 AFTER_LEVEL 合成主体和体积拖尾，禁止使用 AFTER_LEVEL 的投影 PoseStack 作为视图矩阵。玩家位置使用 xOld/yOld/zOld 插值；Shader 中相机和云位置使用同一个 256 格世界原点。
- `JindouCloudTrailCache`：按 tick/距离保存世界轨迹，高速补点，限长限时；关闭神通/卸载/切世界/瞬移清理，停止移动时只补齐最后一个移动端点，旧轨迹继续按年龄消散。每个样本保存出生位置、时间、速度和宽度/密度配置快照；另保存平滑运动量与累计位移平流相位。朝向取真实水平位移，按最短角差平滑并限制每 tick 18 度，再做 partial tick 角度插值，停下后继续平滑收敛。
- 第八版 `JindouCloudRenderer` 的 5×32 RGBA32F 数值纹理传曲线两端位置/年龄、出生速度/寿命、出生宽度/密度及世界控制点。端点取相邻历史点中点，控制点取原历史点；GLSL `curveParameter` / `curvePoint` 求二次曲线上的最近点，相邻段位置与切线连续。`Point.lifetime` 在出生时取 min(maxTrailLifetime, wakeTravelDistance / speed)，默认中心轨迹约 5 格；停止后寿命不受当前速度影响。Java 和 GLSL 都跳过已到期段，高速采样结合出生寿命和点数预算。
- 第七版历史密度取同一 `cloudShape` 的中央宽截面，覆盖主体直径，沿曲线作体积延续。历史截面与当前速度、距当前头部的路径长度解耦，年龄只用于密度衰减、侵蚀和最多 12% 扩散。`HistoryNoiseOrigin` 在 Java 双精度世界坐标中按 10 单位周期取模，Shader 用逆朝向还原世界轴采样；`HistoryDetailOffset` 独立于主体运动平流，转身不会带动历史噪声旋转。只有一个体积材质和一次透明合成，Shader 合并射线区间并跳过空隙；包围盒含曲线控制点，数值纹理随世界切换释放。
- 第八版 `cloudShape` 改为极坐标圆润体积与 1/3/5 阶低频边缘翻涌，移除四角密度云瓣造成的方形。`FlowPhase` 提供 11/17/23 秒连续相位；主体 `stretchRear` 在有无历史时都按平滑运动量产生有限的后向梨形过渡。光照用局部密度/高度的散射近似，移除每步最多三次全尾流阴影重追踪；噪声仅在有效体积内采样。保守积分盒不参与可见轮廓塑形，纵向厚度和中央包脚保留。
- `JindouCloudPlayerPose`：通过现有 `MeditationModels.SeatedPlayer.setupAnim` 固定站姿，Post/下一帧恢复腿、双臂及对应衣袖/裤腿。动画入口清除普通走路和待机摆动输入，临时禁用蹲伏、骑乘和游泳模型姿态。第五版在 setupAnim 和 bodyParts 绘制前固定非主动状态的 EMPTY/ITEM 双臂，攻击、使用物品、双手及自定义 ArmPose 保持优先级。御剑姿态入口排除筋斗云，不能复用御剑旋转。
- `JindouCloudConfig`：`wuxingxiantu-cloud-client.toml` 中的尺寸、Y 偏移、密度、光照、软交界、第一人称、拖尾、瞬移阈值。无独立筋斗云实体。视觉包仍只广播 UUID 和显示状态，本轮未改飞行规则或协议；沿用版本 47。
- 保留 `restoredBody*`、`verticalFullness` 与 `footEnvelopment` 配置，新增 `wakeTravelDistance`（默认 5）。当前默认渲染半径为 (2.025, 0.9522, 1.575)，Y 偏移约 -0.36044。禁止使用云图、sprite、billboard 或独立 ribbon 替代筋斗云体积。近/中/远采样基准为 32/24/20，长路径最多 104 步并跳过空白区间。
- `textures/effect/jindou_worley.png`：本模组生成的周期性 3D Worley 切片图集，生成脚本 `tools/generate_jindou_noise.cjs`。不需要外部光影包。

### 七十二变 / 变身能力

- `TransformAbilityRegistry.java`：**形态合法性、阵营、形态专属主动技能、抗性、冷却**。
- `DivineArtLogic`：形态收录、切换、寄魄宿主状态管理。
- `PossessionGroundMovement.java`：AI disabled 宿主的地面运动。
- `client/TransformSelectionScreen.java`：形态选择。
- `client/ModClientEvents.java`：大量七十二变模型替代、帽子隐藏、伪装实体维护。
- `client/WuXingKeybinds.java`：寄魄攻击/交互输入。
- Network Transform 系列包：`TransformCyclePacket`, `TransformAbilityPacket`, `TransformCreeperReleasePacket`, `TransformSelectPacket`, `TransformCancelPacket`, `PossessTargetPacket`, `TransformAttackPacket`, `PossessionInputPacket`。

### 时间停止 / 光阴梭

- `TimeStopManager.java`：服务端冻结实体、伤害屏蔽、维度切换与恢复。
- `DivineArtLogic`：神通释放/结束入口。
- `client/TimeStopOverlay.java`：后处理管理。
- `assets/wuxingxiantu/shaders/post/time_stop.json`
- `assets/wuxingxiantu/shaders/program/time_stop.{json,fsh}`

**注意**：时间停止规则与画面滤镜完全分层；改灰度画面不要碰冻结规则，改冻结规则不要只改 shader。

---

## 11. 渡劫与心魔

### 渡劫

- `TribulationManager.java`：**服务器权威流程**：`canStart()` → `start()` → `tick()` → 雷击 → 心魔/成功/失败。
- `Network.TribulationPacket`：玩家请求。
- `Network.TribulationStatePacket`：客户端倒计时/状态。
- `GeneratedMod.livingDeath()`：把死亡事件交给渡劫管理器。
- `data/wuxingxiantu/advancements/tribulation_failure.json`：失败进度。

关键方法：`start`, `strike`, `finishSuccess`, `finishFailure`, `applySpectatorFear`, `onLivingDeath`。

### 心魔

- `HeartDemonEntity.java`：属性、目标、主人绑定、复制玩家状态、BossBar、死亡回调。
- `registry/ModEntities.HEART_DEMON`：实体类型。
- `client/HeartDemonRenderer.java`：玩家身形渲染。
- `items/HeartDemonSpawnEggItem.java`：调试/物品方式生成并绑定使用者。

**不要把心魔自然生成逻辑放进 SpawnPlacement**：当前正常玩法入口是渡劫系统主动创建。

---

## 12. 御剑飞行与本命灵剑

这是工程里最独立、最值得按子系统导航的一套代码。

### 服务端权威

- `yujian/YujianController.java`：**总控制器**；召剑、骑乘、状态机、轨迹、碰撞伤害、剑技、防御。
- `yujian/ControlledSwordEntity.java`：场上飞剑实体；同步 item、owner、roll/bank/speed/state 等。
- `yujian/FlyingSwordState.java`：明确飞行状态机 enum。
- `yujian/FlyingSwordRegistry.java`：每种剑的定义注册；新增剑通常不需要新 Controller。
- `yujian/FlyingSwordDefinition.java`：单剑调参 record。
- `yujian/SwordProfile.java`：剑品阶、最大剑蕴、技能槽、基础飞行属性。
- `yujian/FlyingSwordConfig.java`：server movement 配置 + client camera/trail 配置。
- `yujian/FlightFrame.java`：剑体坐标约定（+Z 刃方向，+Y deck normal）。
- `yujian/FormationGeometry.java`：编队/召回路径和站位。
- `yujian/FormationMode.java`：编队模式。
- `yujian/ManualRoll.java`：手动翻滚累计与回正。
- `yujian/FlightFeedbackEvent.java`：服务端声音/效果扩展钩子。

### 灵剑物品与养成

- `items/SpiritSwordItem.java`：剑灵力、击杀、炼化次数、剑蕴 NBT；不负责脱手实体运动。
- `yujian/NurtureData.java`：单把 ItemStack 的剑蕴经验/阶段/洞察/已学技能。
- `yujian/SwordNurture.java`：选中剑、战斗触发、cast、迁移。
- `yujian/SwordTechniqueRegistry.java`：剑技注册与学习条件。
- `SwordTechniqueManager.java`：普通功法体系到剑技系统的桥。
- `GeneratedMod.applySwordSuppression`（`livingHurt`）：近战直击的剑阶压制。境界不足时按境界差
  衰减伤害（每差一级 ×0.70，下限 25%）并给统一提示 `gate.sword_suppress`；只处理玩家本人近战，
  不碰投射物、剑诀与异火的独立结算，创造模式旁路。

### 网络

在 `Network.java` 只搜索这些 symbol，不要全读：

- `SwordFlightPacket`
- `SwordFlightInputPacket`
- `SwordFlightStatePacket`
- `SwordNurtureActionPacket`
- `yujian/SwordRecallPacket`

### 客户端输入/镜头

- `client/YujianClientController.java`：**只负责 input/camera，不决定服务端结果**。
- `client/YujianClientCommands.java`：只改本地 client config。
- `client/WuXingKeybinds.java`：通用按键注册/触发。

### 模型/姿态/渲染

- `client/ControlledSwordRenderer.java`：飞剑实体渲染。
- `client/FlyingSwordItemRenderer.java`：BEWLR，世界显示与实体共享模型。
- `client/FlyingSwordItemModels.java`：GUI icon / 世界模型分流，`worldModel(definition)` 按物品 ID 选择 `item/<id>_flying`，手持和御剑必须使用同一入口。
- 第九版：明玦剑=`azure_steel_sword`，青冥剑=`tiangang_sword`，玄霄剑=`big_dipper_sword`。`tools/model_sources/*.bbmodel` 保存原文件，`tools/import_sword_models.py` 导出 Forge OBJ/MTL/内嵌纹理，材质 Ka 保留自发光；`tools/render_sword_models.py` 生成物品栏图标和离线预览。几何位于 `models/item/<id>/sword.obj`，统一一格长、尖端 -X、正面 +Y，柄锚点与骑乘偏移见 `tools/sword_import_report.json`。
- `-PswordModelTests runClient`：独立客户端检查真实 Forge 烘焙、纹理、发光、GUI 分流和四种手持锚点；测试代码仅在指定参数时编译。
- `client/SwordHeldTransform.java`, `SwordHeldTransforms.java`：每把剑手持姿态登记。
- `client/InterpolatedFlyingSwordTransform.java`：每 render frame 的插值根变换。
- `client/YujianRidingPose.java`：骑剑玩家站姿。
- `client/FlyingSwordEffects.java`：剑气路径/螺旋拖尾。
- `client/TrailShaderBridge.java`：保存世界深度并在合成阶段做遮挡。

### Shader

- `assets/wuxingxiantu/shaders/core/sword_trail_post.{json,vsh,fsh}`：剑气后处理路径。

### 配置文件名

运行后由 Forge 配置：

- `wuxingxiantu-flight-server.toml`
- `wuxingxiantu-flight-client.toml`

### 御剑问题排查顺序

**按键无反应**：`WuXingKeybinds` → 发送包 → `Network.SwordFlightPacket.handle` → `YujianController.beginSummon/stop`。

**能召剑不能飞**：`YujianController.tick` / `tickFlightEntity` → `FlyingSwordDefinition/Profile` → 玩家灵力/剑绑定。

**服务器飞但客户端抖**：`ControlledSwordEntity` SynchedEntityData → `InterpolatedFlyingSwordTransform` → renderer/client controller。

**模型大小/朝向错**：`FlightFrame` 坐标约定 → renderer → item model，不要先改服务端运动。

**拖尾穿墙/被 shader 覆盖**：`FlyingSwordEffects` → `TrailShaderBridge` → `sword_trail_post` shader。

---

## 13. 异火与灵力附魔

### 异火状态

- `items/FireSeedItem.java`：持续炼化、主动蜕变、NBT 动态名字和药力提示。旧 detectTier 已删除。
- `fire/FireBottleData.java`：瓶中 fire_id、八药力、BottleId、历史、配方重复衰减。药性只读 `SpiritPlantDefinition.properties`。
- `fire/FireRefinement.java`：100 tick 可中断炼化，唯一生存 learnFire 调用者；不会消耗瓶子。
- `fire/FireEvolution.java`：集中路线和条件，同栈变更、扣药力、余额保留 50%，不自动掌握。
- `fire/FireDiscovery.java`：玩家仅保存发现掩码；原 Capability 继续保存掌握/装备。
- `fire/ExoticFireSourceBlock.java`：独立非燃烧源，原子封存、不可挖掘、不掉落、浸水保持。
- `fire/ExoticFireSourceFeature.java`、`FireLightningEvents.java`：四种自然源及紫霄雷暴事件；本模组人工闪电均打排除标记。
- `fire/FireCatalog.java`：九火 ID、阶位、稀有度、境界和获取类别；新增自然来源见 `fire_source_*`。
- `ExoticFireBlock.java`：九阶独立火焰方块。
- `ExoticBurnSourceSync.contact`：首次点燃/火源品阶切换立即同步，同源每六刻刷新；熄灭清除同步节流记录。`contactTier` 按实际包围盒检测火源，覆盖脚部坐标未进入火格的边缘接触。
- `ExoticFireState.java`：**世界坐标→异火品阶的权威 API + 旧版 minecraft:fire 迁移**。
- `ExoticFireSavedData.java`：服务器持久化。
- `ExoticFireColorRegistry.java`：九阶颜色、亮度、名称。
- `SpiritFirePalette.java`：客户端/资源的灵火色盘辅助。
- `EternalSpiritCoalBlock.java`：永燃灵煤块承载独立灵火。
- `EternalSpiritFireBlock.java`：温度/颜色辅助。
- `GeneratedMod` chunk load/unload 与左键事件：恢复/扑灭状态。

### 异火客户端

- `client/SpiritFireSpriteLoader.java`：图集加载期调色。
- `client/ExoticFireOrbitRenderer.java`：玩家周身异火。
- `client/ExoticBurnRenderer.java`：异火燃烧覆盖。
- 2026-09-21 源码修复（未构建）：攻击/缠绕/领域灼烧通过 `Network.sendExoticBurnEffect` 同步至独立 `EFFECT_BURNS`，`ExoticBurnPacket.elementalEffect` 区分物理火源染色和独立元素灼烧，协议版本 48。`coremods/exotic_burn.js` 在 Dispatcher 的 `Entity.displayFireAnimation` 判断后接入 `shouldRenderFlame`，无需修改服务器原版 fire ticks 即可显示同一套火焰几何。`SpiritEnchantmentLogic` 仍独立结算元素伤害；结束、死亡、换世界清理效果，领域续时立即同步。旧版客户端/服务器不能与此协议混用。
- 第九版：`ExoticFireBlock.entityInside` 经 `ClientPacketSink.exoticFireContact` 通知客户端保存实体专属、四刻有效的接触预测；第三人称优先同步来源，其次接触预测/实际碰撞火源。无需扫描所有实体，也不使用其他实体或玩家装备的颜色兜底。`-PexoticBurnTests runClient` 在独立世界验证点燃同步、来源切换、首帧材质和普通火不染色。
- 第八版 `META-INF/coremods.json` / `coremods/exotic_burn.js`：仅在 `EntityRenderDispatcher.renderFlame` 的两次 Material.sprite 取值后调用 `ExoticBurnRenderer.worldFireSprite`。第三人称复用第一人称异火图集，优先按实体同步的点燃来源、其次按脚下异火品阶选图；无异火来源或缺失资源时返回原版素材。保留原版火焰几何与着火标记，不新增火柱或改全局火焰贴图。钩子按方法描述符定位，支持开发与 SRG 命名，目标只涉及客户端渲染类。
- `client/ExoticFire*Particle*` / `CodeFire*`：粒子。
- `ModClientEvents.replaceExoticFireParticles()`：客户端 Tick 补充/替换视觉。

### 灵力附魔

- `SpiritEnchantment.java`：7 类附魔注册和适用装备。
- `SpiritEnchantmentLogic.java`：**服务端实际效果**，包括修复、护体、汲取、轻身、御剑相关、异火缠绕伤害/燃烧。
- `GeneratedMod` 的 `livingHurt`, `livingHeal`, `livingDeath`, Tick 事件把效果接进 Forge。

---

## 14. 魂魄、拘魂珠、炼魂、愈魂与人皇幡

### 14.1 魂珠数据中心

**`SoulPearlData.java` 是所有魂珠 NBT 的中心。**

它负责：

- 判断拘魂/摄魄/万魂/灭魂/魂力珠类型。
- 拘魂珠保存村民交易 + 收藏交易。
- 摄魄珠记录 EntityType/实体 ID/经验/破碎状态。
- 万魂珠多种魂魄存储、提取、修复。
- 魂力存取。
- 创建新的 Soul Pearl ItemStack。

相关物品：

- `items/SoulBindingPearlItem.java`：捕获村民/流浪商人交易。
- `items/SoulCapturePearlItem.java`：长按灵魂射线与生物魂魄记录。
- `items/SoulPearlItem.java`：完整/破碎魂珠交互。
- `items/SoulUtilityPearlItem.java`：万魂珠/灭魂珠。
- `items/SoulEnergyPearlItem.java`：魂力容器。

### 14.2 灵魂交易

- `SpiritMerchant.java`：不依附实体的 Merchant，由拘魂珠打开。
- `SoulTradeMenu.java`：菜单。
- `client/SoulTradeScreen.java`：原版 MerchantScreen 扩展收藏星标。
- `Network.SoulTradeFavoritePacket` / `SoulTradeStatePacket`。

### 14.3 炼魂炉 / 化魄炉

- `SoulFurnaceBlock.java`：两种 Kind 共用方块类。
- `SoulFurnaceBlockEntity.java`：**实际容器和循环加工逻辑**。
- `SoulFurnaceMenu.java`：菜单。
- `client/SoulFurnaceScreen.java`：界面。
- `Network.SoulFurnaceCyclePacket`：设置加工循环。

### 14.4 愈魂室

- `SoulHealingRoomBlock.java`
- `SoulHealingRoomBlockEntity.java`：修复进度、魂力、燃料。
- `SoulHealingRoomMenu.java`
- `client/SoulHealingRoomScreen.java`

### 14.5 人皇幡

**最大核心文件：`items/HumanEmperorBannerItem.java`（约 1085 行）**。

只按具体 symbol 搜索：

- 菜单：`openMenu`, `handleMenuAction`
- 吸魂：`absorbSoulPearls`, `absorbPearlStack`, `absorbMyriadStack`
- 魂仆：`summon`, `summonOne`, `recallServants`, `tickServants`
- 死亡：`onServantDeath`, `markServantDead`
- 复活：`reviveAllDead`, `reviveSelected`
- 魂力：`soulPower`, `pourSoulPower`, `spendSoulPower`
- 战斗模式：`combatMode`, `setCombatMode`
- 龙蛋：`absorbDragonEgg`
- 状态序列：`bannerState`, `allSouls`

其它文件：

- `HumanEmperorBannerMenu.java`
- `HumanEmperorBannerStandBlock.java` / `HumanEmperorBannerPoleBlock.java`
- `HumanEmperorBannerStandBlockEntity.java`
- `client/HumanEmperorBannerScreen.java`
- `client/HumanEmperorBannerStandRenderer.java`
- `client/HumanEmperorBannerPoseModel.java`
- `client/HumanEmperorBannerFX.java`
- Network：`OpenBannerPacket`, `BannerActionPacket`, `BannerStatePacket`

---

## 15. 世界生成、资源与灵祠浮空岛

### 标准 Forge worldgen

数据路径：

- `data/wuxingxiantu/worldgen/configured_feature/`
- `data/wuxingxiantu/worldgen/placed_feature/`
- `data/wuxingxiantu/forge/biome_modifier/`

当前五组：

1. `spirit_ore`
2. `spirit_vein_ore`
3. `spirit_coal_ore`
4. `dragon_scale_grass`
5. `spirit_liquid_lake`

灵液湖 Java Feature：

- `registry/ModFeatures.java`
- `SpiritLiquidLakeFeature.java`

### 灵祠浮空岛不是标准 structure_set

不要在 `worldgen/structure_set` 里找它。当前实现：

- `SpiritShrineManager.java`：Chunk load 触发排队、自定义定位/生成、pending retry。
- `SpiritShrineLocations.java`：位置记录。
- `data/wuxingxiantu/structures/spirit_shrine_island.nbt`：结构模板。
- `ModCommands.locateSpiritShrine()`：定位指令入口。
- 生成高度/逻辑应以 `SpiritShrineManager` 为准。

如果要把它改成标准 `/locate structure` Forge 结构，需要另做 Structure/StructureSet 注册，而不是只改当前 manager。

### 桃树

- `PeachTreeGrower.java`：树苗采用原版樱花树型，仅换桃木/桃叶。
- `WuXingBlocks.java`：桃木全套 block 注册。
- 当前自然 worldgen 是否存在应查 `data/worldgen`；本导航不把树苗 grower 等同于自然生成。

---

## 16. 灵液与流体

- `registry/ModFluids.java`：FluidType + Source + Flowing 注册。
- `WuXingFluids.java`：兼容/转发层。
- `SpiritLiquidFluidType.java`：流体类型表现/性质。
- `SpiritLiquidBlock.java`：流体方块行为。
- `SpiritLiquidLakeFeature.java`：世界湖泊。
- `items/SpiritLiquidBucketItem.java`：放置灵液源。
- `items/SpiritLiquidDrinkItem.java`：饮用基类。
- `items/SpiritLiquidPotItem.java` / `EmptySpiritLiquidPotItem.java`：壶装取用。
- `GeneratedMod.tickSpiritLiquidConversion()`：掉落物浸泡转换逻辑（煤炭→灵煤，骨粉→灵肥）。

---

## 16.5 灵植生态系统（第二批）

统一框架，14 株灵植共用同一套方块/物品/事件逻辑，行为差异全部来自数据字段，**禁止**再写
`if (plant == A) ... else if (plant == B)` 式散落分支。

- `plants/SpiritPlantDefinition.java`：一种灵植的全部静态数据（稀有度、基质、硬条件、
  生长偏好 `Preference`、灵肥推进数、骨粉可用性、药性 `HerbProperty`）。
  - `canPlaceAt`：种植/存活硬条件唯一入口（基质 + 水体）。玄水藻=`isWaterlogged(self)` 完全浸水，
    清心莲=本格浸润或脚下水源；两者都**不再接受“仅相邻有水”**，干燥岸边不可种沉水藻。
  - `growthOneIn`：本随机刻推进概率分母；偏好只加减速度，**绝不致死**。
  - `fertilizerAdvanceAt`：灵肥单次推进阶段数（含夜生/末地减速修正），0 表示硬条件不合法。
- `plants/SpiritPlantBlock.java`：统一灵植方块（`BushBlock` + `BonemealableBlock`）。
  共享 `AGE 0..7`；硬条件破坏才 `destroyBlock` 掉回本体。普通骨粉路径与灵肥共用
  `fertilizerAllowed` 复核，防止绕过灵壤门槛。
- `plants/SpiritPlantItem.java`：既是药材也是繁殖材料（本体可再植）；Tooltip 三行
  （药性 / 野外稀有度 / 培养提示）。`appendHerbTooltip` 供龙鳞草、蓝蘑菇复用。
- `plants/SpiritFertilizerItem.java`：灵肥。对灵植走 `applyFertilizer`（服务端复核硬条件）；
  对原版作物/树苗等价普通骨粉；对其它方块无效果。
- `plants/SpiritPlantCatalog.java`：全部灵植的静态清单（唯一声明处）。
- `plants/SpiritPlantRegistry.java`：统一注册表；由 `GeneratedMod` 构造器 `bootstrap()`
  触发，早于注册事件。旧 ID `dragon_scale_grass` / `glowing_blue_mushroom` 保留。
- `plants/HerbProperty.java`：药性枚举（灵/木/水/火/土/风/雷/阴/阳/寒/血/龙/星/幽 +
  调和/滋养/恢复/清净/神魂/聚气/修炼/生机/经脉/气血/炼体/坚韧/身法/淬炼）。
  lang 键 `herb.wuxingxiantu.<id>`。第三批炼丹/异火按此读取，不依赖逐物品 if-else。
- `plants/Substrate.java`：合法种植基质（SOIL / SOIL_STRICT / WATER / WATER_OR_ABOVE /
  END_STONE_OR_SPIRIT / ROCKY）。灵壤通过方块标签 `wuxingxiantu:spirit_soil` 判定，只有一种。
- `plants/WildRarity.java`：COMMON/UNCOMMON/RARE/VERY_RARE/SPECIAL，**只表示野外发现难度**，
  不构成凡/灵/玄/天品阶。lang 键 `wild.wuxingxiantu.<id>`。
- `plants/SpiritPlantFeature.java`：生态化植被特性（按 `Rule` 挑落点：SURFACE_SOIL /
  ROCKY / SANDY / WATER_BODY / WATER_SURFACE / CAVE_FLOOR / CAVE_WATER / END_MAIN_ISLAND），
  与手动种植共用 `canPlaceAt`，野外落点必然可存活。
- `blocks/SpiritSoilBlock.java`：灵壤方块（带 `spirit_soil` 标签）。

**Worldgen 数据**（`data/wuxingxiantu/`）：
- `worldgen/configured_feature/<id>.json` + `worldgen/placed_feature/<id>.json`：每株一份。
- `forge/biome_modifier/add_spirit_plants_surface|caves|rocky|water|hot.json`：
  地表 / 洞穴 / 山地岩壁 / 水域 / 炎热（赤阳草）分类投放；
  `add_dragon_scale_grass.json` 限末地主岛生物群系。
- 五类生态补丁：`add_dew_drop_flower` / `add_spirit_ginseng` / `add_vein_mending_vine` /
  `add_highland_spirit_plants` 四个修改器分别引用 `tags/worldgen/biome` 下的生态标签。
  `SpiritPlantFeature.Config` 新增可选 `biome_tag` / `min_y` / `open_sky`，在每个实际落点复核，
  防止 patch 跨越群系边界或高度线。凝露花用 `SURFACE_NEAR_WATER` 查水平±4、垂直-2..0 的水源；
  聚灵参用 `FOREST_FLOOR` 找林下地表；续脉藤用 `SURFACE_ROCK_EDGE` 查相邻原生石层；
  雷纹草与星辉花用 `SURFACE_HIGHLAND`，分别最低 Y=120/160 且开阔露天。
  星辉花 placed feature 稀有度改为 1/64、configured feature 仅尝试 1 个落点。
  这些限制只影响自然生成，人工种植和生长偏好保持原有定义。
- `loot_tables/blocks/<id>.json`：未成熟必掉 1 本体（保证不灭绝）；成熟保底 1 + 时运加成。
- `tags/blocks/spirit_plants.json`、`tags/items/alchemy_herbs.json` 及
  `water_plants` / `soul_herbs` / `yang_herbs` / `yin_herbs` / `body_refining_herbs` / `qi_herbs`。
- `recipes/spirit_soil.json`：4 泥土 + 1 灵液 → 4 灵壤。
- 灵肥无工作台合成配方：骨粉浸入灵液约 3 秒（`BONE_MEAL_CONVERSION_TICKS`），每格真实灵液源
  最多处理 8 份（`BONE_MEAL_PER_SPIRIT_SOURCE`），剩余整叠重新计时；64 份累计消耗 8 格源。
  另有灵蕴台蕴养路线，见 §5；泥土→灵壤也可通过灵蕴台完成，保留现有无序合成。
  `consumeSpiritLiquid` 只在掉落物包围盒覆盖范围内消耗灵液**水源**；流水格会被上游回填、
  不计成本，找不到水源就继续等待。检测（`isInSpiritLiquid`）与消耗用同一坐标集合。

**设计红线（勿再改回）**：灵植无统一品阶；灵壤无品级（只一种）；聚灵阵不参与灵植系统；
灵肥是正式催熟手段但不能绕过硬条件；普通骨粉不能量产珍稀灵植；龙鳞草=末地主岛野生；
发光蓝蘑菇=地下资源；桃树=普通资源树（不要求灵壤）。

---

## 17. 村民职业、交易与道士

- `WuXingProfessions.java`
  - `SPIRIT_CULTIVATOR`：工作站 `SPIRIT_PLATFORM`。
  - `TAOIST`：工作站 `DRAWING_PLATFORM`。
- `SpiritTradeEvents.java`
  - `addTrades()`：灵修者 + 原版牧师交易。
  - `addTaoistTrades()`：符纸、墨、刻刀、随机符、随机印章。
- `TaoistEvents.java`
  - 随机符/印章 NBT。
  - 阻止道士感染为僵尸村民。
  - 每次购买印章后刷新下一枚随机符文。
- `SpiritMerchant.java` 属于魂珠虚拟 Merchant，不是职业村民。

---

## 18. 客户端 UI / HUD / 输入

### 修仙主 UI

- `client/CultivationScreenEvents.java`：只替换原版生存背包入口。
- `client/CultivationMainScreen.java`：主壳，仍保留原 InventoryScreen/Menu。
- `client/CultivationPageRegistry.java`：页面注册与可见条件。
- `client/CultivationVisionPage.java`：内视/自身修炼状态。
- `client/CultivationArtsPage.java`：功法/心法/神通。
- `client/CultivationSwordPage.java`：灵剑页。
- `client/CultivationAdvancementsPage.java`：读取原版 advancement 同步结果。
- `client/CultivationSettingsPage.java`：御剑客户端配置。
- `client/CultivationLayout.java`：尺寸/布局数学。
- `client/CultivationUi.java`：像素框、按钮、进度条、文字格式等共享组件。
- `client/InkButton.java`：水墨按钮。

旧/独立面板：

- `client/InnerVisionScreen.java`：较大的独立内视面板，仍承载若干状态/领域交互。
- `client/RootSelectionScreen.java`
- `client/HeartMethodScreen.java`
- `client/ArtWheelScreen.java`
- `client/ArtRadialScreen.java`

### HUD

- `client/WuXingClient.java`：HUD 绘制、渡劫状态、重复 overlay 隐藏。
- `HudConfig.java`：HUD client config。

### 按键

- `client/WuXingKeybinds.java`：注册和主 Tick 分发；V 内视、R 功法等以及寄魄输入。
- 特定御剑 input 在 `client/YujianClientController.java`。

### 客户端事件总入口

`client/ModClientEvents.java` 很大（约 810 行），只在这些任务读取：

- Entity/BE renderer 注册
- 异火粒子与燃烧视觉
- 七十二变实体模型/帽子隐藏
- 巨人镜头/姿态
- 灵魂交易屏幕替换
- 部分角色渲染姿势

---

## 19. 网络层索引

`Network.java` 约 2320 行，是本项目最大文件。**禁止为了一个包直接全读。**先搜索 record 名。

### 修炼/根基

`SelectRootPacket`, `SelectHeartMethodPacket`, `SyncPacket`, `CrystallizePacket`, `RootFormPacket`, 五行 `*DomainPacket`。

### 炼丹/炼器

`OpenScreenPacket`, `AlchemyPacket`, `RefiningPacket`, `CollectRefiningPacket`。

### 渡劫

`TribulationPacket`, `TribulationStatePacket`。

### 普通功法

`EquipArtPacket`, `ArtReleasePacket`。

### 御剑

`SwordFlightPacket`, `SwordFlightInputPacket`, `SwordNurtureActionPacket`, `SwordFlightStatePacket`, 外部 `SwordRecallPacket`。

### 魂魄/人皇幡

`SoulFurnaceCyclePacket`, `SoulTradeFavoritePacket`, `SoulTradeStatePacket`, `OpenBannerPacket`, `BannerActionPacket`, `BannerStatePacket`。

### 神通/变身/寄魄

`EquipDivineArtPacket`, `DivineReleasePacket`, `DivineArtBannerPacket`, `DivineSyncPacket`, `TransformCyclePacket`, `TransformAbilityPacket`, `TransformCreeperReleasePacket`, `TransformSelectPacket`, `TransformCancelPacket`, `OpenTransformSelectionPacket`, `PossessTargetPacket`, `TransformAttackPacket`, `PossessionInputPacket`。

### 异火

`FireSelectPacket`, `FireStatePacket`, `FireSyncPacket`, `ExoticBurnPacket`, `WrapVisualPacket`。

### 符箓

`TalismanSubmitPacket`, `TalismanRubPacket`, `TalismanSelectPacket`。

### 寻真司南

`CompassOpenPacket`, `CompassSearchPacket`, `CompassResultPacket`, `CompassTeleportPacket`。

### S2C 客户端处理

- `ClientPacketSink.java`：通用桥接/缓存。
- `client/WuXingClientPackets.java`：真实 PLAY_TO_CLIENT 处理器注册。

**新增 S2C 包时必须确认客户端 classloading 安全**，不要让 common-side `Network` 直接硬加载仅客户端类。

---

## 20. 资源目录导航

### `assets/wuxingxiantu`

- `lang/zh_cn.json`, `lang/en_us.json`：名称、GUI、tooltip、神通/功法文案。
- `models/item/`：物品模型（数量大）。
- `models/block/`：方块模型；异火子模型很多。
- `blockstates/`：方块状态映射。
- `textures/item/`, `textures/block/`, 其他 texture 子目录：贴图。
- `particles/`：异火粒子 sprite set。
- `shaders/`：时间停止与御剑拖尾。
- `sounds.json`, `sounds/`：自定义音效。

### `data/wuxingxiantu`

- `recipes/`：126 个 JSON；其中 20 个炼丹、7 个炼器，其余普通 crafting/smelting/blasting。
- `loot_tables/blocks/`：自定义方块掉落。
- `worldgen/` + `forge/biome_modifier/`：标准世界生成。
- `structures/spirit_shrine_island.nbt`：灵祠浮空岛模板。
- `advancements/tribulation_failure.json`：渡劫失败进度。
- `tags/`：模组 tag。其中 `tags/items/creative_test.json` 标记创造/测试专属物品（万法归宗、创造丹、创造魂珠×2、心魔刷怪蛋），与 `WuXingItemSources.java` 的 CREATIVE_TEST 分类保持一致——这些物品**永远不补生存配方**，不算断链。

### 修改资源时的最短搜索

- 不知道 item model：搜索 `assets/wuxingxiantu/models/item/<id>.json`。
- 不知道贴图：先看 model JSON 的 `textures` 引用，不要递归扫全部 249 张贴图。
- 不知道 block model：从 `blockstates/<id>.json` 反查 model。
- 不知道配方：直接 `rg 'wuxingxiantu:<id>' data/wuxingxiantu/recipes`。
- 不知道掉落：直接 `loot_tables/blocks/<id>.json`，再检查 Java 事件是否额外掉落。

---

## 21. 获取方式/掉落来源该从哪里查

若任务是“某物怎么获得/为什么生存拿不到”，按以下优先级，不要只查 recipes：

0. `WuXingItemSources.java`：先看代码侧权威分类——CREATIVE_TEST（如创造丹、万法归宗）与 INTERNAL（结构部件/渲染载体）**本就没有生存来源，不是断链**，不要为它们补配方。
1. `data/wuxingxiantu/recipes/*.json`
2. `data/wuxingxiantu/loot_tables/**`
3. `SpiritTradeEvents.java` / `TaoistEvents.java`
4. `GeneratedMod.java`：`breakBlock`, `livingDeath`, `fishing`, `smeltOre`, `injectChestInsight`, `injectDivineInheritance`, 右键事件。
5. 具体 Item 的 `use/useOn/interactLivingEntity`。
6. 世界生成：`data/worldgen`, biome modifier, `SpiritShrineManager`。
7. 机器产出：Alchemy / Refining / Soul Furnace / Healing Room / Spirit Platform。

**配方存在 ≠ 生存可达。** 若需要完整可达性，继续读取 `README_五行仙途_源码审计版.md`。

---

## 22. 测试与参考目录：什么时候才读

### 默认不要读

- `build/`：构建产物，不是源码权威。
- `source-reference/`：参考工程配置，不参与当前主逻辑。
- `shader-reference/`：参考 shader，仅在移植/对比 shader 时读。
- `src/clienttest`, `src/layouttest`, `src/jadetest`：默认未加入 main sourceSet。

### 条件测试源集

`build.gradle` 中：

- `-PfurnaceTests`：加入 `src/gametest/java` 与 `src/gametest/resources`。
- `-PflightClientTests`：加入 `src/flightclienttest/java`。
- `-PuiClientTests`：加入 `src/uiclienttest/java`。
- Jade：`src/jade/java` **始终加入** main Java source dir，但依赖是 `compileOnly`。

### GameTest 文件

- `FurnaceGameTests.java`：炼丹/机器。
- `FlyingSwordGameTests.java`, `YujianGameTests.java`：御剑。
- `PossessionMovementGameTests.java`, `PossessionCameraGameTests.java`：寄魄移动/镜头。
- `SpiritIslandGameTests.java`, `LocateIslandGameTests.java`：灵岛/定位。
- `ProfessionGameTests.java`：职业。

### 客户端 smoke test

- `FlightClientSmokeTest.java`
- `CultivationUiSmokeTest.java`
- `VisualSmokeTest.java`

---

## 23. 常见修改模板

### 23.1 新增普通物品

1. `WuXingItems.java`
2. `assets/.../lang/zh_cn.json` / `en_us.json`
3. `assets/.../models/item/<id>.json`
4. texture
5. 获取方式：recipe / loot / trade / Java event
6. 若需要 tooltip/特殊行为：新 Item class 或 `GeneratedMod.itemTooltip`

### 23.2 新增方块

1. `WuXingBlocks.java` 注册 Block。
2. 同类中注册 BlockItem（很多 block item 也在该类）。
3. blockstate → block model → item model → texture。
4. loot table。
5. 若有 BE：`registry/ModBlockEntities.java`。
6. 若有菜单：`registry/ModMenus.java` + menu + screen 注册。

### 23.3 新增实体

1. `registry/ModEntities.java`
2. Entity class
3. 若 Mob：attribute 注册在 `GeneratedMod.ModEvents.registerAttributes()`。
4. client renderer 注册在 `ModClientEvents.registerRenderers()`。
5. 需要生成规则时才做 spawn placement/worldgen。

### 23.4 新增普通功法

1. `ArtCatalog.java`
2. `WuXingItems.java` 中秘籍注册（若需要物品学习）
3. `Network.executeArt()` 实现行为，或桥到独立 manager
4. lang
5. 获取方式
6. UI 一般由 catalog 自动读取；特殊 UI 再改 `Art*Screen`

### 23.5 新增神通

1. `DivineArtCatalog.java`
2. 传承物品 `WuXingItems` / `DivineManualItem`
3. `DivineArtLogic.tryRelease/release/tick`
4. 若有持续状态：`CultivationData` + sync
5. lang / HUD banner
6. 获取方式（箱子注入或其他）

### 23.6 新增可御剑灵剑

1. 注册 `SpiritSwordItem`
2. model/texture/lang
3. `FlyingSwordRegistry` 添加 definition
4. `SwordProfile` / profile 参数
5. `SwordHeldTransforms` 若手持姿态不同
6. `FlyingSwordItemModels`/renderer 若模型路径特殊
7. 配方/炼器
8. 实测服务端飞行与客户端渲染；不要复制一个新的 controller

### 23.7 新增自定义机器

优先照现有模式拆成：Block → BlockEntity → Menu → Screen → Recipe/Data → Network；不要把物品消耗、计时和产物权威逻辑塞进 Screen。

---

## 24. 故障定位速查

| 症状 | 第一检查点 | 第二检查点 |
|---|---|---|
| 客户端显示变了但服务器不认 | 具体系统服务端类 | Network C2S handler |
| 服务器数据变了 UI 不更新 | `GeneratedMod.sync()` / 对应 send | `SyncPacket`/S2C handler |
| 重进游戏字段丢失 | `CultivationDataImpl.serialize/deserializeNBT` | capability clone/login |
| 方块能摆但机器不成型 | Structure 类 `matches/refresh` | `GeneratedMod` place/neighbor hook |
| 配方 JSON 存在但机器不显示 | Recipe serializer/type | Screen recipe list/筛选 |
| 物品有注册但生存拿不到 | 获取方式审计链 | README 源码审计版 |
| Entity 服务端存在客户端看不见 | `ModClientEvents.registerRenderers` | EntityType client tracking/data |
| 模型朝向错误但运动正确 | renderer/transform/模型 JSON | 不要改服务端控制器 |
| 御剑输入有按键但不移动 | client input → packet | `YujianController` 服务端状态 |
| 神通结束后 mayfly/noPhysics 残留 | `DivineArtLogic.stop/clear/saveAbilities` | `TimeStopManager`/effect removal |
| 异火重进区块变普通火 | `ExoticFireSavedData` | `ExoticFireState.restoreChunk` |
| 人皇幡魂仆丢失/重复 | banner UUID/active/dead 计数 | `tickServants` + recall/death |
| 结构/灵岛 locate 不到 | `SpiritShrineManager` | 不要找标准 StructureSet |
| Shader 看得到但穿墙 | depth capture/TrailShaderBridge | render stage/后处理 shader |

---

## 25. 核心调用关系（高层）

```text
Forge / 玩家事件
  └─ GeneratedMod
      ├─ CultivationData (Capability)
      │   ├─ CultivationLogic
      │   ├─ PhysiqueLogic
      │   ├─ DivineArtLogic
      │   └─ Network.SyncPacket
      ├─ Alchemy / Refining / Soul machines
      ├─ TribulationManager -> HeartDemonEntity
      ├─ ExoticFireState / SpiritEnchantmentLogic
      └─ HumanEmperorBannerItem / TransformAbilityRegistry

客户端输入
  ├─ WuXingKeybinds
  ├─ YujianClientController
  └─ Screens
      ↓ C2S Network packets
服务端权威处理
      ↓ S2C Sync packets
客户端 HUD / Renderer / Shader
```

---

## 26. 主源码完整文件索引（仅在找不到入口时用）

> 这一节是兜底索引。**不要默认整节读入上下文**；直接在本文件里搜索类名即可。

### 根包 / 服务端与通用系统

| 文件 | 行数 | 作用 |
|---|---:|---|
| `AlchemyFurnaceBlock.java` | 173 | 炼丹炉核心：本身只是一个带贴图的方块（6 品级各自 32x32 贴图），是 5x5x4 炼丹炉结构的组成方块之一。结构齐全时把 FORMED 置位，开启炼丹交互与炼制特效； 成型时绘制完整炉体模型，原材料暂存于不遮... |
| `AlchemyFurnaceBlockEntity.java` | 281 | 炼丹炉的动态状态载体：同步炼制状态，成型外观由独立炉体模型呈现。 六种品阶共用一个方块实体类型，普通右键打开八卦炼丹面板。 <p>容器布位：0-7 为八个八卦素材槽，8 为「异火瓶」点火槽。素材与点火均由 {@li... |
| `AlchemyFurnaceMenu.java` | 165 | 八卦炼丹面板菜单：八个八卦素材槽 + 一个异火瓶点火槽，下方为玩家物品栏。 槽位坐标与 {@link AlchemyScreen} 严格一致，保证贴图与物品图标对齐。 |
| `AlchemyFurnacePartBlock.java` | 85 | Invisible collision shell that neither culls the ground nor blocks skylight. |
| `AlchemyFurnacePartEntity.java` | 49 | Persistent snapshot of a material block hidden by the assembled furnace. |
| `AlchemyFurnaceStructure.java` | 154 | 5 x 5 x 4 blueprint, relative to the bottom-center core. |
| `AlchemyRecipe.java` | 147 | 八卦炼丹炉配方：输入数量、炉品级、炼制时间和灵力消耗均由数据包定义。 |
| `ArtCatalog.java` | 278 | 集中维护功法品级、类型、熟练度和界面显示规则。 |
| `CaveTokenBlock.java` | 118 | 薄型洞府令牌，可贴附在完整方块的墙面、地面或天花板上。 |
| `CaveTokenLocations.java` | 219 | 按维度保存洞府令牌，并用固定大小空间分桶提供有界刷怪查询。 |
| `ChenghuaPedestalBlock.java` | 136 | 承华台：可承载物品的基座（Goety 祭坛基座语义），右键放入/取回一叠物品。 同时充当炼器台的素材入口——启动炼制时优先从炼器台周围的承华台上抽取素材， 素材会以实体形态飞入中央异火中完成炼制（见 Network... |
| `ChenghuaPedestalBlockEntity.java` | 88 | 承华台的持久化状态：与灵蕴台一致的 Goety 基座语义——用一个槽位保存承载物品， 随区块存盘并经 getUpdatePacket 同步到客户端，由 PedestalFloatingRenderer 悬浮展示。 ... |
| `ClientPacketSink.java` | 42 | PLAY_TO_CLIENT 包的客户端处理桥接。 <p>包记录的 handle 方法若直接引用 net.minecraft.client 下的类，Forge 的 RuntimeDistCleaner 会在模组注册... |
| `CultivationBlock.java` | 155 | 可交互的修炼功能方块：聚灵、洞府标记与打坐共用轻量方块实现。 |
| `CultivationCapability.java` | 30 | 兼容现有调用点；新代码统一使用 INSTANCE。 |
| `CultivationData.java` | 192 | 玩家修炼数据；所有修改均在服务端执行，并通过网络同步给客户端。 |
| `CultivationDataImpl.java` | 588 | 天雷淬体次数与变异灵根状态：解锁后仍保留，形态可随时切换。 |
| `DivineArtCatalog.java` | 51 | 神通目录：神通不占用普通功法槽位，单独显示在轮盘外圈。 |
| `DivineArtLogic.java` | 1085 | 神通服务端状态机，负责消耗、冷却、持续效果和踏罡七星判定。 |
| `EternalSpiritCoalBlock.java` | 118 | 永燃灵煤块：承载独立灵火，支持点燃、换火和主动扑灭。 |
| `EternalSpiritFireBlock.java` | 28 | 旧异火方块 API 的兼容桥。异火现在标记原版 FireBlock，视觉由动态粒子叠加。 |
| `ExoticBurnSourceSync.java` | 30 | 燃烧颜色跟随点燃来源：正在着火且脚下（或身下）方块是异火/已染阶火焰的实体， 定期把该火源的品阶同步给追踪客户端，实体燃烧外观不再回退到玩家装备的异火。 |
| `ExoticFireBlock.java` | 136 | 独立的九阶灵火：Spiritfire 动画主体不依赖粒子数量或额外品阶包。 |
| `ExoticFireColorRegistry.java` | 53 | 火焰、物品与余焰共用的九阶配色和亮度配置。 |
| `ExoticFireSavedData.java` | 82 | 跨重启保存异火位置和品阶。位置按维度分别保存在该维度的 level data 中， 避免把不同维度的坐标混在一起，也避免依赖易失的静态 Map。 |
| `ExoticFireState.java` | 231 | 独立异火状态及旧版 minecraft:fire 品阶记录的兼容迁移。 |
| `FloatingItemHolder.java` | 20 | 可悬浮承载物品的基座方块实体统一接口。 灵蕴台与承华台共用同一套悬浮渲染与炼器台素材抽取逻辑。 （getLevel() 由 BlockEntity 基类天然实现，这里只是把它纳入接口。） |
| `GeneratedMod.java` | 1563 | 五行仙途主类：注册内容，并集中处理服务端修炼规则。 |
| `HeartDemonEntity.java` | 319 | 大乘渡劫末道出现的心魔，属性取渡劫者当前值的十倍。 |
| `HeartMethodCatalog.java` | 30 | 集中维护心法 ID 与显示名称，供界面和服务端校验共用。 |
| `HudConfig.java` | 13 | 系统辅助类；按类名搜索引用后再读取。 |
| `HumanEmperorBannerMenu.java` | 334 | 人皇幡菜单：管理魂魄顺序、渡灵魂珠和玩家物品栏。 |
| `HumanEmperorBannerPoleBlock.java` | 101 | 人皇幡插地后的杆身延伸段：插地座往上共 4 格的隐形辅助方块，只为延长可交互 范围（右键/左键命中任意一截都等同于对插地座操作），不渲染、不阻挡移动； 破坏任意一截即整幡收回，掉落由插地座统一处理。 |
| `HumanEmperorBannerStandBlock.java` | 142 | 人皇幡的地面插旗座：由人皇幡物品右键方块生成，可空手右键取回原物品；上方杆身由无碰撞的杆格延伸可交互范围。 |
| `HumanEmperorBannerStandBlockEntity.java` | 83 | 地面人皇幡的持久数据；保存完整 ItemStack，确保魂魄、耐久与自定义标签不丢失。 |
| `MeditationSeatEntity.java` | 80 | 座位位置就是坐面；模型折腿后的最低点比实体脚底高半格。 |
| `ModCommands.java` | 629 | 五行仙途管理员与玩家指令。所有数据修改都在服务端完成，并立即同步客户端。 |
| `ModEffects.java` | 155 | 可在物品栏查看说明的五行领域状态效果。领域本身的数值逻辑仍由 CultivationLogic 驱动。 |
| `ModParticles.java` | 29 | 五行仙途客户端异火粒子注册；水滴缠绕粒子使用独立的 exotic_fire_droplet 贴图。 |
| `ModSounds.java` | 20 | 五行仙途自定义音效注册。 |
| `Network.java` | 2320 | 寻真司南最近一次搜索到的目标：供“传送”请求使用，避免客户端伪造坐标。 |
| `OfferingItemEntity.java` | 105 | 供奉异火的供品：由炼器台在承华台与炉心之间生成，直线飞向中央异火， 抵达后化作火焰粒子消散。纯视觉载体——素材在服务端点击“炼制”时即已扣除， 因此这里禁用拾取、碰撞与伤害，也不做原版物品实体的重力与合并逻辑。 |
| `PeachTreeGrower.java` | 53 | 桃树苗使用原版樱花树的完整树形，仅替换为桃木和桃树叶。 |
| `PedestalContainer.java` | 100 | 炼器台周围承华台的“虚拟容器”视图：把半径内每个承华台的承载物品当作一个槽位， 直接复用 RefiningRecipe 的 matches/consume 逻辑；setChanged 时统一清理空叠并同步客户端。 |
| `PhysiqueType.java` | 24 | 文档定义的八种体质；万灵道体只在飞升后自然获得。 |
| `PossessionGroundMovement.java` | 44 | Ground movement for AI-disabled possession hosts, using vanilla acceleration and tick order. |
| `ProgressionGate.java` | 374 | 统一进度门槛层：全部境界资格判定的唯一权威（见 4.5）。品级→境界配置表集中于此；获得与使用分离、旧存档只降级不清除、创造旁路。 |
| `RealmMiningTrait.java` | 69 | 境界特性：炼气期自带挖掘等级 0，每提升一个大境界挖掘等级 +1，无视手持工具； 化神期起删除所有挖掘速度惩罚（包括飞行中与水下方块）。 |
| `RefiningForgeBlock.java` | 184 | 炼器台核心；核心、底层符文石与磨制黑石砖台阶、上层符文石共同组成 3x3x2 多方块结构。 核心本身是实心方块，仅用贴图表现外观；结构成型时切换 FORGED 状态点亮器台造型。 |
| `RefiningForgeBlockEntity.java` | 165 | 炼器台核心：既是未成型结构的客户端预览载体（由渲染器显示结构幽灵方块）， 也在炼制结束时承接成品——成品悬浮于异火之上，等待玩家右键炼器台核心领取。 成品随区块存盘并同步到客户端，供渲染器绘制悬浮物品。 |
| `RefiningForgeCornerBlock.java` | 107 | 炼器台角座：成型后的四角外观方块。外观是外角位的镂空火盆座（盆体靠结构外侧， 四个角各朝向外方，故带 facing 属性选择对应切片模型），未成型时该位置是玩家 摆放的磨制黑石砖台阶。炼器台点火时角座同步进入 LI... |
| `RefiningForgeStructure.java` | 226 | 炼器台多方块结构的组装管理：玩家用普通方块摆出框架， 结构完整的那一刻整体切换为“成型”外观（符文石点亮纹面、四角磨制黑石砖台阶 替换为角座），拆毁任意部件即恢复为玩家摆放的原始方块。 <p>成型只校验方块种类，不... |
| `RefiningRecipe.java` | 151 | 炼器台配方；材料、灵力消耗和炼制时间由数据包定义。 |
| `RuneStoneBlock.java` | 109 | 炼器台符文石；单块摆放时是普通刻纹石砖，炼器台成型（FORGED）后切换为器台造型模型。 成型时由 RefiningForgeStructure 写入 part/facing，让模型从整幅墙带/法阵大图上 裁取自己... |
| `SoulFurnaceBlock.java` | 126 | 炼魂炉/化魄炉：正面显示燃烧状态，右键投入手持物品并打开机器界面。 |
| `SoulFurnaceBlockEntity.java` | 456 | 炼魂炉和化魄炉共用的服务端熔炼容器。 |
| `SoulFurnaceMenu.java` | 206 | 炼魂炉与化魄炉共用菜单：上方为机器槽位，下方为完整玩家物品栏。 |
| `SoulHealingRoomBlock.java` | 68 | 愈魂室：消耗灵魂沙/灵魂土修复破碎魂珠。 |
| `SoulHealingRoomBlockEntity.java` | 224 | 愈魂室的修复逻辑：每点燃一份灵魂沙或灵魂土获得5点魂力。 |
| `SoulHealingRoomMenu.java` | 109 | 愈魂室菜单：破碎魂珠、灵魂沙/灵魂土和修复进度。 |
| `SoulPearlData.java` | 467 | 两种灵珠的服务端 NBT 数据和交易处理。 |
| `SoulTradeMenu.java` | 38 | 服务端拘魂交易菜单：验证收藏请求，并把重排后的交易与收藏状态同步给客户端。 |
| `SpiritEnchantment.java` | 148 | 灵力附魔注册与适用范围定义。 |
| `SpiritEnchantmentLogic.java` | 549 | 灵力附魔的服务端效果实现。 |
| `SpiritFirePalette.java` | 49 | 灵火调色公式；只替换色相和焰心，完整保留参考素材的透明轮廓与逐帧细节。 |
| `SpiritLiquidBlock.java` | 60 | 灵液表面的流光效果，流体本身仍由 ForgeFlowingFluid 负责扩散。 |
| `SpiritLiquidFluidType.java` | 31 | 灵液的客户端渲染属性：淡蓝色、发光且使用专属水面纹理。 |
| `SpiritLiquidLakeFeature.java` | 78 | 在地表浅层生成灵液湖，并在湖岸草方块上生成发光蓝蘑菇。 |
| `SpiritMerchant.java` | 106 | 不依附实体的灵魂交易商；收藏状态写回打开界面的那颗拘魂珠。 |
| `SpiritOrbEntity.java` | 166 | 独立于经验球的灵力掉落，避免被原版经验球合并后变成经验。 |
| `SpiritPlatformBlock.java` | 140 | 灵蕴台：吸收附近灵石块；右键一次放入一个物品，物品借鉴 Goety 祭坛基座的做法 存入方块实体槽位，并以悬浮旋转的姿态展示在托盘之上（渲染见 PedestalFloatingRenderer）。 基座造型为独立方... |
| `SpiritPlatformBlockEntity.java` | 201 | 灵蕴台的持久化状态：吸收灵石块，并像 Goety 祭坛基座（PedestalBlockEntity）那样 用一个方块实体槽位保存悬浮物品——物品不落实体、随区块存盘， 通过 getUpdatePacket 同步到客... |
| `SpiritShrineLocations.java` | 62 | 记录已经生成的灵修者结构坐标，供 /locate 查询并跨存档保存。 |
| `SpiritShrineManager.java` | 165 | Loads the authored island only after its entire footprint is available. |
| `SpiritTradeEvents.java` | 67 | 将灵修者交易表接入自定义职业与原版牧师，兼容原版村庄生成与存档。 |
| `SwordTechniqueManager.java` | 25 | 剑技只使用当前蕴养灵剑的技能集合；御剑能力与主动剑技分离。 |
| `TalismanCatalog.java` | 460 | 符箓目录：登记每一种符箓的 ID、显示名、符文图样、绘制消耗与使用效果。 <p> 画符机制参考《魔路》(molu) 的思路，但这里改为"临摹长条符纸"： 符纸是一张 {@link #CANVAS_WIDTH}×{@... |
| `TalismanData.java` | 52 | 符箓相关物品的 NBT 读写助手。 <p> 印章（Seal）与符咒（Talisman）都通过 {@code TalismanId} 记录当前携带的符箓种类； 印章可反复使用，符咒使用一次即消耗。 |
| `TalismanForgeEvents.java` | 54 | 符箓系统的服务端事件：把丢入异火的灵煤转化为灵墨。 |
| `TalismanKnowledge.java` | 22 | 符箓知识：由《万法归宗》残卷解锁；持有时才允许在镌印台/绘制台描绘符文。 |
| `TalismanPlatformBlock.java` | 68 | 符箓平台：镌印台 / 绘制台 / 拓印台共用同一方块逻辑，按 kind 区分行为。 |
| `TalismanPlatformBlockEntity.java` | 142 | 符箓平台方块实体：镌印台 / 绘制台 / 拓印台 共用同一容器逻辑。 |
| `TalismanPlatformMenu.java` | 203 | 符箓平台菜单：镌印台 / 绘制台 / 拓印台 共用，按 kind 摆放槽位。 |
| `TaoistEvents.java` | 57 | Cancel infection only; normal damage/death and non-zombie conversions keep vanilla behavior. |
| `TimeStopManager.java` | 151 | 光阴锁的服务端运行时状态；只暂停范围内非玩家实体，不影响施术者和其他玩家。 |
| `TransformAbilityRegistry.java` | 676 | 七十二变的能力注册表。形态仍是客户端伪装实体，能力由服务端根据形态 ID 决定， 客户端只发送一次“使用能力”意图，绝不提交伤害、坐标或传送结果。 |
| `TribulationManager.java` | 397 | 服务端渡劫状态机：倒计时、落雷、心魔、结算与观战限制均由服务端决定。 |
| `WuXingBlocks.java` | 424 | 五行仙途方块注册。所有方块和对应方块物品都采用延迟构造。 |
| `WuXingCreativeTabs.java` | 15 | @deprecated 创造模式标签页已迁移到 {@link ModTabs}。 |
| `WuXingFluids.java` | 20 | @deprecated 流体注册已迁移到 {@link ModFluids}。 |
| `WuXingItemSources.java` | 78 | 物品来源分类权威：SURVIVAL / INTERNAL / CREATIVE_TEST；与 `#wuxingxiantu:creative_test` 标签一致，供审计与界面提示查询。 |
| `WuXingItems.java` | 397 | 五行仙途物品注册。所有物品都只在 Forge 注册事件中构造。 |
| `WuXingProfessions.java` | 38 | 灵修者职业与灵蕴台工作站点。 |
| `WuXingRecipes.java` | 18 | @deprecated 配方注册已迁移到 {@link ModRecipes}。 |

### items / 物品行为

| 文件 | 行数 | 作用 |
|---|---:|---|
| `items/ArtManualItem.java` | 48 | 功法秘籍：右键学习一次，学习后自动装备到第一个空槽。 |
| `items/AuraItem.java` | 17 | 物品行为。 |
| `items/BasePillItem.java` | 145 | 所有丹药的公共规则：最大堆叠 64、无冷却、食用动画、灵力消耗与服务端效果。 |
| `items/BreakthroughPillItem.java` | 64 | 渡劫丹：按丹药品级执行跨阶惩罚与服务端成功率判定。 |
| `items/CarvingKnifeItem.java` | 22 | 刻刀：镌印台的刻字工具，具备耐久度。镌刻失败时消耗耐久。 |
| `items/CreationPillItem.java` | 160 | 创造丹：服用后一步登天。 境界直升地仙·巅峰且修为灵力圆满，习得全部功法并登峰造极， 领悟所有神通与心法，集齐九阶异火，五行灵根尽达极品并凝聚混沌灵根。 |
| `items/CreatureCompassItem.java` | 33 | 寻真司南：右键打开界面输入生物名称，搜寻距离最近的生物。 |
| `items/CultivationInsightItem.java` | 53 | 修炼心得：右键将固定数值转化为当前阶段修为。 |
| `items/CultivationLogic.java` | 727 | 五行仙途的数值规则与灵根被动效果。 |
| `items/DivineManualItem.java` | 62 | 神通传承物品：学习后进入功法轮盘外圈。 |
| `items/DragonScaleGrassItem.java` | 13 | 末地主岛的稀有药草，可直接食用并作为洗髓丹材料。 |
| `items/EffectPillItem.java` | 92 | 物品行为。 |
| `items/EmptySpiritLiquidPotItem.java` | 59 | 空灵液壶：右键灵液源块会取走源块并变为装满的灵液壶。 |
| `items/EternalSpiritCoalBlockItem.java` | 18 | 永燃灵煤块物品：块本体禁止作为燃料（炼魂炉、化魄炉与原版熔炉都不可入炉），永燃特性只属于灵煤物品。 |
| `items/EternalSpiritCoalItem.java` | 23 | 永燃灵煤：由灵蕴台转化灵煤得到的永恒燃料。 原版熔炉按近无穷烧制时长处理；炼魂炉与化魄炉把它当作永不消耗的燃料。 |
| `items/ExperienceCrystalItem.java` | 38 | 化魄炉凝结的经验单位；每枚固定储存 5 点原版经验。 |
| `items/FireSeedItem.java` | 99 | 空火种瓶：在不同维度和环境中右键，吸收对应品阶的异火。 |
| `items/GlowingBlueMushroomItem.java` | 78 | 可种植的发光蓝蘑菇；空手右键空气时也能作为小型灵力食材使用。 |
| `items/GuandingItem.java` | 254 | 灌顶大法：对低于自身一个大境界的玩家进行五秒引导，将灵气与风险一并传入。 |
| `items/HealingPillItem.java` | 37 | 按最大灵力百分比恢复灵力的回灵丹。 |
| `items/HeartDemonSpawnEggItem.java` | 54 | 心魔刷怪蛋：生成后自动以使用者为主人，并复制使用者当前状态。 |
| `items/HeartMethodItem.java` | 42 | 心法秘籍：装备后替换当前心法，数量限制由能力数据保证为一个。 |
| `items/HuaLingPeiItem.java` | 126 | 化灵佩：右键将 10 点灵力转换为 1 点经验，以灵力球的形式呈现。 手持时每 0.5 秒（10 tick）尝试再转换一次，直到灵力不足或松开。 下蹲右键可调整转化倍率，每次 ×10，最高 ×100000；到达最高... |
| `items/HumanEmperorBannerItem.java` | 1085 | 人皇幡：保存魂魄库存，并管理魂仆的放出、回收和引渡。 |
| `items/PeachSwordItem.java` | 13 | 旧类名兼容层；新注册统一使用 SpiritSwordItem。 |
| `items/PhysiqueLogic.java` | 71 | 将体质表转换为可重复刷新的原版属性与效果。 |
| `items/PhysiqueResetPillItem.java` | 28 | 洗经伐髓丹：随机重置体质，不受境界限制。 |
| `items/RootAwakeningItem.java` | 38 | 灵根觉醒丹：觉醒指定灵根并提升其品级。 |
| `items/SealItem.java` | 34 | 印章：镌印台产物，携带某种符箓的符文（NBT），可反复拓印，无耐久限制。 |
| `items/SmallBreakthroughPillItem.java` | 60 | 只推进当前大境界小境界的突破丹，不会触发天劫。 |
| `items/SoulBindingPearlItem.java` | 50 | 捕获村民或流浪商人的交易灵魂；仅潜行右键空气打开保存的交易界面。 |
| `items/SoulCapturePearlItem.java` | 249 | 长按右键发射灵魂射线；首次被射线击杀的生物会被记录。 |
| `items/SoulEnergyPearlItem.java` | 45 | 用于复活人皇幡内战死魂魄的魂力容器。 |
| `items/SoulPearlItem.java` | 44 | 人皇幡专用魂珠；完整魂珠可召唤，破碎魂珠归藏后记录为战死状态。 |
| `items/SoulUtilityPearlItem.java` | 83 | 人皇幡专用工具珠：万魂珠按模式收纳或释放魂魄，灭魂珠直接销毁魂魄。 |
| `items/SpiritLiquidBucketItem.java` | 38 | 灵液桶：可放置灵液源块，也可用于配方消耗。 |
| `items/SpiritLiquidDrinkItem.java` | 99 | 可饮用的灵液容器；饮用后补充玩家灵力并返还空容器。 |
| `items/SpiritLiquidPotItem.java` | 43 | 物品行为。 |
| `items/SpiritSwordItem.java` | 139 | 本命灵器剑：保留近战、品阶、剑灵力与养成记录，不提供脱手投射。 |
| `items/TalismanItem.java` | 56 | 符咒：刻印或绘制的成品符箓，右键即触发对应效果并消耗一张。 |
| `items/WanfaGuizongItem.java` | 41 | 《万法归宗》残卷：右键研读一次，永久解锁画符箓的权限。 |

### yujian / 御剑系统

| 文件 | 行数 | 作用 |
|---|---:|---|
| `yujian/ControlledSwordEntity.java` | 135 | Inventory-backed implement: its display copy can never be picked up or saved. |
| `yujian/FlightFeedbackEvent.java` | 12 | Server-side hooks for authored sounds or additional effects. No placeholder vanilla sounds. |
| `yujian/FlightFrame.java` | 26 | +Z is the blade direction; +Y is the deck normal. Shared physical/render convention. |
| `yujian/FlyingSwordConfig.java` | 72 | Server config is synced by Forge; client presentation has its own local config. |
| `yujian/FlyingSwordDefinition.java` | 33 | Per-sword tuning. Movement code stays shared while each sword can have its own feel. |
| `yujian/FlyingSwordRegistry.java` | 47 | Central registry for flying sword definitions. Adding a sword does not require a new controller. |
| `yujian/FlyingSwordState.java` | 11 | Explicit server-side state machine for the sword ride. |
| `yujian/FormationGeometry.java` | 113 | All editable formation geometry and return-lane waypoints live here. |
| `yujian/FormationMode.java` | 48 | 系统辅助类；按类名搜索引用后再读取。 |
| `yujian/ManualRoll.java` | 57 | 连续累计弧度及弧度/刻。松键保持角度；主动回正在八刻内平滑结束。 |
| `yujian/NurtureData.java` | 49 | 每把灵剑独立持久化的服务器数据。所有变更都通过服务端验证后写回 ItemStack。 |
| `yujian/SwordNurture.java` | 79 | 系统辅助类；按类名搜索引用后再读取。 |
| `yujian/SwordProfile.java` | 33 | 品阶属于剑种类，剑蕴属于具体物品。 |
| `yujian/SwordRecallPacket.java` | 9 | 系统辅助类；按类名搜索引用后再读取。 |
| `yujian/SwordTechniqueRegistry.java` | 26 | 剑技固定注册表；学习条件由剑品阶、剑蕴阶段和洞察点共同决定。 |
| `yujian/YujianController.java` | 425 | Adapted YujianCraft formation/flight/technique behavior for the cultivation mana system. Original: Copyrigh... |

### registry / 注册层

| 文件 | 行数 | 作用 |
|---|---:|---|
| `registry/ModBlockEntities.java` | 108 | 注册或模组基础设施。 |
| `registry/ModEntities.java` | 55 | 模组实体类型注册。 |
| `registry/ModFeatures.java` | 20 | 五行仙途世界生成特性注册。 |
| `registry/ModFluids.java` | 50 | 灵液注册：Source 与 Flowing 使用不同的注册 ID，并共享同一组流体属性。 |
| `registry/ModMenus.java` | 32 | 五行仙途容器菜单注册。 |
| `registry/ModRecipes.java` | 32 | 五行仙途配方类型与序列化器注册。 |
| `registry/ModTabs.java` | 27 | 五行仙途创造模式标签页注册。 |

### blocks / 独立方块

| 文件 | 行数 | 作用 |
|---|---:|---|
| `blocks/DragonScaleGrassBlock.java` | 20 | 只能扎根在末地石上的龙鳞草。 |

### client / 客户端

| 文件 | 行数 | 作用 |
|---|---:|---|
| `client/AlchemyFurnaceBlockEntityRenderer.java` | 143 | 炼丹炉渲染：结构未成型时显示 5x5x4 网格的结构预览——已摆对的位置显示淡蓝光罩， 缺失/摆错的位置显示红色呼吸警示盒并悬浮一枚所需方块的全息缩影。 成型后绘制导入的五格炉体；组成方块由不遮光的结构部件代替。 ... |
| `client/AlchemyScreen.java` | 373 | 八卦炼丹面板：八枚素材槽环绕中心太极排成后天八卦，异火瓶点火槽位于卦环正下方， 卦环中心预览当前素材能炼出的丹药。配方不再手工翻页——界面按八枚槽位里的实际物品 自动匹配可用配方，异火瓶就位且材料齐备时「开始炼制」... |
| `client/ArtRadialScreen.java` | 314 | 功法释放界面：点击选中的功法槽位后释放功法。 |
| `client/ArtWheelScreen.java` | 398 | 功法轮盘设置：普通功法使用八个槽位，神通使用独立槽位。 |
| `client/CauldronStructureVisuals.java` | 11 | 客户端表现/输入辅助。 |
| `client/CodeFireEmitter.java` | 67 | 客户端异火发射器：每 tick 为可见异火生成内焰、外焰和余烬三层复合粒子。 发射器只读取同步状态，不改变火焰方块的物理、燃烧和蔓延逻辑。 |
| `client/CodeFireParticle.java` | 59 | 使用灵火透明纹理的上升余焰；旧粒子ID保留以兼容存档和指令。 |
| `client/CodeFireParticleProvider.java` | 24 | 兼容旧粒子品阶编码，改用标准透明粒子图集。 |
| `client/ControlledSwordRenderer.java` | 38 | 客户端渲染器。 |
| `client/CreatureCompassScreen.java` | 203 | 寻真司南界面：输入生物名称，向服务端查询距离最近的生物，并可直接传送到它附近。 关闭界面后仍保留上次的搜索内容与结果（存活于同一局游戏内）。 |
| `client/CultivationAdvancementsPage.java` | 102 | 读取原版已同步进度；不在 UI 推算条件或发放奖励。 |
| `client/CultivationArtsPage.java` | 246 | 槽位、列表与详情分区；三种系统各自发送既有网络请求。 |
| `client/CultivationLayout.java` | 19 | 中置窗口：左右固定留白，内容只在窗口内部滚动。尺寸均为缩放后的 GUI 像素。 |
| `client/CultivationMainScreen.java` | 280 | 原版容器保留在同一个 Screen 中；换页不关闭 Menu，不改 Slot 坐标或物品包。 |
| `client/CultivationPage.java` | 15 | 页面沿用 Screen 的完整输入和生命周期；注册后由主界面装配。 |
| `client/CultivationPageRegistry.java` | 31 | 附属可注册页面及可见条件；未实现的任务、创世不生成占位入口。 |
| `client/CultivationScreenEvents.java` | 30 | 仅替换原版生存背包，不抢占其他模组的背包子类和世界容器。 |
| `client/CultivationSettingsPage.java` | 74 | 左侧分类，右侧只编辑已经存在的客户端御剑配置。 |
| `client/CultivationSwordPage.java` | 130 | 灵剑页只发送既有请求；成长数据和装备校验仍由服务端处理。 |
| `client/CultivationUi.java` | 258 | 各页面共用的像素边框、按钮状态、数值格式与进度条。 |
| `client/CultivationVisionPage.java` | 271 | 内视只显示自身修行状态；所有操作调用现有网络消息。 |
| `client/DivineArtBanner.java` | 77 | 神通发动提示：仅在 HUD 顶部显示短暂文字，不再使用会伪装成断线界面的整屏图片。 |
| `client/ExoticBurnRenderer.java` | 226 | 第一人称异火遮罩与第三人称原版火焰素材替换；worldFireSprite 由客户端 coremod 钩子调用，品阶取点燃来源。 |
| `client/ExoticFireDropletParticle.java` | 67 | 异火缠绕水滴粒子：使用 exotic_fire_droplet 实心水滴贴图（尖朝上、圆底朝下）， 按装备异火品阶动态染色，缓慢上升、轻微摆动并渐隐，取代旧版用异火方块贴图绘制的火苗四边形。 |
| `client/ExoticFireDropletParticleProvider.java` | 27 | 水滴粒子工厂：沿用旧发射器的参数编码——xd 携带品阶（tier 0.01），zd 携带水滴尺寸， yd 为上升速度，避免为此新增网络/存档格式。 |
| `client/ExoticFireOrbitRenderer.java` | 217 | 异火缠绕（防具）视觉发射器：按 WrapVisualPacket 同步来的品阶与缠绕等级，维持一圈小水滴 沿"倾斜环面"轨迹绕玩家旋转（ExoticFireRingParticle）。 <p>每颗水滴固定槽相位 +... |
| `client/ExoticFireRingParticle.java` | 139 | 异火缠绕环形水滴：锁定主人，沿"倾斜环面"轨迹绕身体旋转。 默认环面绕水平轴倾斜 45°（tilt），从正面看向 YZ 竖直面投影时呈现一条与地面成 45° 的线； 缠绕等级更高时另一条环取 -45°（135°）。... |
| `client/FlyingSwordEffects.java` | 221 | Distance-sampled axis path and an independent procedural spiral, both using entity vertices. |
| `client/FlyingSwordItemModels.java` | 36 | GUI 使用图标；世界中的显示统一交给共享几何渲染器。 |
| `client/FlyingSwordItemRenderer.java` | 27 | 根据物品 ID 与飞剑实体共享对应的烘焙模型。 |
| `client/HeartDemonRenderer.java` | 59 | 心魔沿用玩家身形与装备，并使用原版生物渲染流程保持朝向、名称和阴影正确。 |
| `client/HeartMethodScreen.java` | 158 | 心法切换面板：选择后由服务端校验并立即同步。 |
| `client/HumanEmperorBannerFX.java` | 68 | 人皇幡手持特效：旗帜中部（幡面星云区）持续逸散紫色星尘，爪心宝石处闪出白色星芒。 建模提示词接口备注：模型（models/item/human_emperor_banner.json）为静态烘焙物品模型， 无法自带... |
| `client/HumanEmperorBannerPoseModel.java` | 164 | 人皇幡手持渲染包装模型：把物品模型的变换链劫持下来，在使用（释放光线）状态下 依据手持者实体的当前手臂姿态逐帧计算一个补偿四元数，使幡杆在世界里严格垂直于 地面、幡面徽记朝前；空闲手持与其它场景（GUI/掉落/插地... |
| `client/HumanEmperorBannerScreen.java` | 419 | 人皇幡界面：左侧为幡内魂魄，右上为万魂珠魂魄列表，右下为引渡操作和背包。 |
| `client/HumanEmperorBannerStandRenderer.java` | 47 | 插地人皇幡渲染：沿用物品模型的完整 3D 几何，杆尾落入地面并随朝向旋转。 |
| `client/InkButton.java` | 65 | 五行仙途统一的自绘水墨按钮：不使用原版按键贴图，而是深墨底 + 描边， 悬停提亮、禁用变暗，文字在按钮框内水平居中，过长时自动等比缩小，保证在窄栏里也不溢出。 内视、功法轮盘、七十二变、寻真司南等界面共用，观感与面... |
| `client/InnerVisionScreen.java` | 963 | 半透明水墨风内视面板：显示修炼状态、灵根、体质、功法、心法与领域。 |
| `client/InterpolatedFlyingSwordTransform.java` | 41 | One immutable sample per root per render frame, shared by every presentation consumer. |
| `client/InvisibleFireBakedModel.java` | 35 | 原版 FireBlock 的客户端空模型：物理和燃烧逻辑仍由原版方块保留。 |
| `client/MeditationAura.java` | 89 | Procedural emissive discs and tapered ribbons, with no vanilla particle or texture dependency. |
| `client/MeditationModels.java` | 204 | Separate six-pixel upper/lower limbs are used only for meditation. Normal animation and skin geometry remai... |
| `client/MeditationSeatRenderer.java` | 26 | 隐形座位实体不绘制任何几何体，玩家本身仍正常渲染。 |
| `client/ModClientEvents.java` | 810 | 客户端实体渲染器注册。 |
| `client/PedestalFloatingRenderer.java` | 49 | 基座悬浮物品渲染（灵蕴台与承华台共用）：逐点对照 Goety 的 PedestalRenderer—— 物品平移到托盘上方 (0.5, 0.95, 0.5)（新基座模型托盘沿顶为 14/16）， 以 GROUND ... |
| `client/RefiningForgeBlockEntityRenderer.java` | 139 | 未成型炼器台的结构预览： 已摆对的位置显示很淡的蓝色半透明光罩；缺失或摆错的位置显示红色呼吸警示盒， 并在格子中心悬浮一枚缓慢旋转、轻微起伏的“所需方块”全息缩影（符文石 / 磨制黑石砖台阶）， 让玩家直接看清每一... |
| `client/RefiningForgeScreen.java` | 678 | 炼器台界面：深色鎏金面板，配方翻页、产出展示、材料卡实时对照承华台存量， 温度标尺自适应品阶；开始按钮与服务端做同一套校验，不满足时点名缺什么。 材料卡显示材料本名，悬停物品可查看详细信息；关闭时记住停留的配方页。 |
| `client/RootSelectionScreen.java` | 98 | 客户端界面。 |
| `client/SoulFurnaceScreen.java` | 222 | 炼魂炉与化魄炉的共用界面；机器槽位和玩家物品栏严格使用菜单坐标。 |
| `client/SoulHealingRoomScreen.java` | 66 | 愈魂室界面：显示破碎魂珠、能量燃料与修复进度。 |
| `client/SoulTradeScreen.java` | 176 | 原版村民交易界面的拘魂交易扩展：每个可见交易行左侧都有独立收藏星标。 |
| `client/SpiritFireSpriteLoader.java` | 66 | 在图集加载时一次性调色，不逐 tick 重建区块，也不叠乘原版橙色。 |
| `client/SpiritOrbRenderer.java` | 110 | 灵力球渲染：与原版 ExperienceOrbRenderer（1.20.1，已反编译核对）逐行同构。 <p>不再使用任何独立贴图——直接复用原版内置纹理 {@code minecraft:textures/ent... |
| `client/SwordHeldTransform.java` | 54 | 所有坐标采用烘焙模型的像素单位（16 单位为一格），旋转绕真实握柄中心进行。 |
| `client/SwordHeldTransforms.java` | 35 | 每把剑独立登记手持姿态；不修改原始模型及御剑实体姿态。 |
| `client/TalismanPlatformScreen.java` | 452 | 符箓平台界面（不使用原版按键，全部为自绘按钮 + 标注机口）： <ul> <li>镌印台 / 绘制台：左侧是一张长条符纸画布，玩家沿半透明引导笔迹用墨水临写符文， 按住鼠标拖动时用 Bresenham 补线防止断笔... |
| `client/TaoistHatLayer.java` | 100 | Yellow Taoist robe and raised cap, with black robe binding and golden hat trim. |
| `client/TimeStopOverlay.java` | 97 | Scene desaturation before the hand and HUD, independent of vanilla camera shaders. |
| `client/TrailShaderBridge.java` | 134 | 在世界阶段保存深度，合成结束后按保存的世界深度逐像素遮挡剑气。 |
| `client/TransformSelectionScreen.java` | 250 | 七十二变发动时的形态选择界面；显示本地化生灵名称，服务端负责最终校验索引。 顶部新增搜索栏：按本地化名称或形态 ID 做不区分大小写的模糊（子串）匹配。 |
| `client/VerticalSwimFishRenderer.java` | 134 | 鱼类竖直游泳渲染器。 原版 1.20.1 的 Cod/Salmon/TropicalFish/Pufferfish/Tadpole/Turtle 模型与渲染器都从不把 实体的俯仰角（xRot）应用到鱼身上：无论七十... |
| `client/WuXingClient.java` | 231 | 客户端表现/输入辅助。 |
| `client/WuXingClientPackets.java` | 181 | 把各 PLAY_TO_CLIENT 包的真实客户端处理逻辑装进桥接类；仅由客户端初始化路径调用。 |
| `client/WuXingKeybinds.java` | 282 | V 内视按键；R 打开功法轮盘，点击功法槽位释放。 |
| `client/YujianClientCommands.java` | 71 | 客户端御剑命令：只改本地配置，不向服务器发送命令包。 |
| `client/YujianClientController.java` | 176 | Client input/camera bridge. It never decides the authoritative flight result. |
| `client/YujianRidingPose.java` | 61 | The render root rotates about the blade; bones only describe the standing stance. |

---

## 27. Jade 兼容

`src/jade/java/cn/blockforge/generated/generatedmod/compat/CauldronJadePlugin.java`

- `build.gradle` 将 `src/jade/java` 加入 `sourceSets.main.java`。
- Jade 依赖为 `compileOnly maven.modrinth:jade:11.13.3+forge`。
- 若问题是 Jade 指向炼丹炉显示组成结构方块，而不是核心/整体机器，优先检查这个 plugin 与多方块核心定位逻辑，不要改真实碰撞结构。

---

## 28. 维护本导航的规则

发生以下变化时应更新：

- 新增/删除 subsystem。
- 核心入口类改名。
- 玩家永久存档字段体系变化。
- Network 包拆分或新增独立 channel。
- 多方块结构入口改变。
- 御剑 controller/renderer 架构改变。
- 灵祠从自定义 manager 改为标准 StructureSet。

不需要因为以下变化每次更新：

- 单纯贴图替换。
- lang 文案小改。
- 单个 recipe 数值调整。
- 不改变入口的内部重构。

### 建议放置位置

建议把本文件放到项目根目录，文件名保留为：

`AI_SOURCE_MAP.md`

然后在项目根目录的 `AGENTS.md` / Codex 项目指令中加一句：

```text
处理本项目源码任务前先查 AI_SOURCE_MAP.md；禁止在导航能定位时无目的扫描整个 src。
```

这样才能真正持续节省 token，而不是每次仍让 AI 重新理解整个项目。
