# 御剑与植物物品修复记录

本次基于此前三项修复版本继续修改。未修改丹方、PNG、植物世界模型及无关数值平衡。

## 御剑截停与翻滚突变

- `FlightCollision.java` 原先把建造高度上下限当作飞行边界。碰撞盒及一格检查余量使主世界约 Y=317 就被拒绝；末地 Y=300 已高于其建造高度，因此一上剑即被阻挡。现在不再用建造高度限制实体飞行，只在实际存在方块的高度范围扫描方块。世界边界、真实未加载区块、实体/方块碰撞仍按原规则检查。
- `ManualRoll.java`、`YujianController.java`：凌空收回姿态改为趋向最近的整圈水平角，避免把累计多圈角度乘以 0.8 引起突然倒转。
- `YujianController.java`：挂载前及骑乘飞行时清除原版潜行下马标记。潜行键仍通过御剑输入包控制下降。

### D+Space 的 A/B 运行轨迹

相同旧版本、固定 D+Space、无 W/疾跑、无主动技能：

| 时刻 | 输入 | 阶段 | rollVelocity（弧度/刻） | 碰撞计时 | 现象 |
|---|---|---|---:|---:|---|
| A：世界 tick 178 / 飞行第 6 刻 | D=true、Space=true | BASIC | 0.0418879 | 0 | 达到螺旋显示阈值 |
| tick 212 | 同上 | BASIC | 0.1907277 | 0 | 正常上升 |
| tick 213 | 同上 | BASIC | 0.0572274 | 6 | Y≈317，高度判定误报碰撞，首先降低角速度 |
| B：tick 214 / 第 42 刻 | 同上 | BASIC | 0.0192626 | 6 | 速度归零，角速度低于螺旋显示阈值 |

整个区间 bank=0、rollPulseTicks=0、rollPulseCooldown=0、wasRolling=false；无惊鸿或遁虚阶段切换。首先改变的是碰撞结果，随后 `tickFlight` 的 `ride.manualRoll.velocity*=0.3D` 连续压低角速度。累计 roll 并未归零；客户端快照延迟呈现服务端结果，没有单独预测归零。`FlyingSwordEffects.spiral` 的 factor<0.15 或 speed<0.03 会停止绘制，因此视觉上像临时技能结束。修复高度判定后，相同 D+Space 持续 425 刻，从 Y≈300 升至 475，速度约 0.413 格/刻，未截停。

现有御剑操控确实将 A/D 作为手动侧滚输入，而非另设主动翻滚技能。此次保留该既有操控；解决错误中断，没有简单禁用 Roll。

## 惊鸿与遁虚

- 删除 JIANDUN 持续阶段、启动按键状态、旧冷却和持续耗灵；G 只负责遁虚。
- 新增 `JinghongBurst`：支持该能力的剑、已学御剑且满足驾驭条件、原境界 4 / 熟练度 60、疾御前进+疾跑、速度达到该剑疾御上限 70%、连续有效侧滚至少 5 刻、无碰撞、灵力足够、独立冷却结束。
- 成功惊鸿只扣一次原启动消耗 16×剑效率；冷却 30 刻，表现衰减 16 刻；同一次持续按住不重复触发。增加一次前向速度脉冲，复用原翻滚拖尾、残影和冲撞伤害路径。灵力不足不阻止普通侧滚。
- 遁虚直接从疾御进入：支持能力、原境界/熟练度要求（5/80）、前进+疾跑、速度≥疾御上限70%、G连续12刻、无碰撞、路径检查/安全历史通过、灵力及冷却满足。保留20刻持续、240刻冷却、32×效率启动和30×效率/秒耗灵。
- `FlightSnapshot` 增加惊鸿强度；协议版本为57，客户端与服务端须一起更新。
- 关联文件：`YujianPhase`、`YujianTuning`、`YujianController`、`JinghongBurst`、`ProgressionGate`、`ControlledSwordEntity`、`FlightSnapshot`、`FlightInterpolation`、`Network`、`WuXingKeybinds`、`YujianClientController`、`FlyingSwordEffects`、`SpiritSwordItem`、中英文语言文件。

## 植物物品

14种灵植物品此前直接继承 block crossed-plane 模型，在物品渲染路径仍显示交叉面并受到方向光影响；世界模型正确并不能保证物品路径正确。

将以下 `assets/wuxingxiantu/models/item/*.json` 改为 `minecraft:item/generated`，layer0引用原有PNG：adamantine_vine、blood_spirit_flower、clear_heart_lotus、dark_water_weed、dew_drop_flower、dragon_scale_grass、gale_grass、glowing_blue_mushroom、red_sun_grass、spirit_ginseng、spirit_sprout_grass、starlight_flower、thunder_vein_grass、vein_mending_vine。桃树苗原本正确，合计核查15种。

新增公共生成器 `tools/plant-models/generate-item-models.mjs`，按cross模型体系自动生成独立物品模型，`--check`检查一致性。原工程没有对应Java物品datagen。世界模型保留原有 ambientocclusion=false、每element shade=false；本轮未更改世界光照或BakedModel。562个PNG/世界模型哈希未变，219个配方/Formula文件相对原始源码未变。

## 验证

- Forge 1.20.1 / 47.4.10、Java17完整build与reobfJar通过；304个Java、974个JSON静态解析通过，无旧剑遁标识。
- `JinghongBurstTest`：连续按住不重复、冷却、灵力不足、门槛、取消及持续时间通过。
- `ManualRollTest`：正负多圈进入凌空均向最近水平角平滑收回。
- 普通与Oculus/Embeddium/Complementary光影客户端：15种物品烘焙模型为平面、创造/生存物品栏、手持及世界放置截图已检查。
- 调试HUD实际显示遁虚；服务端在遁虚阶段穿过Z=288..290的石头/泥土/石头三格厚墙，穿出后Z>291。惊鸿同步、结束回疾御、连续侧滚只触发一次通过。光影拖尾提交与深度捕获正常。
- 隔离复制用户测试实例模组（未修改用户存档），检查境界飞行、创造飞行、漂浮、缓降、疾风丹同等速度/跳跃效果；未发现它们直接覆盖御剑移动。
- 最终专项运行数据及截图随验证包提供。未进行独立远程多人延迟测试；未声称验证任意第三方飞行药水。

### 最后专项结果

- 末地 Y≈300，双击空格进入境界飞行、D+Space斜向移动后上剑：425刻持续输入，升至Y≈487，速度约1.315格/刻，未发生截停（用户实例模组复制环境）。
- 末地Y=-16、主世界Y=-80：各425刻持续W+D，速度约1.233格/刻，零停滞；下限不再阻挡。
- 按住潜行上剑：修复前实际运行挂载失败；修复后成功挂载、持续下降425刻，零停滞。打开背包后的停止属于刻意清空输入/刹车，不计入连续输入区间。
- 验证包保留失败运行日志以便追溯：早期长距离测试撞到了前一测试未清理的墙/顶板，已经修正测试场景；跨维度双击空格需等待客户端重建；低空测试也需预先加载测试区块。不能把这些测试夹具失败当成生产修复通过。最终低空/潜行专项及D+Space修复前后对照均有独立成功记录；末地高空完整轨迹在后续场景失败之前已完成。
