# 第九批：独立法衣槽审计

后续批 B 已将本界面扩展为“独立装备”，共 38 槽（法衣 1、御剑 1、背包/快捷栏 36），网络协议 55。下文保留第九批历史说明；现行持久御剑槽、锁定、存档和同步规则见 `BATCH_B_REPAIR_REPORT.md`。

法衣槽属于五行仙途核心，数量 1，不依赖 Curios / Accessories，不占用 HEAD、CHEST、LEGS、FEET。未加入其他饰品槽、正式法衣品质、属性、效果或获取系统。

## 数据与容器

- `CultivationDataImpl.robeStack` 保存完整 ItemStack，NBT 为 `robe_stack`；物品 ID、数量、名称、附魔及自定义 NBT 由 ItemStack 标准存档保留，槽位上限 1。
- `robe/RobeSlots` 提供 `getRobe`（副本）、`setRobe`、`canEquipRobe`、`hasRobe`。服务端 set 校验数量与 `#wuxingxiantu:robes`；客户端不能发任意 stack 的装备请求。
- `RobeContainer` 为服务端能力数据的实时容器视图，开放菜单不缓存第二份装备；命令清空、死亡、菜单交互读取同一实际栈。
- `RobeMenu` 共 37 槽：1 个法衣槽、27 个背包槽、9 个快捷栏槽。服务器注册正式 MenuType，客户端使用原生容器同步，鼠标光标、拖拽、双击、丢弃与关闭沿用 AbstractContainerMenu。
- shift-click：背包中的合法法衣优先进入空法衣槽；法衣槽向玩家背包移动；其他物品只在背包/快捷栏之间转移。非法物品不能放入法衣槽；满背包不强行删除物品。
- 沿用原版绑定诅咒的不可脱下规则，创造模式或死亡不受该提取限制。原物品 NBT 不因装备重建为默认物品。

## UI

- 现有生存背包 `CultivationMainScreen` 的玩家预览和合成区之间，增加 18×18 法衣图标入口（原背包相对 x=79,y=7），显示当前法衣或道袍轮廓。
- 点击入口打开 `RobeScreen` 的 176×147 小型装备容器。可以在这个面板中实际拖入、取出、双击和 shift-click；**未篡改原版 InventoryMenu 的槽序号**。
- 普通背包界面里的 shift-click 仍沿用原版逻辑；法衣优先转移在法衣面板内执行。原背包不是一个伪装的本地装备槽。
- 配方书打开时隐藏入口，避免覆盖配方面板；光标持物或正在拖拽时不切换容器。现有 GUI 布局和 JEI 报告窗口范围保持。
- 创造模式未替换原版创造背包，可通过 OP `/wuxingxiantu robe open` 打开同一个真实容器。没有另写一套创造物品移动协议。
- 已做槽位坐标与最低常用 GUI 尺寸的几何检查。GUI Scale、JEI/REI、效果栏和网络延迟的实际游戏画面未运行验证。

## 测试物品

`wuxingxiantu:dev_test_robe` 是唯一测试占位物，普通 Item、不可堆叠，加入 robes 与 creative_test 标签，并列入 `WuXingItemSources.CREATIVE_TEST`。

有独立 16×16 道袍轮廓图标、物品模型和中英文名称；无生存配方、交易、掉落、属性、套装或正式世界观定位。本批没有正式穿戴模型，图标不代表最终法衣外观。

## 死亡、保存与同步

- keepInventory=true：能力栈保留并随 Clone 复制。
- keepInventory=false：`LivingDropsEvent` 在追加唯一掉落实体前将能力栈清空；消失诅咒不掉落。`GeneratedMod.clonePlayer` 再按死亡规则排除已应掉落的法衣，防止复制路径留下一份。
- 正常进入/退出心境和维度切换不卸法衣。心境死亡由同一掉落事件处理，再随正常死亡物品迁移到安全返回点；不独立生成第二份法衣。
- 登录、重生、换维度、开始追踪玩家及装备变更发送 `RobeSyncPacket`；包含实体 ID、玩家 UUID 和完整 ItemStack。
- `TRACKING_ENTITY_AND_SELF` 同步自己与观察者，客户端按 UUID 缓存，兼容追踪包先于实体生成；离开世界/服务器清理缓存。不在每 tick 发送法衣 NBT。
- 服务端容器依然使用原生状态 ID 与物品包纠正迟到的点击，装备同步包只负责数据/渲染，不接受反向修改。

## 渲染接口

- `client/RobeRenderProfile` 提供 model、texture、renderType 与 VisibilityMask；head/chest/legs/feet 四个布尔值分别控制四个盔甲部位。
- `RobeLayer.register(itemId,profile,visual)` 是客户端注册入口，Visual 收到玩家、物品副本、玩家模型、PoseStack、缓冲、光照和 partial tick，可供后续正式模型接入。
- 测试法衣注册空外观和不隐藏任何部位的 profile，Layer 回调增加 `renderedTestFrames`，便于开发断点验证实际渲染路径；本批不假装已有正式道袍模型。
- `RobeArmorLayer` 复用 Forge 1.20.1 `getArmorModelHook`：被隐藏的部位返回不输出顶点的模型，否则继续原钩子。纹理、附魔光效和饰纹均通过该模型；不删除或替换任何服务器盔甲 ItemStack。
- 只在玩家渲染器中替换原版标准 HumanoidArmorLayer，其他模组自定义的整层实现不强行替换。使用已有工程的按类型反射访问层列表模式，需在真实模组组合中验收。
- 玩家皮肤、未覆盖部位、盔甲属性都保留。所有模型/渲染引用限于 client 包，公共能力与 robe 包不导入 Minecraft 客户端类。

## 开发命令与验证

- `/wuxingxiantu robe inspect`：OP 查看服务端法衣完整保存数据。
- `/wuxingxiantu robe open`：OP 打开真实测试容器，也可用于创造模式。
- `/wuxingxiantu robe clear`：OP 关闭当前容器、卸下法衣并放回背包，背包满时沿用原版放回/掉落逻辑。

已通过：Java/JSON 解析、API 签名核对、NBT 与标签路径、服务器校验、原生容器移动分支、死亡清空/复制顺序、同步接收方、四部位渲染掩码、无客户端公共引用、图标非空与 UI 坐标不重叠等静态检查。

**用户追加允许构建后，完整 Gradle build 与 reobfJar 已通过，并单独交付 JAR；没有实际多人/死亡/容器运行验收。** 编译 0 错误、88 条警告；标准 test 任务为 NO-SOURCE。附件 L-T（非法物品、存档、跨维度、两种死亡规则、shift-click、拖拽双击、观察者同步）仍需在游戏中逐项实测，不能把编译或静态审查写成已证实无 duplication。
