# 历史实现记录：心铸机制

后续权威契约及跨御剑伤害修改见 docs/audits/current/20260926_SOURCE_UPDATE.md。本文件描述当时实现，不代表当前验证结果。

状态：源码已修改，未编译、未构建、未运行 GameTest。下述运行行为为实现目标和代码路径说明，不是实机验证结论。

## 统一公式

Java 根目录：`src/main/java/cn/blockforge/generated/generatedmod/`。

权威入口为 `combat/HeartSwordCombatProfile.java`：

- 复制玩家当前 ATTACK_DAMAGE 属性，移除当前主手武器贡献，保留角色境界、体质和其他合法属性修饰，得到非武器基准 C。不修改玩家实时属性。
- 心剑 B = C × (1.10 + 0.05 × clamp(realm,0,8)) × (1.00 + 0.02 × clamp(stage,0,3))。
- 原剑 A = 同一属性副本重新加入原剑主手修饰后的数值。
- 合法主人心铸攻击基准 = max(A,B)。不把 A、B 相加，不重加 RealmBalance.attack，不再叠加角色完整小阶段倍率。
- 原版 Player.attack 在此基准后继续处理攻击冷却、暴击和合法附魔；Tooltip 显示的是基准而非每次实际扣血。
- HeartSwordItem 不再向主手属性暴露 DIAMOND + 固定攻击的兼容数值，攻击速度保留。

## Traits、伤害与归属

纯心剑与心铸共用 Trait 集合（目前 TRUE_DAMAGE）。NBT 只保留 HeartForged、HeartOwner 等既有状态，不保存伤害快照；每次攻击查询实际持有者当前能力。

`coremods/heart_sword_combat.js` 替换 Player.attack 内的攻击属性读取和原有 hurt 调用，不追加第二次主攻击。横扫继续使用原版次级伤害公式和目标排除规则，并共享心剑伤害性质。原版暴击、击退、火焰附魔、命中回调仍沿原攻击流程执行。替换入口有 ThreadLocal 重入保护。

专用 `wuxingxiantu:heart_true` 经正式 `target.hurt(DamageSource, amount)` 结算，没有直接改血。数据包标签绕过 armor、shield、resistance、enchantments、effects；LivingEntity 与 Player 的 actuallyHurt 内只针对此伤害将吸收贡献视为零并跳过吸收值写入，因此吸收生命保留。

本 Mod 护体、心法、元素和御剑数值防御跳过此伤害；`HeartTrueDamageEvents` 保留事件入口伤害下限，同时尊重取消事件。它不承诺压过任意第三方 Mod 的自定义 hurt 覆盖、同优先级后执行监听或另行取消攻击。

没有 BYPASSES_INVULNERABILITY、BYPASSES_COOLDOWN 或 generic_kill 语义。保留时停、冻结、心境隔离、心魔转阶段锁等取消/无敌路径；显式拒绝已死、removed、创造/旁观目标。非主人纯心剑拒绝主伤害，非主人心铸只走普通武器；不查询离线主人。掉落实体灵剑保留原物品并解除心铸。

普通功法不会因为手持心剑自动变成真实伤害。未来专属能力可显式调用 applyHeartTrueDamage，并自行承担技能资格和消耗检查。

## UI、创造丹和视觉

- Tooltip 显示境界/阶段共鸣、伤害性质和动态基准；心铸同时显示原剑与心剑投影。`InnerVisionScreen` 使用同一攻击入口。
- `CreationPillItem` 使用显式 restoreDaoXin(1)，清除入侵原因与待挑战选择。已满配玩家仍可再次修复道心。心境归返/封存尚未恢复时拒绝继续改写状态，不消耗丹药。
- 右侧法衣、御剑、副手坐标统一为 x=80，y=8/35/62，间隔 27。副手索引和 Shift 转移规则保留。
- 贴图保持 256×256、原 UV 布局和 alpha，增强冷玉晶面、明亮剑脊与浅金护手细节；Blockbench 内嵌纹理同步。
- 第一人称 display rotation 为 [-12,0,-14]，scale 保持 0.55，translation 根据 OBJ 握点 (0,-0.2,0) 重新计算。原握点不漂移，左右手由原版镜像变换处理。第三人称参数未改。
- 对比图 `source-assets/heart_sword-texture-comparison.png` 左旧右新，仅为纹理图，不是游戏截图。

## 自动化验证状态

实际运行并通过：11 项资源检查、3 项心剑素材检查、两份 coremod JS 语法检查。只读 javap/SRG 检查确认 AttributeInstance.replaceFrom、伤害标签、主攻击/横扫调用位置、吸收挂钩、装备槽构造坐标；修正吸收读取 SRG 为 m_6103_。

以下 `HeartSwordCombatGameTests` 21 项均 required，已编写但未编译/未运行：

1. armorAndToughness
2. resistance
3. protection
4. absorptionPreserved
5. shield
6. allRealmAndStageGrowth
7. forgedUsesMaximumAndSharedTraits
8. unforgePreservesPhysicalItem
9. nonownerPureSwordRejected
10. nonownerForgedRemainsPhysical
11. existingForgeGrowsWithoutNbtSnapshots
12. creativeAndSpectatorProtected
13. exactlyOnePrimaryHit
14. cooldownStillScalesDamage
15. unrelatedSpellStaysPhysical
16. heartDemonPhaseLockRespected
17. ordinaryInvulnerabilityRespected
18. creationPillRepairsDaoHeartAgain
19. numericReductionBypassedButCancellationRespected
20. forgedMeleeKeepsEnchantmentAndTrueDamage
21. rightEquipmentSlotsAligned

另有 `RecheckGameTests.heartTruePhaseTwoKillCompletesChallenge`，复用已存在的真实 ServerPlayer、合法心境会话和区块等待夹具，覆盖两阶段、主人击杀结算、封存恢复与修为保持，同样尚未运行。

玩家测试使用 GameTestPlayer，不使用 FakePlayer；计时字段只用于设定原版攻击冷却/盾牌起手的测试初始条件，不覆写伤害行为。心魔阶段单测直接构造并加入测试 Level，不改正式自然生成限制；完整结算测试走合法会话。

下一次获准构建后，需要先编译并执行上述 required GameTest；任何失败必须逐项诊断，不可改为 non-blocking 后宣称通过。GUI 比例、持剑观感、四动作与完整整合包兼容仍需要实机验证。
