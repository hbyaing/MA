# 新增修复批 B：御剑槽、BossBar、打坐视觉

目标 Minecraft 1.20.1 / Forge 47.4.10 / Java 17 / GeckoLib 4.8.4。源码版本保持 1.0.0-r10，网络协议由 54 更新为 55，客户端与服务器需要同步更新。

本批遵循用户“不直接构建”：没有运行 Gradle、javac、runData、Minecraft，也没有新 JAR。下述检查是源码、缓存 API 和离线资源检查，不代表游戏实测。上一批已封存为 `wuxingxiantu-r10-core-regression-source.zip`。

## 文档问题逐项回答

1. **切换主手为何退出**：旧 `YujianController.updateHeldSword` 每 tick 使用主手执行御剑资格检查，拿方块、丹药等物品就返回 false 并 stop。该方法已移除。
2. **槽保存位置**：`CultivationDataImpl.yujianStack`，NBT 键 `yujian_stack`。真实 ItemStack 标准序列化，保留名称、附魔、剑灵力、剑蕴、剑诀配置和 Forge 能力数据。旧档缺键读为空槽。
3. **唯一飞剑来源**：`robe/YujianSlot.activeFlyingSword(player)` 返回该能力中的真实栈。持续合法性、飞行定义、阶段速度、养剑经验与冲撞属性均从此栈读取；实体 ITEM 仅是同步给渲染器的显示快照，不是可提取库存。
4. **主手要求**：只在空槽起飞时读取主手。先将主手设 EMPTY，再把原对象放入能力槽；没有 copy 或保留原剑。预装槽优先，热键栏、主副手切换不改变飞剑。养剑界面新增御剑槽入口，战斗剑诀优先使用主手另一把灵剑，飞行仍使用槽内剑。原有主动下剑、资源不足、死亡、维度切换和其他安全退出条件保留。
5. **死亡与重连**：正常落地、退出和换维度不退还槽内剑，继续作为持久装备。无 keepInventory 时掉落事件先清空能力槽，再添加唯一掉落实体；消失诅咒沿用原版规则。Clone 在普通死亡时不复制已掉落装备，并清空旧玩家的御剑槽。keepInventory / 非死亡 Clone 从完整 NBT 继承。登录、重生、换维度、追踪和装备变更同步栈与锁状态；飞行中每秒更新养剑 NBT。服务器的 menu/slot/container/setter 均拦截飞行中的提取或替换。
6. **标题距离原因**：当前代码实际上已自己绘制 Component，但颜色写死白色；旧原图 crop 包含大量透明边距，标题放在 crop 顶部，视觉上像远离血条的原版标题。修复保留 Component/lang，不烙字。
7. **标题参数**：`nameOffsetX`、`nameOffsetY`、`nameScale`、`nameColor`、`nameShadow`。默认偏移 0、比例 0.9，每个 Boss 有配套颜色。统一 renderer，标题与有效图像间距 2 GUI 像素。
8. **堆叠公式**：条目高度 = 缩放后的字体高度 + 标题偏移留白 + 2 + 实际裁剪血条高度；下一条增加条目高度 + 5。多条超高且数量大于 3 时分两列，再等比缩小完整条目以适配可用高度。UUID、Component、纹理和血量保存在同一个 Entry 中。
9. **黑斑证据与边界**：旧 11 张 frame 图中，每张存在 8,954 至 49,461 个 `0 < alpha <= 16 && max(RGB) < 32` 的像素；原图约 2100 像素宽却每帧缩到 HUD 尺寸。离线分析确认这些近透明黑像素和大幅缩小采样问题；未启动实际光影环境，不能声称已经证明所有实机黑斑只由它们造成。
10. **alpha/filter/state**：保留原 PNG，新增 520 像素宽 HUD 资源。定向去除低 alpha 黑像素，按有效轮廓裁剪，用预乘 alpha 面积采样缩小，再进行透明边缘 RGB bleed。实际蓝白、红黑实色装饰不按颜色删除。texture metadata 和运行时都禁止线性模糊、mipmap。每条绘制重置 blend/depth/color，finally 恢复进入前的 shader、颜色、贴图、深度写入、深度测试、剔除和 blend；HUD 不改 scissor。
11. **打坐为何受光影影响**：源码已不是纯 ParticleEngine，而是在 AFTER_PARTICLES 用 position-color shader 直接绘制到当时 framebuffer；后续光影合成可能覆盖或错误解释该输出。原实现也只恢复默认状态，没有完整保存进入时状态。实际测试光影包未启动，因此这是代码链路证据，不是运行期定位报告。
12. **复用链路**：光影开启时复用御剑 `TrailShaderBridge` 的世界深度快照、自定义 shader 和合成后 RenderGuiEvent.Pre 绘制；F1 时由 RenderTickEvent.END 提交。与筋斗云一样保存世界相机矩阵/深度以维持遮挡。打坐有独立 BufferBuilder 和 pending，不复用/覆盖飞剑 mesh；同帧共享已成功捕获的深度。通道补充保存/恢复颜色和 scissor。
13. **丹田金光**：汇聚光带、流动光头、三层无贴图光核/淡晕，由 position-color 几何绘制，不受环境光压暗。光核呼吸，汇聚到达增加亮度；只有服务端修为实际增加才同步一次短时扩散反馈。不是单个黄色粒子。
14. **300 tick 金红插值**：打坐座位 SynchedEntityData 同步真实冥想状态、主线入境标志、tick 采样及采样时间，每 10 tick 更新。客户端最多外推 12 tick；0–60 金色，60–160 金到琥珀，160–240 琥珀到金红混色，240–300 到暗红，段内 smoothstep。普通打坐永远读取进度 0。
15. **最后一刻**：290–300 tick 累积加速汇聚，光核半径最多缩到约 28%，局部亮度渐弱到 50%，然后沿用既有心境转移。无全屏爆闪。取消/移动/受击后座位状态清零或实体移除，绘制要求真实乘坐且 active，因此不会留下永久红光。
16. **mc_check**：当前工具环境没有 mc_check。替代静态检查 8 项全部通过：Java/JSON/metadata 解析、栈所有权与锁入口、存档和同步路径、HUD 像素/引用、打坐数据/渲染路径、直接求值颜色函数、缓存 Forge API 签名、与封存源码的保护范围对比。另有 20 组 1/2/3/10 Boss × 5 GUI 尺寸的离线布局边界/不重叠检查。离线预览使用 Windows 字体，不是游戏截图。
17. **Forge build**：未执行，遵循用户限制。新增两个 Forge GameTest 源码用例，并更新旧用例中与持久御剑槽直接冲突的断言；没有编译或运行它们。现有 src/gametest 是可选测试源，当前 build.gradle 未配置 GameTest run。
18. **最终 Jar**：无新 JAR，不能将旧 r9 JAR 当作本批结果。交付 `wuxingxiantu-r10-repair-b-source.zip`。

## 文件范围

- 能力与同步：`CultivationData.java`、`CultivationDataImpl.java`、`GeneratedMod.java`、`Network.java`。
- 御剑槽：新增 `robe/YujianSlot.java`；修改 `RobeSlots`、`RobeContainer`、`RobeMenu`、`client/RobeClient`、`RobeScreen`、`CultivationSwordPage`、`yujian/YujianController`、`ControlledSwordEntity`、`SwordNurture`。
- BossBar：`boss/BossVisualDefinition.java`、`client/boss/BossBarHud.java`、`boss_visuals.json`、22 张新 HUD PNG 和 22 份采样 metadata。
- 打坐：`MeditationSeatEntity.java`、`CultivationBlock.java`、`mindscape/MindscapeManager.java` 仅增加进度同步、`client/MeditationAura.java`、`TrailShaderBridge.java`。
- 其他：两份 lang 中装备标题/槽名，`FlyingSwordGameTests.java` 与交付文档。逐文件清单见 `batch-b-changed-files.json`。

丹药注册、灵植、炼器台、灵剑附魔、GeckoLib、心魔战斗/镜像、炼丹炉 GUI、境界与 Boss 数值均未改动。资源扫描两个模组的 1234 份 JSON、558 个模型、25 组动画、85 个世界生成条目，报告 0 error / 0 warning；这不是运行期 codec 或 shader 验证。

## 尚待实机验收

未验证当前光影包下的最终像素、OpenGL 状态、F1、GUI Scale、玩家装备包到达顺序、真实死亡/重连和多人玩法。因此不能把静态通过写成“确认实机无黑斑、无复制或光影兼容”。后续获准构建与启动后，应执行附件的全部 18 条场景；尤其包含飞行时打开装备界面的所有点击方式、keepInventory 两种模式、无空位背包、双人跟踪，以及十个 Boss 与打坐/御剑同时显示。
