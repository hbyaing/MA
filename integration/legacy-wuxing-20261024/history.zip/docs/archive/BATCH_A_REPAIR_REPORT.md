# 新增修复批 A V2：炼丹炉专项

基于第十批 V2 与新增修复批 B 的当前源码。目标保持 Minecraft 1.20.1、Forge 47.4.10、Java 17、GeckoLib 4.8.4。用户后续已明确授权完整构建；此前第十批与批 B 的源码封存包不覆盖。

## 实现与复核

| 文档要求 | 实现 |
| --- | --- |
| 用户模型原样接入 | 将 Blockbench 5.0 free 格式的 4,779 个 cube 按祖先组/元素旋转导出 OBJ，38,232 个顶点、28,204 个面；不删改造型。6 张内嵌 PNG 原样提取。原 bbmodel 保存在 source-assets。 |
| 运行时路径 | assets/wuxingxiantu/models/block/cauldron_structure.json、.obj、.mtl；材质位于 textures/block/cauldron/material_0..5.png。 |
| 侧壁颜色修正 | 新导出 UV 的 V 已是贴图上缘为 0。旧配置 flip_v=true 会再次翻转，错误采样金色区域；改成 false，恢复原始深绿色符文侧壁。贴图本身与模型内嵌原图逐字节一致。 |
| 集中视觉坐标 | AlchemyFurnaceVisualLayout：底板上沿 0.56125；材料中心 y=1.38；火心 y=0.64、最大火高 0.84；炉口 y=3.2217925；成丹 y=4.0017925。坐标相对底部核心，XZ 中心加 0.5。 |
| 材料排布 | BER 直接读取原有 8 个材料槽的 ItemStack。1 槽居中、2–4 槽半径 0.43、5–8 槽半径 0.78，带轻微浮动/自转与末段收拢；没有视觉库存或材料 ItemEntity。 |
| 材料仍然参与炼制 | 开炉按原配方预留各槽数量并锁槽；完成、取消或重载失去任务时结算预留消耗。保留原有开炉消耗灵力、失败损耗素材的规则；槽中未使用余量保留。预留仅保存整数数量，无第二份物品库存。 |
| 输入锁定 | GUI mayPlace/mayPickup、容器移除/写入、Shift 合并路径均检查 brewing，防止期间移走真实素材/异火瓶。 |
| 碰撞 | 从主体炉壁、炉盖、底座、支撑及窗口大框提取保守的 1/4 格碰撞，再合并轴对齐盒。59 个有实体轮廓的格，单格最多 19 盒，启动缓存四向 VoxelShape；不是逐三角面物理碰撞。 |
| 炉口和正面 | 炉口中心保留空洞，实体炉口圈保留碰撞；正面窗口中段空，不再整格堵住。SEAL/内部占位块存储原 AIR 并按实际轮廓返回形状；拆炉恢复原方块与原方块实体。 |
| 选择形状 | 选择形状另加入简化龙身/凤身选区，碰撞不加入须、羽毛、符文等细节。占位块和核心使用 dynamicShape，避免位置相关形状被同一 BlockState 错误缓存。 |
| 四朝向 | 核心放置记录 FACING，渲染、效果和碰撞共享方向计算；既有 NORTH 核心继续保留原方向。对称搭建蓝图保持原布局与朝外高炉规则。 |
| actual fire_id | 开始炼制时从实际点火槽瓶子的 FireCultivation.fire_id 记录 activeFireId，保留至取丹结束；不读取玩家装备异火。 |
| 异火视觉 | FireCatalog 解析 fire_id，复用 ExoticFireColorRegistry 的主色/辅色；专用世界几何绘制半透明火舌与核心，客户端每 5 tick 少量火色 dust 辅助。无真实 FireBlock、无碰撞、无服务端逐 tick 粒子广播。 |
| 炼制阶段 | 0–20% 起火，20–70% 稳定，70–95% 核心增强/素材收拢，95–100% 素材聚合/火焰收束。 |
| 丹成动画 | 8 tick 收火、10 tick 金色核心、42 tick 螺旋上升光带和稀疏几何符文，48 tick 起显丹，60 tick 后仅保留真实物品悬浮及微弱金辉。没有爆炸闪屏。 |
| 参考图语言 | 多股半透明带相互缠绕、从炉口向上升、顶端淡出；金/白金核心搭配实际异火辅色。Grade 影响条数、大小和强度；仅已有 Element 标签时添加对应辅色，不写入新 Element。 |
| 光影通路 | 炉火/丹气使用独立 BufferBuilder 和待提交网格，复用 TrailShaderBridge 世界深度快照和光影合成后绘制；GUI 隐藏时由 RenderTick END 提交。常规路径恢复混合、深度、剔除、颜色和 shader 状态，不覆盖御剑/打坐缓冲。 |
| 唯一结果 | AlchemyFurnaceBlockEntity.completedResult 为唯一已完成物品源；Network 完成时提交给 BE，不再生成丹药 ItemEntity。GUI 中央预览优先引用相同结果，不增加输出槽。 |
| 自动取丹 | 服务端每 8 tick 检查炉口 2.5 格范围，按玩家眼位核对球形距离；不锁炼丹者。主动画结束后允许领取。 |
| 满包/多人 | 先合并相同物品与 NBT，再使用空主背包格；只 split/shrink 实际插入数量。全满不扣数量；多人按服务端顺序操作同一对象。创造模式也不调用会抛弃剩余物品的通用 add 路径。 |
| 存档 | CompletedResult 完整保存 ItemStack NBT，保留 Grade 与未知标签；ActiveFireId、预留数量、炼制状态一同保存。CompletionTick 只发送客户端，不写磁盘，重载结果不会从头重放主动画。 |
| 新炉保护 | completedResult 非空时服务端拒绝开始，GUI 提示“先取走丹药”，防止覆盖。全部领取后结果和视觉状态清空。 |
| 拆核心 | 正常拆除时丹药随核心方块物品的 BlockEntityTag 携带，放回后恢复，不单独生成丹药掉落物；创造拆除和使用不合适工具也保留此携带核心。任意管理命令强制销毁方块/物品不属于取丹事务。 |
| 同步 | BE 更新包和区块初始数据同步真实库存、状态、火种、结果；应用快照前清空旧槽，避免省略的空槽在客户端留下假材料。 |

## 验证与边界

静态验证共 7 组：所有 314 个主/可选测试 Java 文件以及 1,021 个 JSON/metadata 解析；原模型/贴图一致性；四向碰撞采样；直接提取生产插入方法的语义测试；结果持久化和锁槽检查；渲染路径检查；与批 B 源码封存逐文件对比。资源扫描覆盖两 MOD，1,235 个 JSON、558 个模型、85 个 worldgen 条目，未报错误或警告。

已执行 Gradle 8.8 的完整 build（项目没有 gradlew，使用本机已缓存的同版 Gradle），包含 compileJava、processResources、jar、reobfJar；不是只执行编译。首次编译发现第十批 LegacyStackMigration 的 mapping.key 非公开，已改用 Forge 1.20.1 的 mapping.getKey()；不改迁移行为。mc_check 工具在本会话不可用，由上述检查及隔离 Forge 实机测试替代。

隔离客户端以生产重混淆 JAR 启动 Java 17 / Forge 47.4.10 / GeckoLib 4.8.4，创建独立世界，验证模型烘焙 28,204 面、四向炉口与底座、真实 ItemStack 部分/满包/连续两人领取、结果 NBT 重载、不重播标记、禁止覆盖、旧 ID 的 ItemStack 构造迁移、真实玩家自动取丹及客户端同步；另完成真实配方预留、异火瓶绑定、完成流程截图。隔离测试 MOD 不进入交付 JAR。

可选 src/gametest 用例已更新旧“完整封口”断言并补充领取/持久化用例。默认 build 没有配置 gametest sourceSet，不把 test NO-SOURCE 算作这些测试通过；核心场景由独立实机探针直接调用生产代码验证。

最终光影、截图、JAR 资源逐项核对及 SHA256 见交付目录 batch-a-delivery-verification.json。硬件和其他光影包的表现不能由单个测试组合保证。保存/加载路径已实测 NBT roundtrip，不将其描述成真实专用服务器重启测试。

光影实测组合为 Oculus 1.8.0 + Embeddium 0.3.31 + Complementary Unbound r5.8.1。开启光影时获取到 960×540 世界深度快照；炉内蓝色异火、上升旋流及悬浮丹药均已截图核对，侧壁恢复原深绿色符文贴图。光影包自身仍报告 BIOME_PALE_GARDEN/endFlashIntensity uniform 与 stone_slab variant 跨版本兼容警告；Oculus 对 Embeddium 的 mixin 修改提示也仍存在。这些未修改第三方文件规避，测试客户端正常退出。

原有 Java API 弃用提示（ResourceLocation 构造器、部分 RenderLayer API）和 Gradle 9 兼容性提示仍保留；不为消除警告改用 1.21 API。离线账号的 Realms 验证提示、空配置首次默认值写入提示不属于炉子资源错误。

构建内部文件名：wuxingxiantu-1.0.0-r10.jar。交付名称：wuxingxiantu-1.0.0-r10-repair-a.jar，内容为同一重混淆产物。源码包包含批 10、批 B、批 A 的累计改动，之前独立封存文件保留。
