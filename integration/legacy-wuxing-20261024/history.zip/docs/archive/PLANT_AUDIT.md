# 第十批灵植显示审计

本批仅做资源与源码静态检查，没有启动游戏。手持/世界亮度差异的定位依据是模型链，而非亮度截图测量。

14 种灵植共 42 个 block model，全部加入 `textures.particle=#cross` 并验证 cross 指向真实 PNG。低龄/中龄模型原本自行定义 elements 且没有 parent/particle，导致破坏粒子解析到 missing texture；成熟模型原继承 vanilla cross，本批同样显式声明以统一验证。

幼苗原横向范围始终 0.8..15.2，纵向却是 0..6 / 0..11，完整 UV 被单独压缩高度。现在宽高统一按 6/16、11/16 缩放，保留年龄视觉差异，成熟阶段维持原 cross 尺寸。旋转围绕植株底部中心，仅绕 Y 轴。

自定义幼苗 elements 原省略 shade，默认面方向变暗，且与成熟/物品渲染链不同。现在全部 elements `shade=false`、模型 `ambientocclusion=false`；保留环境光，不给普通灵植额外发光。未提亮或改写任何灵植 PNG、item model、blockstate、tint 或生长定义。

客户端现有 14 种 `RenderType.cutout()` 保留。没有注册灵植 biome/color tint；星辉花和蓝蘑菇原有光照值保留。透明 PNG、waterlogged、年龄状态和自然生成数据保持。

| 灵植 ID | 三阶段比例 | particle / PNG | 手持资源 |
| --- | --- | --- | --- |
| spirit_sprout_grass | 已静态检查 | 已静态检查 | 未改 |
| dew_drop_flower | 已静态检查 | 已静态检查 | 未改 |
| clear_heart_lotus | 已静态检查 | 已静态检查 | 未改 |
| spirit_ginseng | 已静态检查 | 已静态检查 | 未改 |
| red_sun_grass | 已静态检查 | 已静态检查 | 未改 |
| vein_mending_vine | 已静态检查 | 已静态检查 | 未改 |
| blood_spirit_flower | 已静态检查 | 已静态检查 | 未改 |
| adamantine_vine | 已静态检查 | 已静态检查 | 未改 |
| gale_grass | 已静态检查 | 已静态检查 | 未改 |
| dark_water_weed | 已静态检查 | 已静态检查 | 未改 |
| thunder_vein_grass | 已静态检查 | 已静态检查 | 未改 |
| starlight_flower | 已静态检查 | 已静态检查 | 未改 |
| dragon_scale_grass | 已静态检查 | 已静态检查 | 未改 |
| glowing_blue_mushroom | 已静态检查 | 已静态检查 | 未改 |

待实机逐株验证：年龄 0/3/成熟、水中/陆地、昼夜、破坏粒子、透明边缘、手持/掉落模型和光影包。
