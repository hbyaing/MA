# 丹药审计（第十批更新）

## 范围与验证边界

Minecraft 1.20.1 / Forge 47.4.10 / Java 17，r10 源码增量。遵守用户“不直接构建”的要求，
没有运行 Gradle、Java 编译、Minecraft、旧世界载入或多人测试。以下“已实现”表示源码与数据已修改，
静态检查通过；游戏内效果、旧世界读写及最终数值平衡仍需后续实机验收。

## 注册和迁移

原项目 52 个正常丹药注册，加创造丹 1 个，共 53 个丹药注册。
另有 6 个妖兽内丹复用了 BasePillItem 派生类，它们是引劫原料，不计为丹药；修炼心得也不是丹药。

| 原组 | 原注册数 | 正式类型数 | 迁移 |
| --- | --- | --- | --- |
| 五行灵根丹 | 20 | 1 | root_awakening_pill + Element + Grade |
| 回灵丹 | 4 | 1 | aura_pill + Grade |
| 筑基丹 | 4 | 1 | foundation_pill + Grade |
| 渡劫丹 | 5 | 1 | tribulation_pill + Grade；旧 common 对应 LOW |
| 突破丹 | 4 | 1 | breakthrough_pill + Grade |
| 修为丹 | 4 | 1 | cultivation_pill + Grade + CultivationTier |
| 其余普通功能丹 | 10 | 10 | 原单 Item + Grade |
| 洗髓丹 | 1 | 1 | 原单 Item + Grade |
| 创造丹 | 1 | 1 测试 | 保留，绝无生存配方 |

品质重复部分减少 31 个正式注册（其中含旧凡品渡劫丹重复档），五行元素收束再减少 4 个，
52 个原始生存注册对应 17 个正式类型。第十批实际删除全部 40 个旧别名注册，
最终为 17 个生存丹药 Item + 1 个创造测试丹，共 18 个；妖兽内丹和修炼心得另计。

完整退役 ID 范围：

- `root_{gold,wood,water,fire,earth}_{low,mid,high,perfect}`：20 个。
- `aura_pill_{low,mid,high,perfect}`：4 个。
- `foundation_pill_{mid,high,perfect}`：3 个；原 foundation_pill 为正式 ID。
- `tribulation_pill_{common,low,mid,high,perfect}`：5 个。
- `breakthrough_pill_{low,mid,high,perfect}`：4 个。
- `cultivation_pill_{low,mid,high,perfect}`：4 个。

旧 ID 不再注册或列入命令建议，也没有新配方产出。所有正常丹药由 UnifiedPillItem 创建，BasePillItem 仍调用原统一效果。
`LegacyStackMigration.migrate` 在 `ItemStack(CompoundTag)` 解析注册 ID 前复制原 NBT，改为 canonical ID，补 Grade/Element，保留 Count、ForgeCaps、CultivationTier 和所有额外字段。
MissingMappings 将旧注册引用映射到统一 Item，但品质从仍未被解析的原始 NBT id 恢复，避免映射后丢失后缀信息。
背包、箱子、掉落物及其他调用原生 ItemStack NBT 构造的存储均按需迁移，不依赖玩家 tick，也不扫描重写未加载区块。
旧修为丹缺少适用境界信息时按练气档处理，保留原品质，不继承旧百分比暴涨逻辑。
缺少 Grade 的原单 Item 按 LOW 处理；损坏的 Element 回退到兼容默认值，不进入旧效果旁路。

## 数据结构

Forge 1.20.1 使用 ItemStack NBT：`Grade=LOW/MID/HIGH/PERFECT`。
灵根丹另存 `Element=METAL/WOOD/WATER/FIRE/EARTH`，如极品火灵根丹为
`wuxingxiantu:root_awakening_pill{Grade:"PERFECT",Element:"FIRE"}`。
修为丹的 `CultivationTier=0..8` 对应练气至地仙。
同一物品不同 NBT 不会普通合堆；创造栏用同一个注册构造不同品质、元素和境界档位。

丹方卷轴使用一个 `alchemy_formula` Item，NBT `FormulaId=wuxingxiantu:<丹药类型>`。
知识存于玩家持久 NBT `PlayerPersisted.wuxingxiantu_formulas`，死亡复制；每类只学习一次，
覆盖所有品质，灵根丹也覆盖五行，修为丹也覆盖九境。

## 来源和效果

所有 17 类生存丹药都有丹方、材料、炉/火/境界要求与效果，无本次范围内的缺失链。
逐条 116 配方详见 `PILL_RECIPE_AUDIT.md`，包含 FormulaId、Grade、材料、来源、炉阶、火阶、境界、消耗和时长。
基本配方在 2–4 种材料左右，高阶最多 6 种，不超过 8。

| ID | 分类与知识来源 | 使用效果 |
| --- | --- | --- |
| aura_pill | 恢复，丹师 | 按品质恢复 25/50/75/100% 本人灵力上限，封顶 |
| golden_wound_pill | 恢复，丹师 | 每级 8 生命，单次最多本人生命上限的一半 |
| bigu_pill | 功能，丹师 | 练气时每级增加 18000 秒辟谷，整数上限保护 |
| clear_heart_pill | 心神，丹师 | 清普通 DaoXin/反胃，短时再生；不改 DaoHeartUnstable |
| gathering_pill | 修炼，丹师 | 每级增加 15% 打坐修为收益，持续每级 60 秒 |
| foundation_pill | 灵根，丹师 | 随机补足/提升一项普通根，最多到本丹品质 |
| continue_vein_pill | 恢复，筑基且本人进入下界 | 修复经脉/虚弱，每级 10 秒再生 |
| diamond_body_pill | 炼体，筑基且本人进入下界 | 限时抗性与吸收，强度有上限 |
| berserk_pill | 炼体，筑基且本人进入下界 | 限时力量和速度 |
| gale_pill | 身法，筑基且本人进入下界 | 限时速度和跳跃，不永久修改移动属性 |
| profound_water_pill | 水系，筑基且本人进入下界 | 限时水下呼吸、夜视、急迫 |
| cultivation_pill | 修炼，境界成长确定解锁 | 固定修为表 × 品质，最多当前突破上限 |
| breakthrough_pill | 突破，境界成长确定解锁 | 前置满足才推进一个小阶段；品质降低灵力支出 |
| tribulation_pill | 渡劫，境界成长确定解锁 | 仅已开始天劫时使用，每级减免 10% 劫雷伤害 |
| calming_pill | 心神，金丹确定解锁 | 清普通 DaoXin/反胃，绝不移除主线道心不稳 |
| root_awakening_pill | 灵根，本人获得钻石进度 | 提升指定普通五行根，不降级，不直接解锁天雷/异火变体 |
| physique_reset_pill | 特殊，元婴且本人击败末影龙 | 随机普通体质，不含万灵体；品质提升附带再生时长/强度 |

丹师以凡品炼丹炉核心认领职业。1 级回灵/金创，2 级辟谷/清心，3 级聚灵/筑基，
每级只有这两条知识交易，避免村民随机抽两条造成基础配方永远缺失。4–5 级仅出售材料。
中高知识根据个人进度和境界每 100 tick 自动发放，不以随机战利品为唯一路径。
原牧师/灵修者的基础丹输出改为正式 Grade 栈；删除直接售卖渡劫中品、洗髓丹的交易。

## 境界和前置

所有 PillCatalog 丹药在开始服用及完成服用时调用 `ProgressionGate.canUsePill(player, stack)`。
普通恢复类按类型下限，进度类再叠加下/中/上/极对应练气/筑基/金丹/元婴；修为丹再叠加自身境界档位。
境界不足返回且不消耗丹药。多人赠送保留物品，但不会授予使用权限。

修为固定基础值依次为 `100,500,2500,10000,40000,150000,500000,1500000,5000000`，
乘品质 1–4，最后限制到当前突破剩余需求。低档丹在高境界仍仅提供自己的固定值。
突破丹要求阶段 < 3、境界 < 地仙、修为圆满、至少七成灵力、道心稳定；不更改大境界，不跳过渡劫。
渡劫丹的减伤接在 `TribulationManager.strike` 实际劫雷伤害处，包含原 void 类型伤害，不能只靠无效的普通抗性。
重复限时丹取现有效果与新效果时长/强度的较大值，不无限追加时长；没有新增丹毒、耐药或冷却系统。

引劫催化剂由可掉落妖兽内丹提供：练气凡品、筑基下品、金丹中品、元婴上品、化神及以后极品。
按钮要求、直接使用和击杀掉落共享 requiredCoreIndex。仙品内丹仍无生存掉落，不再被必需流程引用。
内丹跨阶使用从伤害/死亡惩罚改为拒绝且不消耗；引劫仍检查修为、灵力、阶段、洞府和道心状态。

## 材料链

14 种现有灵植全部进入正式配方并保留原世界生成与种植获取方式。
金刚藤/赤阳草/血灵花进入炼体；疾风草进入疾风丹；玄水藻进入玄水丹和水根丹；
雷纹草是渡劫丹核心；星辉花用于净神和高境修为丹；龙鳞草用于洗髓、极品炼体与极品突破。
普通回灵丹不要求龙鳞草。药材没有新增品质分裂，炼丹普通材料槽仍为 8。
其余材料来自原版采集、种植、战利品或合成；空异火瓶、丹炉的原有配方保留。

## 炼丹及兼容

Recipe 字段：formula_id、result_grade、furnace_tier、min_fire_tier、required_fire（可选）、minimum_realm、
ingredients、aura_cost、time、result、element/cultivation_tier（对应类型）、fire_essence_multiplier。
旧 aura_percent/advanced 读取接口保留；本轮配方采用固定灵力和确定品质。客户端配方网络字段同步，协议升至 49。

高阶炉可以炼低阶配方，但操作者仍需满足该高阶设施本身的使用门槛。原随机失败移除。
界面可切换 116 条配方并查看中央成丹和材料；未知丹方、境界不足、未掌握火、火候不足分别提示。
代码未发现现成 JEI 插件，未新增 JEI 依赖；原生炼丹界面提供真实查询与生产入口。

主要文件：alchemy 包、BasePillItem、ProgressionGate、AlchemyRecipe、AlchemyFurnaceMenu/BlockEntity、
AlchemyScreen、Network、SpiritTradeEvents、WuXingProfessions、ModEffects、ModTabs、GeneratedMod、TribulationManager、
WuXingItems，以及 recipes/models/lang/职业和状态纹理。

## 静态结果与待运行验收

已检查全部新增/修改 Java 语法、JSON、116 条配方的类型/品质覆盖、8 材料上限、材料资源、
丹方确定来源、进度门槛顺序、旧 NBT 迁移、原灵蕴台与 Bug 修复回归。第十批仅静态检查，真实旧世界升级需后续实机验证。
没有执行旧存档载入、跨玩家赠送、服用动作、GUI 渲染、渡劫减伤或完整 Forge 构建；这些不能标作实机通过。
