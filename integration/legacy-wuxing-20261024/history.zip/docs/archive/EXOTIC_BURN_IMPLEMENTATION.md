# 历史实现记录：异火独立系统

后续原版火抑制及活动缓存修改见 docs/audits/current/20260926_SOURCE_UPDATE.md。本文件描述当时实现，不代表当前验证结果。

状态：源码重构完成，运行验收未完成。遵守用户“不直接构建”：没有执行 Gradle、Java 编译、GameTest 或客户端。所有运行行为说明均为实现规则；不能把静态检查当成端到端 PASS。

Java 路径均相对于 `src/main/java/cn/blockforge/generated/generatedmod/`。

## 状态与统一入口

1. `fire/ExoticBurnState.java` 为不可变状态，保存 fireId、remainingTicks、sourceUuid、intensity、damageTimer、enchantmentLevel、elemental 来源类别。
2. `fire/ExoticBurnManager.java` 独占实体 PersistentData 的 `WuxingExoticBurn` 子标签。提供 ignite、clear、tick、isBurning、getFireId、getRemainingTicks、setRemainingTicks、copyState、sync。正常计时/点燃路径不读取或写入 vanilla fire ticks，不依赖 isOnFire。
3. 唯一点燃入口是 Manager.ignite 的重载。方块接触由 Manager.contact 调用入口；附魔、防具光环、异火领域经 SpiritEnchantmentLogic 转入同一 Manager，不再自行写燃烧 NBT。

## 旧依赖清理

- ExoticFireBlock.entityInside 不再调用 BaseFireBlock.entityInside，因此不再间接设置原版燃烧计时。世界火焰传播和方块美术没有重做。
- 附魔异火的 ignite/tick 不再调用 clearFire，普通火可以独立共存。移除旧 NBT 写入、旧周期伤害和旧广播。
- 删除异火领域“无有效装备异火时 setSecondsOnFire”的退化点火。没有有效来源就不生成异火；原有直接领域伤害仍保留。
- 删除 `ExoticBurnSourceSync.java`、`coremods/exotic_burn.js`、`coremods/ignition_source.js` 及注册项；已搜索全部源码集，旧接口引用为零。
- 保留的原版点火为 CultivationLogic 的普通火灵根领域、人工雷击，以及 TalismanCatalog 的普通火符。它们不产生 ExoticBurnState。
- Manager.migrate 唯一一次性 clearFire 用于升级旧存档：旧 WuxingIgnitionSourceFireId 已明确表示这段原版计时来自旧异火系统，转换为独立 160 tick 状态并清掉历史耦合。它不读取原版剩余时间，不参与新系统持续计时。旧附魔独立 NBT 优先迁移，旧字段随后移除。

## Tick、伤害与平衡

Manager 的 LivingTickEvent 递减独立 remainingTicks 和 damageTimer，每 20 tick 经正式 hurt(DamageSource, amount) 结算；没有直接改生命值。

附魔持续时间保留 60/80/100/120/160 tick，伤害保留 0.5/0.65/0.8/1.0/1.2 每秒乘层数，上限 1/2/2/3/3。领域续时不叠层；红流增伤、九幽减疗、涅槃归属回血仍接原机制。持续粒子沿用原频率，没有增加新粒子系统。

方块接触保持每次接触 1 点伤害，脱离接触后的独立烧伤每 20 tick 1 点，原火焰保护缩短时长的公式保留。Dropped Item 等非 LivingEntity 保留直接接触伤害，不赋予原版点燃计时。

专用伤害类型：

| DamageType | 对应原职责 | 标签规则 |
| --- | --- | --- |
| wuxingxiantu:exotic_fire | 原附魔 magic 灼烧 | 绕护甲、女巫抗性、唤醒蠹虫、避开守卫者荆棘，保留原 magic 的相关标签 |
| wuxingxiantu:exotic_fire_contact | 原方块 in_fire 接触 | IS_FIRE，不绕护甲 |
| wuxingxiantu:exotic_fire_burn | 原 on_fire 周期烧伤 | IS_FIRE、绕护甲、烧伤盔甲架；不使用点燃盔甲架标签，以免其内部重新设置 vanilla fire |

所有 minecraft 标签均 replace=false。攻击/伤害/死亡事件、Boss 阶段和来源实体仍由正式 hurt 流程处理。心铸真伤的主命中仍能触发原附魔异火，但异火后续伤害不会变成 heart_true。

火抗与熄灭规则显式写在 Manager：方块接触型不点燃天生 fireImmune 实体；火抗药水保留状态但免疫伤害；水/雨/气泡柱/粉雪清除此类状态。原附魔元素灼烧仍按 magic 规则，不因原版火抗或湿润而消除，没有擅自给九种火新增克制表。

同火同来源保留唯一状态并续时；附魔命中才按既有规则叠层。不同火按最后一次有效来源覆盖种类和持续时间，绝不读取受害者装备异火来选颜色。普通火不能改写此 fireId。

## 渲染入口

- `client/ExoticBurnRenderer.java` 在 RenderLevelStageEvent.AFTER_ENTITIES 独立绘制分层 billboard，读取 ExoticBurnClientState，使用现有 9 种异火的两套 atlas 帧。
- `client/ExoticBurnOverlay.java` 在 RenderGuiEvent.Pre 独立绘制既有两片四边形遮罩；F1 隐藏 GUI 时从 AFTER_LEVEL 绘制。使用自己的投影与视图矩阵，并恢复渲染矩阵状态，不依赖原版着火 Overlay 是否触发。
- 异火与普通火可同时造成各自伤害、各自绘制；没有修改普通火 renderer。异火通过后续独立绘制显示，不用“替换原版 sprite”的方式抢占来源。
- 未知 fireId 或缺少 atlas sprite 返回 null、暂不绘制；每个 ID 最多记录一次警告，日志集合有数量上限。不会返回 minecraft fire/soul_fire 或任何原版火 profile。
- 原版 renderFlame、ScreenEffectRenderer 挂钩彻底删除；结构检查覆盖这项约束。
- 40 个既有异火贴图/动画元数据与旧 build/resources/main 逐一 SHA256 相同。没有改颜色、重画火舌、增加 mesh/shader 或重做传播。

## 同步与生命周期

ExoticBurnPacket 携带 entityId、实体 UUID、维度、fireId、剩余 tick、intensity、source UUID 和递增 sequence。协议版本升级到 58，双方必须使用同一新版本。

客户端独立缓存只接收维度匹配、序号较新的快照；渲染前再次核对 UUID，避免实体 ID 复用串火。包先于实体创建到达时保留至过期；客户端用游戏时间预测剩余持续时间。

| 生命周期 | 明确处理 |
| --- | --- |
| 首次点燃、种类/来源/强度改变 | 立即广播完整状态 |
| 附魔/领域或显式 ignite 刷新 | 同步更新持续时间 |
| 持续方块接触 | 合并刷新，通常最多每 10 tick 一次；不同来源立即发送 |
| 低频校正 | 接触型每 40 tick、附魔型每 100 tick；不对全部燃烧实体每 tick 广播 |
| clear、到期、真实死亡 | 删除服务端状态并发送清除快照 |
| 开始追踪 | 立即向新观察者补发完整状态，包括无状态快照 |
| 停止追踪 | 向该观察者发送清除；不清掉实体服务端燃烧 |
| 客户端实体卸载 | 删除匹配 UUID 的缓存；关世界/断线清缓存 |
| 服务器实体卸载/退出 | 保留 NBT；移除同步节流记录，计时在离线/卸载期间暂停 |
| 玩家切维度 | 保留独立状态，目的维度重新同步；客户端旧 Level 缓存清空 |
| 玩家死亡重生 | 明确不复制燃烧；Clone 不提前依赖新连接，Respawn 再发送快照 |
| 非死亡 Clone | 复制独立状态，随后同步 |
| 登录/重连 | 加载保存状态并补发自身状态；观察其他实体通过 StartTracking 补发 |

`/wuxingxiantu debug exoticburn` 为客户端调试命令，显示准星实体（无目标时自己）的 vanilla flag/ticks、异火 fireId/ticks/source 和两个独立绘制计数。原版 ticks 标为客户端估计，因为原版不向客户端完整同步该计时器。

## 已执行与未执行

实际执行：资源检查 11 项 PASS；心剑素材检查 3 项 PASS；异火结构检查 6 项 PASS；40/40 火焰资源哈希相同。读取现有 Forge 1.20.1 字节码、伤害标签和 API 签名核对调用，没有编译。

新增 `ExoticBurnGameTests` 以下 17 项 required 测试，均为未运行：

1. ordinaryFireRemainsOrdinary
2. blockIgnitesWithoutVanillaTimer
3. burnTicksAndDamagesWithoutVanillaFire
4. expiresCleanly
5. sourcesDoNotCrossEntities
6. equippedFireCannotReplaceSource
7. sameFireRefreshesOneState
8. latestValidFireReplacesSource
9. vanillaFireCannotChangeExoticSource
10. dimensionTravelPreservesIndependentState
11. deathAndRespawnClearBurn
12. unknownClientFireHasNoVanillaFallback
13. snapshotsOrderUuidAndDimension
14. trackingSnapshotAndPacketRoundtrip
15. persistenceAndCopyPreserveSource
16. contactFireResistanceAndPowderSnow
17. elementalBalanceAndDomainRefresh

快照测试覆盖序列化、缓存、顺序、身份与维度；它们不等价于实际多人网络测试。可选客户端测试 `-PexoticBurnTests runClient` 已迁移到新接口并加入独立 world/overlay 绘制计数检查，本轮没有运行。后续必须实际运行 GameTest、客户端测试，并实机检查普通火/岩浆/火焰附加、两种视角、F1、维度往返、重连、观察者进出范围和整合包兼容。

本批不启动下一批火焰美术设计。当前只能标记“源码重构完成、运行验收待验证”，不能标记“异火独立系统已验证完成”。
