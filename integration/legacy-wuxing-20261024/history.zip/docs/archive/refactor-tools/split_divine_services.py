from pathlib import Path
import runpy,re
m=runpy.run_path(str(Path(__file__).with_name('refactor_audit.py')))
b=m['BASE'];p=b/'DivineArtLogic.java';s=p.read_text(encoding='utf-8')
im=m['imports'](s)+'import cn.blockforge.generated.generatedmod.*;\nimport static cn.blockforge.generated.generatedmod.DivineArtLogic.*;\n'
def extract_field(name):
 global s
 found=re.search(r'^    private static final [\s\S]*?\b'+name+r'\s*=[\s\S]*?;',s,re.M)
 # Restrict beginning to the declaration containing the field.
 found=re.search(r'^    private static final [^\n]*\b'+name+r'\s*=[\s\S]*?;',s,re.M)
 assert found,name
 field=found[0];s=s[:found.start()]+s[found.end():];return field
def extract_methods(service,names,exports):
 global s
 parts=[];wrappers=[]
 for name in names:
  s,part=m['take_method'](s,name)
  if name in exports:
   signature=part[:part.index('{')].strip()
   params=signature[signature.index('(')+1:signature.rindex(')')]
   args=', '.join(param.strip().split()[-1] for param in params.split(',') if param.strip())
   returns='' if re.search(r'\bvoid\s+'+name,signature) else 'return '
   wrappers.append('    '+signature+'{ '+returns+'cn.blockforge.generated.generatedmod.divineart.'+service+'.'+name+'('+args+'); }')
   part=part.replace('private static','public static',1)
  parts.append(part)
 return parts,wrappers
dipper=['tickDipper','pointForStep','originPoint','transform','startDipperEffect','ensureDipperEffect','tickDipperEffect','emitDipperEffect','emitLine','emitPoint','dust','emitCloud','emitAura']
parts,wrappers=extract_methods('DipperEffects',dipper,['tickDipper','startDipperEffect','ensureDipperEffect','tickDipperEffect','emitCloud','emitAura'])
for name in ['DIPPER_EFFECT_TICKS','DIPPER_FADE_TICKS','DIPPER_EFFECTS','RING_PARTICLE','STAR_PARTICLE','LINK_PARTICLE','DIPPER']:parts.insert(0,extract_field(name))
s,part=m['take_record'](s,'DipperEffect');parts.insert(0,part)
parts.append('    public static void clear(ServerPlayer player) { DIPPER_EFFECTS.remove(player.getUUID()); }')
m['write_class'](b/'divineart/DipperEffects.java','DipperEffects',im,parts)
s=s.replace('DIPPER_EFFECTS.remove(player.getUUID());','cn.blockforge.generated.generatedmod.divineart.DipperEffects.clear(player);')
names=['possessionTarget','possessedTarget','activeAbilityForm','tryPossess','isPossessing','possessingPlayer','setPossessionAbilityMotion','onPossessedEntityDeath','setPossessionInput','tickPossession','resetDragonHoverTarget','dragonInputMotion','isControlledFlyingTarget','isAquaticForm','possessAttack','clearPossession']
exports=names[:10]+['clearPossession']
parts,w=extract_methods('PossessionController',names,exports);wrappers+=w
for name in ['POSSESSIONS','DRAGON_HOVER_TARGET_FIELDS','LOGGER']:parts.insert(0,extract_field(name))
a,z=m['span'](s,r'^    private static final class PossessionState\s*\{')
parts.insert(0,s[a:z]);s=s[:a]+s[z:]
parts=[part.replace('if (data == null || !"yi_hun_ji_po"','if (target == null || data == null || !"yi_hun_ji_po"') for part in parts]
m['write_class'](b/'divineart/PossessionController.java','PossessionController',im,parts)
s=s.rsplit('}',1)[0]+'\n'+'\n'.join(wrappers)+'\n}\n'
p.write_text(s,encoding='utf-8')
