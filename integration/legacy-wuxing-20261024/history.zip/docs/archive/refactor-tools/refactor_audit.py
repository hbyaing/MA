"""One-shot structural extraction, preserving packet registration order and event priorities."""
from pathlib import Path
import re,zipfile
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'src/main/java/cn/blockforge/generated/generatedmod'
PKG='cn.blockforge.generated.generatedmod'

def mask(s):
    return re.sub(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:''.join('\n' if c=='\n' else ' ' for c in m[0]),s)
def span(s,pattern):
    masked=mask(s); m=re.search(pattern,masked,re.M)
    if not m: raise ValueError(pattern)
    start=m.start();opening=masked.index('{',m.end()-1);depth=1;end=opening+1
    while depth:
        if masked[end]=='{':depth+=1
        if masked[end]=='}':depth-=1
        end+=1
    return start,end
def take_method(s,name):
    pattern=r'^[ \t]*(?:@SubscribeEvent(?:\([^\n]*?\))?\s+)?(?:public|private|protected)\s+(?:static\s+)?[\w.<>?, \[\]]+\s+'+name+r'\([^;{]*\)\s*\{'
    a,b=span(s,pattern);return s[:a]+s[b:],s[a:b]
def take_record(s,name):
    a,b=span(s,r'^    (?:public|private) record '+name+r'\([^;{]*\)\s*\{')
    return s[:a]+s[b:],s[a:b]
def imports(s):return '\n'.join(re.findall(r'^import .*;',s,re.M))+'\n'
def write_class(path,name,im,parts,annotation='',fields=''):
    path.parent.mkdir(parents=True,exist_ok=True)
    package=PKG+'.'+str(path.parent.relative_to(BASE)).replace('\\','.').replace('/','.')
    path.write_text(f'package {package};\n\n{im}\n{annotation}\npublic final class {name} {{\n{fields}\n'+ '\n\n'.join(parts)+f'\n    private {name}() {{}}\n}}\n',encoding='utf-8')

def events():
    p=BASE/'GeneratedMod.java';s=p.read_text(encoding='utf-8');im=imports(s)+f'import {PKG}.*;\nimport static {PKG}.GeneratedMod.*;\n'
    groups={
      'CombatEvents':['livingDeath','replaceMonsterXpWithSpiritOrb','resolveKiller','meritChangeForKill','saturatedAdd','livingHurt','applyPhysiqueElementalDamage','livingHeal','livingDamage','livingAttack','attackEntity','fallDamage','transformDamageImmunity'],
      'PlayerLifecycleEvents':['attachCapabilities','clonePlayer','playerLogout','playerRespawn','beforeDimension','afterDimension','restoreDimensionHealth','playerLogin'],
      'AlchemyEvents':['refiningForgePlace','alchemyFurnacePlace','alchemyFurnaceNeighbor','refiningForgeNeighbor'],
      'WorldEvents':['caveTokenChunkLoad','exoticFireChunkUnload','anvilCrushesSpiritStone','breakBlock','injectChestInsight','injectDivineInheritance','fishing','smeltOre','spawnCheck','preventServantDespawn'],
      'InteractionEvents':['rightClickItem','rightClickBlock','handleGoldDomain','isCustomGoldDomainOre','mineralDropFor','rightClickEntity','applyBeastTaming','leftClickBlock','isSwitchableBlock','useFood'],
      'TooltipEvents':['addSpiritEnchantmentTips','itemTooltip','tooltipKey'],
      'ServerTickEvents':['serverTick','serverStopping','tickSpiritLiquidConversion','isConvertibleInSpiritLiquid','consumeSpiritLiquid','isInSpiritLiquid','trackConversionItem','untrackConversionItem'],
    }
    for name,names in groups.items():
        parts=[]
        for method in names:
            s,part=take_method(s,method)
            part=re.sub(r'\b(public|private) void ',r'\1 static void ',part)
            parts.append(part)
        fields=''
        if name=='ServerTickEvents':
            for field in ['SPIRIT_LIQUID_CONVERSION_TIME','SPIRIT_LIQUID_CONVERSION_TICKS','BONE_MEAL_CONVERSION_TICKS','BONE_MEAL_PER_SPIRIT_SOURCE','SPIRIT_LIQUID_CANDIDATES']:
                m=re.search(r'^    private static final [^\n]*\b'+field+r'\b[^\n]*\n',s,re.M);assert m,field
                fields+=m[0];s=s[:m.start()]+s[m.end():]
            parts=[v.replace('TimeStopManager.clearAll(event.getServer());','TimeStopManager.clearAll(event.getServer());\n        SPIRIT_LIQUID_CANDIDATES.clear();') for v in parts]
        parts=[v.replace('// 灵剑压制先于异火缠绕结算：境界不足者连基础剑势都发挥不出，异火加成随基础伤害一并缩水。','// 元素体质倍率先于异火缠绕结算，不施加通用境界伤害压制。') for v in parts]
        write_class(BASE/'event'/f'{name}.java',name,im,parts,'@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID)',fields)
    for helper in ['hasRoot','isSoulProjection']:s=s.replace('private static boolean '+helper,'public static boolean '+helper)
    s=re.sub(r'\n\s*/\*\*[\s\S]*?\*/(?=\s*(?:/\*\*|\n\s*\n))','\n',s) if False else s
    s=re.sub(r'\n(?:[ \t]*\n){2,}','\n\n',s)
    p.write_text(s,encoding='utf-8')

def network():
    p=BASE/'Network.java';s=p.read_text(encoding='utf-8');im=imports(s)+f'import {PKG}.*;\nimport static {PKG}.Network.*;\n'
    groups={'alchemy':['AlchemyPacket','RefiningPacket','CollectRefiningPacket'], 'cultivation':['ArtReleasePacket','GoldDomainPacket','WaterDomainPacket','EarthDomainPacket','CompassTeleportPacket','CompassSearchPacket'], 'divineart':['TransformAbilityPacket'], 'talisman':['TalismanSubmitPacket','TalismanRubPacket','TalismanSelectPacket']}
    # Service owns mutable jobs and handler implementations; packets keep only serialization/delegation.
    services={'AlchemyService':[], 'TalismanService':[], 'CompassService':[]}
    service_im=im
    for group,names in groups.items():
        for name in names:
            s,part=take_record(s,name)
            target= 'AlchemyService' if group=='alchemy' else 'TalismanService' if group=='talisman' else 'CompassService' if name.startswith('Compass') else None
            extra=''
            if target:
                # Original nested record indentation is eight spaces for methods.
                a,b=span(part,r'^        public static void handle\([^;{]*\)\s*\{')
                handler=part[a:b].replace('void handle(','void handle'+name+'(')
                services[target].append(handler)
                part=part[:a]+f'        public static void handle({name} packet, Supplier<NetworkEvent.Context> supplier) {{\n            {target}.handle{name}(packet, supplier);\n        }}'+part[b:]
                extra=f'import {PKG}.network.service.{target};\n'
            target_path=BASE/'network/packet'/group/f'{name}.java';target_path.parent.mkdir(parents=True,exist_ok=True)
            target_path.write_text(f'package {PKG}.network.packet.{group};\n\n'+im+extra+'\n'+part.strip()+'\n',encoding='utf-8')
            fq=f'{PKG}.network.packet.{group}.{name}'
            s=s.replace('public final class Network {',f'import {fq};\n\npublic final class Network {{')
            service_im+=f'import {fq};\n'
            for other in BASE.rglob('*.java'):
                if other==p or other==target_path:continue
                t=other.read_text(encoding='utf-8');new=t.replace('Network.'+name,fq)
                if new!=t:other.write_text(new,encoding='utf-8')
    helpers={
        'AlchemyService':['tickAlchemy','cancelAlchemyAt','isAlchemyBusy','hasAlchemyJob','clearRefining','clearPending'],
        'TalismanService':['handlePlatformSubmit','handleRub','isInk','inkRemaining','inkTotal','hasSolidInk','consumeInk','placeOutput','sealWith','talismanWith','talismanStack','sealQuality','damageKnife'],
        'CompassService':['findNearestCreature','teleportToCompassTarget','findLandingSpot','isSafeStand']}
    wrappers=[]
    for service,methods in helpers.items():
        for method in methods:
            s,part=take_method(s,method);services[service].append(part)
            if service=='AlchemyService':
                signature=part[:part.index('{')].strip()
                args={'tickAlchemy':'server','cancelAlchemyAt':'level, pos','isAlchemyBusy':'player','hasAlchemyJob':'level, pos','clearRefining':'player','clearPending':'server'}[method]
                wrappers.append('    '+signature+'{ '+('return ' if 'boolean ' in signature else '')+f'{PKG}.network.service.{service}.{method}({args}); }}')
    for service,records,fields in [('AlchemyService',['PendingAlchemy','PendingRefining'],['PENDING_ALCHEMY','PENDING_REFINING']),('CompassService',['CompassTarget'],['COMPASS_TARGETS']),('TalismanService',[],[])]:
        for name in records:s,part=take_record(s,name);services[service].append(part)
        for name in fields:
            m=re.search(r'^    private static final [^\n]*\b'+name+r'\b[^\n]*\n',s,re.M);assert m,name
            services[service].append(m[0]);s=s[:m.start()]+s[m.end():]
    s=s.replace('private static final int CANVAS_BIT_BYTES','public static final int CANVAS_BIT_BYTES').replace('private static void toggleDomain','public static void toggleDomain').replace('private static boolean isLookTargetAbility','public static boolean isLookTargetAbility')
    for name,parts in services.items():write_class(BASE/'network/service'/f'{name}.java',name,service_im,parts)
    s=s.rsplit('}',1)[0]+'\n'+'\n'.join(wrappers)+'\n}\n'
    # Channel setup and discriminator order have one owner.
    s,registration=take_method(s,'register')
    ci=imports(s)+f'import {PKG}.*;\n'
    fields='    private static final String VERSION = "57";\n    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(\n            new ResourceLocation(GeneratedMod.MOD_ID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);\n    private static int id;\n'
    write_class(BASE/'network/NetworkChannel.java','NetworkChannel',ci,[registration],fields=fields)
    s=re.sub(r'    private static final String VERSION = "57";[\s\S]*?    private static int id;','    public static final SimpleChannel CHANNEL = '+PKG+'.network.NetworkChannel.CHANNEL;\n    public static void register() { '+PKG+'.network.NetworkChannel.register(); }',s,count=1)
    s=re.sub(r'\n(?:[ \t]*\n){2,}','\n\n',s)
    p.write_text(s,encoding='utf-8')

if __name__=='__main__':
    backup=ROOT/'build/audit/pre-structural-refactor.zip';backup.parent.mkdir(parents=True,exist_ok=True)
    if backup.exists():raise SystemExit('Already applied; do not run twice')
    with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
        for p in BASE.rglob('*.java'):z.write(p,p.relative_to(ROOT))
    events();network()
