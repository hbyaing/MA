from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'src/main/java/cn/blockforge/generated/generatedmod'
p=root/'items/CultivationLogic.java';s=p.read_text(encoding='utf-8')
s=s.replace('import cn.blockforge.generated.generatedmod.CultivationCapability;', 'import cn.blockforge.generated.generatedmod.CultivationCapability;\nimport cn.blockforge.generated.generatedmod.balance.RealmBalance;\nimport cn.blockforge.generated.generatedmod.balance.ManaBalance;')
for name in ['AURA_CAPS','CULTIVATION_BASE_CAPS','REALM_REGEN_PERCENT','REALM_HEALTH_TOTAL','REALM_ATTACK_BASE','STAGE_MULTIPLIERS','MEDITATION_CULTIVATION_PER_SECOND']:
    s=re.sub(r'    private static final (?:int|long|float|double)\[\] '+name+r' = \{.*?\};\n','',s,flags=re.S)
s=s.replace('AURA_CAPS[Math.max(0, Math.min(8, realm))]','RealmBalance.mana(realm)')
s=s.replace('STAGE_MULTIPLIERS[Math.max(0, Math.min(3, stage))]','RealmBalance.stage(stage)')
s=s.replace('Math.min(Long.MAX_VALUE, CULTIVATION_BASE_CAPS[safeRealm] * (safeStage + 1L))','RealmBalance.cultivation(safeRealm, safeStage)')
s=s.replace('MEDITATION_CULTIVATION_PER_SECOND[Math.max(0, Math.min(8, data.wuxingxiantu$getRealm()))]','RealmBalance.meditation(data.wuxingxiantu$getRealm())')
s=s.replace('REALM_REGEN_PERCENT[realm]','RealmBalance.regeneration(realm)').replace('REALM_HEALTH_TOTAL[realm]','RealmBalance.health(realm)').replace('REALM_ATTACK_BASE[realm]','RealmBalance.attack(realm)')
s=s.replace('float value = baseAura(data.wuxingxiantu$getRealm())\n                * (1.0F + data.wuxingxiantu$getAuraBonus() / 100.0F)\n                * PhysiqueLogic.manaMultiplier(data);\n        return Float.isFinite(value) ? Math.max(0.0F, value) : 0.0F;', 'return ManaBalance.maximum(data.wuxingxiantu$getRealm(), data.wuxingxiantu$getAuraBonus(),\n                PhysiqueLogic.manaMultiplier(data));')
s=s.replace('maxMana * (meditating ? 0.04F : 0.008F)','ManaBalance.regenerationCap(maxMana, meditating)')
p.write_text(s,encoding='utf-8')
p=root/'CultivationDataImpl.java';s=p.read_text(encoding='utf-8')
s=s.replace('import net.minecraft.core.BlockPos;','import net.minecraft.core.BlockPos;\nimport cn.blockforge.generated.generatedmod.balance.RealmBalance;\nimport cn.blockforge.generated.generatedmod.balance.ManaBalance;')
s=re.sub(r'    private static final float\[\] MANA_CAPS = .*?;\n','',s)
s=s.replace('MANA_CAPS[0]','RealmBalance.mana(0)')
s=s.replace('MANA_CAPS[Math.max(0, Math.min(8, realm))]','RealmBalance.mana(realm)')
s=s.replace('float requested = Float.isFinite(value) ? Math.max(0.0F, value) : 0.0F;\n        // Safety bound only: legitimate aura and physique bonuses multiply together.\n        float cap = RealmBalance.mana(realm) * 3.0F;\n        maxMana = Math.min(cap, requested);','maxMana = ManaBalance.sanitizeMaximum(realm, value);')
s=s.replace('return Float.isFinite(value) ? Math.max(0.0F, Math.min(maximum, value)) : 0.0F;','return ManaBalance.clamp(value, maximum);')
assert 'MANA_CAPS' not in s
p.write_text(s,encoding='utf-8')
