# CORE_BALANCE_REWORK_REPORT

## Scope

本批次只重构境界生命/攻击、灵力恢复、打坐修为、击杀修为奖励、功法消耗与功法伤害，并修复创造模式灵力恢复。最大灵力主曲线、修为需求主曲线、御剑基础消耗和其他 Boss/丹药/符箓/炼器系统未重做。

## Changed files

- `src/main/java/cn/blockforge/generated/generatedmod/items/CultivationLogic.java`
- `src/main/java/cn/blockforge/generated/generatedmod/GeneratedMod.java`
- `src/main/java/cn/blockforge/generated/generatedmod/SpiritEnchantmentLogic.java`
- `src/main/java/cn/blockforge/generated/generatedmod/ArtCatalog.java`
- `src/main/java/cn/blockforge/generated/generatedmod/Network.java`
- `src/main/java/cn/blockforge/generated/generatedmod/client/CultivationArtsPage.java`
- `src/main/java/cn/blockforge/generated/generatedmod/client/ArtRadialScreen.java`

## New core rules

### Realm attributes

The indexed realm data in the existing save format represents Qi Condensation through Earth Immortal. Their base total health is `40, 70, 140, 300, 600, 1000, 1600, 2500, 4000`; base attack bonuses are `+2, +5, +12, +28, +55, +85, +125, +180, +260`. Mortal (`20`, `+0`) is the vanilla pre-realm baseline and has no separate persisted realm index. Stage multipliers are `1.00 / 1.06 / 1.13 / 1.20` and apply to health and realm attack.

### Mana recovery

Natural recovery is `maxMana * realmRate`, with rates `0.25%, 0.26%, 0.28%, 0.30%, 0.32%, 0.34%, 0.36%, 0.38%, 0.40%` per second. The old minimum `1 point/second` was removed; float state is retained. Root multipliers are `1.00 / 1.10 / 1.20 / 1.35 / 1.50`. Dao-heart, physique and heart-method multipliers remain as existing values. Spirit Surge is now `1 + level * 0.05`. Environment factors are clamped to `[0.5, 2.0]` after multiplication. Final recovery is capped at `maxMana * 0.008` outside meditation and `maxMana * 0.04` while meditating.

Meditation recovery is a single path through `tickManaRegen`: ordinary/intermediate/advanced meditation use `x2/x3/x4`. `meditationAuraReward` is retained only as a deprecated compatibility method returning zero, and the player tick no longer grants a second aura reward.

### Cultivation

Meditation cultivation is independent from mana recovery. Base rates per second are `1, 5, 25, 150, 1000, 3500, 10000, 19000, 28000`; meditation facilities use `x1.00/x1.30/x1.60`. Gathering-pill bonuses are capped by the final `x3` cultivation multiplier. The old `breakthroughRequirement / 240` rate was removed. Creative players do not gain ordinary cultivation, spectator players gain neither cultivation nor normal mana regeneration, and creative players still receive normal mana regeneration.

Kill rewards are read from entity persistent data key `CultivationReward`. Ordinary animals return zero; hostile entities without an explicit value receive only a small health-derived fallback, with no player-realm multiplier. This provides one entity-owned reward hook without changing Boss tables in this batch.

### Arts

Arts use `fixedManaCost + maxMana * percentageCost`. Percentage values are within the requested tier ranges: 2% Huang, 5% Xuan, 8% Di, and 14% Tian. Damage uses:

```text
(playerAttack * artPowerMultiplier + artBaseDamage)
* (1 + percentageCost * 0.06)
* proficiencyMultiplier
```

The player attribute value is read at cast time. Proficiency now contributes a percentage up to +30%; the old fixed `masteryLevel * 2` damage path was removed. Client pages and item tooltips show fixed plus maximum-mana percentage costs.

## Compatibility

No persisted fields were renamed or cleared. Existing `currentMana`, `cultivation`, `realm`, `stage`, root data and cooldown data continue to load. Current mana is clamped to the recalculated maximum during the existing refresh path. The indexed realm layout is unchanged.

## Validation

- Static search confirms removal of the minimum-1 regen rule, the `breakthroughRequirement/240` meditation formula, the old meditation aura grant, the 20% Spirit Surge increment, and fixed `masteryLevel * 2` art damage.
- Gradle `compileJava` was attempted with the cached Gradle 8.14 and 8.8 distributions and Java 17. Both attempts were stopped by the host's `Unable to establish loopback connection` error before Java compilation started.
- Runtime game tests for the requested mana, cultivation, kill-reward and art scenarios remain pending until Gradle can start in an environment with a functioning loopback channel.

## Out of scope / risks

- Boss-specific reward tables, pill economy, talisman, refining, human-emperor-banner, divine-art and sword-flight numerical redesigns remain unchanged.
- The existing save schema has no distinct mortal realm index; mortal values therefore remain the vanilla baseline before Qi Condensation.
- Any custom entity that wants a precise reward should set its own `CultivationReward` persistent value or be added to the future registry/tag layer.
