# 第十批 V2 核心系统回归修复报告

## 交付与验证边界

基于当前 work/source/mod 源码修改，目标 Minecraft 1.20.1、Forge 47.4.10、Java 17、GeckoLib 4.8.4。源码版本 1.0.0-r10，网络协议 54，客户端和服务器需一起更新。

用户本次直接要求“修复 bug，不直接构建”。此要求优先于附件的构建条款：本次未运行 Gradle、javac、mc_check、mc_build、runData、Minecraft，也没有生成或更新任何 JAR。既有 r9 JAR 和历史构建日志仍是旧批次产物。

验证包含 Java 语法解析、JSON/动画 metadata 解析、资源引用扫描、读取缓存 Forge 47.4.10 类签名、执行实际迁移 coremod 的 JavaScript 转换器及静态布局检查。它们不能证明 Java 类型检查、Forge 类转换实装、旧世界升级和游戏行为已经通过。完整结果见交付的 batch10-static-validation.json、batch10-resource-audit.json；全部逐文件变更见 batch10-changed-files.json。

## 修改范围

| 系统 | 主要文件 |
| --- | --- |
| 御剑 | yujian/FlyingSwordConfig.java、YujianController.java；client/InterpolatedFlyingSwordTransform.java、YujianWindSound.java |
| 旧附魔 | SpiritEnchantment.java、SpiritEnchantmentLogic.java；两种语言文件；共用 LegacyStackMigration |
| 丹药 | WuXingItems.java、alchemy/PillData.java、LegacyStackMigration.java、coremods/legacy_stack_migration.js、META-INF/coremods.json；ModCommands.java、client/RootSelectionScreen.java；退役物品模型与语言键；两个正式模型和一个进度图标 |
| 炼器 | client/RefiningForgeScreen.java、RefiningRecipe.java、RefiningForgeBlock.java、Network.java、两种语言文件 |
| 灵植 | 14 种灵植的成熟/低龄/中龄 block model，共 42 个 |
| 炼丹炉 | AlchemyUiLayout.java、AlchemyFurnaceMenu.java、client/AlchemyScreen.java；background_compact.png、page_arrows.png |
| 灵剑 | items/SpiritSwordItem.java、SpiritSwordAnvil.java |
| 心魔 | HeartDemonEntity.java、items/HeartDemonSpawnEggItem.java、boss/BossTestCommands.java、mindscape/MindscapeManager.java、TribulationManager.java |
| 文档 | README、AI_SOURCE_MAP、PILL_AUDIT、BOSS_AUDIT、YUJIAN_ADVANCED_AUDIT、REFINING_AUDIT、PLANT_AUDIT、本报告 |

原桃树、灵液、灵植世界生成、异火附魔联动、法衣、境界数值和正式场景未重构。仅心魔测试入口恢复既有镜像战斗；另外九种测试 Boss 仍保持视觉测试用途。灵植 registry ID、心魔实体 registry ID 和二阶段资源 ID 不变。

## 原文 35 项答复

1. 螺旋消失原因：InterpolatedFlyingSwordTransform 以 speed / 旧 sprintSpeed 超过 1 作为强度来源。第八批阶段限速使普通翻滚无法跨过该门槛，FlyingSwordEffects 的 spiralFactor 门限因而挡住绘制。原程序螺旋代码并没有被删除。
2. 恢复方法：改从 ControlledSwordEntity 已同步、已插值的翻滚角速度计算强度，默认 150°/秒为满强度；凌空横移不当作翻滚。复用原螺旋、拖尾和光影兼容路径，没有第二套特效系统。
3. 真实脉冲：默认目标速度乘 1 + 0.25×正弦包络，持续 16 tick，冷却 40 tick，追速系数最高乘 1.5。正常巡航目标默认是当前阶段上限的 85%，脉冲最多到 100%，满巡航下目标相对最多增加 17.65%。最终实际速度受阶段上限和 3 格/tick 绝对上限约束，不保证每次脉冲都到达目标峰值。所有新参数在 FlyingSwordConfig。
4. 客户端表现：修复后的 spiralFactor 接通原螺旋半径/长度、拖尾强度、FOV（基础增强 5°、螺旋 9°）与相机缓动；姿态继续使用服务端角速度插值。新增本地鞘翅风声循环，按同步速度/翻滚强度调节并在退出淡出。
5. 旧凌空附魔删除：删除 LEVITATION 注册和 LevitationEnchantment 类、旧 flightSpeedMultiplier、enchantment.wuxingxiantu.levitation 两种语言键，以及功法说明中的旧附魔加速文案。未发现其余 loot/trade/tag/recipe 注册引用。LINGKONG 阶段保留。
6. 旧附魔兼容：MissingMappings 忽略退役 enchantment id；NBT 构造钩子只删 Enchantments / StoredEnchantments 中的 wuxingxiantu:levitation，其他附魔原样保留。剑 inventory 初始化也执行同一清理，不复制物品，不改剑蕴和剑诀字段。
7. 炼器温度 UI 删除：移除 drawTemperatureArea、drawPointer、渐变条、刻度/指针、温度文字及布局常量，面板由 336 高压缩到 282 高，操作区上移。原代码没有实际调温按钮/包；本次未保留隐藏点击区。
8. Recipe temperature：只保留 legacy/internal fire-tier proxy 和原网络序列化。requiredFireTier() 计算最低火阶，至少为 1；界面和开炉服务端都检查真实煤块+异火阶位。旧境界门槛的代理值接口保留，配方不重写。
9. 最终丹药数量：17 个生存丹药 Item + 1 个创造测试丹，共 18。已实际删除 40 个旧品质/五行注册；6 种妖兽内丹属于原料、修炼心得属于修为物品，均不计入丹药类型。
10. 旧丹迁移：coremod 在 ItemStack(CompoundTag) 的第一条原始指令前插入 migrate，读取原 id 的品质/元素后改为统一 id+Grade/Element；原 CompoundTag 复制保留 Count、ForgeCaps、CultivationTier 和其他字段，已有字段不覆盖。MissingMappings 负责旧 registry 映射。包括箱子、掉落物、装备容器等经原生 ItemStack NBT 读取的路径，未加载箱子无需提前打开或扫描。第三方完全自定义的数值 ID 序列化须单独验收。
11. 灵植路径问题：14 种灵植的 low/mid 自定义模型都没有 particle；主 PNG 路径存在。成熟 cross 继承模型也改为显式 particle，便于统一校验。具体 14 个 ID 见 PLANT_AUDIT。
12. 紫黑粒子根因：自定义低龄/中龄模型既无父模型的 particle 继承，又未声明 particle；补为 #cross 并检查实际 PNG。
13. 压扁根因：完整 UV 原被画在宽 14.4、高 6 或 11 的平面上。现在横纵按相同比例缩放，保持生长阶段差异和成熟形状。shade=false / ambientocclusion=false 修正幼苗额外方向阴影，保留环境光；没有整体提亮 PNG。全部灵植仍用 cutout，原两种发光灵植的光照值保持。
14. 翻页实现：PageButton 使用专用 32×64 箭头图集，左右两列、normal/hover/pressed/disabled 四行。位于标题两端、中心 y=21，标题宽限制为 82。菜单与按钮同时校验首页/末页，不循环越界；无自动选中配方时下一页先选第一项。
15. Overlay 根因：原 AlchemyScreen 令 leftPos/topPos=0，并把 super.render 整体放进 translate+scale，同时把鼠标转为局部坐标。虽然 push/pop 成对，Forge/第三方回调仍在被变换的坐标中执行，公开容器边界也不是真实屏幕边界。
16. 坐标修复：保留原生居中 leftPos/topPos、原生输入和 super.render 的屏幕坐标。只有自己的背景绘制做局部 push/translate/finally-pop，标签用原生容器已有坐标。布局改为 308×232，最小常见 320×240 GUI 内完整容纳；静态检查了四组视口。没有给 FTB 加任何特定偏移。
17. 无耐久剑不可附魔根因：只覆盖 getMaxDamage/isDamageable，却没有覆盖默认以可损坏性判断的 isEnchantable。getEnchantmentValue=20 原本已在。
18. 灵剑接口：新增 isEnchantable、canApplyAtEnchantingTable、isBookEnchantable，保留 getEnchantmentValue=20 和零耐久接口；另加 SpiritSwordAnvil 处理两把同种无耐久剑被原版提前拒绝合并的问题。
19. 允许附魔：使用 Forge 正常类别判断，允许锋利、亡灵杀手、节肢杀手、击退、火焰附加、抢夺、横扫等合法剑附魔以及兼容的模组剑附魔，沿用互斥和等级上限。
20. 耐久/经验修补：新附魔资格与双剑合并明确拒绝 UNBREAKING、MENDING。直接作弊命令写 NBT 属于原版管理员路径，不额外拦截或清除其他旧附魔。
21. 铁砧：附魔书使用原版+Forge 类别检查和 book 钩子；双剑合并只处理同种灵剑，复制左剑数据、合并合法附魔、保留修理惩罚和费用，不引入耐久修复。尚未进行实机操作验证。
22. GeckoLib build 原版本：这次开始时已是 4.8.4，来自上一轮兼容修复；更早的旧源码是 4.4.9。当前 build.gradle 从 geckolib_version 读取 4.8.4。
23. mods.toml 原范围：历史错误是 [4.4.9,4.5)；本次接手时已经是属性展开的 [4.8.4,5)。
24. 当前版本和范围：继续使用 4.8.4 / [4.8.4,5)，检查构建声明、属性、mods.toml、GeoModel/Renderer/AnimationController 调用链，没有回退或改成无限上界。
25. 是否确认 4.8.4 可启动：前一批历史产物有 Forge 47.4.10 / GeckoLib 4.8.4 启动与新世界记录；第十批没有构建或启动，不能确认本批可启动。
26. 心魔直接死亡根因：phase 只是视觉选择，hurt/die 中不存在致死转阶段逻辑；die 直接清空血条并调用正常死亡。
27. 拦截点：actuallyHurt 打开受控扣血标记，在原版处理护甲、吸收和 Forge 伤害事件后，setHealth 看到最终 health<=0 时调用 transitionToPhase2，早于 super.hurt 的死亡判断；直接 die 调用另有兜底。没有在 LivingDeathEvent 里复活。
28. 持久化/同步：PHASE 为 SynchedEntityData，BossVisualPhase 写 NBT；新增 MirrorInitialized、PhaseTransitionTicks、MirrorTeleportCooldown。阶段二重载重新应用独立基础属性并保留已受伤血量，保护计时有上限。
29. 同一实体：切阶段不 spawn/discard，只改现有对象 phase、属性与状态；实体 UUID 与已创建的 ServerBossEvent 不变。
30. 阶段二血量：沿用项目已有心魔基础值作为独立的过渡基线，200 HP、30 attack、0.25 move speed、0 armor、0.4 flying speed、32 follow range。转换时清除镜像装备/效果/属性修改器后只补满一次；没有擅自给正式 Boss 做境界倍率重算。
31. 一阶段不掉落/不结算：源码路径在死亡前返回，未调用 super.die，不发最终死亡事件，不移除血条；心境/渡劫结算另检查 phase2。未以实机验证措辞代替源码结论。
32. 二阶段结算：第二次致死正常 super.die，走既有掉落/XP/事件链；心境会话验证保留。模型、glow、BossBar 根据同一同步 phase 使用原已有资源。转换播放已有 phase_two_unmask 动画，短保护仅 20 tick，不是整段 3.8 秒动画永久无敌。最终结算实机待测。
33. mc_check：未执行。完成独立 Node 静态验证，不冒称工具 mc_check 或 JVM 测试。
34. Forge build：按本次直接要求未执行。
35. 最终 Jar：无本批 Jar。交付 wuxingxiantu-r10-core-regression-source.zip，旧 Jar 名称和文件未改。

## V2 镜像能力 15 项答复

1. 原生命复制在 work/original/mod 的 HeartDemonEntity.copyPlayerState；当前方法源自该实现。
2. 复制的是 owner.getMaxHealth()，不是 owner.getHealth()；作为 Boss max health 的十倍，最低 20。
3. 初次 bindToOwner 同步并补满；原代码明确每 20 tick 动态刷新，本批保留这个周期，且仅限 PHASE_1。魂仆沿用原持久绑定规则。
4. 不每 tick 重置生命。后续同步保持 Boss 当前生命百分比，读档保存 stateInitialized 防止首次同步错误回满；phase2 不同步镜像。
5. 原攻击复制同在旧 HeartDemonEntity.copyPlayerState。
6. 使用 owner.getAttributeValue(Attributes.ATTACK_DAMAGE)×10，最低 3；增加非有限值防护，正常值公式不改。
7. getAttributeValue 是玩家当时最终属性值，包含已挂载的武器/装备/修仙 AttributeModifier；在伤害事件里额外计算、未进入该属性的增伤不包含。原装备/效果复制语义保留，没有另造境界倍率。
8. 飞行组件并未删除；后续心魔蛋/心境改成 bindVisualOwner，心境还 setNoAi(true)，导致镜像复制和追击路径被绕过。普通地面近战 Goal 对悬空目标也可能没有可用路径。
9. 保留 noGravity、FlyingMoveControl、FlyingPathNavigation；真实心魔入口恢复 bindToOwner/AI，并在一阶段服务端有视线时设置空中追踪点，补有限空中近战检查。视觉预览可显式 boss_bind；其他九种测试蛋保持原模式。
10. 现有原始源码和当前残留代码未找到心魔战斗瞬移；只找到人皇幡魂仆远距回到主人等其他用途的 teleport，不能据此声称找回旧战斗参数。用户也不记得旧参数，因此采用已说明的保守恢复方案。
11. 冷却 100 tick；与目标距离 16–32 格时尝试，单次移动不超过 32 格；优先玩家身后，半径 3 格、目标脚部高度+0.25，旋转尝试最多 8 点。检查整个包围盒覆盖的区块已加载、世界边界、建筑高度、方块/实体碰撞、液体；无安全点则等待下次冷却。noGravity 保持空中落点，禁止虚空底部坐标。位置、portal 粒子与传送音效都由服务端执行。
12. 转阶段停止导航和运行 Goal，清目标/位移、瞬移和空中攻击冷却、镜像刷新计时、预览、装备、效果与属性修改器，再应用二阶段参数。相同的通用近战 Goal 可在转场结束后用于基础行动；专属镜像飞行/瞬移方法仅 phase1 执行。
13. 源码已分离二阶段基础属性，明确阻止 copyPlayerState 在 phase2 运行。尚无实机属性读取结果。
14. 两名玩家实机测试未执行。公式上，在不计额外被复制装备的情况下，maxHealth 20/attack 2 对应镜像基础 200/20；maxHealth 80/attack 12 对应镜像基础 800/120；阶段二两者都回到基础 200/30。以上为源码计算示例，不是测试测量。
15. 飞行/瞬移实机测试未执行。必须后续覆盖地面、高处、御剑、开阔地、墙边、高差、狭窄空间、未加载区块及世界边界。

## 仍需运行验证

- 静态资源扫描没有警告；因为没有编译，本批不能报告“编译零警告”，历史弃用警告不算本次新结果。
- 实际旧世界升级验证须包含箱中/背包/掉落物/魂仆容器内旧丹、所有 40 旧注册和额外 NBT，确认 coremod 与其他修改 ItemStack 的模组兼容。
- 附魔台、单书/混合书、双剑附魔合并、互斥附魔和异火联动；FTB 叠层与原版背包/箱子对照；各 GUI Scale 操作均待实机。
- 心魔普通/溢出/连续致死、转阶段同 UUID 与同血条、阶段二保存重载、最终心境结算与魂仆行为待实机。
- 御剑各阶段限速、短脉冲体感、光影包拖尾与风声淡出，及全部灵植昼夜/破坏/水中显示待实机。

本批不继续九境界平衡、正式场景、新 Boss 技能或法衣玩法。
