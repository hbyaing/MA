# 2026-09-29 技能粒子库交接

本轮目标：从现有源码提取功法、Boss等技能，为制作这些特效提供定制粒子素材与配方。产物独立存放，没有修改生产 Java、替换现有模组、运行 Gradle或进入游戏。

## 入口

- 制作库：`source-assets/skill-particle-library-v1/`
- 离线预览：`source-assets/skill-particle-library-v1/preview/index.html`
- 完整制作包：`deliverables/wuxingxiantu-skill-particle-library-v1.zip`
- Photon资源包：`deliverables/wuxingxiantu-vfx-resourcepack-v1.zip`
- 提取与生成脚本：`tools/vfx_library/`
- 本轮检查及截图：`reports/skill-particle-library-v1/`

## 已提取与制作

| 类别 | 数量 | 权威源码 |
|---|---:|---|
| 普通功法 | 18 | ArtCatalog、ArtReleasePacket |
| 御剑剑技 | 5 | ArtCatalog与SwordTechniqueRegistry去重 |
| 神通 | 7 | DivineArtCatalog |
| 被动心法 | 10 | HeartMethodCatalog |
| 常规Boss技能 | 67 | BossCombatCatalog、BossSkillPrograms |
| 心魔技能 | 10 | HeartDemonSkillPrograms |
| 符箓 | 6 | TalismanCatalog，直接提取16×32符纹 |
| 异火配色 | 9 | FireCatalog与现有weapon_flames JSON |
| 心剑仪式 | 4 | HeartSwordSystem的SUMMON、DISPERSE、FORGE、UNFORGE |
| 系统特效 | 3 | 渡劫、丹炉、祭炼 |
| 总计 | 139 | 每项保留源码行号与SHA256 |

60种基础材质，256×256 RGBA；其中24种含16帧动画，图集为512×512、4×4排列，共384帧。32套可复用组合配方，全部139项都有映射和调色建议。60个单材质样片、32个组合样片，共92个`.fx`与92个`.fxproj`；每个项目包含完整60种材质库。

颜色、粒子数、尺寸、寿命和轨迹为新美术建议；Boss前摇、恢复、冷却、阶段、提示和程序片段为源码提取值。心法是被动系统，九种异火素材也不表示恢复旧退役武器外观。范围不包含所有生物AI普通攻击或七十二变每种实体的全部动作。

## 检查结果

- `validation.json`：139条映射、60个不重复基础遮罩、384个非空动画帧、透明边界、32配方、92对NBT读回、5840次材质引用、27个源码输入哈希检查通过。
- `reports/skill-particle-library-v1/browser-validation.json`：139技能条目、60材质与300个帧抽样、中文搜索、换色、拖动时间、配方下载、680像素窄屏布局检查通过；无浏览器错误和贴图加载失败。
- 已查看材质总览、烈焰与心魔凝视页面截图；预览GIF由本轮浏览器帧生成。
- ZIP交付记录见同报告目录的 `delivery.json`，含文件大小、SHA256与ZIP完整性结果。

## 实装边界

Photon原生样片为Billboard选材和调参样片；浏览器环绕/内吸/落剑等轨迹表达制作意图，未宣称一比一游戏技能复刻。地面法阵、真实光束、拖尾、晶体柱与分身需要实际几何、实体或Beam/Trail承载。主工程目前不依赖Photon，本资源包不会自动注册新Forge粒子，也没有自动替换功法特效。

未来接入优先使用现有 `BossCombatFx` / `BossCombatFxPacket` 的落点与形状参数，逐个子攻击调用装饰层；保留安全区和真实缺口。普通功法绑定 `ArtReleasePacket.emitArtParticles`，剑技绑定独立御剑控制器；神通绑定 `DivineArtLogic`，心剑绑定已有视觉包阶段。伤害结算留在服务器。

本轮未进行Minecraft原生反序列化、实机播放、联机或性能验收。不能以浏览器动画、NBT读回或历史客户端日志替代这些验证。
