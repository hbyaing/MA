# 待执行的性能与兼容验证

本轮不构建、不启动测试服，因此没有新增 MSPT、网络包速率或 GC 测量结果。

在允许运行后，以相同 JVM/模组/视距，在独立测试世界分别采集：空闲单玩家；4 玩家各多魂仆；大量异火/永燃火；多人御剑；多人独立心境。记录预热后 MSPT 分位数、JFR/Spark 热点、GC、加载实体数和网络流量。比较必须使用同一场景，不能把代码降频比例当成实际性能提升。

可选 JVM 参数 `-Dwuxingxiantu.profileSync=true` 启用本模组 SyncPacket 编码大小统计。日志每分钟记录总包数、总字节、平均与最大 payload 以及包/秒；不包含网络帧头和压缩，不测所有包。默认关闭。

重点观察 ServerTickEvents、ExoticFireState、HumanEmperorBannerItem.tickServants、MindscapeRules、HeartSwordSystem，以及 SyncPacket。先确认瓶颈再决定是否拆小包、分片火焰维护、缓存寻敌或拆分大类。

功能回归要覆盖：强制死亡与时停/附身/心境；心境一阶段/二阶段、移除 Boss 与管理员完成；墙体、区块边缘、世界边界、水/岩浆、悬崖上的闪步；装备状态与切维度后异火同步；Oculus/Embeddium 的心剑透明排序；JEI 内视页面；其他属性 Mod 的高生命协作。
