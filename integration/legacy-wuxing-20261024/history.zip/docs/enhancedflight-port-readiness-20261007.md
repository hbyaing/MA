# Enhanced Flight 1.0.6：境界飞行移植准备

日期：2026-10-07。范围：静态资源检查、字节码反编译研究、项目接入设计；尚未修改运行代码、安装参考 MOD 或进行游戏实测。附件中的说明与配置注释均作为被研究数据，不作为用户指令。

## 结论

飞行动作、过渡、人物倾斜和原版粒子效果具备在本项目重建/适配的技术条件，未发现这些视觉功能需要另一个未提供的动画资源包。不能认定“完整 MOD 可以直接无损移植”：九件演示胸甲缺物品模型，未提供原始源码和构建工程；反编译仍有 SRG 名称与合成方法；本项目已有专用玩家模型和多个飞行控制器。代码复用许可也存在元数据矛盾。

推荐优先移植视觉表现，保留本项目的境界授权、灵力结算与御剑控制；将加速、蓄力起飞、落地攻击等作为后续单独设计的玩法。整包依赖安装只适合隔离对照实验，不能直接作为正式集成方案。

## 可复核证据

- 原件：`C:/Users/Nostzephert/Downloads/enhancedflight-1.0.6-forge.jar`，1,657,294 字节。
- SHA-256：`a2551581bf48aea9a4d8dec70cd367ca71efc63cc4e715a1bca2aaabd18728ce`。
- 审计输出：[audit.json](../reports/enhancedflight-1.0.6/audit.json)、[完整目录与 CRC](../reports/enhancedflight-1.0.6/jar-inventory.json)、[原始元数据](../reports/enhancedflight-1.0.6/metadata/META-INF/mods.toml)。
- 研究源码：[反编译目录](../reports/enhancedflight-1.0.6/decompiled/com/cheatyblack/enhancedflight/)。CFR 0.152 完成反编译，summary 无错误；缺少依赖产生的 `Could not load` 注释不等同于原 JAR 缺类。反编译文本不是可直接编译的原工程。
- 复跑：`python tools/audit_enhancedflight.py "C:/Users/Nostzephert/Downloads/enhancedflight-1.0.6-forge.jar"`；该脚本使用已生成的 ModItems 研究文本识别注册物品。

## 资源是否完整

| 检查项 | 结果及含义 |
|---|---|
| ZIP 可读性/CRC | 42 个目录项、34 个文件；逐项 CRC 校验通过 |
| 字节码 | 26 个 class，major 61（Java 17） |
| 平台 | Forge loader `[47,)`，MC `[1.20.1,1.21)`；本项目实际为 MC 1.20.1 / Forge 47.4.10 / Java 17 |
| Mixin | 3 个声明类齐全，mixins JSON 与 refmap 存在，JSON 能解析；尚未实测注入成功 |
| 配置 | 默认值由 ModConfigManager/ModClientConfig 生成，不需要随 JAR 附带 TOML |
| 动画 | FlightAnimator/FlightState 和渲染变换生成，无 GeckoLib geo/animation 文件；属于程序动画 |
| 特效 | 代码使用原版粒子和声音，无独立纹理、shader 或 sounds.json；不构成动画资产缺漏 |
| 语言 | 只有 en_us、pt_br，无简体中文；移植需要本项目中文文案 |
| 演示胸甲 | ModItems 注册 9 件胸甲，均无 assets/enhancedflight/models/item/*.json；预期背包/手持缺失模型，需实测确认。穿戴使用原版 ArmorMaterial，不能据此认为穿戴贴图也全部缺失 |
| 数据资源 | 无配方与默认 tags JSON；标签入口可以供外部数据包填充，缺省不等于必需文件丢失。演示胸甲没有配方来源 |
| 许可证/源码 | 无 LICENSE/NOTICE/源码文件，只有编译产物；logo 为宣传图，不需要移植 |

这里的“CRC/配置完整”仅是静态检查，不证明运行兼容或视觉完全一致。

## 行为组成与值得移植的部分

FlightAnimType 共 9 种：HORIZONTAL_ARMS_FORWARD、VERTICAL_ARMS_DOWN、HORIZONTAL_ARMS_BACK、VERTICAL_ARMS_OUT、VERTICAL_ARMS_FORWARD、HORIZONTAL_ARMS_FORWARD_VARIANT_A/B、VERTICAL_ARMS_DOWN_VARIANT_A、SURFING_POSTURE。

| 模块 | 推荐 | 接入方式 |
|---|---|---|
| 垂直垂臂/张臂悬停、横向后掠飞行 | 首批 | 作为御空与高速飞行姿态，调整为修仙风格；境界映射待设计确认 |
| 9 姿态参数与骨骼混合 | 保留研究全部，首批择用 | FlightAnimator 中手臂、腿、身体、头部参数，转换为本项目模型姿态层 |
| 平滑过渡 | 首批 | FlightState：飞行每 tick 0.1、加速 0.125；smoothstep `x*x*(3-2*x)`，再做 partialTick 插值；远端用位置差估算运动 |
| 悬停起伏、速度倾斜、转向侧倾 | 首批 | MixinPlayerRenderer 的 PoseStack 变换需归入统一人物根变换；纯表现不改变碰撞箱 |
| 镜头侧倾 | 可选 | CameraRollManager，设开关与幅度，离开飞行时平滑归零 |
| 坠落、临地收势、落地姿态 | 第二批 | 保留条件与过渡思想，改成轻盈收势；原码人物落地阈值 -0.6、服务端冲击波 -0.8，不能混为同一触发条件 |
| 起飞/落地原版粒子 | 第二批 | 先复现程序发射轨迹，再替换成本项目五行色彩；不应宣传为已有复杂能量材质 |
| 加速同步/进入追踪补发 | 保留设计思想 | 在本项目网络频道实现，状态变化广播并给新观察者补发；不是直接拷贝原频道 ID |
| 冲浪站姿 | 留作参考 | 可研究其重心/转弯，但本项目御剑已有专用分段四肢动作，不整套覆盖 |
| 胸甲、创造标签页、装备/Curios/NBT 授权 | 不纳入首批 | 本项目应由境界权限授权；Curios 为反射可选支持，无必要新增硬依赖 |
| 饥饿/经验/生命/FE/耐久扣费、过热、挨打禁飞 | 不直接移植 | 与既有灵力和战斗平衡重复或冲突 |
| 落地范围伤害、撞碎方块、免摔 | 独立玩法评审后再做 | 原 MOD 不只是动画 MOD；这些会改变世界和战斗，不能随视觉功能默认带入 |
| TestConfigCopy | 不移植 | 会把世界 serverconfig 复制至 defaultconfigs，属于参考 MOD 的额外文件副作用 |

## 与本项目的具体衔接

1. `event/CultivationTicker.updateFlight` 已在服务端处理境界飞行：realm >= 3 授予飞行；realm 3/4 飞行每秒扣 25 灵力；realm >= 5 免费；退出时会恢复飞行速度。创造/旁观、御剑、筋斗云已有专门分支。应保留该授权主体，不能并入参考 MOD 的胸甲授予/撤销逻辑。
2. `client/MeditationModels.SeatedPlayer.setupAnim` 在 super 后处理心剑、筋斗云、御剑、打坐和锻造；参考 MOD 的 HumanoidModel TAIL 注入会发生在 super 内，之后可能被本项目覆盖。优先在本项目最终姿态分支显式应用御空动画，护甲、衣袖、外套、帽子必须同步复制。
3. 全身倾斜需检查玩家 renderer 根变换与手持物品层，不能只转手臂。水平姿态的渲染位移不修改 AABB；贴墙、低矮通道和第一人称必须分别验收。
4. 新建建议模块：`client/realmflight/RealmFlightVisualState`（视觉状态）、`RealmFlightPose`（骨骼）、`RealmFlightRenderTransform`（根变换）、`RealmFlightCamera`（可选镜头）。服务端仅在需要加速/落地玩法时引入独立控制器与经过校验的输入包。
5. 建议提供一个飞行模式解析入口，先排除死亡、旁观、坐骑、御剑、筋斗云、鞘翅/游泳、打坐等情形，再明确判定境界御空。该优先顺序是准备方案，不是已确认产品规格。
6. 远端人物不能依赖本地玩家 abilities 自动同步；参考 MOD 有 SyncFlight/SyncBoost 和 StartTracking 补发。境界状态和飞行状态须按本项目现有 CultivationSync 能力核实接入。

## 不能照搬的实现细节

- 参考 `isFlyingForAnimation` 接受 abilities.flying、EF_IsFlying 及 fall-flying；不能把其通用判断直接用于境界飞行，否则可能覆盖鞘翅或其他模式。
- FlightState 含 client Minecraft 引用并在公共逻辑中可被引用：移植时把客户端视觉状态与服务端玩法状态分开，必须专服启动验证。
- ServerboundBoostPacket 只做了初步飞行资格检查；过热主要由客户端处理。若移植加速玩法，服务端应重新验证境界、模式、实际飞行、灵力、频率与速度，而非信任客户端 boosting。
- FlightState 每次 tick 扫描最多 31 格下方地形，临地又扫 8 格；按所有可见玩家运行时需优化触发条件，不能仅凭发布说明认定性能已足够。
- 状态表有 EntityLeaveLevel 清理，但新模块仍要处理断线、切维度、重生和暂停；镜头与模型变换需要无残留复位。
- 原第一人称排除使用 `ageInTicks == 0`，较脆弱；项目应显式区分手部渲染上下文，并保留挥手、攻击、弓弩/盾和心剑动作。
- 原第三方装备授权与速度覆盖会争夺 mayfly/flying/setFlyingSpeed；不得与现有御剑、筋斗云同时控制。

## 许可与来源核对

本地 `META-INF/mods.toml` 写 `license="All Rights Reserved"`，没有版权许可正文。作者发布页则显示 MIT，且明确允许整合包使用；页面没有展示源码仓库链接。整合包许可和合并源码的许可不能混为一谈。当前只保存研究材料，不把反编译代码编入产品。

- 作者项目页：https://www.curseforge.com/minecraft/mc-mods/enhanced-flight
- 本版本发布页：https://www.curseforge.com/minecraft/mc-mods/enhanced-flight/files/8773885
- 发布页 1.0.6 说明修复了第一人称手臂和小落差误触发落地效果；仍需在本项目验证。

正式代码复用前应取得与 1.0.6 对应的源代码、MIT 许可正文和版权声明，解释 JAR 标注差异；如果无法取得，可按行为规格独立实现，避免直接纳入反编译文本。此项是来源未解决的工程准备事项，不是要求本轮用户确认。

## 实施顺序与验收

阶段 A：统一飞行模式/视觉状态；首选垂直悬停和后掠飞行；接入 SeatedPlayer、护甲与根变换，中文设置中提供姿态和镜头开关。先只做视觉，不改变速度及扣费。

阶段 B：加入远端追踪同步、柔和落地/坠落过渡、起落粒子和可选镜头；使用配置限制粒子密度与扫描开销。

阶段 C：如需高速御空、蓄力起飞或落地攻击，再设计境界数值与灵力耗费，使用服务端状态机、限流和碰撞检测，不继承参考 MOD 的客户端授权路径。

验收矩阵：realm 2/3/4/5、灵力不足/耗尽、创造/旁观、筋斗云/御剑/打坐切换、鞘翅和游泳、死亡重生/切维度/重连、两个客户端及晚加入观察者、专服启动；普通/纤细皮肤、全部护甲层、主副手、第一/三人称、弓盾/挥砍/心剑动作；低空小落差不误触发、开界面不触发加速、姿态退出无残留、镜头关闭即正常。必须完成真实客户端录屏或截图对照才能宣称视觉移植完整。

本轮完成：JAR 清单、CRC/JSON/Mixin 资源检查、反编译研究材料、缺失模型清单、许可差异记录、集成入口及分阶段验收计划。未完成且未冒称：运行测试、可编译移植代码、视觉一致性或正式复用授权。
