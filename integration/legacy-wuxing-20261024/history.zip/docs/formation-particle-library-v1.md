# 阵法与基础粒子扩展库 V1

`source-assets/formation-particle-library-v1/` 是独立的阵法储备库，面向源码技能、Boss 场景和后续接入制作。它不改动生产 Java、伤害判定或技能注册。

本版包含 9 个视觉家族：五行、剑阵、封禁、传送、雷劫、召灵、炼丹、心境、虚空；每个家族 4 套独立编排，共 36 套阵法。每套配方记录最大半径、持续时间、边界、符文、节点、阵眼和余韵层，阵法范围只作为视觉绑定参数，实际判定仍来自技能事件。

基础粒子扩充为 108 种角色化材质。角色包括阵眼、符文、边界、节点、火花、碎片，以及飞针、弧片、印记、灵点、结索、星芒。核心、符文、火花和弧片带 16 帧图集动画，36 套阵法层各自生成 512px/帧的 16 帧图集；预览和原生样片共用同一份图集、范围和时间线。

## 入口

- 交互预览：`source-assets/formation-particle-library-v1/preview/index.html`
- 完整制作包：`deliverables/wuxingxiantu-formation-particle-library-v1.zip`
- 独立资源包：`deliverables/wuxingxiantu-formation-resourcepack-v1.zip`
- 结构检查：`tools/vfx_library/validate_formation_v1.py`
- 浏览器检查：`tools/vfx_library/check_formation_preview.cjs`
- 重新生成：`python tools/vfx_library/formation_library_v1.py --package`

## 清晰度和范围规则

素材保留硬边主体，只在透明边缘做很小的抗锯齿；阵眼、危险边界和安全空洞分层绘制，避免整片雾化。图集会把每层裁在半径内，预览额外显示源码范围参考圆和格网。Photon 文件是可编辑的原生样片；NBT 读回、离线浏览器像素检查和资源包完整性检查不等于 Minecraft 实机播放验收。

## 验证结果

V1 当前已通过 9 家族、36 阵法、108 材质、180 阵法层、144 `.fx`、144 `.fxproj` 的结构检查。浏览器检查覆盖每套阵法 4 个时间点，共 144 帧抽样，并通过 file:// 离线加载、灰度切换、配方导出和 680px 窄屏溢出检查。`minecraftRendered` 与 `productionIntegrated` 保持 `false`，因为本轮没有启动游戏或修改生产代码。
