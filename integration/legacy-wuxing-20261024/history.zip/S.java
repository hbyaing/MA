import java.net.*;
public class S { public static void main(String[]x)throws Exception {var s=new ServerSocket(0,10,InetAddress.getLoopbackAddress()); System.out.println(s); var c=new Socket(); c.connect(new InetSocketAddress(InetAddress.getLoopbackAddress(),s.getLocalPort())); System.out.println(c);}}
