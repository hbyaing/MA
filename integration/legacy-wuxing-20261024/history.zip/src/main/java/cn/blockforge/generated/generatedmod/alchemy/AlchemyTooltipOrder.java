package cn.blockforge.generated.generatedmod.alchemy;

import net.minecraft.network.chat.Component;
import java.util.List;
import java.util.ArrayList;

/** Keep attribution supplied by the item tooltip after screen-specific recipe details. */
public final class AlchemyTooltipOrder {
    public static List<Component> attributionLast(List<Component> original) {
        List<Component> content=new ArrayList<>(),sources=new ArrayList<>();
        for(var line:original) {
            String text=line.getString().trim();
            if(text.equals("五行仙途")||text.equals("Wu Xing Xian Tu"))sources.add(line);
            else content.add(line);
        }
        content.addAll(sources);return content;
    }
    private AlchemyTooltipOrder() {}
}
