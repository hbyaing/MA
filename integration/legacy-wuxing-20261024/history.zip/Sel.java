import java.nio.channels.*; public class Sel {public static void main(String[]a)throws Exception {System.out.println(Selector.open());}}
