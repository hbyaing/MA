# 五行仙途 0.2 — Forge 1.20.1

当前测试安装成品：`wuxingxiantu-0.2-20261008-project-build.jar`。当前源码完整构建通过，包含 UI 与 JEI 调整及近期灵植素材；发光蓝蘑菇采用单一外观和小蘑菇式扩散。客户端实机仍由用户验收。

源码当前说明见 [CURRENT_STATUS.md](CURRENT_STATUS.md)，实现入口见 [AI_SOURCE_MAP.md](AI_SOURCE_MAP.md)。历史构建测试结果仅代表对应版本，不能作为当前版本的全量验证结论。

默认安装目录为 `D:\MC\库\red.ghs.axolotl\profiles\测试 (1)\mods`；使用 `tools/install_test_mod.ps1`，只替换本 mod，并保留备份。

旧版发布叙述与本次清理前完整说明保存在 `docs/archive/20261008-document-cleanup/`。

Java 17、Forge 47.4.10、GeckoLib 4.8.4。构建：Windows 执行 `gradlew.bat build`，Linux/macOS 执行 `./gradlew build`。成品位于 `build/libs/`。

资源检查：`python tools/check_resources.py`，也已接入 Gradle `check` / `build`。专项图像检查需要 Python 3 与 Pillow（`python -m pip install 'Pillow>=10,<12'`）；Python 不在 PATH 时传入 `-PpythonExecutable=绝对路径`。CI 安装依赖后执行完整验证；编译不能代替客户端、专用服务器与联机测试。

审计记录保存在 `docs/audits/`。历次报告保存在 `docs/archive/`，属于历史记录，不能作为当前验证证据。当前实现入口见 `AI_SOURCE_MAP.md`，验证和未验收事项见 `CURRENT_STATUS.md`。原始模型、美术与设计约束仍在 `reference_assets/` 和 `source-assets/`。




完整验证入口为 `verifyFull`；默认数值报表由 `balanceReport` 输出至 `reports/balance/`，也接入 `check/build`。服务端灵力、司南、渡劫和魂仆设置位于世界 `serverconfig/wuxingxiantu-gameplay-server.toml`。管理员可执行 `/wuxing audit acquisition` 导出当前数据包的获取来源证据；未收录来源不等于无法获得。

丹道需研读“丹道入门”明确解锁。分类丹书传授指定丹方，全书从 PillCatalog 动态读取全部丹方且仅供创造/管理员使用。管理命令：`/wuxing alchemy <玩家> unlock|all|reset|learn <丹方ID>`，要求权限等级 2。

心境异常恢复：`/wuxing mindscape force_restore`，权限等级 2；必须存在有效、未恢复的外界快照。恢复记录仅在操作成功后标记完成。

心境使用 64 个持久化实例槽；离线玩家仍占用租约。首次进入时初始化竞技场，后续复用。
