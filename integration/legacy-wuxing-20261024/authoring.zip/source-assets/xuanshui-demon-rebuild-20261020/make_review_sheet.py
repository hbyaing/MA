"""Pair the reference crops with unretouched Blockbench model captures."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent
ref=Image.open(P/'reference.png').convert('RGB')
spec=[('front',(16,6,440,500)),('side',(453,53,1447,500)),('back',(23,522,425,1041)),('top',(443,510,653,1041)),('perspective',(653,551,1448,1041))]
canvas=Image.new('RGB',(1500,1900),(238,240,242));draw=ImageDraw.Draw(canvas)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',23)
for i,(name,box) in enumerate(spec):
    y=i*380
    draw.text((25,y+12),name.upper()+' / REFERENCE',font=font,fill=(35,40,45))
    draw.text((775,y+12),'BLOCKBENCH / NEW WHITE SCULPT',font=font,fill=(35,40,45))
    a=ref.crop(box)
    raw=Image.open(P/'review'/(name+'-raw.png')).convert('RGBA')
    b=raw.crop(raw.getchannel('A').getbbox())
    for col,im in enumerate([a,b]):
        im.thumbnail((710,320),Image.Resampling.LANCZOS)
        x=col*750+(750-im.width)//2
        yy=y+50+(320-im.height)//2
        if im.mode=='RGBA':canvas.paste(im,(x,yy),im)
        else:canvas.paste(im,(x,yy))
    draw.line((0,y+379,1500,y+379),fill=(193,199,204))
canvas.save(P/'review'/'reference-comparison.png')
print(P/'review'/'reference-comparison.png')
