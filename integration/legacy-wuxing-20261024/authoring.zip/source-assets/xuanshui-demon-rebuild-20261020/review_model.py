"""Load the new model and capture independent Blockbench inspection cameras."""
import argparse
import base64
import json
import pathlib
import time
import urllib.request
from PIL import Image, ImageDraw, ImageFont

P=pathlib.Path(__file__).resolve().parent
URL='http://localhost:3000/bb-mcp'
SESSION=None

def rpc(method,params=None):
    global SESSION
    data=dict(jsonrpc='2.0',id=10,method=method,params=params or {})
    headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream'}
    if SESSION:headers['mcp-session-id']=SESSION
    req=urllib.request.Request(URL,json.dumps(data).encode(),headers)
    with urllib.request.urlopen(req,timeout=90) as r:
        if r.headers.get('mcp-session-id'):SESSION=r.headers['mcp-session-id']
        raw=r.read().decode()
    result=json.loads(raw) if raw else {}
    if 'error' in result:raise RuntimeError(result)
    return result.get('result',result)

def call(name,args=None):
    r=rpc('tools/call',dict(name=name,arguments=args or {}))
    if r.get('isError'):raise RuntimeError(r)
    return r

def evaluate(code):
    r=call('risky_eval',dict(code=code))
    return [c.get('text') for c in r.get('content',[]) if c['type']=='text']

def connect():
    print(rpc('initialize',dict(protocolVersion='2024-11-05',capabilities={},clientInfo=dict(name='Xuanshui-Rebuild',version='1.0'))),flush=True)
    headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream','mcp-session-id':SESSION}
    data=dict(jsonrpc='2.0',method='notifications/initialized')
    with urllib.request.urlopen(urllib.request.Request(URL,json.dumps(data).encode(),headers),timeout=10) as r:r.read()

VIEWS={
    'side':([-230,31,29],[0,31,29],.216),
    'front':([0,32,-230],[0,32,-10],.35),
    'perspective':([-170,96,-155],[0,28,27],.23),
    'back':([0,91,235],[0,29,27],.31),
    'top':([0,250,29],[0,0,29],.145),
    'head':([-90,57,-124],[0,34,-25],.64),
    'feet':([-100,54,-121],[0,12,-10],.55),
    'tail':([-170,70,80],[0,28,69],.42),
}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--load',action='store_true');parser.add_argument('--views',nargs='*',default=['side','front','perspective','back','top']);args=parser.parse_args()
    connect()
    if args.load:
        path=str(P/'玄水妖_白模重建.bbmodel')
        code='(async()=>{const path='+json.dumps(path)+';if(Project && Project.save_path===path){if(!Project.saved)throw new Error("Unsaved edits in current sculpt");await Project.close(true);}await new Promise(resolve=>Blockbench.read([path],{readtype:"text"},files=>{Codecs.project.load(JSON.parse(files[0].content),{path:files[0].path});Project.view_mode="solid";Project.saved=true;Canvas.updateAll();resolve();}));return {name:Project.name,meshes:Mesh.all.length};})()'
        print(evaluate(code),flush=True)
    call('create_offscreen_view',dict(id='rebuild_review',width=1600,height=1100,copy_view='none'))
    out=P/'review';out.mkdir(exist_ok=True)
    for name in args.views:
        pos,target,zoom=VIEWS[name]
        r=call('set_camera_angle',dict(view='rebuild_review',position=pos,target=target,projection='orthographic',zoom=zoom,format='png'))
        for c in r.get('content',[]):
            if c['type']=='image':
                raw=out/(name+'-raw.png');raw.write_bytes(base64.b64decode(c['data']))
                im=Image.open(raw).convert('RGBA')
                bg=Image.new('RGBA',im.size,(222,226,229,255));bg.alpha_composite(im);bg.convert('RGB').save(out/(name+'.png'))
        print('captured',name,flush=True)
    try:
        call('delete_offscreen_view',dict(view='rebuild_review'))
    except RuntimeError as exc:
        # Plugin 1.10.1 may throw after disposal in its UI cleanup callback.
        if 'onContextMenu is not defined' not in str(exc):raise
        print('Plugin viewport cleanup callback failed after captures; images are saved.',flush=True)

if __name__=='__main__':main()
