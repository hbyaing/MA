"""Build the independent Xuanshui clay sculpt from the approved five-view sheet.

Dependencies: numpy, scipy, scikit-image. No earlier model is imported.
Coordinates are registered to the side view; x is the transverse axis.
"""
from __future__ import annotations
import argparse
import json
import math
import os
from pathlib import Path
import sys
import uuid

optional_deps = os.environ.get('XUANSHUI_PYTHON_DEPS')
if optional_deps:
    sys.path.insert(0, optional_deps)
import numpy as np
from scipy.interpolate import PchipInterpolator, CubicSpline
from scipy.ndimage import gaussian_filter
from skimage.measure import marching_cubes

P = Path(__file__).resolve().parent
S = 7.0
ELEMENTS, GROUPS, OUTLINER = [], [], []
NS = uuid.UUID('f8be9f34-0d2e-4f9d-8658-e9ec460cf431')

def w(u, v, x=0):
    return np.array([x / S, (495-v) / S, (u-750) / S], dtype=float)

def group(name, parent=None, pivot=None):
    uid = str(uuid.uuid5(NS, name))
    GROUPS.append(dict(name=name, uuid=uid, origin=list(pivot if pivot is not None else [0,0,0]),
                       rotation=[0,0,0], export=True, visibility=True))
    node = dict(uuid=uid, isOpen=False, children=[])
    (OUTLINER if parent is None else parent['children']).append(node)
    return node

def mesh(name, vertices, faces, parent):
    unique, remap, lookup = [], [], {}
    for v in vertices:
        key=tuple(round(float(q),7) for q in v)
        if key not in lookup:
            lookup[key]=len(unique);unique.append(key)
        remap.append(lookup[key])
    vs = np.asarray(unique, dtype=float)
    if not np.isfinite(vs).all():raise ValueError(name+': non-finite geometry')
    fs=[]
    for face in faces:
        f=list(dict.fromkeys(remap[int(i)] for i in face))
        if len(f)<3:continue
        polys=[f] if len(f)<=4 else [[f[0],f[j],f[j+1]] for j in range(1,len(f)-1)]
        for poly in polys:
            area=sum(np.linalg.norm(np.cross(vs[poly[j]]-vs[poly[0]],vs[poly[j+1]]-vs[poly[0]])) for j in range(1,len(poly)-1))
            if area>1e-14:fs.append(poly)
    volume = sum(np.dot(vs[f[0]], np.cross(vs[f[j]],vs[f[j+1]]))
                 for f in fs for j in range(1,len(f)-1)) / 6
    if volume < 0:
        fs = [list(reversed(f)) for f in fs]
    uid = str(uuid.uuid5(NS, name))
    e = dict(name=name, uuid=uid, type='mesh', origin=[0,0,0], rotation=[0,0,0],
             color=0, shading='smooth', export=True, visibility=True,
             vertices={f'v{i}': [round(float(q),7) for q in v] for i,v in enumerate(vs)},
             faces={f'f{i}': dict(vertices=[f'v{j}' for j in f],
                    uv={f'v{j}':[0,0] for j in f},texture=False) for i,f in enumerate(fs)})
    ELEMENTS.append(e)
    parent['children'].append(uid)
    return e

def unit(v):
    return v / max(1e-10, np.linalg.norm(v))

def curve(points, radii, samples=36):
    p=np.asarray(points,float)
    t=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
    q=np.linspace(0,t[-1],samples)
    return CubicSpline(t,p,bc_type='natural')(q), PchipInterpolator(t,radii)(q)

def tube(name, points, radii, parent, sides=12, samples=0, aspect=1):
    points, radii = np.asarray(points,float), np.asarray(radii,float)
    if samples:
        points,radii=curve(points,radii,samples)
    rings=[]
    for j,(p,r) in enumerate(zip(points,radii)):
        t=unit(points[min(j+1,len(points)-1)]-points[max(0,j-1)])
        a=unit(np.cross([1,0,0] if abs(t[0])<.9 else [0,0,1],t))
        b=unit(np.cross(t,a))
        rings.append([p+r*(a*math.cos(k*math.tau/sides)+b*aspect*math.sin(k*math.tau/sides)) for k in range(sides)])
    vs=np.array(rings).reshape(-1,3)
    fs=[]
    for j in range(len(rings)-1):
        for k in range(sides):
            fs.append([j*sides+k,j*sides+(k+1)%sides,(j+1)*sides+(k+1)%sides,(j+1)*sides+k])
    fs.extend([list(reversed(range(sides))),list(range((len(rings)-1)*sides,len(rings)*sides))])
    return mesh(name,vs,fs,parent)

def ellipsoid(name, center, radius, parent, n=28, rows=16):
    vs=[np.asarray(center)+[0,-radius[1],0]]
    for j in range(1,rows):
        a=-math.pi/2+j*math.pi/rows
        for k in range(n):
            vs.append(np.asarray(center)+np.asarray(radius)*[math.cos(a)*math.cos(k*math.tau/n),math.sin(a),math.cos(a)*math.sin(k*math.tau/n)])
    vs.append(np.asarray(center)+[0,radius[1],0])
    fs=[[0,1+(k+1)%n,1+k] for k in range(n)]
    for j in range(rows-2):
        for k in range(n):
            a=1+j*n+k;b=1+j*n+(k+1)%n
            fs.append([a,b,b+n,a+n])
    last=1+(rows-2)*n
    fs.extend([[len(vs)-1,last+k,last+(k+1)%n] for k in range(n)])
    return mesh(name,vs,fs,parent)

def smin(a,b,k):
    h=np.maximum(k-np.abs(a-b),0)/k
    return np.minimum(a,b)-h*h*k*.25

PRIMITIVES=[]

def ell(c,r,k=1.2,angle=0):
    PRIMITIVES.append(('ell',np.asarray(c),np.asarray(r),k,angle))

def bone(points,radii,k=.8,samples=16):
    p,r=curve(points,radii,samples)
    for a,b,ra,rb in zip(p[:-1],p[1:],r[:-1],r[1:]):
        PRIMITIVES.append(('cap',a,b,float(ra),float(rb),k))

def field(x,y,z,primitives=None):
    out=np.full(np.broadcast_shapes(np.shape(x),np.shape(y),np.shape(z)),1e4,dtype=np.float32)
    for item in PRIMITIVES if primitives is None else primitives:
        if item[0]=='ell':
            _,c,r,k,angle=item
            xx=x-c[0]; yy=(y-c[1])*math.cos(angle)-(z-c[2])*math.sin(angle)
            zz=(y-c[1])*math.sin(angle)+(z-c[2])*math.cos(angle)
            d=(np.sqrt((xx/r[0])**2+(yy/r[1])**2+(zz/r[2])**2)-1)*min(r)
        else:
            _,a,b,ra,rb,k=item
            v=b-a
            t=np.clip(((x-a[0])*v[0]+(y-a[1])*v[1]+(z-a[2])*v[2])/np.dot(v,v),0,1)
            d=np.sqrt((x-a[0]-t*v[0])**2+(y-a[1]-t*v[1])**2+(z-a[2]-t*v[2])**2)-(ra+(rb-ra)*t)
        out=smin(out,d,k)
    return out

def implicit(name, fn, low, high, spacing, parent):
    axes=[np.arange(lo,hi+spacing*.5,spacing,dtype=np.float32) for lo,hi in zip(low,high)]
    x,y,z=np.meshgrid(*axes,indexing='ij',sparse=True)
    values=gaussian_filter(fn(x,y,z),.58)
    vs,fs,_,_=marching_cubes(values,0,spacing=(spacing,)*3,allow_degenerate=False)
    vs+=np.asarray(low)
    print(name,len(vs),len(fs),flush=True)
    return mesh(name,vs,fs,parent)

def fin(name, root, tips, parent, thick=.18, fold=.4, ribs=True, teeth=True, bend=None):
    """Closed radial membrane, with thickness, pleats and separate tapered rays."""
    root=np.asarray(root,float); tips=np.asarray(tips,float)
    bend=np.asarray(bend if bend is not None else [0,0,0],float)
    ends=[]
    for j in range(len(tips)-1):
        for k in range(8):
            t=k/8
            end=tips[j]*(1-t)+tips[j+1]*t
            if teeth and k%2:
                end=end+(root-end)*([.022,.047,.031,.063][(k//2+j)%4])
            ends.append(end)
    ends.append(tips[-1]); ends=np.asarray(ends)
    rows=10; cols=len(ends)
    axis=unit(np.cross(tips[0]-root,tips[-1]-root))
    vs=[]
    for side in [-1,1]:
        for j in range(rows+1):
            t=j/rows
            for k,end in enumerate(ends):
                pleat=math.cos(k/8*math.tau)*fold*math.sin(math.pi*t)
                p=root+(end-root)*t+bend*math.sin(math.pi*t)+axis*(pleat+side*(thick+(1-t)*.22))
                vs.append(p)
    size=(rows+1)*cols; fs=[]
    for side in range(2):
        base=side*size
        for j in range(rows):
            for k in range(cols-1):
                f=[base+j*cols+k,base+j*cols+k+1,base+(j+1)*cols+k+1,base+(j+1)*cols+k]
                fs.append(f if side else f[::-1])
    boundary=list(range(cols))+[j*cols+cols-1 for j in range(1,rows+1)]+list(range(rows*cols+cols-2,rows*cols-1,-1))+[j*cols for j in range(rows-1,0,-1)]
    for a,b in zip(boundary,boundary[1:]+boundary[:1]):fs.append([a,b,b+size,a+size])
    mesh(name+' membrane',vs,fs,parent)
    if ribs:
        for j,end in enumerate(tips):
            middle=root*.48+end*.52+bend+axis*fold*.35
            tube(name+f' ray {j+1}',[root,middle,end],[.68 if j==0 else .38,.48 if j==0 else .28,.13],parent,sides=10,samples=16)

def leaf(name,start,end,width,height,parent,normal):
    start=np.asarray(start);end=np.asarray(end);normal=unit(np.asarray(normal,float))
    lateral=unit(np.cross(end-start,normal))
    mid=start*.45+end*.55
    vs=[start-lateral*width*.55,start+lateral*width*.55,mid+lateral*width,end,mid-lateral*width,
        start*.75+end*.25+normal*height,mid+normal*height*.8]
    vs += [v-normal*.22 for v in vs[:5]]
    fs=[[0,1,5],[1,2,6,5],[2,3,6],[3,4,6],[4,0,5,6],[11,10,9,8,7]]
    for i in range(5):fs.append([(i+1)%5,i,7+i,7+(i+1)%5])
    return mesh(name,vs,fs,parent)

def sculpt():
    root=group('Xuanshui | new white sculpt')
    body=group('01 | continuous chest shoulders limbs and tail',root)
    head=group('02 | skull jaw eye sockets',root)
    headfins=group('03 | swept cheek fans and brow crests',root)
    dorsal=group('04 | dorsal sail membranes and rays',root)
    tail=group('05 | caudal fans',root)
    armor=group('06 | fitted throat and belly scutes',root)
    feet=group('07 | separate hooked claws',root)
    limbs=group('08 | elbow and ankle fins',root)
    whiskers=group('09 | four independent whiskers',root)

    ell(w(732,277),[13.8,14.8,22],2.4)
    ell(w(830,322),[13.4,11.0,24],2)
    ell(w(945,359),[10,8.5,15],2)
    ell(w(628,292),[10.8,11.5,16],2)
    ell(w(643,341),[9.7,10.2,12],2)
    for side in [-1,1]:
        ell(w(695,287,side*101),[7.1,9.7,8.4],1.8,angle=-.24)
        bone([w(702,314,side*106),w(730,356,side*118),w(687,402,side*132),w(640,442,side*138),w(615,465,side*138)],[5.9,5.6,6.4,5.6,4.4],1.9,24)
        ell(w(606,472,side*138),[7.8,3.3,6.2],1.0)
        for k in range(5):
            xx=side*(94+k*22)
            u=550+abs(k-2)*7
            bone([w(608,472,xx),w(588,476,xx+side*2),w(u+25,480,xx+side*3)],[2.15,2.0,1.55],.55,8)
            tube(('L' if side<0 else 'R')+f' front claw {k+1}',[w(u+26,477,xx+side*3),w(u+9,480,xx+side*3),w(u-5,487,xx+side*3),w(u-11,492,xx+side*3)],[1.65,1.48,.8,.03],feet,sides=10,samples=18,aspect=.9)
        ell(w(916,352,side*86),[7.8,11.2,9.4],1.4,angle=.4)
        bone([w(927,376,side*99),w(960,408,side*119),w(975,440,side*129),w(974,472,side*133)],[6.2,5.5,4.8,4.0],1,18)
        ell(w(963,476,side*134),[6.8,2.9,5.5],.9)
        for k in range(4):
            xx=side*(100+k*23)
            u=916+abs(k-1.5)*6
            bone([w(965,474,xx),w(946,478,xx),w(u+22,482,xx)],[2.05,1.95,1.5],.55,8)
            tube(('L' if side<0 else 'R')+f' hind claw {k+1}',[w(u+22,478,xx),w(u+6,482,xx),w(u-5,488,xx),w(u-10,493,xx)],[1.6,1.4,.7,.03],feet,sides=10,samples=16)
    tailpoints=[(963,373,8),(1030,401,6),(1120,435,4.8),(1205,450,4.3),(1280,437,4),(1343,395,3.8),(1376,339,3.5),(1385,280,3.1),(1376,227,2.8),(1353,186,1.9),(1329,164,.65)]
    bone([w(u,v) for u,v,r in tailpoints],[r for u,v,r in tailpoints],1.2,65)
    implicit('Sculpted continuous body',lambda x,y,z:np.maximum(field(x,y,z),.35-y),[-31,-1,-35],[31,65,100],.8,body)

    sections=np.array([[467,277,294,20],[482,264,308,31],[510,247,316,44],[542,228,322,53],[580,210,325,61],[618,203,324,62],[650,218,319,49],[670,245,303,28]],float)
    interpolators=[PchipInterpolator(sections[:,0],sections[:,i],extrapolate=True) for i in [1,2,3]]
    def skullfield(x,y,z):
        u=z*S+750; v=495-y*S
        uu=np.clip(u,467,670); top,bottom,wide=[f(uu) for f in interpolators]
        cy=(top+bottom)/2; ry=(bottom-top)/2
        d=((np.abs(x*S/wide)**2.5+np.abs((v-cy)/ry)**2.5)**.4-1)*np.minimum(wide,ry)/S
        d=np.maximum(d,np.maximum((467-u)/S,(u-670)/S))
        for side in [-1,1]:
            c=w(527,264,side*45)
            socket=(np.sqrt(((x-c[0])/1.7)**2+((y-c[1])/.90)**2+((z-c[2])/3.3)**2)-1)*.90
            d=np.maximum(d,-socket)
            c=w(470,282,side*13)
            nostril=(np.sqrt(((x-c[0])/.48)**2+((y-c[1])/.40)**2+((z-c[2])/.72)**2)-1)*.4
            d=np.maximum(d,-nostril)
        # A continuous shallow mouth groove wraps the broad muzzle.
        groove_y=(495-(300+.105*(uu-480)))/S
        groove=np.sqrt(((y-groove_y)/.20)**2+((np.abs(x)*S-wide*.76)/5.6)**2)-1
        groove=np.maximum(groove,np.maximum((480-u)/S,(u-560)/S))
        return np.maximum(d,-groove*.20)
    implicit('Broad carved skull with orbital and lip recesses',skullfield,[-11,22,-42],[11,44,-10],.38,head)
    rings=[]
    for u,top,bottom,width in [(470,291,300,20),(487,297,311,29),(521,307,324,43),(557,315,331,49),(588,316,328,43)]:
        rings.append([w(u,(top+bottom)/2-(bottom-top)/2*math.sin(k*math.tau/24),width*math.cos(k*math.tau/24)) for k in range(24)])
    jawfaces=[]
    for j in range(len(rings)-1):
        for k in range(24):jawfaces.append([j*24+k,j*24+(k+1)%24,(j+1)*24+(k+1)%24,(j+1)*24+k])
    jawfaces.extend([list(range(23,-1,-1)),list(range(96,120))])
    mesh('Angular lower jaw',np.asarray(rings).reshape(-1,3),jawfaces,head)
    for side in [-1,1]:
        tag='L' if side<0 else 'R'
        ellipsoid(tag+' recessed eye',w(527,264,side*41.8),[.7,.36,1.8],head)
        tube(tag+' swept brow',[w(495,272,side*27),w(516,254,side*42),w(549,236,side*57),w(592,214,side*61),w(639,192,side*55)],[.28,.85,1,.85,.12],headfins,sides=12,samples=34)
        # Scalloped cheek ridges carry the face into the fan root.
        tube(tag+' cheek ridge',[w(487,297,side*24),w(523,300,side*43),w(557,287,side*55),w(594,266,side*65)],[.38,.65,.9,.15],head,sides=10,samples=25)
        for k in range(4):
            u=544+k*18;v=234-k*10
            leaf(tag+f' brow scale {k+1}',w(u-9,v+12,side*(49+k*4)),w(u+25,v-10,side*(60+k*2)),1.35,.65,headfins,[side*.65,.7,-.1])
        fin(tag+' cheek fan',w(547,281,side*54),[w(676,178,side*119),w(661,210,side*143),w(650,243,side*153),w(635,276,side*144),w(614,309,side*115),w(580,315,side*76)],headfins,fold=.42,thick=.17)
        for k in range(2):
            raw=[(504+k*15,304,side*(22+k*19)),(523+k*13,340,side*(27+k*20)),(522+k*13,378,side*(31+k*22)),(501+k*10,419-k*7,side*(35+k*22)),(489+k*14,445-k*8,side*(32+k*23)),(500+k*15,462-k*10,side*(24+k*25))]
            tube(tag+f' whisker {k+1}',[w(*p) for p in raw],[.72,.7,.6,.46,.3,.04],whiskers,sides=12,samples=45)
        fin(tag+' elbow fin',w(713,375,side*150),[w(752,293,side*145),w(755,323,side*156),w(769,345,side*161),w(762,369,side*159),w(736,397,side*151)],limbs,fold=.22)
        fin(tag+' forearm fan',w(626,459,side*169),[w(779,385,side*175),w(763,416,side*184),w(749,443,side*188),w(771,469,side*184),w(748,484,side*177),w(685,478,side*169)],limbs,fold=.28)
        fin(tag+' hock upper fin',w(962,408,side*147),[w(1003,351,side*147),w(991,380,side*156),w(982,403,side*156)],limbs,fold=.18)
        fin(tag+' hock fan',w(980,461,side*155),[w(1020,400,side*151),w(1030,428,side*167),w(1046,450,side*174),w(1078,486,side*168),w(1024,480,side*162)],limbs,fold=.24)

    sails=[((540,242),(596,129),(634,204)),((606,201),(706,85),(730,185)),((681,178),(806,62),(816,213)),((764,199),(876,107),(882,255)),((837,242),(934,156),(944,302)),((905,287),(998,213),(1019,350)),((986,339),(1063,275),(1092,393)),((1063,385),(1192,330),(1204,425))]
    for i,(base,tip,end) in enumerate(sails):
        a=np.array(tip,float);b=np.array(end,float)
        ends=[w(*a)]
        for j in range(1,5):
            p=a+(b-a)*j/4
            p[0]-=11*math.sin(j/4*math.pi)
            ends.append(w(*p))
        fin(f'Dorsal sail {i+1:02}',w(*base),ends,dorsal,thick=.20,fold=.33,bend=[0,.85,-1.55])
    tube('Forehead central lance',[w(478,273),w(517,239),w(553,206),w(594,175),w(629,156)],[.3,1.2,1.4,1.15,.07],headfins,sides=14,samples=38,aspect=.65)

    for side in [-1,1]:
        tag='L' if side<0 else 'R'
        fin(tag+' caudal upper fan',w(1360,354,side*14),[w(1205,191,side*80),w(1255,174,side*71),w(1298,121,side*52),w(1335,148,side*34),w(1365,199,side*21)],tail,fold=.5,thick=.2)
        fin(tag+' caudal inner web',w(1260,437,side*13),[w(1198,399,side*37),w(1247,353,side*49),w(1300,319,side*42),w(1338,345,side*23)],tail,fold=.3,thick=.16)
        fin(tag+' caudal lower fan',w(1269,430,side*15),[w(1290,446,side*145),w(1339,479,side*128),w(1390,487,side*78),w(1422,443,side*35),w(1404,400,side*20)],tail,fold=.45,thick=.18)

    def vertical_surface(u,x=0,upper=True):
        ys=np.linspace(5,56,260);zs=np.full_like(ys,(u-750)/S)
        ds=field(np.full_like(ys,x),ys,zs)
        ids=np.where(ds<0)[0]
        if not len(ids):raise ValueError('Surface ray missed body')
        j=ids[-1] if upper else ids[0]
        q=min(j+1,len(ys)-1) if upper else max(j-1,0)
        return ys[j]+(ys[q]-ys[j])*(-ds[j])/(ds[q]-ds[j])
    for i,u in enumerate(range(641,1015,28)):
        a=np.array([0,vertical_surface(u)+.16,(u-750)/S])
        b=np.array([0,vertical_surface(u+32)+.35,(u+32-750)/S])
        leaf(f'Dorsal overlapping keel scute {i+1:02}',a,b,1.55 if u<900 else 1.15,.62,dorsal,[0,1,0])

    def ventral(u,a):
        cy=(495-322)/S
        rs=np.linspace(0,23,180)
        xs=rs*math.sin(a);ys=cy-rs*math.cos(a);zs=np.full_like(rs,(u-750)/S)
        ds=field(xs,ys,zs,PRIMITIVES[:5]);ids=np.where(ds<0)[0]
        if not len(ids):raise ValueError('Ventral ray missed body')
        j=ids[-1];q=j+1
        if q>=len(rs):raise ValueError('Ventral ray did not exit torso')
        r=rs[j]+(rs[q]-rs[j])*(-ds[j])/(ds[q]-ds[j])+.12
        return np.array([r*math.sin(a),cy-r*math.cos(a),(u-750)/S])
    for row,u in enumerate(range(668,922,36)):
        for col in range(4):
            a0=-1.38+col*.69;vs=[];fs=[]
            for j in range(4):
                for k in range(5):
                    a=a0+k*.69/4
                    v=ventral(u+j*11.3+3*math.sin(k/4*math.pi),a)
                    vs.append(v)
            for j in range(3):
                for k in range(4):fs.append([j*5+k,j*5+k+1,(j+1)*5+k+1,(j+1)*5+k])
            n=len(vs)
            vs += [v+np.array([-math.sin(a0+(i%5)*.69/4),math.cos(a0+(i%5)*.69/4),0])*.25 for i,v in enumerate(vs)]
            fs += [[v+n for v in reversed(f)] for f in fs.copy()]
            boundary=[0,1,2,3,4,9,14,19,18,17,16,15,10,5]
            for a,b in zip(boundary,boundary[1:]+boundary[:1]):fs.append([b,a,a+n,b+n])
            mesh(f'Ventral armor {row+1:02}-{col+1}',vs,fs,armor)

    def front_surface(x,y):
        zs=np.linspace(-37,8,450)
        ds=field(np.full_like(zs,x),np.full_like(zs,y),zs)
        ids=np.where(ds<0)[0]
        if not len(ids):return None
        j=ids[0]
        return zs[j] if j==0 else zs[j-1]+(zs[j]-zs[j-1])*ds[j-1]/(ds[j-1]-ds[j])
    for row in range(6):
        vs=[];fs=[];wide=[7.5,8.0,7.7,6.7,5.3,3.5][row]
        for j in range(4):
            for k in range(13):
                t=k/6-1;x=t*wide*(1-j*.045)
                y=32.1-row*2.72-j*.88-(1-abs(t))*1.1
                z=front_surface(x,y)
                if z is None:z=front_surface(x,y+.6)
                if z is None:raise ValueError('Chest scute missed body')
                vs.append([x,y,z-.19-.13*math.sin(k/12*math.pi)])
        for j in range(3):
            for k in range(12):fs.append([j*13+k,j*13+k+1,(j+1)*13+k+1,(j+1)*13+k])
        # Closed, thin plates avoid double-sided coincident planes.
        n=len(vs);vs+= [[x,y,z+.32] for x,y,z in vs]
        fs+= [[v+n for v in reversed(f)] for f in fs.copy()]
        boundary=list(range(13))+[j*13+12 for j in range(1,4)]+list(range(50,38,-1))+[26,13]
        for a,b in zip(boundary,boundary[1:]+boundary[:1]):fs.append([b,a,a+n,b+n])
        mesh(f'Throat chevron scute {row+1}',vs,fs,armor)

    return dict(meta=dict(format_version='5.0',model_format='free',box_uv=False),
                name='玄水妖_白模重建',model_identifier='xuanshui_white_rebuild',
                resolution=dict(width=16,height=16),elements=ELEMENTS,groups=GROUPS,
                outliner=OUTLINER,textures=[],animations=[],view_mode='solid')

def main():
    model=sculpt()
    dst=P/'玄水妖_白模重建.bbmodel'
    dst.write_text(json.dumps(model,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    print(json.dumps(dict(file=str(dst),meshes=len(ELEMENTS),vertices=sum(len(e['vertices']) for e in ELEMENTS),faces=sum(len(e['faces']) for e in ELEMENTS)),ensure_ascii=False))

if __name__=='__main__':main()
