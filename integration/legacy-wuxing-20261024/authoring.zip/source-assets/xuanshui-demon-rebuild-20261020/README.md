# 玄水妖白模重建

本目录为 2026-10-20 按用户提供的五视图独立新建的雕塑工程。

- `玄水妖_白模重建.bbmodel`：可直接在 Blockbench 打开的通用网格白模。
- `reference.png`：本次使用的参考图。
- `review/`：从 Blockbench 离屏视口取得的五视图、局部图和参考对照图。
- `validation.json`：保存模型的结构检查结果。
- `build_white.py`：独立生成脚本，不读取或修改旧版模型。

模型包含连续躯干、肩部、屈曲前后肢、卷尾，以及独立的头脸、眼窝、下颌、四根须、趾爪、鳍膜、鳍骨和甲片。保留为无贴图白模，等待外观确认后再进行 UV、贴图和动画工作。当前为雕塑源文件，尚未转为游戏使用的拓扑或接入 Minecraft。

## 重建和检查

Python 依赖：`numpy`、`scipy`、`scikit-image`、`Pillow`。可通过环境变量 `XUANSHUI_PYTHON_DEPS` 指定额外依赖目录。

```powershell
python build_white.py
python validate_model.py
python review_model.py --load --views front side back top perspective head feet tail
python make_review_sheet.py
```

预览脚本使用本地 `http://localhost:3000/bb-mcp`，创建独立离屏相机，不操作真实鼠标。模型重新载入时不会覆盖当前工程内尚未保存的修改。截图只做透明背景合成及对照排版，不修饰模型轮廓。

验证范围：UUID 与场景归属、有限坐标、面顶点引用、闭合边、非流形边、面朝向、无贴图状态，以及 Blockbench 实际载入和多视图检查。该检查不等同于动画变形、自动碰撞或游戏验收。
