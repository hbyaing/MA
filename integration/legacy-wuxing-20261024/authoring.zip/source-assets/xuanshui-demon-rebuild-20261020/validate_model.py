"""Check saved geometry, closed surfaces, symmetry and scene references."""
import collections
import json
import math
from pathlib import Path

P=Path(__file__).resolve().parent
m=json.loads((P/'玄水妖_白模重建.bbmodel').read_text(encoding='utf-8'))
errors=[];warnings=[];bounds=[];rows=[]
ids=[e['uuid'] for e in m['elements']]+[g['uuid'] for g in m['groups']]
if len(ids)!=len(set(ids)):errors.append('Duplicate UUIDs')
known=set(ids);referenced=[]
def walk(nodes):
    for n in nodes:
        if isinstance(n,str):referenced.append(n)
        else:
            referenced.append(n['uuid']);walk(n['children'])
walk(m['outliner'])
if set(referenced)!=known or len(referenced)!=len(set(referenced)):errors.append('Invalid outliner ownership')
if m['textures'] or m['animations']:errors.append('Unexpected textures or animations')
for e in m['elements']:
    vs=e['vertices'];edge_counts=collections.Counter();directions=collections.Counter()
    for key,p in vs.items():
        if len(p)!=3 or not all(math.isfinite(v) for v in p):errors.append(e['name']+': invalid vertex '+key)
        bounds.append(p)
    for f in e['faces'].values():
        v=f['vertices']
        if len(v) not in [3,4] or len(v)!=len(set(v)):errors.append(e['name']+': invalid face')
        if any(k not in vs for k in v):errors.append(e['name']+': missing vertex');continue
        if f.get('texture') is not False:errors.append(e['name']+': textured face')
        for a,b in zip(v,v[1:]+v[:1]):
            edge_counts[tuple(sorted([a,b]))]+=1;directions[(a,b)]+=1
    open_edges=sum(n==1 for n in edge_counts.values())
    nonmanifold=sum(n>2 for n in edge_counts.values())
    inconsistent=sum(directions[(a,b)]==2 or directions[(b,a)]==2 for a,b in edge_counts)
    if open_edges or nonmanifold or inconsistent:
        errors.append(f"{e['name']}: open={open_edges}, nonmanifold={nonmanifold}, winding={inconsistent}")
    rows.append(dict(name=e['name'],vertices=len(vs),faces=len(e['faces']),open_edges=open_edges,nonmanifold_edges=nonmanifold))
report=dict(model=m['name'],meshes=len(rows),vertices=sum(x['vertices'] for x in rows),faces=sum(x['faces'] for x in rows),
            bounds=[[min(v[i] for v in bounds),max(v[i] for v in bounds)] for i in range(3)],
            textures=0,errors=errors,warnings=warnings,parts=rows)
(P/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='parts'},ensure_ascii=False,indent=2))
raise SystemExit(bool(errors))
