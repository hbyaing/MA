from pathlib import Path
from PIL import Image
import json,shutil
root=Path(__file__).resolve().parents[1];a=root/'src/main/resources/assets/wuxingxiantu'
source=Path(r'C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-8078c739-7bdb-4c2e-b5bc-fcd20584404b.png')
out=root/'source-assets/blue-mushroom-20261008';out.mkdir(parents=True,exist_ok=True);shutil.copy2(source,out/'reference-original.png')
im=Image.open(source).convert('RGBA');im=im.crop(im.getbbox());im.save(out/'crop.png')
side=max(im.size);tile=Image.new('RGBA',(side,side));tile.alpha_composite(im,((side-im.width)//2,side-im.height))
name='glowing_blue_mushroom';tile.save(a/'textures/block'/(name+'.png'))
(a/'models/block'/(name+'.json')).write_text(json.dumps({'parent':'minecraft:block/cross','render_type':'minecraft:cutout','textures':{'cross':'wuxingxiantu:block/'+name}},indent=2)+'\n')
state_path=a/'blockstates'/(name+'.json');states=json.loads(state_path.read_text())
for variant in states['variants'].values():variant['model']='wuxingxiantu:block/'+name
state_path.write_text(json.dumps(states,indent=2)+'\n')
(a/'models/item'/(name+'.json')).write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'wuxingxiantu:block/'+name}},indent=2)+'\n')
for suffix in ['_low','_mid']:
    (a/'models/block'/(name+suffix+'.json')).write_text(json.dumps({'parent':'wuxingxiantu:block/'+name})+'\n')
for stage in ['young','growing']:tile.save(a/'textures/block'/(name+'_'+stage+'.png'))
loot=root/'src/main/resources/data/wuxingxiantu/loot_tables/blocks'/(name+'.json')
loot.write_text(json.dumps({'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'wuxingxiantu:'+name}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]},indent=2)+'\n')
for language in ['zh_cn','en_us']:
    p=a/'lang'/(language+'.json');data=json.loads(p.read_text(encoding='utf-8'))
    data['tooltip.wuxingxiantu.hint.glowing_blue_mushroom']='单一形态，低光环境缓慢扩散；菌丝与灰化土可在明亮处种植。' if language=='zh_cn' else 'One form; spreads slowly in dim light. Mycelium and podzol allow bright-light planting.'
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Imported single mushroom form',tile.size)
