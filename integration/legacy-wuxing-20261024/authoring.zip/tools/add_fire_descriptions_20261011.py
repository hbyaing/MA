"""Localized descriptions audited against SpiritEnchantmentLogic and ExoticBurnManager."""
from pathlib import Path
import json

root=Path(__file__).resolve().parents[1]/'src/main/resources/assets/wuxingxiantu'
prefix='tooltip.wuxingxiantu.fire_detail.'
zh={
 'requirement':'缠绕条件：内视装备异火、满足驭火境界，并附有异火缠绕。',
 'levels':'附魔 I–V：武器倍率再乘 1 / 1.04 / 1.08 / 1.12 / 1.20。',
 'burn':'灼烧 I–V：3/4/5/6/8秒；每秒每层 0.5/0.65/0.8/1/1.2 伤害。',
 'armor':'防具等级相加，上限 V；水平检测外扩 2.25/2.5/2.75/3/3.25 格。',
 'armor_interval':'防具每 1.9/1.6/1.3/1/1 秒点燃；纵向检测外扩 1.25 格。',
 'stacks':'重复点燃刷新持续时间，叠层上限 I–V：1/2/2/3/3。',
 'targets':'缠绕不影响玩家或魂仆；防具点燃不触发武器命中特效。',
 'placement':'创造放置用异火；放置或持有不等于炼化、获得或装备异火。',
}
en={
 'requirement':'Requires an equipped fire, its realm requirement, and Exotic Fire Wrap.',
 'levels':'Wrap I-V: multiply weapon damage again by 1 / 1.04 / 1.08 / 1.12 / 1.20.',
 'burn':'Burn I-V: 3/4/5/6/8 s; damage per stack per second: 0.5/0.65/0.8/1/1.2.',
 'armor':'Armor levels add up to V; horizontal detection expansion: 2.25/2.5/2.75/3/3.25 blocks.',
 'armor_interval':'Armor ignites every 1.9/1.6/1.3/1/1 s; vertical detection expansion: 1.25 blocks.',
 'stacks':'Repeated ignition refreshes duration; stack caps I-V: 1/2/2/3/3.',
 'targets':'Wrap excludes players and soul servants; armor ignition does not trigger weapon hit specials.',
 'placement':'Creative placeable fire. Holding or placing it does not refine, unlock or equip it.',
}
lores=[
 ('赤红如潮的灵焰，炽烈直接，擅长持续灼烧。','A fierce crimson flame that strengthens lingering burns.'),
 ('金橙交融的淬火，凝聚熔金破甲之力。','A golden-orange tempering flame with armor-piercing power.'),
 ('灰白冷焰侵入骨髓，迟滞敌人的步伐与攻势。','An ashen cold flame that slows movement and attacks.'),
 ('青翠灵焰孕育生机，在交锋中滋养施术者。','A verdant flame that restores its wielder during combat.'),
 ('碧蓝如海的灵焰，以沧海重压束缚敌人。','An ocean-blue flame that arrests enemy movement.'),
 ('紫焰裹挟霄雷，命中时可向周围敌人放电。','A violet flame that can discharge lightning into nearby foes.'),
 ('白金圣焰如烈日，对亡灵偶有额外净化之力。','A white-gold sacred flame with occasional power against undead.'),
 ('幽紫冥焰侵蚀兵甲，并压制敌人的恢复。','A dark violet flame that corrodes equipment and suppresses healing.'),
 ('多彩神焰流转生灭，追加伤害并在击杀后回馈生机。','A shifting spectrum flame that adds damage and rewards kills with healing.'),
]
specials=[
 ('武器命中：你的元素灼烧伤害 +10%，持续3秒；触发冷却3秒。','Weapon hit: +10% to your elemental burn damage for 3 s; cooldown 3 s.'),
 ('武器命中：20%概率使本次攻击等效无视目标10%护甲。','Weapon hit: 20% chance for this attack to effectively ignore 10% of target armor.'),
 ('武器命中：缓慢 I 持续3秒；目标具有攻击速度属性时，攻速 -15% 持续3秒。','Weapon hit: Slowness I for 3 s; -15% attack speed for 3 s if the target has that attribute.'),
 ('武器命中：回复 max(1点，最大生命×0.5%)；冷却2秒。','Weapon hit: heal max(1 health point, 0.5% of maximum health); cooldown 2 s.'),
 ('武器命中：缓慢 XI 持续1秒，并清零目标水平速度；冷却5秒。','Weapon hit: Slowness XI for 1 s and zero horizontal velocity; cooldown 5 s.'),
 ('武器命中：10%概率对目标周围4格内其他敌对生物造成基础伤害×50%；冷却3秒。','Weapon hit: 10% chance to deal 50% of base damage to other hostile mobs in a 4-block expanded area; cooldown 3 s.'),
 ('武器命中亡灵：5%概率额外增加基础伤害×35%；冷却3秒。','Weapon hit on undead: 5% chance to add 35% of base damage; cooldown 3 s.'),
 ('武器命中：目标六个装备槽各损1耐久；护甲 -10%、治疗量 -50% 持续5秒；冷却8秒。','Weapon hit: damage each of six damageable equipment slots by 1 durability; -10% armor and -50% healing for 5 s; cooldown 8 s.'),
 ('武器命中：额外增加基础伤害×20%。由你击杀仍带有你施加的涅槃灼烧的目标时，回复最大生命10%。','Weapon hit: add 20% of base damage. Kill a target still burning with your Nirvana fire to heal 10% of maximum health.'),
]
multipliers=['1.05','1.10','1.15','1.20','1.25','1.30','1.35','1.40','1.50']
for i,((zl,el),(zs,es),m) in enumerate(zip(lores,specials,multipliers),1):
 zh[f'lore.{i}']=zl; en[f'lore.{i}']=el
 zh[f'weapon.{i}']=f'武器缠绕：护甲结算前，基础命中伤害×{m}×附魔倍率。'
 en[f'weapon.{i}']=f'Weapon wrap: before armor, base hit damage x {m} x enchantment multiplier.'
 zh[f'special.{i}']=zs; en[f'special.{i}']=es
for locale,content in [('zh_cn',zh),('en_us',en)]:
 path=root/'lang'/f'{locale}.json'; data=json.loads(path.read_text(encoding='utf-8-sig'))
 data.update({prefix+k:v for k,v in content.items()})
 path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Restore the fire entries' public introductions too, for catalogue readers outside item tooltips.
path=root/'item_text_catalog.json'; catalog=json.loads(path.read_text(encoding='utf-8-sig'))
colors=[0xFF3C1E,0xFFAA28,0x9194AD,0x3CC882,0x32A0FF,0xAA50FF,0xFFD34F,0x5A2A78,0x40E0D0]
names=['red_flow','molten_gold','cold_bone','azure_wood','cobalt_sea','violet_thunder','sun_saint','nether_void','nirvana']
for i,name in enumerate(names):
 catalog['exotic_fire_'+name].update(nameColor=colors[i],gradeColor=colors[i],visibility='player')
path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
