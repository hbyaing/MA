const fs=require('fs'),vm=require('vm'),assert=require('assert');
class Canvas{
 constructor(){this.width=0;this.height=0;this.pixels=[];this.classList={toggle(){}}}
 getContext(){const dst=this;let mirrored=false,clip=null;return {imageSmoothingEnabled:false,drawImage(src){const input=src.pixels.slice();for(let x=0;x<dst.width;x++)if(!clip||(x>=clip[0]&&x<clip[0]+clip[1]))dst.pixels[x]=input[mirrored?dst.width-1-x:x]},save(){},restore(){mirrored=false;clip=null},beginPath(){},rect(x,y,w){clip=[x,w]},clip(){},clearRect(){},translate(){},scale(x){mirrored=x<0},moveTo(){},lineTo(){},stroke(){}}}
 toDataURL(){return 'data:'}
}
const elements=new Map();for(const id of ['texture','stage','tex','keepLeft','keepRight','editStatus','axis','download','importImage','resetEdits','exportTexture'])elements.set(id,{value:id==='stage'?'flower':id==='tex'?'flower':'' ,classList:{toggle(){}},parentElement:{prepend(){}}});
const source={pixels:[1,2,3,4],naturalWidth:4,naturalHeight:1,complete:true};
const context={console,Map,Image:function(){},document:{createElement:type=>type==='canvas'?new Canvas():{}},$:(id)=>elements.get(id),plant:{id:'lotus'},model:{elements:[{faces:{front:{texture:'#cross'}}},{faces:{front:{texture:'#cross'}}}]},images:new Map(),gpuTextures:new Map(),gl:{deleteTexture(){}},tc:new Canvas().getContext(),draw(){},drawTexture(){},selectStage(){},imageFor(){return source}};
vm.createContext(context);vm.runInContext(fs.readFileSync('deliverables/plant-workbench-20261010/editor.js','utf8'),context);
const evaluate=s=>vm.runInContext(s,context);
evaluate("applySymmetry('left')");assert.deepStrictEqual(Array.from(evaluate('editState().result.pixels')),[1,2,2,1]);
evaluate("applySymmetry('right')");assert.deepStrictEqual(Array.from(evaluate('editState().result.pixels')),[4,3,3,4]);
source.pixels=[1,2,9,3,4];source.naturalWidth=5;
evaluate("applySymmetry('left')");assert.deepStrictEqual(Array.from(evaluate('editState().result.pixels')),[1,2,9,2,1]);
evaluate("applySymmetry('right')");assert.deepStrictEqual(Array.from(evaluate('editState().result.pixels')),[4,3,9,3,4]);
elements.get('resetEdits').onclick();assert.strictEqual(evaluate('editState().result'),null);
console.log('PASS: left/right symmetry, original-source switching, odd center retention and reset');
