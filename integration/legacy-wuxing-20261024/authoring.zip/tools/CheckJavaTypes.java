import com.sun.source.util.JavacTask;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaFileObject;
import javax.tools.ToolProvider;

/** Analyze symbols against existing dependency jars; never generate mod classes or run Gradle. */
public class CheckJavaTypes {
    public static void main(String[] args) throws Exception {
        String classpath = Files.readString(Path.of(args[0])).strip();
        var compiler = ToolProvider.getSystemJavaCompiler();
        var diagnostics = new DiagnosticCollector<JavaFileObject>();
        try(var files=compiler.getStandardFileManager(diagnostics,null,StandardCharsets.UTF_8)) {
            var units=files.getJavaFileObjectsFromStrings(Arrays.asList(args).subList(1,args.length));
            var task=(JavacTask)compiler.getTask(null,files,diagnostics,
                List.of("-proc:none","--release","17","-classpath",classpath,"-sourcepath","src/main/java"),null,units);
            task.parse(); task.analyze();
        }
        for(var d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR)System.out.println(d);
        long errors=diagnostics.getDiagnostics().stream().filter(d->d.getKind()==Diagnostic.Kind.ERROR).count();
        System.out.println("Java type analysis: "+errors+" errors; no mod class or JAR generated.");
        if(errors>0)System.exit(1);
    }
}
