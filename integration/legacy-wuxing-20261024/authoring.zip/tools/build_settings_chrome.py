"""Native scalable rails; the slider's jade bead remains an extracted PNG."""
from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/settings'
OUT.mkdir(parents=True,exist_ok=True)
S=32
points=[(1,.25),(127,.25),(127.75,1),(127,1.75),(1,1.75),(.25,1)]
for name,fill,border in [('slider_track','#14262b','#a58e5a'),('slider_fill','#83ae9d',None)]:
    im=Image.new('RGBA',(128*S,2*S));d=ImageDraw.Draw(im)
    # Filled range stays inside the bezel, so the gold rail stays visible at
    # full value instead of becoming another broad solid strip.
    shape=points if border else [(1,.65),(127,.65),(127.4,1),(127,1.35),(1,1.35),(.6,1)]
    polygon=[(round(x*S),round(y*S)) for x,y in shape]
    d.polygon(polygon,fill=fill)
    if border:d.line(polygon+[polygon[0]],fill=border,width=round(.23*S),joint='curve')
    im.resize((512,8),Image.Resampling.LANCZOS).save(OUT/f'{name}.png')
    (OUT/f'{name}.png.mcmeta').write_text('{"texture":{"blur":true,"clamp":true}}')
print('Built flat two-pixel matte-gold slider track and jade fill at 4x')
