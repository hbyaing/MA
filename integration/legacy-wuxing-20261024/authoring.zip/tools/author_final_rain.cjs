const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve('deliverables/tribulation-final-rain-20261010/workbench');
const realmNames=['练气','筑基','金丹','元婴','化神','炼虚','合体','大乘'];
const diameters=[4,6,8,12,16,22,28,32],counts=[3,5,7,9,12,16,20,24];
const ctx={};vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'recipe.js'),'utf8')+';globalThis.validate=validateRecipe;',ctx);
const recipes={};
for(let r=0;r<8;r++){
 const key=String(r+1).padStart(2,'0');
 const base=JSON.parse(fs.readFileSync(`src/main/resources/assets/wuxingxiantu/tribulation/${key}.json`,'utf8'));
 const recipe={...base,mode:'rain',rainStyle:'cluster',rainCount:counts[r],rainSpread:diameters[r],rainDepthSpread:diameters[r],rainStagger:.35+r*.05,
  rainMaxBranchDepth:0,rainMaxBranches:0,rainBranchProbability:0,strikeHeight:96,strikeWidth:.065+r*.012,glowWidth:.23+r*.035,
  strikeDisplacement:1.5+r*.3,strikeRoughness:.53,durationTicks:16+r*2,progressionTicks:1.2+r*.12,restrikeCount:2,
  maxSegments:1200,impactRadius:1.6+r*.35,impactDuration:18+r*2,impactRays:10+r,impactSparks:18+r*2};
 recipes[key]=ctx.validate(recipe);
 fs.writeFileSync(path.join(root,'presets',`final-rain-${key}.json`),JSON.stringify(recipe,null,2));
}
fs.writeFileSync(path.join(root,'final-rain-recipes.js'),'const finalRainRecipes='+JSON.stringify(recipes)+';\n');
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
html=html.replace('<script src="app.js"></script>','<script src="final-rain-recipes.js"></script><script src="app.js"></script>');
html=html.replace(/<select id="formStage">[\s\S]*?<\/select>/,'<select id="formStage"><option value="normal">终劫落雷场 · 八境预设</option></select>');
html=html.replace(/<select id="tribulationPreset">[\s\S]*?<\/select>/,'<select id="tribulationPreset">'+realmNames.map((name,r)=>`<option value="${String(r+1).padStart(2,'0')}">${name} · 终劫雷场 · 直径 ${diameters[r]} 格 / ${counts[r]} 束</option>`).join('')+'</select>');
html=html.replace('此为设计预览，尚未接入主 MOD。','终劫雷场待接入游戏；覆盖直径随境界增长。每束位置由种子确定，短间隔连续落下。');
fs.writeFileSync(path.join(root,'index.html'),html);
let app=fs.readFileSync(path.join(root,'app.js'),'utf8').replace('recipe={...tribulationRecipes.original}','recipe={...finalRainRecipes["01"]}').replaceAll('tribulationRecipes[e.target.value]','finalRainRecipes[e.target.value]').replaceAll("tribulationRecipes[$('tribulationPreset').value]","finalRainRecipes[$('tribulationPreset').value]");
app=app.replace('time=recipe.progressionTicks+.8;','time=recipe.progressionTicks+(recipe.rainCount-1)*recipe.rainStagger+.8;');
app=app.replace("const extent=Math.min(20,Math.max(4,recipe.rainSpread*.5+recipe.impactRadius));","const extent=Math.max(4,recipe.rainSpread*.5+recipe.impactRadius);");
fs.writeFileSync(path.join(root,'app.js'),app);
console.log('8 complete validated skill rain recipes authored');
