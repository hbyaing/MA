"""Extract only the outer gold border from the supplied UI reference."""
from pathlib import Path
from PIL import Image
import shutil,json
root=Path(__file__).resolve().parents[1]
source=Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-b371b729-9c03-49d8-b6fb-ee41ceae2d33.png')
archive=root/'source-assets/outer-frame-20261011'
folder=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/outer_frame'
archive.mkdir(parents=True,exist_ok=True);folder.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,archive/'reference-original.png')
im=Image.open(source).convert('RGBA')
boxes={'tl':(36,36,72,72),'tr':(1518,36,1554,72),'bl':(36,919,72,955),'br':(1518,919,1554,955),
       'top':(100,36,300,49),'bottom':(100,942,300,955),'left':(36,150,49,350),'right':(1541,150,1554,350),
       'diamond':(782,35,804,56)}
sizes={}
for name,box in boxes.items():
    out=im.crop(box)
    for y in range(out.height):
        for x in range(out.width):
            r,g,b,a=out.getpixel((x,y))
            alpha=max(0,min(255,round(min(r-50,(r-b)*3)*2))) if r>g and g>b else 0
            out.putpixel((x,y),(r,g,b,alpha))
    out.save(folder/(name+'.png'))
    (folder/(name+'.png.mcmeta')).write_text('{"texture":{"blur":false,"clamp":true}}')
    sizes[name]=out.size
# Use one source corner and edge for each axis so opposite sides are exact mirrors.
corner=Image.open(folder/'tl.png')
corner.transpose(Image.Transpose.FLIP_LEFT_RIGHT).save(folder/'tr.png')
corner.transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(folder/'bl.png')
corner.transpose(Image.Transpose.FLIP_LEFT_RIGHT).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(folder/'br.png')
Image.open(folder/'left.png').transpose(Image.Transpose.FLIP_LEFT_RIGHT).save(folder/'right.png')
Image.open(folder/'top.png').transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(folder/'bottom.png')
(archive/'manifest.json').write_text(json.dumps(sizes,indent=2))
# Inspect the border on a flat background, with the interior untouched.
preview=Image.new('RGBA',(480,294),'#0d1a23')
for name,x,y,w,h in [('top',11,0,458,4),('bottom',11,290,458,4),('left',0,11,4,272),('right',476,11,4,272),
                      ('tl',0,0,11,11),('tr',469,0,11,11),('bl',0,283,11,11),('br',469,283,11,11),('diamond',237,0,7,7)]:
    preview.alpha_composite(Image.open(folder/(name+'.png')).resize((w,h),Image.Resampling.NEAREST),(x,y))
preview.resize((1440,882),Image.Resampling.NEAREST).save(archive/'preview.png')
print('Extracted 9 outer-frame elements')
