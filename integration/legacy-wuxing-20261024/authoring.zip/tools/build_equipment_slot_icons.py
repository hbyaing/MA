"""Reproducible 16px empty-slot silhouettes; transparent, matching vanilla slot icons."""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "src/main/resources/assets/wuxingxiantu/textures/item"
ICONS = {
    "empty_robe_slot": [
        "................", ".....##..##.....", "....#.####.#....", "...#..#..#..#...",
        "..#...#.#....#..", ".#....##.....#..", ".####.#.#.####..", "....#.#..#.#....",
        "....#.####.#....", "....#......#....", "...#........#...", "...#........#...",
        "..#..........#..", "..############..", "................", "................",
    ],
    "empty_sword_slot": [
        "................", "............###.", "...........#..#.", "..........#..#..",
        ".........#..#...", "........#..#....", ".......#..#.....", "......#..#......",
        "...#.#..#.......", "...##..#........", "....###.........", "...####.........",
        "..##...#........", ".##.............", ".##.............", "................",
    ],
}

for name, rows in ICONS.items():
    assert len(rows) == 16 and all(len(row) == 16 for row in rows)
    image = Image.new("RGBA", (16, 16))
    for y, row in enumerate(rows):
        for x, char in enumerate(row):
            if char == "#":
                image.putpixel((x, y), (172, 172, 159, 255))
    OUTPUT.mkdir(parents=True, exist_ok=True)
    image.save(OUTPUT / f"{name}.png")
print("Generated robe and sword empty-slot icons")
