"""Data-only alchemy pacing and gradual cultivation-pill furnace requirements."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
times={'aura_pill':30,'golden_wound_pill':40,'bigu_pill':45,'clear_heart_pill':50,
       'gathering_pill':60,'foundation_pill':90,'continue_vein_pill':75,'diamond_body_pill':85,
       'berserk_pill':55,'gale_pill':35,'profound_water_pill':65,'breakthrough_pill':120,
       'tribulation_pill':150,'calming_pill':100,'root_awakening_pill':180,'physique_reset_pill':210}
changed=[]
for path in sorted((root/'src/main/resources/data/wuxingxiantu/recipes').glob('*.json')):
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    if data.get('type')!='wuxingxiantu:alchemy':continue
    item=data['result']['item'].split(':')[-1]
    if item=='cultivation_pill':
        tier=data.get('cultivation_tier',0)
        seconds=40+15*tier
        data['furnace_tier']=min(5,tier)
    elif item in times:seconds=times[item]
    else:continue
    data['time']=seconds*20
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    changed.append((path.name,seconds,data['furnace_tier']))
report=root/'reports/ui-corner-alignment-20261011'
report.mkdir(parents=True,exist_ok=True)
(report/'alchemy-times.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'Updated {len(changed)} alchemy recipes; cultivation furnace tiers 0,1,2,3,4,5,5,5,5')
