"""Deterministic, hand-authored pixel silhouettes for young/growing spirit plants.

Run explicitly to regenerate assets; Pillow is an authoring dependency only.
Mature artwork is never rewritten. Pixels use opaque/transparent alpha for cutout.
"""
from pathlib import Path
import json
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
# id, growth habit, stem/leaf shadow, leaf light, immature bud/accent
PLANTS = [
    ('thunder_vein_grass','grass','#344772','#759bda','#bab8f0'),
    ('dark_water_weed','weed','#163c47','#327487','#7193a7'),
    ('red_sun_grass','grass','#703925','#bc7332','#e9bb51'),
    ('starlight_flower','flower','#294c55','#619184','#9eade5'),
    ('adamantine_vine','vine','#505e37','#a5ae62','#d6cf83'),
    ('glowing_blue_mushroom','mushroom','#244559','#4c9ec2','#94d6df'),
    ('spirit_sprout_grass','sprout','#2a623b','#79b55c','#d4e99c'),
    ('gale_grass','grass','#315b49','#69aa80','#b6daba'),
    ('spirit_ginseng','ginseng','#395a31','#80a456','#b99864'),
    ('dew_drop_flower','flower','#335f4a','#70ae83','#b5dfea'),
    ('dragon_scale_grass','scales','#344d36','#739859','#c4ad6c'),
    ('blood_spirit_flower','flower','#573b3e','#96716a','#be6775'),
    ('vein_mending_vine','vine','#36564a','#6aa98a','#bdd7a4'),
    ('clear_heart_lotus','lotus','#325f49','#78a67a','#d9b3c4'),
]

def draw_stage(habit, shadow, leaf, bud, growing):
    image = Image.new('RGBA',(16,16))
    d = ImageDraw.Draw(image)
    top = 4 if growing else 8
    def line(points,color=shadow,width=1): d.line(points,fill=color,width=width)
    def blade(x,y,side=1):
        d.polygon([(x,y),(x+side*4,y-3),(x+side*3,y),(x,y+1)],fill=shadow)
        line([(x,y),(x+side*3,y-2)],leaf)
    if habit == 'mushroom':
        d.rectangle((7,10 if growing else 12,9,15),fill=shadow)
        line([(8,10 if growing else 12),(8,14)],bud)
        d.polygon([(3,9),(5,6),(9,5),(12,7),(13,10),(3,10)] if growing
                  else [(5,12),(6,9),(9,8),(11,10),(11,12)],fill=shadow)
        d.polygon([(4,8),(6,6),(9,6),(11,8),(12,9),(4,9)] if growing
                  else [(6,10),(7,9),(9,9),(10,11),(6,11)],fill=leaf)
        d.point((7,7 if growing else 10),fill=bud)
        if growing:
            line([(3,15),(3,13)],shadow);d.rectangle((1,12,4,13),fill=leaf)
    elif habit == 'lotus':
        d.polygon([(2,13),(4,11),(10,11),(13,13),(10,15),(4,15)],fill=shadow)
        line([(3,13),(6,12),(10,12)],leaf)
        line([(8,13),(8,8 if growing else 11)],leaf)
        if growing:
            d.polygon([(6,8),(7,5),(8,4),(10,7),(9,10),(7,10)],fill=bud)
            line([(7,9),(7,7)],'#f0dce5')
        else:
            d.polygon([(7,12),(6,10),(8,9),(10,11),(9,12)],fill=leaf)
    elif habit in ('grass','weed','scales'):
        tips = [(3,6),(8,3),(12,5),(14,8)] if growing else [(5,9),(8,7),(11,9)]
        for i,(x,y) in enumerate(tips):
            d.polygon([(7+i%2,15),(x-1,y+2),(x,y),(x+1,y+4),(9,15)],fill=shadow)
            line([(8,14),(x,y+1)],leaf)
            if habit=='weed': blade(x,y+4,-1 if i%2 else 1)
            if habit=='scales':
                d.point((x,y+3),fill=bud)
                if growing: d.point((x+1,y+5),fill=bud)
        if growing and habit=='grass': line([(8,6),(8,4)],bud)
    elif habit == 'vine':
        points=[(7,15),(9,12),(6,9),(9,6),(8,3)] if growing else [(7,15),(9,12),(7,9)]
        line(points,shadow,2);line(points,leaf)
        blade(8,12,-1);blade(7,10,1)
        if growing:
            blade(8,7,-1);line([(8,3),(11,3),(11,5)],bud)
    else:
        line([(8,15),(8,top)],shadow,2);line([(8,14),(8,top)],leaf)
        blade(8,12,-1);blade(8,11,1)
        if growing:
            blade(8,8,-1);blade(8,7,1)
        if habit=='ginseng':
            d.rectangle((7,13,9,14),fill=bud)
            line([(7,14),(6,15)],bud);line([(9,14),(10,15)],bud)
        elif habit=='flower' and growing:
            # Closed calyx rather than a miniature mature blossom.
            d.polygon([(7,5),(6,3),(8,2),(10,3),(9,5)],fill=bud)
            line([(7,5),(9,5)],shadow)
        elif habit=='sprout':
            blade(8,top+1,-1)
            if growing: blade(8,top,1)
    return image

def main():
    preview=Image.new('RGB',(7*192,2*168),(37,43,43))
    labels=ImageDraw.Draw(preview)
    for index,(name,habit,shadow,leaf,bud) in enumerate(PLANTS):
        for stage,model_stage,growing in [('young','low',False),('growing','mid',True)]:
            image=draw_stage(habit,shadow,leaf,bud,growing)
            image.save(ASSETS/'textures/block'/f'{name}_{stage}.png')
            model_path=ASSETS/'models/block'/f'{name}_{model_stage}.json'
            model=json.loads(model_path.read_text(encoding='utf-8'))
            model['textures']['cross']=f'wuxingxiantu:block/{name}_{stage}'
            model_path.write_text(json.dumps(model,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            x=(index%7)*192+(64 if growing else 0);y=(index//7)*168
            enlarged=image.resize((64,64),Image.Resampling.NEAREST)
            preview.paste(enlarged,(x,y),enlarged)
        mature=json.loads((ASSETS/'models/block'/f'{name}.json').read_text(encoding='utf-8'))
        texture=next(v for v in mature['textures'].values() if v.startswith('wuxingxiantu:'))
        art=Image.open(ASSETS/'textures'/(texture.split(':')[1]+'.png')).convert('RGBA').resize((64,64),Image.Resampling.NEAREST)
        preview.paste(art,(index%7*192+128,index//7*168),art)
        labels.text((index%7*192,index//7*168+68),name.replace('_','\n'),fill='white')
    out=ROOT/'build/audit';out.mkdir(parents=True,exist_ok=True)
    preview.save(out/'plant-stages.png')
    print('Wrote 28 stage textures and updated 28 model references.')

if __name__=='__main__': main()
