from pathlib import Path
from PIL import Image
import json
root=Path(__file__).resolve().parents[1]
source=Image.open(root/'source-assets/cultivation-vision-reference-v2/reference-original.png').convert('RGBA')
out=root/'source-assets/reference-borders';out.mkdir(exist_ok=True)
runtime=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/reference/borders';runtime.mkdir(parents=True,exist_ok=True)
sizes={}
def save(name,box,ink=False):
    img=source.crop(box);img.save(out/(name+'-raw.png'))
    for y in range(img.height):
        for x in range(img.width):
            r,g,b,a=img.getpixel((x,y))
            if ink:
                alpha=max(0,min(255,round((165-(r+g+b)/3)*4)))
                img.putpixel((x,y),(66,57,44,alpha))
            else:
                alpha=max(0,min(255,round(min(r-65,(r-b)*3)*2))) if r>g and g>b else 0
                img.putpixel((x,y),(r,g,b,alpha))
    img.save(runtime/(name+'.png'));img.save(out/(name+'.png'));sizes[name]=img.size
    (runtime/(name+'.png.mcmeta')).write_text('{"texture":{"blur":true,"clamp":true}}')
save('rule_gold',(36,134,249,146))
save('rule_ink',(479,133,657,145),True)
for kind,(l,t,r,b),ink in [('gold',(1191,95,1652,919),False),('ink',(303,166,746,634),True)]:
    e=16
    boxes={'tl':(l,t,l+e,t+e),'tr':(r-e,t,r,t+e),'bl':(l,b-e,l+e,b),'br':(r-e,b-e,r,b),
           'top':(l+e,t,r-e,t+3),'bottom':(l+e,b-3,r-e,b),'left':(l,t+e,l+3,b-e),'right':(r-3,t+e,r,b-e)}
    for part,box in boxes.items():save(kind+'_'+part,box,ink)
(out/'manifest.json').write_text(json.dumps(sizes,indent=2))
lines=['package cn.blockforge.generated.generatedmod.client;','final class CultivationBorderAssets {','private record Size(int w,int h) {}','private static final java.util.Map<String,Size> SIZES=java.util.Map.ofEntries(']
lines.append(',\n'.join(f'java.util.Map.entry("{n}",new Size({w},{h}))' for n,(w,h) in sizes.items())+');')
lines+=['static void draw(net.minecraft.client.gui.GuiGraphics g,String name,int x,int y,int w,int h){if(w<=0||h<=0)return;var s=SIZES.get(name);com.mojang.blaze3d.systems.RenderSystem.enableBlend();com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();g.blit(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("wuxingxiantu","textures/gui/wuxia/reference/borders/"+name+".png"),x,y,w,h,0,0,s.w(),s.h(),s.w(),s.h());com.mojang.blaze3d.systems.RenderSystem.disableBlend();}',
'static void frame(net.minecraft.client.gui.GuiGraphics g,String k,int x,int y,int w,int h){int e=5;draw(g,k+"_tl",x,y,e,e);draw(g,k+"_tr",x+w-e,y,e,e);draw(g,k+"_bl",x,y+h-e,e,e);draw(g,k+"_br",x+w-e,y+h-e,e,e);draw(g,k+"_top",x+e,y,w-2*e,1);draw(g,k+"_bottom",x+e,y+h-1,w-2*e,1);draw(g,k+"_left",x,y+e,1,h-2*e);draw(g,k+"_right",x+w-1,y+e,1,h-2*e);}','}']
(root/'src/main/java/cn/blockforge/generated/generatedmod/client/CultivationBorderAssets.java').write_text('\n'.join(lines),encoding='utf-8')
print('Prepared',len(sizes),'original-resolution border crops')
