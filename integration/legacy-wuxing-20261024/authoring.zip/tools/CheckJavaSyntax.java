import com.sun.source.util.JavacTask;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaFileObject;
import javax.tools.ToolProvider;

/** Parse selected files only. No symbol analysis, annotation processors, class generation or Gradle. */
public final class CheckJavaSyntax {
    public static void main(String[] paths) throws Exception {
        if(paths.length==0)throw new IllegalArgumentException("Pass the changed Java source paths.");
        var compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("A JDK is required.");
        var diagnostics=new DiagnosticCollector<JavaFileObject>();
        try(var files=compiler.getStandardFileManager(diagnostics,null,StandardCharsets.UTF_8)) {
            var units=files.getJavaFileObjectsFromStrings(Arrays.asList(paths));
            var task=(JavacTask)compiler.getTask(null,files,diagnostics,
                    List.of("-proc:none","--release","17"),null,units);
            task.parse();
        }
        long errors=diagnostics.getDiagnostics().stream().filter(d->d.getKind()==Diagnostic.Kind.ERROR).count();
        for(var diagnostic:diagnostics.getDiagnostics())System.out.println(diagnostic);
        System.out.println("Java syntax only: "+paths.length+" files, "+errors+" errors. Types/runtime NOT checked.");
        if(errors>0)System.exit(1);
    }
}
