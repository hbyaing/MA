from pathlib import Path
p=Path('E:/五行仙途/tools/firecoil-workbench')
s=(p/'serve.py').read_text('utf-8')
s=s.replace("profiles\\ASTRA-TEST", "profiles\\测试 (1)").replace("ROOT.parent/'vfx-palettes/nine-flames.json'","ROOT/'nine-flames.json'")
start=s.index(' def game_status(self):');end=s.index(' def do_GET',start)
s=s[:start]+''' def game_status(self):
  jars=list((GAME/'mods').glob('wuxingxiantu-*.jar')) if GAME.is_dir() else []
  return {'hasRuntime':bool(jars),'compatibleRuntime':any('firecoil' in j.name for j in jars),'instance':'测试 (1)','gameDir':str(GAME)}
'''+s[end:]
start=s.index("    if not self.game_status()['compatibleRuntime']");end=s.index("   self.send_json(404",start)
s=s[:start]+'''    if value['action']!='reload':raise ValueError('宿主工作台只支持保存配置。')
    recipe=validate(value.get('recipe'));path=GAME/'config/wuxingxiantu/firecoil.json'
    if path.exists():write_json(path.with_name('firecoil.previous.json'),loads(path.read_text(encoding='utf-8-sig')))
    write_json(path,recipe)
    self.send_json(200,{'ok':True,'configSaved':True,'message':'已写入测试 (1) 的配置，游戏内按 F3+T 重载生效。颜色仍由实际异火决定。'});return
'''+s[end:]
(p/'serve.py').write_text(s,'utf-8')
s=(p/'editor.js').read_text('utf-8').replace('ASTRA-TEST','测试 (1)').replace('运行库至 0.2.0','宿主 Mod 至异火缠绕版')
s=s.replace("function confirmedGameMessage(","function originalConfirmedGameMessage(")
s="function confirmedGameMessage(result,recipe){return result.message||'已保存游戏配置；按 F3+T 重载生效。';}\n"+s
(p/'editor.js').write_text(s,'utf-8')
s=(p/'index.html').read_text('utf-8').replace('ASTRA-TEST','测试 (1)').replace('应用到 测试 (1)','保存到 测试 (1)').replace('应用到测试 (1)','保存到测试 (1)')
s=s.replace('</header>','<p>宿主审查版：三维密度内核与游戏一致；人物和武器为观察代理。游戏依据实际异火覆盖三层颜色。游戏版体积使用半分辨率与深度合成，网页当前为原生积分画质参考。</p></header>',1)
(p/'index.html').write_text(s,'utf-8')
(p/'启动工作台.py').write_text("from serve import main\nif __name__=='__main__':main()\n",'utf-8')
