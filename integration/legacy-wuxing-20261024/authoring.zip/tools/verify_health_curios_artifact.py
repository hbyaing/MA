from pathlib import Path
import zipfile, hashlib, json, shutil
ROOT=Path(__file__).resolve().parents[1]
report=ROOT/'reports/ui-health-curios-20261007'
assert (report/'build.exit').read_text().strip()=='0'
assert 'BUILD SUCCESSFUL' in (report/'build.log').read_text(encoding='utf-16')
jar=ROOT/'build/libs/wuxingxiantu-0.2.jar'
with zipfile.ZipFile(jar) as current, zipfile.ZipFile(ROOT/'deliverables/wuxingxiantu-0.2-20261007-ui-root-click-creation.jar') as old:
    images=0
    for name in old.namelist():
        if name.endswith('.class') and '/client/' not in name:
            assert current.read(name)==old.read(name),name
        if name.startswith('assets/wuxingxiantu/textures/gui/wuxia/') and name.endswith('.png'):
            assert current.read(name)==old.read(name),name
            images+=1
    manifest=json.loads((ROOT/'source-assets/vision-ui-components-v3/manifest.json').read_text())
    for name in manifest:
        path='assets/wuxingxiantu/textures/gui/wuxia/vision/components/'+name+'.png'
        assert current.read(path)==(ROOT/'src/main/resources'/path).read_bytes(),name
target=ROOT/'deliverables/wuxingxiantu-0.2-20261007-ui-health-curios.jar'
shutil.copy2(jar,target)
digest=hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.jar.sha256').write_text(digest+'  '+target.name+'\n',encoding='ascii')
result={'artifact':str(target),'sha256':digest,'unchanged_ui_images':images,'new_components':len(manifest),'nonclient_bytecode_unchanged':True,'client_runtime_verified':False}
(report/'artifact-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
