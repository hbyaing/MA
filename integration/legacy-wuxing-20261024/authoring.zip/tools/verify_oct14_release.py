"""Check installed artifact, current resources, and real server/client evidence."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json, sys
root = Path(__file__).resolve().parents[1]
source, installed = map(Path, sys.argv[1:3])
digest = lambda p: sha256(p.read_bytes()).hexdigest().upper()
assert digest(source) == digest(installed)
with ZipFile(installed) as jar:
    names = jar.namelist()
    for name in ('AnvilTemplateMemory', 'plants/DragonGrassCycle', 'balance/ManaLossLedger',
                 'network/packet/cultivation/ManaLossPacket', 'client/MeditationRateHud',
                 'client/furnacevolume/FurnaceFireVolume', 'client/furnacevolume/VolumeGpu'):
        assert 'cn/blockforge/generated/generatedmod/' + name + '.class' in names, name
    assert not any(n.endswith('.class') and any(t in n for t in
        ('GameTests', 'ClientCapture', 'DomainUiCapture', 'Regression')) for n in names)
    resources = root / 'src/main/resources'
    checked = 0
    for file in resources.rglob('*'):
        if file.is_file():
            rel = file.relative_to(resources).as_posix()
            expected = root/'build/resources/main'/rel if rel=='META-INF/mods.toml' else file
            assert jar.read(rel) == expected.read_bytes(), rel
            checked += 1
    assert 'data/wuxingxiantu/forge/biome_modifier/add_dragon_scale_grass.json' not in names
    network = jar.read('cn/blockforge/generated/generatedmod/network/NetworkChannel.class')
    assert b'\x00\x0277' in network, 'Protocol must be 77'
captures = {}
for folder, count in {'guard-solas-20261014':39, 'cloud-black-fix-20261014':5,
    'cloud-solas-20261014':5, 'furnace-bottom-20261014':11,
    'furnace-solas-20261014':11, 'anvil-blue-ui-client':6,
    'ui-details-20261014':4}.items():
    report = json.loads((root/'reports'/folder/'captures.json').read_text(encoding='utf-8-sig'))
    assert not report['failures'], (folder, report['failures'])
    assert len(report['captures']) == count, folder
    for row in report['captures']:
        assert row.get('glError',0) == 0, (folder, row)
    captures[folder] = count
for filename, count in [('task-20261014-anvil-tests.log',8), ('task-20261014-domain-tests.log',9)]:
    log = (root/'reports'/filename).read_text(errors='replace')
    assert f'All {count} required tests passed' in log, filename
assert 'BUILD SUCCESSFUL' in (root/'reports/task-20261014-build.log').read_text(errors='replace')
result = dict(source=str(source), installed=str(installed), sha256=digest(source),
              resourcesVerified=checked, protocol=77, serverTests=17, captures=captures)
(root/'reports/20261014-installed-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
