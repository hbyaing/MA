param([Parameter(Mandatory=$true)][string]$JarPath)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$modsDirectory='D:\MC\库\red.ghs.axolotl\profiles\测试 (1)\mods'
$resolvedMods=(Resolve-Path -LiteralPath $modsDirectory).Path
$source=(Resolve-Path -LiteralPath $JarPath).Path
function Test-OurMod([string]$path) {
    $zip=[System.IO.Compression.ZipFile]::OpenRead($path)
    try {
        $entry=$zip.GetEntry('META-INF/mods.toml')
        if ($null -eq $entry) { return $false }
        $reader=[System.IO.StreamReader]::new($entry.Open())
        try {
            $metadata=$reader.ReadToEnd()
            $modSections=[regex]::Matches($metadata,'(?ms)^\s*\[\[mods\]\]\s*$(.*?)(?=^\s*\[|\z)')
            foreach ($section in $modSections) {
                if ($section.Groups[1].Value -match '(?m)^\s*modId\s*=\s*"wuxingxiantu"') { return $true }
            }
            return $false
        } finally { $reader.Dispose() }
    } finally { $zip.Dispose() }
}
if (!(Test-OurMod $source)) { throw 'Source is not wuxingxiantu mod' }
$target=Join-Path $resolvedMods ([System.IO.Path]::GetFileName($source))
$old=@(Get-ChildItem -LiteralPath $resolvedMods -File -Filter '*.jar' | Where-Object { $_.FullName -ne $target -and (Test-OurMod $_.FullName) })
foreach ($file in $old) {
    if ([System.IO.Path]::GetDirectoryName($file.FullName) -ne $resolvedMods) { throw 'Old file outside expected mods folder' }
}
$backup=Join-Path (Split-Path $PSScriptRoot -Parent) ('deliverables/installed-mod-backups/'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Force -Path $backup | Out-Null
foreach ($file in $old) { Copy-Item -LiteralPath $file.FullName -Destination $backup }
Copy-Item -LiteralPath $source -Destination $target -Force
try {
    foreach ($file in $old) { Remove-Item -LiteralPath $file.FullName -Force }
} catch {
    Remove-Item -LiteralPath $target -Force
    foreach ($file in $old) { if (!(Test-Path -LiteralPath $file.FullName)) { Copy-Item -LiteralPath (Join-Path $backup $file.Name) -Destination $file.FullName } }
    throw
}
if ((Get-FileHash -LiteralPath $source).Hash -ne (Get-FileHash -LiteralPath $target).Hash) { throw 'Installed JAR hash mismatch' }
[pscustomobject]@{Installed=$target;RemovedOldVersions=@($old | ForEach-Object { $_.Name });SHA256=(Get-FileHash -LiteralPath $target).Hash} | ConvertTo-Json
