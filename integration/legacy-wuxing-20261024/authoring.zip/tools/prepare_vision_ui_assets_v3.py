"""Reference crops, clean masks and blank mutation badges; no resampling of source crops."""
from pathlib import Path
from PIL import Image
import colorsys,json
ROOT=Path(__file__).resolve().parents[1]
source=Image.open(ROOT/'source-assets/cultivation-vision-reference-v2/reference-original.png').convert('RGBA')
out=ROOT/'source-assets/vision-ui-components-v3';out.mkdir(parents=True,exist_ok=True)
runtime=ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision/components';runtime.mkdir(parents=True,exist_ok=True)
entries={}
def save(name,img):
    img.save(out/(name+'.png'));img.save(runtime/(name+'.png'))
    (runtime/(name+'.png.mcmeta')).write_text('{"texture":{"blur":true,"clamp":true}}',encoding='utf-8')
    entries[name]=img.size
boxes={'realm':(315,177,375,232),'cultivation':(313,243,377,309),'mana':(311,321,377,387),
       'health':(313,397,377,461),'attack':(315,483,374,534),'armor':(551,482,603,537),
       'heart_method':(315,545,375,609),'dao':(776,177,827,233),'meridian':(775,240,827,299),
       'physique':(771,303,829,359),'purity':(775,366,828,421)}
for name,box in boxes.items():
    raw=source.crop(box);raw.save(out/('raw_'+name+'.png'))
    ink=raw.copy();gold=raw.copy()
    for y in range(raw.height):
        for x in range(raw.width):
            r,g,b,a=raw.getpixel((x,y));lum=(r+g+b)/3
            alpha=round(max(0,min(255,(145-lum)*3)))
            ink.putpixel((x,y),(30,31,28,alpha));gold.putpixel((x,y),(232,200,139,alpha))
    save(name,ink);save(name+'_gold',gold)
for name,box in {'cultivation':(390,284,727,308),'mana':(390,359,727,384),'health':(390,448,727,473)}.items():
    image=source.crop(box);image.save(out/('raw_bar_'+name+'.png'))
    # Keep a capsule mask: paper around the bar must not cover the game UI.
    for y in range(image.height):
        for x in range(image.width):
            edge=min(x,image.width-1-x);dy=abs(y-(image.height-1)/2)
            if edge<10 and dy>edge+2 or y<2 or y>=image.height-2:
                r,g,b,a=image.getpixel((x,y));image.putpixel((x,y),(r,g,b,0))
    save('bar_'+name,image)
    track=image.copy()
    for y in range(5,image.height-5):
        for x in range(10,image.width-10):
            r,g,b,a=track.getpixel((x,y));track.putpixel((x,y),(37,42,43,a))
    save('bar_'+name+'_track',track)
for name,base,hue in [('thunder','wood',.73),('exotic','fire',.52)]:
    img=Image.open(ROOT/f'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision/roots/{base}.png').convert('RGBA')
    # Interpolate the original dark interior across the central letter, preserving the silhouette.
    cx=img.width//2
    for y in range(23,55):
        # Sample only the dark interior; gold strokes must not smear across the badge.
        samples=[img.getpixel((x,y)) for x in range(cx-21,cx+22) if max(img.getpixel((x,y))[:3])<65]
        dark=tuple(sorted(p[k] for p in samples)[len(samples)//2] for k in range(3)) if samples else (8,25,23)
        left=right=dark
        for x in range(cx-20,cx+21):
            t=(x-(cx-21))/42
            img.putpixel((x,y),tuple(round(left[k]*(1-t)+right[k]*t) for k in range(3))+(255,))
    for y in range(img.height):
        for x in range(img.width):
            r,g,b,a=img.getpixel((x,y))
            if a:
                h,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255)
                rgb=colorsys.hsv_to_rgb(hue,max(.45,s),v)
                img.putpixel((x,y),tuple(round(c*255) for c in rgb)+(a,))
    save('root_'+name,img)
(out/'manifest.json').write_text(json.dumps(entries,indent=2),encoding='utf-8')
java=ROOT/'src/main/java/cn/blockforge/generated/generatedmod/client/CultivationVisionAssets.java'
lines=['package cn.blockforge.generated.generatedmod.client;','final class CultivationVisionAssets {',
'private record Size(int w,int h) {}','private static final java.util.Map<String,Size> SIZES=java.util.Map.ofEntries(']
lines.append(',\n'.join(f'java.util.Map.entry("{name}",new Size({w},{h}))' for name,(w,h) in entries.items())+');')
lines.extend(['static void draw(net.minecraft.client.gui.GuiGraphics g,String name,int x,int y,int w,int h){',
'var s=SIZES.get(name); com.mojang.blaze3d.systems.RenderSystem.enableBlend(); com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();',
'g.blit(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("wuxingxiantu","textures/gui/wuxia/vision/components/"+name+".png"),x,y,w,h,0,0,s.w(),s.h(),s.w(),s.h());',
'com.mojang.blaze3d.systems.RenderSystem.disableBlend();','}','}'])
java.write_text('\n'.join(lines),encoding='utf-8')
print(f'Prepared {len(entries)} reusable assets, with raw reference crops.')
