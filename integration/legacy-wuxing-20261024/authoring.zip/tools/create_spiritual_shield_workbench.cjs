const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..'),out=path.join(root,'deliverables/spiritual-shield-workbench-20261011');
const base='E:/着色器渲染/skill/minecraft-stylised-shield/assets/forge-1.20.1/workbench';
fs.mkdirSync(out,{recursive:true});
for(const n of ['index.html','workbench.js','shader-source.js','serve.cjs'])fs.copyFileSync(path.join(base,n),path.join(out,n));
let js=fs.readFileSync(path.join(out,'workbench.js'),'utf8');
const defaults=Function('return '+js.match(/const defaults=(\{.*?\});/)[1])();
const shield={...defaults,depth:1,color:'#37bde8',edgeColor:'#d4f8ff',opacity:.63,centerOpacity:.07,hexOpacity:.22,hexScale:3.8,lineWidth:.025,fresnelStrength:1.8,fresnelPower:3.1,flowIntensity:.7,flowSpeed:.34,distortion:.012,pulseAmplitude:.008,hitWidth:.09,hitDuration:1.25,hitIntensity:2.8,sparkCount:30,sparkColor:'#a9ecff',damage:.04};
const body={...defaults,shape:'body',segments:16,color:'#329be8',edgeColor:'#b7edff',opacity:.6,centerOpacity:.035,fresnelStrength:1.8,fresnelPower:2.5,pattern:'none',showHex:false,showFlow:false,showScan:false,showDissolve:false,distortion:0,pulseAmplitude:0,hitWidth:.07,hitDuration:.65,hitIntensity:2.2,hitRadius:1,hitSpeed:1.8,sparkCount:0,damage:0};
for(const [name,data] of [['spirit-shield',shield],['spirit-body-guard',body]])fs.writeFileSync(path.join(out,name+'.json'),JSON.stringify(data,null,2));
js=js.replace('let p={...defaults};','const customPresets='+JSON.stringify({shield,body})+';let p={...customPresets[new URLSearchParams(location.search).get("plan")==="body"?"body":"shield"]};');
js=js.replace("sphere:'完整球形'","body:'贴身分部御体',sphere:'完整球形'");
js=js.replace('const presets={flow:','const presets={...customPresets,flow:');
js=js.replace("{sphere:'球形',dome:","{body:'贴身御体',sphere:'球形',dome:").replace('{sphere:0,dome:1','{body:4,sphere:0,dome:1');
const geometry=`const parts=[[0,1.3,0,.41,.41,.41],[0,.25,0,.52,.7,.3],[-.78,.25,0,.26,.7,.29],[.78,.25,0,.26,.7,.29],[-.25,-1.04,0,.26,.66,.29],[.25,-1.04,0,.26,.66,.29]];
function bodyPoint(part,u,v){const [x,y,z,rx,ry,rz]=parts[part],ph=v*Math.PI,th=u*2*Math.PI,n=[Math.sin(ph)*Math.cos(th),Math.cos(ph),Math.sin(ph)*Math.sin(th)];const q=n.map(v=>Math.sign(v)*Math.pow(Math.abs(v),.22)),gn=n.map(v=>Math.sign(v)*Math.pow(Math.abs(v),1.78));return [[x+q[0]*rx,y+q[1]*ry,z+q[2]*rz],normalize([gn[0]/rx,gn[1]/ry,gn[2]/rz])];}
`;
js=js.replace('function geometry(u,v){',geometry+'function geometry(u,v){if(p.shape==="body")return bodyPoint(Math.min(5,Math.floor(u*6)),(u*6)%1,v);');
const old=js.match(/function buildMesh\(\)\{[^\n]+/)[0];
let mesh=old.replace('const cols=p.segments,rows=Math.round(cols*.55);','const cols=p.segments,rows=Math.round(cols*.55);for(let part=0;part<(p.shape==="body"?6:1);part++){const offset=positions.length/3;').replace('geometry(i/cols,j/rows)','p.shape==="body"?bodyPoint(part,i/cols,j/rows):geometry(i/cols,j/rows)').replace('const a=j*(cols+1)+i','const a=offset+j*(cols+1)+i').replace('for(const key of [\'position\'','}for(const key of [\'position\'');
js=js.replace(old,mesh).replaceAll('p.shape==="sphere"||p.shape==="dome"','p.shape==="body"||p.shape==="sphere"||p.shape==="dome"');
const avatar=`
let avatarProgram,avatarBuffer,avatarCount;
function drawAvatar(){if(!avatarProgram){function compile(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
avatarProgram=gl.createProgram();gl.attachShader(avatarProgram,compile(gl.VERTEX_SHADER,'attribute vec3 aPos,aColor;uniform mat4 uMVP;varying vec3 c;void main(){c=aColor;gl_Position=uMVP*vec4(aPos,1.);}'));gl.attachShader(avatarProgram,compile(gl.FRAGMENT_SHADER,'precision mediump float;varying vec3 c;void main(){gl_FragColor=vec4(c,1.);}'));gl.linkProgram(avatarProgram);if(!gl.getProgramParameter(avatarProgram,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(avatarProgram));
const data=[],boxes=[[0,1.3,0,.37,.37,.37,[.68,.61,.53]],[0,.25,0,.48,.66,.26,[.21,.31,.37]],[-.78,.25,0,.22,.66,.25,[.28,.39,.43]],[.78,.25,0,.22,.66,.25,[.28,.39,.43]],[-.25,-1.04,0,.22,.62,.25,[.17,.22,.27]],[.25,-1.04,0,.22,.62,.25,[.17,.22,.27]]];
for(const [x,y,z,rx,ry,rz,col] of boxes){const q=[[-rx,-ry,-rz],[rx,-ry,-rz],[rx,ry,-rz],[-rx,ry,-rz],[-rx,-ry,rz],[rx,-ry,rz],[rx,ry,rz],[-rx,ry,rz]];[[4,5,6,7],[1,0,3,2],[0,4,7,3],[5,1,2,6],[3,7,6,2],[0,1,5,4]].forEach((face,f)=>{for(const i of [face[0],face[1],face[2],face[0],face[2],face[3]])data.push(q[i][0]+x,q[i][1]+y,q[i][2]+z,...col.map(c=>c*(.7+f*.055)));});}
avatarCount=data.length/6;avatarBuffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,avatarBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);}
gl.useProgram(avatarProgram);gl.disable(gl.BLEND);gl.disable(gl.CULL_FACE);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.depthFunc(gl.LEQUAL);gl.uniformMatrix4fv(gl.getUniformLocation(avatarProgram,'uMVP'),false,mvp);gl.bindBuffer(gl.ARRAY_BUFFER,avatarBuffer);for(const [name,offset] of [['aPos',0],['aColor',12]]){const a=gl.getAttribLocation(avatarProgram,name);gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,3,gl.FLOAT,false,24,offset);}gl.drawArrays(gl.TRIANGLES,0,avatarCount);}
`;
js=js.replace('function render(ms){',avatar+'function render(ms){').replace('gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(program);','gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);drawAvatar();gl.useProgram(program);');
js=js.replace('buildMesh();requestAnimationFrame(render);','$("preset").value=p.shape==="body"?"body":"shield";buildMesh();requestAnimationFrame(render);');
js=js.replaceAll('const f=1/Math.tan(Math.PI/8)','const f=Math.min(1,canvas.width/canvas.height/(p.shape==="body"?.55:.9))/Math.tan(Math.PI/8)');
fs.writeFileSync(path.join(out,'workbench.js'),js);
let html=fs.readFileSync(path.join(out,'index.html'),'utf8').replace('<title>能量护盾 · 三维材质工作台</title>','<title>灵力护盾 / 灵力御体 · 工作台</title>').replace('能量护盾材质工作台','灵力防御方案工作台').replace('<option value="flow">','<option value="shield">灵力护盾 · 青蓝护罩</option><option value="body">灵力御体 · 蓝色被动御体</option><option value="flow">').replace('<div id="controls">','<p>护盾：青蓝外罩，能量流与受击波。<br>御体：附魔被动，静态薄壳，受击短促闪亮；默认无火星、扫描与噪声流。<br>仅可视化方案，未实装。</p><div id="controls">');
fs.writeFileSync(path.join(out,'index.html'),html);
let shader=fs.readFileSync(path.join(out,'shader-source.js'),'utf8').replace('if(uShape>=2)border=','if(uShape==2||uShape==3)border=');fs.writeFileSync(path.join(out,'shader-source.js'),shader);
fs.writeFileSync(path.join(out,'README.md'),'使用 minecraft-stylised-shield 技能的共享 GLSL。灵力御体新增 body 分部壳几何，是工作台专用扩展，不能直接导入原技能 Forge demo。\n御体默认16段、6个部位、1728三角面，无持续火星/形变/图案/流噪声。生产接入建议合并单次提交，按实际 ModelPart 挂点，远距关闭、不可见剔除，受击窗口结束清除状态。浏览器预览仍使用完整技能 shader，参数关闭不等于生产精简 shader 的 GPU 开销。未修改 mod、未构建。\n');
console.log(out);
