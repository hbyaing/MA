"""Replace only the first blood spirit flower stage from the supplied artwork."""
from pathlib import Path
import json
import shutil
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
OUT = ROOT / 'source-assets/blood-spirit-flower-young-20261008'
OUT.mkdir(parents=True, exist_ok=True)
source = Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-9ecda8a9-e472-4386-9a25-9af6c052cade.png')
shutil.copy2(source, OUT / 'reference-original.png')
original = Image.open(source).convert('RGBA')
bounds = original.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
crop = original.crop(bounds)
crop.save(OUT / 'young-crop.png')
assert max(crop.size) <= 1024, 'Preserve original pixels without resampling'
tile = Image.new('RGBA', (1024, 1024))
x, y = (1024 - crop.width) // 2, 1024 - crop.height
tile.alpha_composite(crop, (x, y))
tile.save(ASSETS / 'textures/block/blood_spirit_flower_young.png')
path = ASSETS / 'models/block/blood_spirit_flower_low.json'
model = json.loads(path.read_text(encoding='utf-8'))
height = 11
width = height * crop.width / crop.height
for element in model['elements']:
    element['from'] = [8 - width / 2, 0, 8]
    element['to'] = [8 + width / 2, height, 8]
    for name, face in element['faces'].items():
        face['uv'] = [x / 64, y / 64, (x + crop.width) / 64, 16] if name == 'north' else [(x + crop.width) / 64, y / 64, x / 64, 16]
path.write_text(json.dumps(model, indent=2) + '\n', encoding='utf-8')
preview = Image.new('RGBA', (400, 400), (45, 49, 45, 255))
art = crop.copy()
art.thumbnail((380, 380), Image.Resampling.NEAREST)
preview.alpha_composite(art, ((400 - art.width) // 2, 390 - art.height))
preview.save(OUT / 'preview.png')
(OUT / 'manifest.json').write_text(json.dumps({'source_bounds': bounds, 'crop_size': crop.size, 'model_height': height, 'model_width': width}, indent=2) + '\n')
print('Imported first stage:', bounds, crop.size)
