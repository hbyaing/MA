from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'src/main/java/cn/blockforge/generated/generatedmod/client/furnacevolume/VolumeGpu.java'
s=p.read_text(encoding='utf-8-sig')
s=s.replace('bedProgram','noiseProgram').replace('bedCaching()','noiseCaching()')
s=s.replace('"\\n#define WUXING_BED_CACHE 1"','"\\n#define WUXING_NOISE_CACHE 1"')
s=s.replace('var bed=corners==null?null:FireBedNoiseCache.prepare(recipe,(float)time);','var bed=recipe.bottomOnly()?FireCornerCache.prepareNoise():null;')
s=s.replace('GL20.glUniform1i(loc("BedHashLow"),3);GL20.glUniform1i(loc("BedHashHigh"),4);','GL20.glUniform1i(loc("NoiseHashLow"),3);GL20.glUniform1i(loc("NoiseHashHigh"),4);')
s=s.replace('            if(bed!=null){GL20.glUniform2iv(loc("BedOriginXY[0]"),bed.origins);GL20.glUniform1iv(loc("BedZFloors[0]"),bed.zFloors);}\n','')
s=s.replace('FireBedNoiseCache.release();','')
s=s.replace('GL30.GL_TEXTURE_BINDING_2D_ARRAY','GL12.GL_TEXTURE_BINDING_3D').replace('GL30.GL_TEXTURE_2D_ARRAY','GL12.GL_TEXTURE_3D')
p.write_text(s,encoding='utf-8')
p=ROOT/'src/cloudglyphclienttest/java/cn/blockforge/generated/generatedmod/client/furnacevolume/VolumePerformanceProbe.java'
s=p.read_text(encoding='utf-8-sig').replace('row.put("bedCacheEnabled",VolumeGpu.bedCaching());','row.put("noiseCacheEnabled",VolumeGpu.noiseCaching());')
s=s.replace('            row.put("bedCacheBuildGpuMs",FireBedNoiseCache.buildGpuMs);\n','').replace('            row.put("bedCacheBuildCpuMs",FireBedNoiseCache.buildCpuMs);\n','')
p.write_text(s,encoding='utf-8')
# Thermal FBM uses the shared full-precision lattice, so the old per-recipe bed cache is retired.
p=ROOT/'src/main/java/cn/blockforge/generated/generatedmod/client/furnacevolume/FireCornerCache.java'
s=p.read_text(encoding='utf-8-sig').replace('FireBedNoiseCache.release();','');p.write_text(s,encoding='utf-8')
glsl=ROOT/'src/main/resources/assets/wuxingxiantu/shaders/furnacevolume/bed_noise.glsl'
glsl.write_text('float avBedFbm(vec3 p,int family){return avFbm(p);}\n',encoding='utf-8')
