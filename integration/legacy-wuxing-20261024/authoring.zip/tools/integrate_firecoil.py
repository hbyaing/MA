from pathlib import Path
import json, shutil
root=Path('E:/五行仙途'); lab=Path('E:/着色器渲染/fire-coil-lab')
pkg='cn.blockforge.generated.generatedmod.client.firecoil'
dst=root/'src/main/java'/pkg.replace('.','/'); dst.mkdir(parents=True,exist_ok=True)
res=root/'src/main/resources/assets/wuxingxiantu/firecoil'; res.mkdir(parents=True,exist_ok=True)
for name in ['Recipe','FireCore','Geometry','VolumeGpu','FireRender']:
 s=(lab/f'forge/src/main/java/dev/firecoil/{name}.java').read_text('utf-8').replace('dev.firecoil',pkg).replace('FireCoil.ID','"wuxingxiantu"')
 s=s.replace('/assets/firecoil/shaders/','/assets/wuxingxiantu/firecoil/shaders/').replace('Client.core.time()','Client.time()').replace('Client.core.ramp()','1')
 if name=='FireRender':s=s.replace('"fire"),DefaultVertexFormat','"firecoil_fire"),DefaultVertexFormat')
 (dst/f'{name}.java').write_text(s,'utf-8')
shutil.copytree(lab/'forge/src/main/resources/assets/firecoil/shaders',res/'shaders',dirs_exist_ok=True)
core=root/'src/main/resources/assets/wuxingxiantu/shaders/core'
for ext in ['json','vsh','fsh']:
 s=(res/f'shaders/core/fire.{ext}').read_text('utf-8').replace('firecoil:fire','wuxingxiantu:firecoil_fire')
 (core/f'firecoil_fire.{ext}').write_text(s,'utf-8')
r=json.loads((lab/'current-recipe.json').read_text('utf-8-sig'));r['attachment']=2
(res/'recipe.json').write_text(json.dumps(r,indent=2),'utf-8')
shutil.copy(lab/'nine-flames.json',res/'nine-flames.json')
# Review workbench: copy only required source, never the standalone mod or its saved worlds.
web=root/'tools/firecoil-workbench';web.mkdir(exist_ok=True)
for name in ['index.html','editor.js','preview.js','geometry.js','schema.js','shaders.js','palettes.mjs','nine-flames.json','recipe.py','serve.py','current-recipe.json','fire.volume.core.glsl','fire.frag.core.glsl']:
 shutil.copy(lab/name,web/name)
(web/'current-recipe.json').write_text(json.dumps(r,indent=2),'utf-8')
