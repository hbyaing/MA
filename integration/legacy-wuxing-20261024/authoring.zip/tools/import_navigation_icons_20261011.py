from pathlib import Path
import shutil
from PIL import Image

root = Path(__file__).resolve().parents[1]
out = root / 'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/reference/icons/navigation'
backup = root / 'deliverables/navigation-icons-20261011/original-icons'
backup.mkdir(parents=True, exist_ok=True)
sources = [
    ('inventory', '908c37fd-5864-497c-9254-bbf97781868e'),
    ('vision', '4de333ef-8ff8-4b83-84df-b85109d5f546'),
    ('arts', '64f1d5aa-1ccb-4d1a-b1ba-04e4e71ca8d9'),
    ('sword', 'f6e3eb63-6d2c-4f57-91ab-1faaf533aacc'),
    ('advancements', '70865f4e-573c-4948-a221-806c9a7b199d'),
    ('settings', 'e96c62f8-8c64-4d66-93a1-b6d8f683a7cb'),
]
for name, source_id in sources:
    destination = out / f'{name}.png'
    size = Image.open(destination).size
    saved = backup / destination.name
    if not saved.exists():
        shutil.copy2(destination, saved)
    source = Path('C:/Users/NOSTZE~1/AppData/Local/Temp') / f'codex-clipboard-{source_id}.png'
    im = Image.open(source).convert('RGBA')
    # Ignore near-invisible export glow when fitting the supplied symbol to its slot.
    bounds = im.getchannel('A').point(lambda a: 255 if a > 16 else 0).getbbox()
    im = im.crop(bounds)
    im.thumbnail((size[0]-2, size[1]-2), Image.Resampling.LANCZOS)
    canvas = Image.new('RGBA', size)
    canvas.alpha_composite(im, ((size[0]-im.width)//2, (size[1]-im.height)//2))
    canvas.save(destination)
    print(name, size)
