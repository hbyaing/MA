"""Extract the intact inner formation and exclude source crop leftovers."""
from pathlib import Path
from PIL import Image, ImageDraw
root=Path(__file__).resolve().parents[1]
folder=root/'src/main/resources/assets/wuxingxiantu/textures/gui/alchemy'
source=Image.open(folder/'background_compact.png').convert('RGBA')
im=source.crop((196,138,636,550))
for y in range(im.height):
    for x in range(im.width):
        r,g,b,a=im.getpixel((x,y))
        # Preserve all gold lettering and flourishes, including strokes outside
        # the inner circle. Exclude the old header rule above the formation.
        inside=(x-218)**2+(y-206)**2<=211**2
        header=y<5 or (y<10 and not 204<=x<=240)
        gold=r>g and g>b and r>100 and r-b>35
        if not inside or header or not gold:
            im.putpixel((x,y),(0,0,0,0))
im.save(folder/'formation_clean.png')
(folder/'formation_clean.png.mcmeta').write_text('{"texture":{"blur":false,"clamp":true}}')
# Compose one background at its final size, with no old formation in the body
# and no filtering across the header/body source boundary.
background=Image.new('RGBA',(1232,1024),(0,0,0,0))
background.paste(source.crop((0,0,1232,144)),(0,0))
# The right title ornament is intact. Mirror it about the title diamond,
# including its lower rule, rather than retaining the damaged left crop.
background.paste(source.crop((611,0,1222,144)).transpose(Image.Transpose.FLIP_LEFT_RIGHT),(0,0))
body=source.crop((0,144,1232,568)).resize((1232,520),Image.Resampling.NEAREST)
ImageDraw.Draw(body).rectangle((168,0,1067,519),fill=(21,42,49,255))
background.paste(body,(0,144))
background.paste(source.crop((0,568,1232,928)),(0,664))
background.save(folder/'background_clean.png')
(folder/'background_clean.png.mcmeta').write_text('{"texture":{"blur":false,"clamp":true}}')
print('Extracted circular formation without rectangular crop remnants')
