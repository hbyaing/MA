"""Validate real Forge shield contacts/GPU frames and compose unchanged captures."""
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'reports/shield-shatter-client'
OUTPUT = ROOT / 'reports/shield-shatter-20261013'
OUTPUT.mkdir(parents=True, exist_ok=True)
data = json.loads((SOURCE / 'captures.json').read_text(encoding='utf-8'))
assert (SOURCE / 'complete.txt').exists() and not data['failures'], data['failures']
assert data['captureCount'] == 39 and data['firstFrames'] == 24 and data['wallFrames'] == 3
assert data['repeatHitOne'] and data['repeatHitTwo']
assert data['initialShader'] != data['reloadedShader'] != 0
assert data['initialShardShader'] != data['reloadedShardShader'] != 0
rows = {row['name']: row for row in data['captures']}
assert all(row['glError'] == 0 for row in rows.values())
for name, pool in [('01-blue-full.png', 12), ('02-purple-half.png', 6),
                   ('03-red-low.png', 1), ('04-red-empty-retained.png', 0)]:
    assert rows[name]['absorption'] == pool and rows[name]['visualEffect']
    assert not rows[name]['hasShatterState']
sequence = [row for row in data['captures'] if row['name'].startswith('shatter-')]
assert len(sequence) == 24
assert all(b['shatterAgeSeconds'] >= a['shatterAgeSeconds'] for a, b in zip(sequence, sequence[1:]))
assert all(row['patchCount'] == 110 and row['sparkCount'] == 64
           for row in sequence if .5 < row['shatterAgeSeconds'] < 2.4)
for name in ['05-recast-blue-clean.png', '11-recast-during-break-blue-clean.png', '12-recast-settled-blue-clean.png']:
    assert rows[name]['absorption'] == 12 and rows[name]['visualEffect'] and not rows[name]['hasShatterState']
assert not rows['09-shatter-expired-clean.png']['hasShatterState']
assert not rows['09-shatter-expired-clean.png']['visualEffect']
assert rows['10-interrupted-shatter-active.png']['hasShatterState']
assert data['combatReadyServerTick'] >= 80

def warm_pixels(name):
    im = np.asarray(Image.open(SOURCE / name).convert('RGB')).astype(np.int16)
    hot = (im[..., 0] > 140) & (im[..., 0] - im[..., 1] > 60) & (im[..., 0] - im[..., 2] > 60)
    # Ignore the player's skin in the central body area, examine flying fragments around it.
    hot[70:740, 470:810] = False
    return int(hot.sum())

motion = [{'name': row['name'], 'age_seconds': row['shatterAgeSeconds'],
           'patch_count': row['patchCount'], 'warm_pixels_outside_player': warm_pixels(row['name'])}
          for row in sequence]
assert max(row['warm_pixels_outside_player'] for row in motion) > 100
wall_counts = {name: warm_pixels(name) for name in ['wall-shatter-0.png', 'wall-shatter-1.png']}
assert all(count == 0 for count in wall_counts.values()), wall_counts
report = {'test': 'spirit-shield-shatter-real-client', 'passed': True,
          'capture_count': len(rows), 'real_server_contacts': data['actualServerContacts'],
          'combat_ready_server_tick': data['combatReadyServerTick'], 'fragment_count': 110,
          'spark_count': 64, 'duration_seconds': 2.4, 'gpu_errors': 0,
          'depleted_shell_retained_until_next_contact': True, 'repeated_contacts_do_not_restart': True,
          'recast_clears_mid_burst': True, 'shader_resource_reload_passed': True,
          'wall_warm_pixels': wall_counts, 'motion': motion,
          'scope': 'Forge 47.4.10 isolated client, native shaders; no external shader pack acceptance'}
(OUTPUT / 'runtime-validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

font = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 23)
small = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 17)
panels = [('04-red-empty-retained.png', '盾值耗尽 · 红壳保留'),
          ('shatter-05-at-05t.png', '下一次受击 · 裂纹扩散'),
          ('shatter-11-at-20t.png', '曲面碎片 · 旋转飞散')]
review = Image.new('RGB', (1170, 620), '#101927')
draw = ImageDraw.Draw(review)
draw.text((18, 12), '灵力护盾 · 游戏内破碎预览', font=font, fill='#e0eaf7')
for i, (name, label) in enumerate(panels):
    im = Image.open(SOURCE / name).convert('RGB').crop((245, 45, 1035, 850))
    im.thumbnail((370, 520), Image.Resampling.LANCZOS)
    review.paste(im, (i*390 + (390-im.width)//2, 85))
    draw.text((i*390 + 15, 52), label, font=small, fill='#ffd0af')
review.save(OUTPUT / 'shield-shatter-game-review.png')

frames = []
durations = []
names = ['04-red-empty-retained.png'] + [row['name'] for row in sequence] + ['09-shatter-expired-clean.png']
for index, name in enumerate(names):
    im = Image.open(SOURCE / name).convert('RGB').crop((145, 35, 1135, 860))
    im.thumbnail((594, 495), Image.Resampling.LANCZOS)
    frame = Image.new('RGB', (614, 550), '#101927')
    d = ImageDraw.Draw(frame)
    label = '血量耗尽 · 等待下一击' if index == 0 else ('破碎消退' if index == len(names)-1 else '下一击触发 · 曲面碎片飞散')
    d.text((12, 10), label, font=font, fill='#e0eaf7')
    frame.paste(im, ((614-im.width)//2, 48))
    frames.append(frame)
    durations.append(700 if index in (0, len(names)-1) else max(30, int(1000 * (sequence[index]['shatterAgeSeconds']-sequence[index-1]['shatterAgeSeconds']))) if index < len(sequence) else 150)
frames[0].save(OUTPUT / 'shield-shatter-game-motion.gif', save_all=True, append_images=frames[1:], duration=durations, loop=0, optimize=False)
print(json.dumps({'passed': True, 'captures': len(rows), 'wall_warm_pixels': wall_counts}, ensure_ascii=False))
