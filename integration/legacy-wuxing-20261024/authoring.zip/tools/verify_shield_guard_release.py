"""Verify the installed shield/guard build against current production resources."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json
import re
import sys

root = Path(__file__).resolve().parents[1]
source = Path(sys.argv[1]).resolve()
installed = Path(sys.argv[2]).resolve()
report_path = root / 'reports/shield-shatter-20261013/installed-verification.json'
required_resources = [
    'assets/wuxingxiantu/shaders/core/spirit_shield_sphere.' + suffix for suffix in ('fsh', 'vsh', 'json')
] + [
    'assets/wuxingxiantu/shaders/core/spirit_shield_shards.' + suffix for suffix in ('fsh', 'vsh', 'json')
] + [
    'assets/wuxingxiantu/shaders/core/spirit_guard_cloud.' + suffix for suffix in ('fsh', 'vsh', 'json')
] + [
    'assets/wuxingxiantu/textures/effect/' + filename for filename in (
        'spirit_guard_cloud_1.png', 'spirit_guard_cloud_2.png',
        'spirit_guard_cloud_mask.png', 'spirit_guard_cloud_4.png')
]
required_classes = [
    'cn/blockforge/generated/generatedmod/client/SpiritShieldRenderer.class',
    'cn/blockforge/generated/generatedmod/client/shield/ShieldFractureGeometry.class',
    'cn/blockforge/generated/generatedmod/client/SpiritGuardArmorRenderer.class',
    'cn/blockforge/generated/generatedmod/client/SpiritGuardArmorRenderType.class',
    'cn/blockforge/generated/generatedmod/network/packet/cultivation/ShieldShatterPacket.class',
]
source_hash = sha256(source.read_bytes()).hexdigest().upper()
installed_hash = sha256(installed.read_bytes()).hexdigest().upper()
assert source_hash == installed_hash, 'Installed file differs from delivery'
entries = {}
with ZipFile(installed) as jar:
    names = jar.namelist()
    assert re.search(r'(?m)^modId\s*=\s*"wuxingxiantu"\s*$', jar.read('META-INF/mods.toml').decode('utf-8'))
    for resource in required_resources:
        original = (root / 'src/main/resources' / resource).read_bytes()
        assert jar.read(resource) == original, resource
        entries[resource] = sha256(original).hexdigest()
    for entry in required_classes:
        assert entry in names, entry
    forbidden = ('ShieldShatterCapture', 'CloudGlyphClientCapture', 'SwordTrailClientCapture',
                 'SpiritShieldGameTests', 'ShieldFractureGeometryRegression')
    assert not any(any(token in name for token in forbidden) for name in names), 'Test fixture entered release'
validation_paths = {
    'shield_shatter': root / 'reports/shield-shatter-20261013/runtime-validation.json',
    'guard_world': root / 'reports/guard-world-fix-20261013/runtime-validation.json',
    'guard_tiers': root / 'reports/guard-tier-20261013/runtime-validation.json',
    'sword_trail': root / 'reports/sword-trail-client/captures.json',
}
validation_hashes = {}
for key, path in validation_paths.items():
    validation = json.loads(path.read_text(encoding='utf-8-sig'))
    assert (validation.get('passed') or validation.get('all_required_capture_checks_passed')
            or validation.get('result') == 'PASS'), key
    validation_hashes[key] = sha256(path.read_bytes()).hexdigest()
flight_config = installed.parent.parent / 'config/wuxingxiantu-flight-client.toml'
assert 'trails = true' in flight_config.read_text(encoding='utf-8'), 'Installed trail preference is still disabled'
report = {'passed': True, 'source': str(source), 'installed': str(installed), 'sha256': installed_hash,
          'resource_bytes_match_source': entries, 'production_classes_present': required_classes,
          'test_fixtures_absent': True, 'protocol_version': '76',
          'runtime_validation_sha256': validation_hashes, 'flight_trails_enabled': True}
report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'passed': True, 'installed': str(installed), 'sha256': installed_hash}, ensure_ascii=False))
