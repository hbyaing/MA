"""Package the approved close-fitting flame over the installed alchemy-fix baseline.

Run only after the final production build/reobfJar succeeds. This tool never
installs a JAR. It preserves every baseline entry outside the explicit visual
whitelist, including every Alchemy* and HerbPreparation class/resource.
Existing output is accepted only when byte-for-byte identical.
"""
from __future__ import annotations

import argparse
from copy import copy
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "deliverables/task-20261015-alchemy-reservation-fix/wuxingxiantu-0.2-20261015-alchemy-reservation-fix.jar"
BASELINE_SHA256 = "35B7CA5D70C2472F83324AF76EC9E7ABBAFDF80E525AD13F0C9BCC6EDC545D19"
CANDIDATE = ROOT / "build/libs/wuxingxiantu-0.2.jar"
OUTPUT_DIRECTORY = ROOT / "deliverables/task-20261015-firecoil-release"
OUTPUT_NAME = "wuxingxiantu-0.2-20261016-firecoil-close-flame.jar"
PACKAGE = "cn/blockforge/generated/generatedmod/"
COIL_PACKAGE = PACKAGE + "client/firecoil/"
COIL_RESOURCE = "assets/wuxingxiantu/firecoil/"
COIL_CLASS_STEMS = frozenset({"Client", "FireCore", "FireRender", "Geometry", "Recipe", "VolumeGpu", "SupportBounds", "CurveCache"})
RENDERERS = frozenset({
    PACKAGE + "client/ExoticFireOrbitRenderer.class",
    PACKAGE + "client/weaponflame/WeaponFlameRenderer.class",
})
CORE_ALIASES = frozenset("assets/wuxingxiantu/shaders/core/firecoil_fire." + ext
                         for ext in ("json", "vsh", "fsh"))
REQUIRED_RESOURCES = CORE_ALIASES | frozenset(COIL_RESOURCE + name for name in (
    "recipe.json", "nine-flames.json", "levels.json", "shaders/volume.fsh",
    "shaders/volume.wrapper.glsl", "shaders/composite.fsh",
    "shaders/shared-volume-core.sha256", "shaders/core/fire.fsh",
    "shaders/core/fire.vsh", "shaders/core/fire.json", "shaders/core/shared-core.sha256",
))
QA_TOKENS = ("GameTest", "ClientCapture", "Regression", "VolumePerformanceProbe",
             "FurnaceMotionFixture", "DomainUiCapture", "BaselineHostScan")
PRESERVED_METADATA = ("filename", "date_time", "compress_type", "comment", "extra",
                      "create_system", "internal_attr", "external_attr")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(data: bytes) -> str:
    return sha256(data).hexdigest().upper()


def entries(archive: ZipFile) -> dict[str, bytes]:
    names = archive.namelist()
    require(len(names) == len(set(names)), "Duplicate ZIP entry names")
    require(archive.testzip() is None, "ZIP checksum verification failed")
    require(all(not n.startswith(("/", "\\")) and ".." not in Path(n).parts for n in names),
            "Unsafe ZIP entry path")
    return {name: archive.read(name) for name in names}


def allowed(name: str) -> bool:
    if name in RENDERERS or name in CORE_ALIASES:
        return True
    if name.startswith(COIL_RESOURCE):
        return True
    if name == COIL_PACKAGE:
        return True
    if name.startswith(COIL_PACKAGE) and name.endswith(".class"):
        relative = name[len(COIL_PACKAGE):-6]
        return "/" not in relative and relative.split("$", 1)[0] in COIL_CLASS_STEMS
    return False


def verify_no_fixtures(names: set[str]) -> None:
    prefixes = set()
    for source_set in (ROOT / "src").iterdir():
        if not source_set.is_dir() or source_set.name == "main":
            continue
        for path in source_set.rglob("*.java"):
            package = re.search(r"^\s*package\s+([\w.]+)\s*;",
                                path.read_text(encoding="utf-8-sig"), re.MULTILINE)
            if package:
                prefixes.add(package.group(1).replace(".", "/") + "/" + path.stem)
    for name in names:
        if name.endswith(".class"):
            require(not any(token in name for token in QA_TOKENS), "QA class in release: " + name)
            require(not any(name == p + ".class" or name.startswith(p + "$") for p in prefixes),
                    "Non-production source-set class in release: " + name)


def normalized_text(data: bytes) -> str:
    # Match pathlib.read_text(newline=None), including Windows CRLF conversion.
    return data.decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")


def verify_shared_sources(built_entries: dict[str, bytes]) -> dict[str, str]:
    web = ROOT / "tools/firecoil-workbench"
    for web_name, native_name in (("current-recipe.json", "recipe.json"),
                                  ("levels.json", "levels.json"),
                                  ("nine-flames.json", "nine-flames.json")):
        expected = json.loads((web / web_name).read_text(encoding="utf-8-sig"))
        actual = json.loads(normalized_text(built_entries[COIL_RESOURCE + native_name]))
        require(actual == expected, "Web/native JSON semantics differ: " + native_name)
    volume = (web / "fire.volume.core.glsl").read_text(encoding="utf-8-sig")
    fragment = (web / "fire.frag.core.glsl").read_text(encoding="utf-8-sig")
    wrapper = normalized_text(built_entries[COIL_RESOURCE + "shaders/volume.wrapper.glsl"])
    require(wrapper.count("__SHARED_FIRE_VOLUME_CORE__") == 1,
            "Expected exactly one native shared-volume placeholder")
    require(normalized_text(built_entries[COIL_RESOURCE + "shaders/volume.fsh"]) ==
            wrapper.replace("__SHARED_FIRE_VOLUME_CORE__", volume),
            "Native volume does not equal wrapper plus approved web density core")
    begin, end = "// SHARED_CORE_BEGIN\n", "// SHARED_CORE_END"
    for name in (COIL_RESOURCE + "shaders/core/fire.fsh",
                 "assets/wuxingxiantu/shaders/core/firecoil_fire.fsh"):
        native = normalized_text(built_entries[name])
        require(native.count(begin) == 1 and native.count(end) == 1,
                "Expected one pair of native sprite markers: " + name)
        embedded = native.split(begin, 1)[1].split(end, 1)[0]
        require(embedded == fragment + "\n", "Native sprite core differs from approved web fragment: " + name)
    hashes = {"volume": sha256(volume.encode("utf-8")).hexdigest(),
              "fragment": sha256(fragment.encode("utf-8")).hexdigest()}
    for key, native_name in (("volume", "shaders/shared-volume-core.sha256"),
                             ("fragment", "shaders/core/shared-core.sha256")):
        require(normalized_text(built_entries[COIL_RESOURCE + native_name]).strip() == hashes[key],
                "Shared GLSL hash marker mismatch: " + native_name)
    return hashes


def check_existing(path: Path, data: bytes) -> None:
    if path.exists():
        require(path.is_file() and path.read_bytes() == data,
                "Refusing to replace different existing output: " + str(path))


def write_new_or_verify(path: Path, data: bytes) -> None:
    if path.exists():
        check_existing(path, data)
    else:
        try:
            with path.open("xb") as stream:
                stream.write(data)
        except FileExistsError:
            check_existing(path, data)
    require(path.read_bytes() == data, "Written output verification failed: " + str(path))


def package(baseline: Path, candidate: Path, output_directory: Path) -> dict:
    baseline = baseline.resolve(strict=True)
    candidate = candidate.resolve(strict=True)
    output_directory = output_directory.resolve()
    baseline_bytes, candidate_bytes = baseline.read_bytes(), candidate.read_bytes()
    require(digest(baseline_bytes) == BASELINE_SHA256, "Approved alchemy baseline SHA256 mismatch")
    with ZipFile(BytesIO(baseline_bytes)) as old, ZipFile(BytesIO(candidate_bytes)) as built:
        before, built_entries = entries(old), entries(built)
        require(not any("firecoil" in name.lower() for name in before), "Baseline unexpectedly contains firecoil")
        include = {name for name in built_entries if allowed(name)}
        required = RENDERERS | REQUIRED_RESOURCES | {
            COIL_PACKAGE + stem + ".class" for stem in COIL_CLASS_STEMS}
        require(required <= include, "Missing visual release entries: " + repr(sorted(required - include)))
        unexpected_coil = {n for n in built_entries if n.startswith(COIL_PACKAGE) and not allowed(n)}
        require(not unexpected_coil, "Unexpected firecoil class/entry: " + repr(sorted(unexpected_coil)))
        for name in include:
            if name.endswith(".class"):
                require(built_entries[name][:4] == b"\xca\xfe\xba\xbe", "Invalid class bytes: " + name)
            elif name.startswith(COIL_RESOURCE) or name in CORE_ALIASES:
                if not name.endswith("/"):
                    source = ROOT / "src/main/resources" / name
                    require(source.is_file() and source.read_bytes() == built_entries[name],
                            "Built visual resource does not match current source: " + name)
        for name in RENDERERS:
            require(name in before and before[name] != built_entries[name],
                    "Expected renderer integration missing: " + name)
        core_hashes = verify_shared_sources(built_entries)
        buffer = BytesIO()
        with ZipFile(buffer, "w") as result:
            result.comment = old.comment
            for original in old.infolist():
                info = copy(original)
                result.writestr(info, built_entries[info.filename] if info.filename in include else before[info.filename])
                info.external_attr = original.external_attr
            for name in sorted(include - before.keys()):
                original = built.getinfo(name)
                info = copy(original)
                result.writestr(info, built_entries[name])
                info.external_attr = original.external_attr
        output_bytes = buffer.getvalue()
        with ZipFile(BytesIO(output_bytes)) as result:
            after = entries(result)
            changed = sorted(n for n in before.keys() & after.keys() if before[n] != after[n])
            added = sorted(after.keys() - before.keys())
            removed = sorted(before.keys() - after.keys())
            require(set(changed) == RENDERERS, "Existing entry changes must equal exactly two visual renderers")
            require(not removed and set(added) == include - before.keys(), "Unexpected entry additions/removals")
            require(all(allowed(n) for n in changed + added), "Release delta exceeds visual whitelist")
            require(all(after[n] == before[n] for n in before if n not in RENDERERS),
                    "A non-whitelisted baseline entry changed")
            require(all(after[n] == built_entries[n] for n in include), "Visual entry differs from production build")
            require(result.namelist()[:len(before)] == old.namelist(), "Baseline entry order changed")
            require(result.comment == old.comment, "Baseline ZIP comment changed")
            for previous in old.infolist():
                current = result.getinfo(previous.filename)
                require(all(getattr(previous, key) == getattr(current, key) for key in PRESERVED_METADATA),
                        "Baseline entry metadata changed: " + previous.filename)
            verify_no_fixtures(set(after))
            alchemy = sorted(n for n in before if "/Alchemy" in n or "/HerbPreparation" in n)
            require(alchemy and all(after[n] == before[n] for n in alchemy), "Alchemy fix was not preserved")
    # Catch a concurrent rebuild rather than packaging a mixed/obsolete candidate silently.
    require(candidate.read_bytes() == candidate_bytes, "Production build changed during packaging")
    output = output_directory / OUTPUT_NAME
    require(output not in {baseline, candidate}, "Output would replace an input")
    report = {
        "result": "PASS", "baseline": str(baseline), "baselineSha256": BASELINE_SHA256,
        "reobfuscatedBuild": str(candidate), "reobfuscatedBuildSha256": digest(candidate_bytes),
        "artifact": str(output), "sha256": digest(output_bytes), "bytes": len(output_bytes),
        "changed": changed, "added": added, "removed": removed,
        "unchangedBaselineEntries": len(before) - len(changed),
        "allOtherEntryBytesUnchanged": True, "allAlchemyEntriesPreserved": True,
        "alchemyEntriesPreserved": alchemy, "testClassesAbsent": True,
        "visualEntriesMatchReobfuscatedBuild": True, "visualResourcesMatchCurrentSource": True,
        "webNativeJsonSemanticsMatch": True, "sharedGlslCoresMatch": True,
        "glslCoreSha256": core_hashes,
        "baselineEntryOrderPreserved": True, "baselineEntryMetadataPreserved": True,
        "zipContainerNote": "ZIP headers/compression streams may normalize; every non-whitelisted uncompressed entry remains byte-identical.",
        "deltaSha256": {n: digest(after[n]) for n in changed + added},
        "installed": False,
    }
    report_bytes = (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    report_path = output_directory / "release-verification.json"
    check_existing(output, output_bytes)
    check_existing(report_path, report_bytes)
    output_directory.mkdir(parents=True, exist_ok=True)
    write_new_or_verify(output, output_bytes)
    write_new_or_verify(report_path, report_bytes)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    parser.add_argument("--input", type=Path, default=CANDIDATE, dest="candidate")
    parser.add_argument("--output-directory", type=Path, default=OUTPUT_DIRECTORY)
    args = parser.parse_args()
    print(json.dumps(package(args.baseline, args.candidate, args.output_directory), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
