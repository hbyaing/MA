"""Copy the actual registered herb block models/textures into an offline inspector."""
import json,re,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
assets=root/'src/main/resources/assets/wuxingxiantu'
out=root/'deliverables/plant-workbench-20261010'
out.mkdir(parents=True,exist_ok=True)
lang=json.loads((assets/'lang/zh_cn.json').read_text(encoding='utf-8'))
catalog=(root/'src/main/java/cn/blockforge/generated/generatedmod/plants/SpiritPlantCatalog.java').read_text(encoding='utf-8')
ids=re.findall(r'\.builder\("([^"]+)"',catalog)
models={};textures=set()
def load(ref):
    if ref in models:return
    if ref=='minecraft:block/cross':
        models[ref]={'textures':{},'elements':[{'from':[.8,0,8],'to':[15.2,16,8],'rotation':{'origin':[8,0,8],'axis':'y','angle':a,'rescale':True},'faces':{'north':{'texture':'#cross','uv':[0,0,16,16]},'south':{'texture':'#cross','uv':[16,0,0,16]}}} for a in (45,-45)]};return
    ns,path=ref.split(':');file=root/f'src/main/resources/assets/{ns}/models/{path}.json'
    data=json.loads(file.read_text(encoding='utf-8'));models[ref]=data
    if data.get('parent'):load(data['parent'])
    for t in data.get('textures',{}).values():
        if not t.startswith('#'):textures.add(t)
plants=[]
for id in ids:
    state=json.loads((assets/f'blockstates/{id}.json').read_text(encoding='utf-8'))
    variants=state['variants'];stages=[]
    for age in range(8):
        item=variants.get(f'age={age},waterlogged=false',variants.get(f'age={age}',variants.get('')))
        if item is None:continue
        if isinstance(item,list):item=item[0]
        load(item['model']);stages.append({'age':age,'model':item['model']})
    plants.append({'id':id,'name':lang.get('block.wuxingxiantu.'+id,id),'stages':stages})
for ref in textures:
    ns,path=ref.split(':');dest=out/f'textures/{ns}/{path}.png';dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/f'src/main/resources/assets/{ns}/textures/{path}.png',dest)
(out/'data.js').write_text('const DATA='+json.dumps({'plants':plants,'models':models},ensure_ascii=False)+';',encoding='utf-8')
print(f'{len(plants)} plants, {len(models)} models, {len(textures)} textures -> {out}')
