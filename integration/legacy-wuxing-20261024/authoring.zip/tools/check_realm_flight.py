"""CPU checks compile the actual movement kernel; no Minecraft runtime claim."""
from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parents[1];out=root/'reports/realm-flight-design-20261008'
source=(root/'src/main/java/cn/blockforge/generated/generatedmod/realmflight/RealmFlightBalance.java').read_text(encoding='utf-8')
source=source.replace('package cn.blockforge.generated.generatedmod.realmflight;','').replace('public final class RealmFlightBalance','final class RealmFlightBalance')
harness='''
public class RealmFlightChecks {
 static void near(double a,double b){if(Math.abs(a-b)>1e-7)throw new AssertionError(a+" != "+b);}
 public static void main(String[] args){
  double[] cruise={8,11,14,18,23,28},boost={12,16,21,27,34,42},vertical={4,5,6,8,10,12};int cases=0;
  for(int r=3;r<=8;r++)for(int s=0;s<4;s++){
   double multiplier=1+.04*s;near(RealmFlightBalance.speed(r,s,false),cruise[r-3]*multiplier);near(RealmFlightBalance.speed(r,s,true),boost[r-3]*multiplier);near(RealmFlightBalance.vertical(r,s),vertical[r-3]*multiplier);
   double target=cruise[r-3]*multiplier/20,step=target/16;
   var v=new RealmFlightBalance.Velocity(0,0,0);
   for(int i=0;i<16;i++)v=RealmFlightBalance.advance(v.x(),v.y(),v.z(),target,0,0,step);
   near(v.x(),target);
   for(int i=0;i<8;i++)v=RealmFlightBalance.advance(v.x(),v.y(),v.z(),0,0,0,target/8);
   near(v.x(),0);
   double diagonal=target/Math.sqrt(2);v=new RealmFlightBalance.Velocity(0,0,0);
   for(int i=0;i<16;i++)v=RealmFlightBalance.advance(v.x(),v.y(),v.z(),diagonal,0,diagonal,step);
   near(Math.hypot(v.x(),v.z()),target);cases++;
  }
  near(RealmFlightBalance.speed(8,3,true),47.04);
  near(RealmFlightBalance.cost(3,false,1000),25);near(RealmFlightBalance.cost(4,true,1000),50);
  near(RealmFlightBalance.cost(5,false,1000),0);near(RealmFlightBalance.cost(8,true,1000),5);
  double ramp=0;for(int i=0;i<12;i++)ramp=RealmFlightBalance.approach(ramp,1,1.0/12);near(ramp,1);
  if(!RealmFlightBalance.doubleJump(107,100)||RealmFlightBalance.doubleJump(108,100)||RealmFlightBalance.doubleJump(99,100))throw new AssertionError("Double-jump window");
  near(RealmFlightBalance.launchVertical(true,0,0),.16);near(RealmFlightBalance.launchVertical(true,1,.03),.16);
  near(RealmFlightBalance.launchVertical(true,-1,-.1),-.1);near(RealmFlightBalance.launchVertical(false,0,0),0);
  System.out.println("PASS: "+cases+" realm/stage traces; acceleration, braking, diagonal caps, boost ramp, mana costs");
 }
}
'''
path=out/'RealmFlightChecks.java';path.write_text(harness+source,encoding='utf-8')
java=Path('C:/tmp/temurin17/jdk-17.0.20.1+1/bin/java.exe')
result=subprocess.run([str(java),'-Dfile.encoding=UTF-8',str(path)],capture_output=True,text=True,encoding='utf-8')
print(result.stdout,end='');print(result.stderr,end='');assert result.returncode==0
(out/'movement-validation.json').write_text(json.dumps({'cpu':result.stdout.strip(),'game_runtime_tested':False},indent=2),encoding='utf-8')
