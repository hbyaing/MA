"""One-shot visual iteration, limited to the unapproved browser workbench."""
from pathlib import Path
import shutil,json,datetime
p=Path('E:/五行仙途/tools/firecoil-workbench')
backup=Path('E:/五行仙途/deliverables/task-20261015-firecoil-iteration2/before')
backup.mkdir(parents=True,exist_ok=True)
for name in ['fire.volume.core.glsl','shaders.js','geometry.js','preview.js','editor.js','current-recipe.json','index.html']:
 if not (backup/name).exists():shutil.copy(p/name,backup/name)
s=(p/'fire.volume.core.glsl').read_text('utf-8')
a=s.index('vec3 fvCenter(');b=s.index('vec2 fvWeaponTongues(',a)
s=s[:a]+'''// Flowing flame crests, with a dominant stream and thinner companions.
vec3 fvCenter(float s,float strand,float t,float seed,float radiusInput,float heightInput,float turnsInput,float waveInput,int strandCount){
 float phase=strand/float(max(strandCount,1));
 float wave=s*8.7-t*WaveSpeed*.8+seed*2.1+strand*2.3;
 float sweep=s+.105*sin(s*6.283-t*.38+strand)+.035*sin(s*16.-t*.61);
 float angle=FC_TAU*(sweep*turnsInput+phase+t*RotationSpeed*.65);
 angle+=.20*sin(wave*.81)+.08*sin(wave*1.91);
 float radius=radiusInput+waveInput*(sin(wave)*.85+sin(wave*1.63)*.38);
 radius+=widthSafeDummy; // replaced below, no shader-only hidden control
 return vec3(cos(angle)*radius,.055+s*heightInput+waveInput*.25*sin(wave*1.2),sin(angle)*radius);
}

// A flame tongue is rooted in the same moving stream before peeling away.
vec2 fvPeel(vec3 p,float t,float seed,float h,float radius,float width,float turns,float wave,int count,float strand,float strength){
 float den=0.,hotWeight=0.;
 for(int i=0;i<5;i++){
  float k=float(i),clock=t*(.32+RiseSpeed*.13)+k*.197+strand*.163,age=fract(clock),birth=floor(clock);
  float rootS=.12+.69*fvHash(vec3(k+strand*7.,seed,birth));
  vec3 root=fvCenter(rootS,strand,t,seed,radius,h,turns,wave,count);
  vec3 radial=normalize(vec3(root.x,0,root.z)),side=vec3(-radial.z,0,radial.x);
  float len=width*(1.3+TongueLength)*(.25+.75*sin(age*FC_PI*.5));
  vec3 axis=normalize(vec3(0,1.0,0)+radial*(.40+.48*age)+side*.36);
  vec3 delta=p-root;float u=clamp(dot(delta,axis)/max(len,.01),0.,1.);
  vec3 bend=radial*(sin(u*2.9)*width*.50)+side*sin(u*4.8-t*.9+k)*width*.35*u;
  vec3 off=delta-axis*(u*len)-bend;
  float taper=pow(1.-u,1.3),w=width*(.27*taper+.018);
  float x=dot(off,radial),z=dot(off,side),axial=dot(off,axis);
  float folded=z+sin(u*10.-t*1.7+k)*w*.8;
  float shape=exp(-x*x/(w*w*.18)-folded*folded/(w*w*1.9)-axial*axial/(w*w));
  float n=fvFbm(vec3(x*18.,u*4.-t*RiseSpeed,z*16.)+seed+k);
  float life=smoothstep(0.,.13,age)*(1.-smoothstep(.58,1.,age));
  float d=shape*smoothstep(.22+Erosion*.2,.62,n)*life*taper*strength*1.9;
  den+=d;hotWeight+=d*(.28+.36*(1.-u));
 }
 return vec2(den,hotWeight);
}

vec2 fvCoilField(vec3 p,float t,float seed,float h,float radiusInput,float widthInput,float turnsInput,float waveInput,int strandCount,float strength,vec3 segmentStep){
 float density=0.,heatWeight=0.;vec3 q=fvWarp(p,t,seed);
 if(strength<.0001)return vec2(0.);
 for(int j=0;j<8;j++){
  if(j>=strandCount)break;float strand=float(j);
  float hierarchy=j==0?1.:(j==1?.60:.40);
  float s=clamp((q.y-.055)/h,0.,1.);
  vec3 c=fvCenter(s,strand,t,seed,radiusInput,h,turnsInput,waveInput,strandCount);
  for(int iteration=0;iteration<2;iteration++){
   vec3 tangent=(fvCenter(s+.003,strand,t,seed,radiusInput,h,turnsInput,waveInput,strandCount)-fvCenter(s-.003,strand,t,seed,radiusInput,h,turnsInput,waveInput,strandCount))/.006;
   s=clamp(s+dot(q-c,tangent)/max(dot(tangent,tangent),.01),0.,1.);
   c=fvCenter(s,strand,t,seed,radiusInput,h,turnsInput,waveInput,strandCount);
  }
  vec3 tangent=normalize(fvCenter(s+.003,strand,t,seed,radiusInput,h,turnsInput,waveInput,strandCount)-fvCenter(s-.003,strand,t,seed,radiusInput,h,turnsInput,waveInput,strandCount));
  vec3 radial=normalize(vec3(c.x,0,c.z));radial=normalize(radial-tangent*dot(radial,tangent));
  vec3 across=normalize(cross(tangent,radial)),delta=q-c;
  float x=dot(delta,radial),z=dot(delta,across);
  float along=s*(8.+turnsInput*2.)-t*RiseSpeed*.9+strand*11.;
  float crest=.5+.5*sin(along*1.15+.5*sin(along*.67));
  float ends=pow(max(0.,sin(s*FC_PI)),.5);
  float w=widthInput*hierarchy*(.24+.44*pow(crest,1.7))*(.35+.65*ends);
  if(length(delta)<w*2.5){
   vec3 flow=vec3(x/max(w,.01)*2.2,along/max(TongueLength,.1),z/max(w,.01)*1.7)+seed;
   float broad=fvFbm(flow),fine=fvFbm(flow*2.7+vec3(1.7,-t*.4,4.1));
   float fold=x+sin(z/max(w,.01)*2.6+along*1.7+fine*2.)*w*.17;
   float sheet=exp(-fold*fold/max(w*w*.045,.00001)-z*z/max(w*w*.82,.00001));
   float lace=smoothstep(.16+Erosion*.22,.52+Erosion*.14,broad+.16*crest);
   float pulse=.2+.8*smoothstep(.17,.72,fvNoise(vec3(along*.48,seed+strand,t*.11)));
   float veil=sheet*lace*pulse*ends;
   vec2 coreOffset=vec2(x-w*.045*sin(along*2.),z-w*.16*sin(along*.8));
   vec2 segment=vec2(dot(segmentStep,radial),dot(segmentStep,across));
   float core=fvFibre(coreOffset,segment,max(.003,w*.085))*ends*pulse;
   float fringe=exp(-fold*fold/max(w*w*.20,.00001)-z*z/max(w*w*1.1,.00001))*lace*ends*.10;
   float d=(veil*2.7+core*2.8+fringe)*strength;
   float heat=clamp(.24+fine*.19+core*.53,0.,1.);
   density+=d;heatWeight+=d*heat;
  }
  vec2 peel=fvPeel(q,t,seed,h,radiusInput,widthInput*hierarchy,turnsInput,waveInput,strandCount,strand,strength);
  density+=peel.x;heatWeight+=peel.y;
 }
 return vec2(density,heatWeight);
}

'''.replace(' radius+=widthSafeDummy; // replaced below, no shader-only hidden control\n','')+s[b:]
# The detached remnants stay dimmer than the attached flame crest.
s=s.replace('(gas*.9*holes+hot*5.3)','(gas*.65*holes+hot*2.8)')
(p/'fire.volume.core.glsl').write_text(s,'utf-8')
(p/'shaders.js').write_text('export const FIRE_FRAGMENT_CORE = '+json.dumps((p/'fire.frag.core.glsl').read_text('utf-8'),ensure_ascii=False)+';\nexport const FIRE_VOLUME_CORE = '+json.dumps(s,ensure_ascii=False)+';\n','utf-8')
r=json.loads((p/'current-recipe.json').read_text('utf-8'));r.update(attachment=0,width=.39,radius=.51,turns=.68,rotationSpeed=.15,waveAmplitude=.16,turbulence=.85,erosion=.38,intensity=1.65,opacity=.90,wispRate=5,wispSize=.13,emberRate=8,emberSize=.012,weaponWidth=.13)
(p/'current-recipe.json').write_text(json.dumps(r,indent=2),'utf-8')
s=(p/'geometry.js').read_text('utf-8');a=s.index('export function coilPoint(') if 'export function coilPoint(' in s else s.index('function coilPoint(');b=s.index('\n}',a)+2
old=s[a:b]
new='''export function coilPoint(r,s,t,strand=0,origin=[0,0,0]){
 const seed=(r.seed%997)*.071,phase=strand/Math.max(r.strands,1),wave=s*8.7-t*r.waveSpeed*.8+seed*2.1+strand*2.3;
 const sweep=s+.105*Math.sin(s*6.283-t*.38+strand)+.035*Math.sin(s*16-t*.61);
 const angle=TAU*(sweep*r.turns+phase+t*r.rotationSpeed*.65)+.20*Math.sin(wave*.81)+.08*Math.sin(wave*1.91);
 const radius=r.radius+r.waveAmplitude*(Math.sin(wave)*.85+Math.sin(wave*1.63)*.38);
 return add(origin,[Math.cos(angle)*radius,.055+s*r.height+r.waveAmplitude*.25*Math.sin(wave*1.2),Math.sin(angle)*radius]);
}'''
s=s[:a]+new+s[b:];(p/'geometry.js').write_text(s,'utf-8')
s=(p/'preview.js').read_text('utf-8').replace('const extent=r.radius+r.waveAmplitude+.3+r.width','const extent=r.radius+r.waveAmplitude+.9+r.width')
(p/'preview.js').write_text(s,'utf-8')
print('Updated browser-only flowing flame candidate; original host shader untouched.')
