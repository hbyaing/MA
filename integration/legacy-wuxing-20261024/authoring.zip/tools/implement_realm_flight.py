from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
java=root/'src/main/java/cn/blockforge/generated/generatedmod'
def edit(path,old,new):
    text=path.read_text(encoding='utf-8'); assert old in text, (path,old[:50]);path.write_text(text.replace(old,new),encoding='utf-8')
p=java/'event/CultivationTicker.java'
t=p.read_text(encoding='utf-8');start=t.index('        if (cn.blockforge.generated.generatedmod.yujian.YujianController.riding(player)) return;');end=t.index('\n    private static int freeFlightCost',start)
t=t[:start]+'''        if (!cn.blockforge.generated.generatedmod.realmflight.RealmFlightControl.eligible(player)) {
            cn.blockforge.generated.generatedmod.realmflight.RealmFlightControl.release(player);
            if(data.wuxingxiantu$getRealm()<3&&!player.isCreative()&&!player.isSpectator()) {
                boolean changed=player.getAbilities().mayfly||player.getAbilities().flying;
                player.getAbilities().mayfly=false;player.getAbilities().flying=false;
                player.getAbilities().setFlyingSpeed(.05F);if(changed)player.onUpdateAbilities();
            }
            return;
        }
        boolean allowed=data.wuxingxiantu$getRealm()>=5||data.wuxingxiantu$getAura()>=1.25F;
        boolean changed=player.getAbilities().mayfly!=allowed;
        player.getAbilities().mayfly=allowed;
        if(!allowed&&player.getAbilities().flying){player.getAbilities().flying=false;changed=true;}
        cn.blockforge.generated.generatedmod.realmflight.RealmFlightControl.tick(player);
        if(changed||gameTime%40==0)player.onUpdateAbilities();
    }
''' +t[end:]
p.write_text(t,encoding='utf-8')
edit(java/'network/NetworkChannel.java','VERSION = "68"','VERSION = "69"')
edit(java/'network/NetworkChannel.java','    public static void register() {','''    public static void register() {
        c2s(73,cn.blockforge.generated.generatedmod.realmflight.RealmFlightInputPacket.class,
                cn.blockforge.generated.generatedmod.realmflight.RealmFlightInputPacket::encode,
                cn.blockforge.generated.generatedmod.realmflight.RealmFlightInputPacket::decode,
                cn.blockforge.generated.generatedmod.realmflight.RealmFlightInputPacket::handle);''')
p=root/'tools/network-message-ids.json';ids=json.loads(p.read_text(encoding='utf-8'));ids.append(dict(id=73,type='cn.blockforge.generated.generatedmod.realmflight.RealmFlightInputPacket',direction='C2S'));p.write_text(json.dumps(ids,indent=2)+'\n',encoding='utf-8')
edit(java/'client/arts/ArtMaterialParticle.java','    static void spawn(','    public static void spawn(')
p=java/'realmflight/RealmFlightVisualPacket.java'
edit(p,'UUID player, boolean active','UUID player, boolean active, int realm, int stage, boolean ghost, boolean boost')
edit(p,'b.writeBoolean(p.active);','b.writeBoolean(p.active);b.writeByte(p.realm);b.writeByte(p.stage);b.writeBoolean(p.ghost);b.writeBoolean(p.boost);')
edit(p,'new RealmFlightVisualPacket(b.readUUID(),b.readBoolean())','new RealmFlightVisualPacket(b.readUUID(),b.readBoolean(),b.readUnsignedByte(),b.readUnsignedByte(),b.readBoolean(),b.readBoolean())')
p=java/'realmflight/RealmFlightTracking.java'
edit(p,'Map<ServerPlayer,Boolean> LAST','Map<ServerPlayer,RealmFlightVisualPacket> LAST')
edit(p,'            boolean active=active(p);var old=LAST.put(p,active);\n            if(old==null || old!=active)Network.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(()->p),new RealmFlightVisualPacket(p.getUUID(),active));','            var packet=packet(p);var old=LAST.put(p,packet);\n            if(!packet.equals(old))Network.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(()->p),packet);')
edit(p,'new RealmFlightVisualPacket(target.getUUID(),active(target))','packet(target)')
edit(p,'    private RealmFlightTracking(){}','''    private static RealmFlightVisualPacket packet(ServerPlayer p){var d=GeneratedMod.data(p);return new RealmFlightVisualPacket(p.getUUID(),active(p),d==null?0:Math.max(0,Math.min(8,d.wuxingxiantu$getRealm())),d==null?0:Math.max(0,Math.min(3,d.wuxingxiantu$getCultivationStage())),d!=null&&d.wuxingxiantu$isGhostImmortal(),RealmFlightControl.boosting(p));}
    private RealmFlightTracking(){}''')
edit(p,'return data!=null && data.wuxingxiantu$getRealm()>=3','return RealmFlightControl.eligible(p) && data!=null && data.wuxingxiantu$getRealm()>=3')
edit(java/'client/realmflight/RealmFlightVisuals.java','checkLevel();if(p.active())','checkLevel();RealmFlightEffects.accept(p);if(p.active())')
print('Integrated control, visual metadata and protocol 69 / ID 73')
