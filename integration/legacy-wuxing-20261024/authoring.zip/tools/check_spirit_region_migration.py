"""Run the current region save/load and spacing code against synthetic NBT, without Gradle."""
from pathlib import Path
import subprocess
import re

root = Path(__file__).resolve().parents[1]
out = root / 'reports/source-review-20261008'
source = (root / 'src/main/java/cn/blockforge/generated/generatedmod/plants/SpiritPlantRegions.java').read_text(encoding='utf-8')
source = source.replace('public final class SpiritPlantRegions', 'final class SpiritPlantRegions')
source = source.replace('SpiritPlantRegions', 'ReviewSpiritPlantRegions')
source = source.replace('ConnectedBiomeRegion', 'ReviewConnectedBiomeRegion')
source = source.replace('package cn.blockforge.generated.generatedmod.plants;', '')
imports, body = source.split('/** Persistent quotas', 1)
harness = r'''
public class RegionMigrationChecks {
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    static CompoundTag region(int id,boolean complete,boolean placed) {
        CompoundTag t=new CompoundTag();t.putInt("Id",id);t.putLong("Seed",123);
        t.putString("Biome","minecraft:plains");t.putBoolean("Complete",complete);t.putBoolean("Decided",true);
        t.putInt("Target",2);t.putLongArray("Cells",new long[]{0,1});
        t.putLongArray("Frontier",new long[]{2});t.putLongArray("Examined",new long[]{0,1,2});
        t.putLongArray("Placements",placed?new long[]{BlockPos.ZERO.asLong()}:new long[0]);
        CompoundTag counts=new CompoundTag();counts.putInt("test_plant",placed?1:0);
        t.put("Counts",counts);t.put("Limits",counts.copy());return t;
    }
    static CompoundTag saved(int policy,boolean complete,boolean placed) {
        CompoundTag t=new CompoundTag();t.putInt("Next",2);if(policy>0)t.putInt("Policy",policy);
        ListTag regions=new ListTag();regions.add(region(1,complete,placed));t.put("Regions",regions);
        t.putLongArray("Cultivated",new long[]{BlockPos.ZERO.offset(8,0,8).asLong()});
        ListTag wild=new ListTag();CompoundTag w=new CompoundTag();w.putLong("Pos",BlockPos.ZERO.asLong());w.putInt("Region",1);wild.add(w);t.put("Wild",wild);
        return t;
    }
    public static void main(String[] args)throws Exception {
        var migrated=ReviewSpiritPlantRegions.load(saved(0,true,true));
        var t=migrated.save(new CompoundTag());
        check(t.getInt("Policy")==2,"migration policy missing");
        var r=t.getList("Regions",Tag.TAG_COMPOUND).getCompound(0);
        check(r.getLongArray("Placements").length==1&&r.getCompound("Counts").getInt("test_plant")==1,"historical quota lost");
        check(!r.getBoolean("Decided"),"legacy species plan not refreshed");
        check(r.getLongArray("Frontier").length==0,"legacy frontier retained");
        check(migrated.isCultivated(BlockPos.ZERO.offset(8,0,8)),"cultivation mark lost");
        var empty=ReviewSpiritPlantRegions.load(saved(0,false,false)).save(new CompoundTag());
        check(empty.getList("Regions",Tag.TAG_COMPOUND).isEmpty(),"unbounded unfinished scan survived migration");
        var current=ReviewSpiritPlantRegions.load(saved(2,false,true)).save(new CompoundTag());
        check(current.getList("Regions",Tag.TAG_COMPOUND).getCompound(0).getLongArray("Frontier").length==1,"current frontier lost");
        var spaced=ReviewSpiritPlantRegions.class.getDeclaredMethod("spaced",BlockPos.class);spaced.setAccessible(true);
        check(!(boolean)spaced.invoke(migrated,new BlockPos(-47,200,0)),"negative-grid spacing missed history");
        check((boolean)spaced.invoke(migrated,new BlockPos(-48,200,0)),"spacing boundary rejected");
        var round=ReviewSpiritPlantRegions.load(t);
        check(!(boolean)spaced.invoke(round,new BlockPos(0,-30,47)),"index lost after round trip");
        round.removed(BlockPos.ZERO);
        check(!(boolean)spaced.invoke(round,new BlockPos(0,0,1)),"harvest refunded historical spacing");
        System.out.println("PASS: legacy migration, quota/marks preservation, interrupted scan, NBT round trip and historical spacing");
    }
}
'''
path = out / 'RegionMigrationChecks.java'
connected=(root/'src/main/java/cn/blockforge/generated/generatedmod/plants/ConnectedBiomeRegion.java').read_text(encoding='utf-8')
connected=re.sub(r'^(package|import) .*?;\s*','',connected,flags=re.M)
connected=connected.replace('public final class','final class').replace('ConnectedBiomeRegion','ReviewConnectedBiomeRegion')
path.write_text('package cn.blockforge.generated.generatedmod.plants;\nimport java.util.function.LongFunction;\n' + imports + harness + '\n/** Persistent quotas' + body+'\n'+connected, encoding='utf-8')
classpath = (root / 'reports/spirit-regions-20261008/classpath.txt').read_text(encoding='utf-8-sig').strip()
classpath = ';'.join(p for p in classpath.split(';') if 'fastutil\\8.3.1\\' not in p)
java = 'C:/tmp/temurin17/jdk-17.0.20.1+1/bin/java.exe'
result = subprocess.run([java, '-classpath', classpath, str(path)], cwd=root, capture_output=True, text=True)
(out / 'migration.log').write_text(result.stdout + result.stderr, encoding='utf-8')
print(result.stdout + result.stderr)
raise SystemExit(result.returncode)
