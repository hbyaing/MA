"""Offline resource/language checks for the Forge 1.20.1 source tree."""
from pathlib import Path
import json, sys

root = Path(__file__).resolve().parents[1]
resources = root / "src/main/resources"
errors = []
for path in resources.rglob("*.json"):
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"invalid JSON: {path}: {exc}")

langs = {}
for path in (resources / "assets/wuxingxiantu/lang").glob("*.json"):
    langs[path.name] = json.loads(path.read_text(encoding="utf-8"))
if "zh_cn.json" in langs and "en_us.json" in langs:
    zh, en = set(langs["zh_cn.json"]), set(langs["en_us.json"])
    for key in sorted(zh - en):
        print(f"missing en_us key: {key}")
    for key in sorted(en - zh):
        print(f"missing zh_cn key: {key}")

if errors:
    print("\n".join(errors), file=sys.stderr)
    raise SystemExit(1)
print(f"validated {sum(1 for _ in resources.rglob('*.json'))} JSON files")
