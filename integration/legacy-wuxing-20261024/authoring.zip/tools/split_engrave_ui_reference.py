from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,shutil
root=Path(__file__).resolve().parents[1]
src=Path(r'C:\Users\Nostzephert\Desktop\下载.png')
out=root/'source-assets'/'engrave-ui-reference-split-v1'
im=Image.open(src).convert('RGBA')
assert im.size==(1467,1072),im.size
regions={
 'window':(38,39,1430,1015),'header':(45,40,1423,145),
 'left_panel':(57,145,414,1004),'center_panel':(430,145,790,633),
 'right_panel':(800,145,1411,633),'details_panel':(430,644,790,999),
 'inventory_panel':(800,644,1411,999),'search_box':(79,205,378,250),
 'equipment_slot':(558,243,661,344),'legacy_book_slot':(457,485,529,563),
 'material_slots':(827,221,1368,314),'primary_button':(818,554,1388,615),
 'inventory_grid':(826,704,1364,886),'hotbar':(826,913,1364,980),
}
icons={'rune_spirit':(83,266,151,334),'rune_guard':(83,348,151,416),'rune_light':(83,429,151,497),'rune_weapon':(83,508,151,576),'rune_evil':(83,590,151,658),'rune_life':(83,669,151,737),'rune_soul':(83,750,151,818),'rune_gather':(83,829,151,897),
'material_1':(833,229,914,308),'material_2':(944,229,1025,308),'material_3':(1055,229,1136,308),'material_4':(1166,229,1247,308),'material_5':(1277,229,1358,308)}
if out.exists(): shutil.rmtree(out)
(out/'raw').mkdir(parents=True)
entries=[]
def save(rel,box,kind='raw_crop',usage='reference_only'):
 p=out/rel; p.parent.mkdir(parents=True,exist_ok=True); crop=im.crop(box); crop.save(p); entries.append({'path':rel.as_posix(),'size':list(crop.size),'source_box':list(box),'kind':kind,'usage':usage}); return crop
for n,b in regions.items(): save(Path('raw/components')/(n+'.png'),b,'raw_crop','reference_only')
for n,b in icons.items(): save(Path('raw/icons')/(n+'.png'),b,'raw_crop','reference_only')
# reusable slot crops from clean material/inventory samples
for n,b in [('material_slot',(827,221,918,312)),('inventory_slot',(826,704,884,765)),('hotbar_slot',(826,913,884,980))]:
 crop=save(Path('components/slot')/(n+'.png'),b,'reusable_crop','candidate_review_required')
# labels remain separate, dynamic runtime text must not be baked
labels={'title':(648,48,817,106),'subtitle':(666,108,800,137),'left_heading':(79,162,250,198),'center_heading':(545,163,696,201),'right_heading':(826,162,1014,200),'detail_heading':(452,662,592,698),'inventory_heading':(827,662,950,697)}
for n,b in labels.items(): save(Path('raw/labels')/(n+'.png'),b,'raw_crop','reference_only_baked_text')
manifest={'schema':'wuxingxiantu-engrave-ui-split/1','source':'reference-original.png','source_size':list(im.size),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'coordinate_convention':'xyxy exclusive','runtime_contract':{'logical_size':[430,330],'inventory_columns':9,'inventory_rows':3,'hotbar_slots':9,'native_slot_pixels':18},'regions':regions,'icons':icons,'labels':labels,'assets':entries,'limitations':['Raw panels contain baked text and items and are reference-only.','Runtime labels, values, player items and slot contents must be rendered independently.','The reference has a 10-column visual inventory rhythm; runtime keeps the existing 9x3 plus 9 hotbar container contract.','Slot crops are source-resolution review material; runtime must nine-slice or draw reusable slot frames.']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(src,out/'reference-original.png')
# contact sheet
sheet=Image.new('RGBA',(1000,((len(entries)+4)//5)*180+50),(25,28,30,255));d=ImageDraw.Draw(sheet);d.text((20,15),'铭刻台 UI 参考拆分 v1 · 原始裁切与层级',fill='white')
for i,e in enumerate(entries):
 x=(i%5)*200;y=50+(i//5)*180; c=Image.open(out/e['path']).convert('RGBA');c.thumbnail((180,130));sheet.alpha_composite(c,(x+10,y+5));d.text((x+8,y+140),Path(e['path']).stem[:26],fill='#e6c87a');d.text((x+8,y+157),str(e['size']),fill='#aab4b5')
sheet.convert('RGB').save(out/'contact-sheet.png')
print(json.dumps({'output':str(out),'assets':len(entries),'source_size':im.size},ensure_ascii=False))
