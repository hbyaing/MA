"""Install the selected imagegen badge outputs, preserving alpha and a shared footprint."""
from pathlib import Path
from PIL import Image
import json

ROOT=Path(__file__).resolve().parents[1]
SOURCES=ROOT/'source-assets/alchemy-followup-20261014/root-icons'
DEST=ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision'
GENERATED=Path('C:/Users/Nostzephert/.codex/generated_images/01a12f69-5e7f-7592-820f-6d6c4fd3f2d0')
FILES={
 'gold':'exec-8ea6a696-4043-463c-81f8-dd28c2974c17.png',
 'wood':'exec-a7e6c90b-5943-42eb-93ac-5e3e3940db70.png',
 'water':'exec-1e8ff31c-cbab-49e2-911f-0dc90bf291d9.png',
 'fire':'exec-8f4c6577-bf00-4cf5-9124-edfd90ca638c.png',
 'earth':'exec-9bceee3c-080c-46dd-be99-2e25a1d4c459.png',
 'thunder':'exec-98cf4b1d-e16b-47e7-b9c5-ba63ff5a7ead.png',
 'exotic':'exec-72d345d9-66ab-4f59-8796-c5af0f40545a.png',
}
SOURCES.mkdir(parents=True,exist_ok=True)
for name,file in FILES.items():
 im=Image.open(GENERATED/file).convert('RGBA')
 assert im.getpixel((0,0))[3]==0, f'{name}: generator did not produce transparency'
 im.save(SOURCES/f'{name}-generated.png')
 im=im.crop(im.getbbox());im.thumbnail((244,244),Image.Resampling.LANCZOS)
 icon=Image.new('RGBA',(256,256));icon.alpha_composite(im,((256-im.width)//2,(256-im.height)//2))
 target=DEST/('components/root_'+name+'.png' if name in ('thunder','exotic') else 'roots/'+name+'.png')
 if not (SOURCES/(name+'-before.png')).exists():
  Image.open(target).save(SOURCES/(name+'-before.png'))
 icon.save(target)
 Path(str(target)+'.mcmeta').write_text(json.dumps({'texture':{'blur':True,'clamp':True}}),encoding='utf-8')
 icon.save(SOURCES/(name+'-256.png'))
print('Installed',len(FILES),'HD badges')
