from pathlib import Path
import json, shutil
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables/task-20261015-talismans-implemented'
OUT.mkdir(parents=True,exist_ok=True)
records=json.loads((ROOT/'deliverables/task-20261015-talismans-review-v2/审查记录-v2.json').read_text(encoding='utf-8'))
# Interior parchment quadrilaterals: UL, LL, LR, UR. Decoration stays outside.
specs=[(1,'gather','聚灵符','GATHER','AQUA',(29,15,23,46,33,49,42,19),'blue'),
 (3,'speed','青岚疾行符','SPEED','GREEN',(25,14,21,49,38,53,43,14),'green'),
 (4,'thunder','惊雷符','THUNDER','YELLOW',(32,14,16,46,28,51,43,19),'red'),
 (5,'ward','镇煞符','WARD','DARK_PURPLE',(29,20,23,43,29,45,35,22),'dark'),
 (6,'thorn','缚荆符','THORN','DARK_GREEN',(30,11,20,45,29,48,39,15),'brown'),
 (11,'fire','赤焰爆符','FIRE','RED',(27,23,23,47,30,50,36,26),'red'),
 (12,'purge','祛邪符','PURGE','GOLD',(28,20,20,51,33,55,41,25),'red')]
java=ROOT/'src/main/java/cn/blockforge/generated/generatedmod'
assets=ROOT/'src/main/resources/assets/wuxingxiantu'
entries=[]
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
sheet=Image.new('RGB',(7*210,400),(24,29,37));d=ImageDraw.Draw(sheet)
audit=[]
for index,(number,id,name,effect,color,quad,ink) in enumerate(specs):
 rec=next(r for r in records if r['编号']==number)
 src=Path(rec['输出']); im=Image.open(src).convert('RGBA')
 dst=assets/'textures/item'/f'talisman_{id}.png';shutil.copy2(src,dst)
 aligned=im.transform((12,28),Image.Transform.QUAD,quad,Image.Resampling.NEAREST)
 rows=['.'*16]*32;grid=[]
 for y in range(28):
  row='..'
  for x in range(12):
   r,g,b,a=aligned.getpixel((x,y))
   hit=a>128 and ((ink=='blue' and b>r*1.12 and g>r*1.05 and r<155)
       or (ink=='green' and g>r*1.1 and g>b*1.12 and g<155)
       or (ink=='red' and r>g*1.28 and r>b*1.3 and g<155)
       or (ink=='dark' and max(r,g,b)<120)
       or (ink=='brown' and r>90 and r>g*1.2 and g>b*1.2))
   row+='X' if hit else '.'
  grid.append(row+'..')
 rows=['.'*16]*2+grid+['.'*16]*2
 assert 20<sum(r.count('X') for r in rows)<350,(id,rows)
 entries.append(f'        put("{id}", "talisman.wuxingxiantu.{id}", Effect.{effect}, ChatFormatting.{color},\n                new String[]{{'+','.join(json.dumps(r) for r in rows)+'}, '+('2' if id in ['thunder','fire','thorn'] else '1')+');')
 model={'parent':'minecraft:item/generated','textures':{'layer0':f'wuxingxiantu:item/talisman_{id}'}}
 (assets/'models/item'/f'talisman_{id}.json').write_text(json.dumps(model),encoding='utf-8')
 x=index*210+15
 sheet.paste(im.resize((160,160),Image.Resampling.NEAREST),(x,12),im.resize((160,160),Image.Resampling.NEAREST))
 d.text((x,180),f'{number:02} {name}',font=font,fill='white')
 d.rectangle((x,215,x+95,215+159),fill=(229,211,154))
 for y,row in enumerate(rows):
  for c,v in enumerate(row):
   if v=='X':d.rectangle((x+c*6,215+y*5,x+c*6+5,215+y*5+4),fill=(173,39,28))
 sheet.paste(aligned.resize((72,168),Image.Resampling.NEAREST),(x+108,215),aligned.resize((72,168),Image.Resampling.NEAREST))
 audit.append({'编号':number,'id':id,'名称':name,'原图内部取样':quad,'模板':rows,'笔画像素':sum(r.count('X') for r in rows)})
sheet.save(OUT/'符文与画符模板.png')
(OUT/'符文提取记录.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
p=java/'TalismanCatalog.java';s=p.read_text(encoding='utf-8');start=s.index('    static {');end=s.index('    private TalismanCatalog()',start)
# Existing shield/heal NBT remain functional, but are not available in new production choices.
legacy=s[start:end];pieces=[]
for id in ['shield','heal']:
 a=legacy.index('        put("'+id+'"');b=legacy.index('}, 1);',a)+len('}, 1);');pieces.append(legacy[a:b])
s=s[:start]+'    static {\n'+'\n'.join(entries+pieces)+'\n    }\n\n'+s[end:]
s=s.replace('public enum Effect { FIRE, SHIELD, HEAL, SPEED, GATHER, PURGE }','public enum Effect { FIRE, SHIELD, HEAL, SPEED, GATHER, PURGE, THUNDER, WARD, THORN }')
s=s.replace('return new ArrayList<>(ENTRIES.keySet());','return List.of("gather", "speed", "thunder", "ward", "thorn", "fire", "purge");')
if '        return switch (entry.effect())' in s:
 a=s.index('        return switch (entry.effect())');b=s.index('\n    private static boolean fire',a)
 s=s[:a]+'''        if (level.isClientSide) return true;
        return TalismanEffects.activate(entry.effect(), player, stack);
    }
''' + s[b:]
# Remove superseded ignition/direct aura restoration code.
if '    private static boolean fire' in s:
 s=s[:s.index('    private static boolean fire')]+'''    /** Stable model codes do not change when catalog order changes. */
    public static int modelCode(String id) {
        return switch(id) { case "gather"->1; case "speed"->2; case "thunder"->3;
            case "ward"->4; case "thorn"->5; case "fire"->6; case "purge"->7; default->0; };
    }
}
'''
p.write_text(s,encoding='utf-8')
model=json.loads((assets/'models/item/talisman.json').read_text(encoding='utf-8'))
model['overrides']=[{'predicate':{'wuxingxiantu:talisman_kind':i+1},'model':f'wuxingxiantu:item/talisman_{spec[1]}'} for i,spec in enumerate(specs)]
(assets/'models/item/talisman.json').write_text(json.dumps(model,indent=2),encoding='utf-8')
for lang in ['zh_cn','en_us']:
 p=assets/'lang'/f'{lang}.json';values=json.loads(p.read_text(encoding='utf-8'))
 for number,id,name,*rest in specs:values[f'talisman.wuxingxiantu.{id}']=name
 descriptions={'gather':'打坐修炼速度提高15%，持续60秒；重复使用仅刷新时间。','speed':'移速提高40%，跳跃增强，持续30秒。','thunder':'指向12格内目标，雷击伤害并短暂麻痹；不引燃方块。','ward':'持续30秒压制虚弱、失明和反胃，削弱重新施加的同类状态；不解除心魔主线。','thorn':'指向12格内目标区域，束缚2.5格内可见敌人4秒。','fire':'指向12格内目标区域，半径2.5格火焰爆发；不破坏或点燃方块。','purge':'解除可净化的负面状态，10秒内再次施加的同类状态持续时间减半；不解除Boss机制。'}
 for id,desc in descriptions.items():values[f'talisman.wuxingxiantu.{id}.description']=desc
 values.update({'effect.wuxingxiantu.talisman_gathering':'聚灵','effect.wuxingxiantu.talisman_gathering.description':'打坐修炼速度提高15%', 'effect.wuxingxiantu.talisman_ward':'镇煞','effect.wuxingxiantu.talisman_ward.description':'压制可净化的邪气状态','effect.wuxingxiantu.talisman_purge':'祛邪护持','effect.wuxingxiantu.talisman_purge.description':'可净化状态持续时间减半','message.wuxingxiantu.talisman_no_target':'前方没有可作用的目标'})
 p.write_text(json.dumps(values,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Installed seven texture variants and source-derived central glyph templates:',OUT)
