import assert from 'node:assert/strict';
import test from 'node:test';
import {createRenderScheduler} from './render-scheduler.mjs';

function harness(options={}){
 let now=0,nextId=0;
 const pending=new Map(),frames=[];
 const scheduler=createRenderScheduler({
  ...options,
  raf:callback=>{const id=nextId++;pending.set(id,callback);return id;},
  caf:id=>pending.delete(id),clock:()=>now,
  onFrame:(elapsed,time)=>{frames.push({elapsed,time});options.onFrame?.(elapsed,time);}
 });
 return {scheduler,frames,pending,step(time){
  assert.ok(time>=now,'Test clock must be monotonic.');now=time;
  const callbacks=[...pending.values()];pending.clear();
  for(const callback of callbacks)callback(time);
 }};
}

test('120 Hz RAF and repeated UI invalidations still render at most 30 FPS',()=>{
 const h=harness();
 for(let i=0;i<=120;i++){
  for(let j=0;j<5;j++)h.scheduler.invalidate();
  h.step(i*1000/120);
  assert.equal(h.pending.size,1,'Only one RAF may be queued.');
 }
 assert.equal(h.frames.length,31);
 assert.equal(h.frames[0].elapsed,0);
 for(let i=1;i<h.frames.length;i++){
  assert.ok(h.frames[i].time-h.frames[i-1].time>=1000/30-.001);
  assert.ok(Math.abs(h.frames[i].elapsed-(h.frames[i].time-h.frames[i-1].time)/1000)<1e-10);
 }
 h.scheduler.dispose();
});

test('elapsed time includes skipped RAF ticks rather than only the most recent tick',()=>{
 const h=harness();
 for(const time of [0,16,32,48,64,80,96])h.step(time);
 assert.deepEqual(h.frames,[{elapsed:0,time:0},{elapsed:.048,time:48},{elapsed:.048,time:96}]);
 h.scheduler.dispose();
});

test('pause stops RAF; invalidations redraw once without advancing animation',()=>{
 const h=harness();h.step(0);h.scheduler.setPaused(true);
 assert.equal(h.pending.size,0);
 h.step(1000);assert.equal(h.frames.length,1);
 for(let i=0;i<100;i++)h.scheduler.invalidate();
 assert.equal(h.pending.size,1);
 h.step(1010);assert.deepEqual(h.frames.at(-1),{elapsed:0,time:1010});
 assert.equal(h.pending.size,0);
 h.scheduler.invalidate();h.step(1020);
 assert.deepEqual(h.frames.at(-1),{elapsed:0,time:1020});
 h.scheduler.setPaused(false);h.step(1030);
 assert.equal(h.frames.length,3,'Unpausing cannot bypass the 30 FPS limit.');
 h.step(1060);assert.deepEqual(h.frames.at(-1),{elapsed:0,time:1060});
 h.step(1100);assert.deepEqual(h.frames.at(-1),{elapsed:.04,time:1100});
 h.scheduler.dispose();
});

test('hiding cancels RAF and resuming does not simulate the hidden interval',()=>{
 const h=harness();h.step(0);h.step(40);
 h.scheduler.setVisible(false);assert.equal(h.pending.size,0);
 h.scheduler.invalidate();assert.equal(h.pending.size,0);
 h.step(300000);assert.equal(h.frames.length,2);
 h.scheduler.setVisible(true);assert.equal(h.pending.size,1);
 h.step(300010);assert.deepEqual(h.frames.at(-1),{elapsed:0,time:300010});
 h.step(300050);assert.deepEqual(h.frames.at(-1),{elapsed:.04,time:300050});
 h.scheduler.dispose();
});

test('paused invalidations survive being hidden without a hidden render loop',()=>{
 const h=harness({paused:true,visible:false});
 assert.equal(h.pending.size,0);h.step(1000);
 h.scheduler.invalidate();h.scheduler.setVisible(true);h.step(1010);
 assert.deepEqual(h.frames,[{elapsed:0,time:1010}]);assert.equal(h.pending.size,0);
 h.scheduler.setVisible(false);h.scheduler.setVisible(true);
 assert.equal(h.pending.size,0,'A clean paused preview needs no redraw on visibility changes.');
 h.scheduler.dispose();
});

test('dispose cancels pending work and makes subsequent requests inert',()=>{
 const h=harness();assert.equal(h.pending.size,1);
 h.scheduler.dispose();h.scheduler.dispose();
 h.scheduler.invalidate();h.scheduler.setPaused(true);h.scheduler.setVisible(false);
 h.scheduler.setPaused(false);h.scheduler.setVisible(true);h.step(100);
 assert.equal(h.pending.size,0);assert.equal(h.frames.length,0);
});

test('onFrame can pause the scheduler without leaving an animation RAF queued',()=>{
 let scheduler;
 const h=harness({onFrame:()=>scheduler.setPaused(true)});scheduler=h.scheduler;
 h.step(0);assert.equal(h.pending.size,0);assert.equal(h.frames.length,1);
 scheduler.dispose();
});
