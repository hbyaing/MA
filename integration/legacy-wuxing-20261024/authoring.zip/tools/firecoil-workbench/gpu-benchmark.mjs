// Opt-in GPU timing. This module never creates queries until measureGpu is called.
const measuring = new WeakSet();
const TIMEOUT_MS = 15000;
const now = () => globalThis.performance?.now() ?? Date.now();
const yieldToBrowser = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

function count(value, name, allowZero) {
  if (!Number.isSafeInteger(value) || value < (allowZero ? 0 : 1)) {
    throw new RangeError(`${name} must be ${allowZero ? 'a non-negative' : 'a positive'} integer.`);
  }
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = sorted.length >> 1;
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

/**
 * Time complete, synchronous WebGL draws using GPU elapsed-time queries.
 * Call only in response to the user's benchmark action, with the normal render
 * loop paused. draw must issue its commands before returning; it must not start
 * or end timer queries. No gl.finish, CPU timings, or background query loop is used.
 *
 * Unsupported devices return supported:false and a reason. Invalid measurements
 * (disjoint, context loss, timeout, draw failure) reject instead of reporting a
 * misleading time. onProgress receives {phase, completed, total, sampleMs?}.
 */
export async function measureGpu(gl, draw, {warmup = 2, samples = 5, onProgress} = {}) {
  if (!gl || typeof gl.getExtension !== 'function' || typeof gl.createQuery !== 'function') {
    throw new TypeError('measureGpu requires a WebGL2 rendering context.');
  }
  if (typeof draw !== 'function') throw new TypeError('draw must be a synchronous function.');
  if (onProgress !== undefined && typeof onProgress !== 'function') {
    throw new TypeError('onProgress must be a function.');
  }
  count(warmup, 'warmup', true);
  count(samples, 'samples', false);

  const extension = gl.getExtension('EXT_disjoint_timer_query_webgl2');
  if (!extension) {
    return {
      supported: false,
      reason: '当前浏览器或显卡不支持 GPU 计时（EXT_disjoint_timer_query_webgl2）。',
      samplesMs: [], medianMs: null, warmup, samples: 0,
    };
  }
  if (measuring.has(gl) || gl.getQuery(extension.TIME_ELAPSED_EXT, gl.CURRENT_QUERY)) {
    throw new Error('A GPU timer query is already running on this context.');
  }

  measuring.add(gl);
  const deadline = now() + TIMEOUT_MS;
  const samplesMs = [];
  let query = null;
  let queryActive = false;

  function checkMeasurement() {
    if (gl.isContextLost()) throw new Error('GPU measurement cancelled: WebGL context lost.');
    if (now() >= deadline) throw new Error('GPU measurement timed out after 15 seconds.');
    if (gl.getParameter(extension.GPU_DISJOINT_EXT)) {
      throw new Error('GPU timing became disjoint; discard this entire measurement and retry.');
    }
  }

  function issueDraw() {
    const result = draw();
    if (result && typeof result.then === 'function') {
      // The submitted prefix is not a valid measurement of an asynchronous draw.
      // Consume a possible rejection so the helpful API error remains the only one.
      Promise.resolve(result).catch(() => {});
      throw new TypeError('draw must issue WebGL commands synchronously; async callbacks are unsupported.');
    }
  }

  function releaseQuery() {
    if (!query) return;
    // Never end a different query if a draw callback changed WebGL query state.
    if (queryActive && !gl.isContextLost()
        && gl.getQuery(extension.TIME_ELAPSED_EXT, gl.CURRENT_QUERY) === query) {
      gl.endQuery(extension.TIME_ELAPSED_EXT);
    }
    queryActive = false;
    gl.deleteQuery(query);
    query = null;
  }

  try {
    checkMeasurement();
    for (let index = 0; index < warmup; index++) {
      issueDraw();
      onProgress?.({phase: 'warmup', completed: index + 1, total: warmup});
      await yieldToBrowser(0);
      checkMeasurement();
    }

    for (let index = 0; index < samples; index++) {
      checkMeasurement();
      query = gl.createQuery();
      if (!query) throw new Error('Unable to allocate a GPU timer query.');
      try {
        gl.beginQuery(extension.TIME_ELAPSED_EXT, query);
        queryActive = true;
        if (gl.getQuery(extension.TIME_ELAPSED_EXT, gl.CURRENT_QUERY) !== query) {
          throw new Error('Unable to begin the GPU timer query.');
        }
        issueDraw();
        if (gl.getQuery(extension.TIME_ELAPSED_EXT, gl.CURRENT_QUERY) !== query) {
          throw new Error('draw changed the active GPU timer query.');
        }
        gl.endQuery(extension.TIME_ELAPSED_EXT);
        queryActive = false;
        gl.flush();

        // Availability is polled in later event-loop turns, without blocking the GPU.
        while (true) {
          await yieldToBrowser(Math.min(16, Math.max(0, deadline - now())));
          checkMeasurement();
          if (gl.getQueryParameter(query, gl.QUERY_RESULT_AVAILABLE)) break;
        }
        const nanoseconds = gl.getQueryParameter(query, gl.QUERY_RESULT);
        checkMeasurement();
        if (typeof nanoseconds !== 'number' || !Number.isFinite(nanoseconds) || nanoseconds < 0) {
          throw new Error('The GPU timer returned an invalid elapsed time.');
        }
        const sampleMs = nanoseconds / 1e6;
        samplesMs.push(sampleMs);
        onProgress?.({phase: 'sample', completed: index + 1, total: samples, sampleMs});
      } finally {
        releaseQuery();
      }
    }
    checkMeasurement();
    return {
      supported: true, samplesMs, medianMs: median(samplesMs), warmup,
      samples: samplesMs.length,
      renderer: gl.getParameter(gl.RENDERER),
    };
  } finally {
    try { releaseQuery(); } finally { measuring.delete(gl); }
  }
}
