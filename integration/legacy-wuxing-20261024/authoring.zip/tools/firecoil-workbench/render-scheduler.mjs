/**
 * Schedules onFrame(deltaSeconds, nowMilliseconds) at up to maxFPS (at most 30).
 * Creation requests the first frame. Paused invalidations coalesce into one RAF;
 * playing invalidations never bypass the frame cap. Visibility and pause changes
 * reset the animation clock, so resuming never simulates time spent inactive.
 */
export function createRenderScheduler({
 onFrame,
 maxFPS=30,
 paused=false,
 visible=true,
 raf=callback=>globalThis.requestAnimationFrame(callback),
 caf=handle=>globalThis.cancelAnimationFrame(handle),
 clock=()=>globalThis.performance.now()
}={}){
 if(typeof onFrame!=='function')throw new TypeError('onFrame must be a function.');
 if(!Number.isFinite(maxFPS)||maxFPS<=0||maxFPS>30)throw new RangeError('maxFPS must be greater than 0 and at most 30.');
 const interval=1000/maxFPS;
 let isPaused=!!paused,isVisible=!!visible,disposed=false,dirty=true,pending=null;
 let lastRenderTime=null,lastAnimationTime=null;
 const cancel=()=>{if(pending!==null){caf(pending);pending=null;}};
 const schedule=()=>{if(!disposed&&isVisible&&pending===null&&(!isPaused||dirty))pending=raf(frame);};
 function frame(){
  pending=null;
  if(disposed||!isVisible)return;
  const now=clock();
  if(isPaused){
   if(dirty){dirty=false;lastRenderTime=now;onFrame(0,now);}
  }else if(lastRenderTime===null||now-lastRenderTime>=interval-.001){
   const elapsed=lastAnimationTime===null?0:Math.max(0,(now-lastAnimationTime)/1000);
   dirty=false;lastRenderTime=now;lastAnimationTime=now;
   onFrame(elapsed,now);
  }
  schedule();
 }
 const scheduler={
  setPaused(value){
   if(disposed||isPaused===!!value)return;
   isPaused=!!value;lastAnimationTime=null;
   cancel();schedule();
  },
  setVisible(value){
   if(disposed||isVisible===!!value)return;
   isVisible=!!value;lastAnimationTime=null;
   cancel();schedule();
  },
  invalidate(){if(disposed)return;dirty=true;schedule();},
  dispose(){if(disposed)return;disposed=true;dirty=false;cancel();}
 };
 schedule();
 return scheduler;
}
