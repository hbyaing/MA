"""Local fire-coil parameter editor and fixed-file game bridge."""
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import argparse,json,os,time,uuid,tempfile,importlib.util

ROOT=Path(__file__).resolve().parent
GAME=Path(r'D:\MC\库\red.ghs.axolotl\profiles\测试 (1)')
_spec=importlib.util.spec_from_file_location('_firecoil_recipe',ROOT/'recipe.py')
_recipe=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_recipe)
loads,validate=_recipe.loads,_recipe.validate

def write_json(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 fd,name=tempfile.mkstemp(prefix='.firecoil-',suffix='.tmp',dir=path.parent)
 try:
  with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
  os.replace(name,path)
 finally:
  if os.path.exists(name):os.unlink(name)

class Handler(SimpleHTTPRequestHandler):
 extensions_map={**SimpleHTTPRequestHandler.extensions_map,'.js':'text/javascript','.mjs':'text/javascript','.glsl':'text/plain; charset=utf-8'}
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def log_message(self,*a):pass
 def end_headers(self):
  self.send_header('Cache-Control','no-store')
  self.send_header('X-Content-Type-Options','nosniff')
  super().end_headers()
 def send_json(self,status,data):
  body=json.dumps(data,ensure_ascii=False).encode('utf-8');self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def local_request(self):
  if self.headers.get('Host') not in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}:raise ValueError('只接受本地工作台请求。')
  origin=self.headers.get('Origin')
  if origin and origin not in {f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'}:raise ValueError('请求来源不匹配。')
 def game_status(self):
  jars=list((GAME/'mods').glob('wuxingxiantu-*.jar')) if GAME.is_dir() else []
  return {'hasRuntime':bool(jars),'compatibleRuntime':any('firecoil' in j.name for j in jars),'instance':'测试 (1)','gameDir':str(GAME)}
 def do_GET(self):
  if self.path.split('?',1)[0]=='/api/flame-palettes':
   try:self.send_json(200,json.loads((ROOT/'nine-flames.json').read_text(encoding='utf-8-sig')))
   except (OSError,ValueError) as e:self.send_json(400,{'ok':False,'error':str(e)})
   return
  if self.path.split('?',1)[0]=='/api/recipe':
   try:self.send_json(200,loads((ROOT/'current-recipe.json').read_text(encoding='utf-8-sig')))
   except Exception as e:self.send_json(400,{'ok':False,'error':str(e)})
  elif self.path.split('?',1)[0]=='/api/game-status':self.send_json(200,self.game_status())
  else:super().do_GET()
 def do_POST(self):
  try:
   self.local_request();size=int(self.headers.get('Content-Length','0'))
   if not 1<=size<=32768:raise ValueError('请求大小无效。')
   body=self.rfile.read(size).decode('utf-8')
   if self.path=='/api/recipe':
    recipe=loads(body)
    old=ROOT/'current-recipe.json';backup=ROOT/'last-recipe.json'
    if old.exists():
     try:write_json(backup,loads(old.read_text(encoding='utf-8-sig')))
     except ValueError:pass
    write_json(old,recipe);self.send_json(200,{'ok':True,'recipe':recipe});return
   if self.path=='/api/game':
    value=json.loads(body)
    if not isinstance(value,dict) or value.get('action') not in {'reload','start','off','status'}:raise ValueError('只支持reload/start/off/status。')
    if value['action']!='reload':raise ValueError('宿主工作台只支持保存配置。')
    recipe=validate(value.get('recipe'));path=GAME/'config/wuxingxiantu/firecoil.json'
    if path.exists():write_json(path.with_name('firecoil.previous.json'),loads(path.read_text(encoding='utf-8-sig')))
    write_json(path,recipe)
    self.send_json(200,{'ok':True,'configSaved':True,'message':'已写入测试 (1) 的配置，游戏内按 F3+T 重载生效。颜色仍由实际异火决定。'});return
   self.send_json(404,{'ok':False,'error':'接口不存在。'})
  except (ValueError,UnicodeDecodeError) as e:self.send_json(400,{'ok':False,'error':str(e)})
  except OSError as e:self.send_json(500,{'ok':False,'error':str(e)})

def main():
 global GAME
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--port',type=int,default=8831);parser.add_argument('--game-dir',type=Path,default=GAME);parser.add_argument('--open-browser',action='store_true');args=parser.parse_args()
 GAME=args.game_dir.resolve()
 # The instance was selected by the user; keep writes confined to that instance.
 if GAME.name!='测试 (1)':raise ValueError('本服务仅连接已选定的测试 (1)。')
 server=None
 for port in range(args.port,args.port+21):
  try:server=ThreadingHTTPServer(('127.0.0.1',port),Handler);break
  except OSError:continue
 if server is None:raise OSError('没有可用本地端口。')
 print(f'http://127.0.0.1:{server.server_port}/',flush=True)
 if args.open_browser:
  import webbrowser
  webbrowser.open(f'http://127.0.0.1:{server.server_port}/')
 server.serve_forever()

if __name__=='__main__':main()
