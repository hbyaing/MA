// Insert after fvCenter, before fvPeel. Compute time-only tongue geometry once
// per fragment, on the GPU, so the hash and trigonometry retain the same float
// implementation as the original density field. No CPU hash approximation.
// Native body and weapon fields are separate draws; keep their cache compact.
#ifdef FC_NATIVE_PEEL_CACHE
// Native draws bake invariant geometry once on the same GPU. Fetching this
// small shared table avoids large dynamically indexed private arrays per ray.
uniform sampler2D CurveCenters;
vec4 fvGetPeelRoot(int i){return texelFetch(CurveCenters,ivec2(i*3,0),0);}
vec4 fvGetPeelAxis(int i){return texelFetch(CurveCenters,ivec2(i*3+1,0),0);}
vec3 fvGetPeelRadial(int i){return texelFetch(CurveCenters,ivec2(i*3+2,0),0).xyz;}
vec4 fvGetTongueRoot(int i){return texelFetch(CurveCenters,ivec2(48+i*3,0),0);}
vec4 fvGetTongueAxis(int i){return texelFetch(CurveCenters,ivec2(49+i*3,0),0);}
vec4 fvGetTongueRadial(int i){return texelFetch(CurveCenters,ivec2(50+i*3,0),0);}
int fvCoilCacheBase(int field){return 0;}
void fvPrepareCache(float t){}
#else
#ifdef FC_SINGLE_COIL
const int FC_PEEL_CAPACITY = 16;
const int FC_TONGUE_CAPACITY = 6;
#else
const int FC_PEEL_CAPACITY = 48;
const int FC_TONGUE_CAPACITY = 12;
#endif

vec4 fvPeelRoots[FC_PEEL_CAPACITY];   // xyz: root, w: life
vec4 fvPeelAxes[FC_PEEL_CAPACITY];    // xyz: axis, w: length
vec3 fvPeelRadials[FC_PEEL_CAPACITY];
vec4 fvTongueRoots[FC_TONGUE_CAPACITY];   // xyz: root, w: length
vec4 fvTongueAxes[FC_TONGUE_CAPACITY];    // xyz: axis, w: life
vec4 fvTongueRadials[FC_TONGUE_CAPACITY]; // xyz: radial, w: random

vec4 fvGetPeelRoot(int i){return fvPeelRoots[i];}
vec4 fvGetPeelAxis(int i){return fvPeelAxes[i];}
vec3 fvGetPeelRadial(int i){return fvPeelRadials[i];}
vec4 fvGetTongueRoot(int i){return fvTongueRoots[i];}
vec4 fvGetTongueAxis(int i){return fvTongueAxes[i];}
vec4 fvGetTongueRadial(int i){return fvTongueRadials[i];}

int fvCoilCacheBase(int field) {
#ifdef FC_SINGLE_COIL
    return 0;
#else
    return field*16;
#endif
}

void fvPrepareCoilCache(int cacheBase,float t,float seed,float h,float radius,float widthInput,float turns,float wave,int count) {
    for(int j=0;j<8;j++) {
        if(j>=count)break;
        float strand=float(j),hierarchy=j==0?1.:(j==1?.58:.38);
        float width=widthInput*hierarchy;
        for(int i=0;i<2;i++) {
            int index=cacheBase+j*2+i;
            float k=float(i),clock=t*(.37+RiseSpeed*.15)+k*.413+strand*.193,age=fract(clock),birth=floor(clock);
            float life=smoothstep(0.,.12,age)*(1.-smoothstep(.56,1.,age));
            fvPeelRoots[index].w=life;
            if(life==0.)continue;
            float rootS=.10+.68*fvHash(vec3(k+strand*7.,seed,birth));
            vec3 root=fvCenter(rootS,strand,t,seed,radius,h,turns,wave,count);
            vec3 radial=normalize(vec3(root.x,0,root.z)),side=vec3(-radial.z,0,radial.x);
            float len=width*(1.25+TongueLength*.45)*(.5+.5*sin(age*FC_PI*.5));
            vec3 axis=normalize(vec3(0,1.,0)+radial*(.10+.12*age)+side*.14);
            fvPeelRoots[index]=vec4(root,life);
            fvPeelAxes[index]=vec4(axis,len);
            fvPeelRadials[index]=radial;
        }
    }
}

void fvPrepareWeaponTongues(int weapon,float t,float seed,float lengthBlade,float bladeRadius) {
    for(int j=0;j<6;j++) {
        int index=weapon*6+j;
        float k=float(j),clock=t*.43+k*.167,age=fract(clock),birth=floor(clock);
        float random=fvHash(vec3(k,seed,birth)),a=FC_TAU*random+t*RotationSpeed*.23;
        vec3 radial=vec3(cos(a),0,sin(a)),side=vec3(-sin(a),0,cos(a));
        vec3 root=radial*(bladeRadius+WeaponRadius*.25)+vec3(0,.04+lengthBlade*(.10+k*.13+.05*random),0);
        vec3 axis=normalize(radial*.42+vec3(0,1.0,0)+side*.36);
        float tongueLength=WeaponWidth*(1.9+.7*random)*(.45+.55*age);
        fvTongueRoots[index]=vec4(root,tongueLength);
        fvTongueAxes[index]=vec4(axis,sin(age*FC_PI));
        fvTongueRadials[index]=vec4(radial,random);
    }
}

void fvPrepareCache(float t) {
    float seed=float(Seed%997)*.071;
    if(BodyEnabled!=0)
        fvPrepareCoilCache(fvCoilCacheBase(0),t,seed,max(Height,.2),Radius,Width,Turns,WaveAmplitude,Strands);
    for(int j=0;j<2;j++) {
        if(j>=WeaponCount)break;
        float weaponSeed=seed+float(j)*2.13;
        fvPrepareCoilCache(fvCoilCacheBase(j+1),t,weaponSeed,max(.2,WeaponOrigins[j].w),
            WeaponAxes[j].w+WeaponRadius,WeaponWidth,WeaponTurns,WaveAmplitude*.25,Strands);
        fvPrepareWeaponTongues(j,t,weaponSeed,WeaponOrigins[j].w,WeaponAxes[j].w);
    }
}
#endif
