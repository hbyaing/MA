// Conservative ray support. The original fixed integration indices, midpoint
// positions and step lengths remain unchanged; an empty bit skips a zero field.
uniform sampler2D SupportSpheres;
uniform int SupportSphereCount;
#ifdef FC_POINT_GRID
uniform usampler2D PointGrid;
uniform vec3 PointGridMin,PointGridInvVoxel;
uniform int PointGridSize;
// Every occupied voxel includes every strand support sphere intersecting its
// full cell box. An integer texel keeps all strand bits; no filtering is used.
uint fvPointGridMask(vec3 localPoint){
 if(SupportSphereCount<0||PointGridSize<=0||any(lessThanEqual(PointGridInvVoxel,vec3(0.))))return 0xffu;
 vec3 voxel=(localPoint-PointGridMin)*PointGridInvVoxel;
 if(any(lessThan(voxel,vec3(0.)))||any(greaterThanEqual(voxel,vec3(float(PointGridSize)))))return 0u;
 ivec3 cell=ivec3(floor(voxel));
 return texelFetch(PointGrid,ivec2(cell.x+cell.y*PointGridSize,cell.z),0).r;
}
#endif
#ifdef FC_POINT_BINS
// Each native single-field draw stores a conservative local support AABB for
// every strand/y bin. Metadata and bounds live after its at-most-256 balls.
// These boxes already include warp, so query the unwarped local field point.
bool fvPointBinSupported(vec3 localPoint,int strand){
 if(SupportSphereCount<32*(strand+1)||SupportSphereCount>256)return true;
 vec4 meta=texelFetch(SupportSpheres,ivec2(strand,2),0);
 if(meta.w<.5||meta.y<=0.)return true;
 if(localPoint.y<meta.x||localPoint.y>meta.z)return false;
 int bin=clamp(int(floor((localPoint.y-meta.x)*meta.y)),0,31);
 vec4 bounds=texelFetch(SupportSpheres,ivec2(strand*32+bin,1),0);
 return localPoint.x>=bounds.x&&localPoint.x<=bounds.y&&localPoint.z>=bounds.z&&localPoint.z<=bounds.w;
}
#endif
#ifdef FC_POINT_SUPPORT
// Main density can be nonzero only within 2.5*w of its final curve point.
// w<=.72*width*hierarchy, curve y differs from .055+s*h by at most
// .25*abs(wave), and warp changes y by at most .045*abs(Turbulence).
// This y interval therefore includes every segment that could contribute.
bool fvPointMainSupported(vec3 localPoint,float h,float widthInput,float waveInput,float hierarchy,int strand){
 // Negative clocks or an incomplete table retain the unculled analytic path.
 if(SupportSphereCount<32*(strand+1))return true;
 float reach=1.801*abs(widthInput)*hierarchy+.25*abs(waveInput)+.045*abs(Turbulence)+.001;
 int lo=max(0,int(floor((localPoint.y-.055-reach)/h*32.))-1);
 int hi=min(31,int(floor((localPoint.y-.055+reach)/h*32.))+1);
 for(int segment=lo;segment<=hi;segment++){
  int index=strand*32+segment;
  vec4 sphere=texelFetch(SupportSpheres,ivec2(index%256,index/256),0);
  vec3 delta=fvSupportQueryPoint-sphere.xyz;
  if(dot(delta,delta)<=sphere.w*sphere.w)return true;
 }
 return false;
}
#endif
uint fvRayMask[16];
vec3 fvSupportOrigin,fvSupportDirection;
float fvSupportFirst,fvSupportLast,fvSupportStep;
int fvSupportSteps;

void fvMarkRayInterval(float enter,float leave){
 if(leave<fvSupportFirst||enter>fvSupportLast)return;
 // An extra sample on each side protects rounding at interval endpoints.
 int lo=max(0,int(floor((max(enter,fvSupportFirst)-fvSupportFirst)/fvSupportStep-.5))-1);
 int hi=min(fvSupportSteps-1,int(ceil((min(leave,fvSupportLast)-fvSupportFirst)/fvSupportStep-.5))+1);
 int firstWord=lo/32,lastWord=hi/32;
 for(int word=firstWord;word<=lastWord;word++){
  uint bits=0xffffffffu;
  if(word==firstWord)bits&=0xffffffffu<<uint(lo&31);
  if(word==lastWord)bits&=0xffffffffu>>uint(31-(hi&31));
  fvRayMask[word]|=bits;
 }
}

void fvMarkSupportSphere(vec3 center,float radius){
 vec3 delta=center-fvSupportOrigin;
 float along=dot(delta,fvSupportDirection);
 float squared=radius*radius-(dot(delta,delta)-along*along);
 if(squared<0.)return;
 float reach=sqrt(max(0.,squared));
 fvMarkRayInterval(along-reach,along+reach);
}

vec3 fvSupportWeaponPoint(vec3 p,int weapon){
 vec3 side=WeaponSides[weapon].xyz,axis=WeaponAxes[weapon].xyz;
 float ss=dot(side,side),aa=dot(axis,axis),sa=dot(side,axis),det=max(1.e-8,ss*aa-sa*sa);
 return WeaponOrigins[weapon].xyz+(side*(aa*p.x-sa*p.y)+axis*(ss*p.y-sa*p.x)+cross(side,axis)*p.z)/det;
}

float fvSupportWeaponStretch(int weapon){
 vec3 side=WeaponSides[weapon].xyz,axis=WeaponAxes[weapon].xyz;
 float ss=dot(side,side),aa=dot(axis,axis),sa=dot(side,axis),det=ss*aa-sa*sa;
 return 1.00001/sqrt(max(1.e-8,min(det,.5*(ss+aa-length(vec2(ss-aa,2.*sa))))));
}

void fvMarkPeelSupport(int cacheBase,int weapon,float widthInput){
 float warp=.077944*Turbulence+.001;
 float stretch=weapon<0?1.:fvSupportWeaponStretch(weapon);
 for(int j=0;j<8;j++){
  if(j>=Strands)break;
  float hierarchy=j==0?1.:(j==1?.58:.38),width=widthInput*hierarchy;
  float support=width*.4+(width*.33+.002)*sqrt(GaussianExponentLimit/.6)+warp;
  for(int k=0;k<2;k++){
   int index=cacheBase+j*2+k;
   vec4 rootLife=fvGetPeelRoot(index);if(rootLife.w==0.)continue;
   vec4 cachedAxis=fvGetPeelAxis(index);float len=cachedAxis.w;
   vec3 center=rootLife.xyz+cachedAxis.xyz*(len*.5);
   if(weapon>=0)center=fvSupportWeaponPoint(center,weapon);
   fvMarkSupportSphere(center,(len*.5+support)*stretch);
  }
 }
}

void fvPrepareRaySupport(vec3 ro,vec3 rd,float first,float last,float stepLength,int steps){
 if(SupportSphereCount<0){for(int word=0;word<16;word++)fvRayMask[word]=0xffffffffu;return;}
 for(int word=0;word<16;word++)fvRayMask[word]=0u;
 fvSupportOrigin=ro;fvSupportDirection=rd;
 fvSupportFirst=first;fvSupportLast=last;fvSupportStep=max(stepLength,1.e-8);fvSupportSteps=steps;
 for(int j=0;j<768;j++){
  if(j>=SupportSphereCount)break;
  vec4 sphere=texelFetch(SupportSpheres,ivec2(j%256,j/256),0);
  fvMarkSupportSphere(sphere.xyz,sphere.w);
 }
 if(BodyEnabled!=0)fvMarkPeelSupport(fvCoilCacheBase(0),-1,Width);
 for(int weapon=0;weapon<2;weapon++){
  if(weapon>=WeaponCount)break;
  fvMarkPeelSupport(fvCoilCacheBase(weapon+1),weapon,WeaponWidth);
  float width=WeaponWidth*.54+.002;
  float support=WeaponWidth*.82+sqrt(max(width*width,.000012)*GaussianExponentLimit)+.077944*Turbulence+.001;
  float stretch=fvSupportWeaponStretch(weapon);
  for(int j=0;j<6;j++){
   int index=weapon*6+j;
   vec4 cachedAxis=fvGetTongueAxis(index);if(cachedAxis.w==0.)continue;
   vec4 rootLength=fvGetTongueRoot(index);float len=rootLength.w;
   vec3 center=rootLength.xyz+cachedAxis.xyz*(len*.5);
   fvMarkSupportSphere(fvSupportWeaponPoint(center,weapon),(len*.5+support)*stretch);
  }
 }
 for(int j=0;j<24;j++){
  if(j>=WispCount)break;
  fvMarkSupportSphere(Wisps[j].xyz,max(Wisps[j].w,.01)*3.391166+.001);
 }
}

bool fvRaySampleSupported(int index){return (fvRayMask[index/32]&(1u<<uint(index&31)))!=0u;}
bool fvRayWordEmpty(int index){return fvRayMask[index/32]==0u;}
bool fvRayAnySupported(){
 uint anyBits=0u;for(int word=0;word<16;word++)anyBits|=fvRayMask[word];
 return anyBits!=0u;
}
