import sys
from serve import main
if __name__=='__main__':
 sys.argv += ['--port','8831','--open-browser']
 main()
