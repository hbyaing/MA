// Same conservative main-curve support as native SupportBounds.java. Its small
// float guard encloses CPU/GPU evaluation differences; this never shades fire.
export const SUPPORT_TEXTURE_WIDTH=256,SUPPORT_TEXTURE_HEIGHT=3;
const SEGMENTS=32,f=Math.fround;
function center(s,strand,t,seed,radius,height,turns,wave,count,rotation,waveSpeed){
 const phase=strand/Math.max(count,1)+.09*Math.sin(strand*2.4),w=s*8.7-t*waveSpeed*.8+seed*2.1+strand*2.3;
 const sweep=s+.12*Math.sin(s*6.283-t*.31+strand*1.7)+.045*Math.sin(s*13-t*.47+strand);
 const angle=6.28318530718*(sweep*turns+phase+t*rotation*.48)+.24*Math.sin(w*.71)+.10*Math.sin(w*1.63);
 const envelope=Math.max(0,Math.sin(s*3.14159265359)),rr=radius*(.84+.16*envelope)+wave*(Math.sin(w)*.85+Math.sin(w*1.63)*.38)*(.65+.35*envelope);
 return [Math.cos(angle)*rr,.055+s*height+wave*.25*Math.sin(w*1.2),Math.sin(angle)*rr];
}
export function buildSupportBounds(recipe,time,weaponOrigins,weaponAxes,weaponSides,bodyEnabled,weaponCount,data=new Float32Array(256*3*4)){
 const r=recipe,t=f(time),seed=f(f(r.seed%997)*f(.071)),strands=r.strands,rotation=f(r.rotationSpeed),waveSpeed=f(r.waveSpeed),rise=f(r.riseSpeed);let count=0;
 if(!Number.isFinite(t)||Math.abs(t)>86400)return {data,count:-1};
 function coil(seed,height,radius,width,turns,wave,weapon){
  const a1=14.70*Math.abs(turns)+2.902,a2=77.56*Math.abs(turns)+29.28,ra=Math.abs(radius),wa=Math.abs(wave),r0=ra+1.231*wa,r1=.503*ra+14.14*wa,r2=1.58*ra+173.2*wa;
  const second=Math.hypot(r2+r0*a1*a1,2*r1*a1+r0*a2)+27.26*wa,chordError=second/(8*SEGMENTS*SEGMENTS),warp=.077944*f(r.turbulence),ds=1/SEGMENTS;
  const roundoff=.001+Math.abs(t)*1.e-5*(Math.abs(rotation)*r0+Math.abs(waveSpeed)*wa+Math.abs(rise*width)+Math.abs(turns)*r0*.12);
  for(let j=0;j<strands;j++){
   const hierarchy=j===0?1:j===1?.58:.38;let previous=center(0,j,t,seed,radius,height,turns,wave,strands,rotation,waveSpeed);
   for(let k=0;k<SEGMENTS;k++){
    const s0=k*ds,s1=(k+1)*ds,mid=(s0+s1)*.5,next=center(s1,j,t,seed,radius,height,turns,wave,strands,rotation,waveSpeed),along=mid*(8+turns*2)-t*rise*1.25+j*11;
    const crest=.5+.5*Math.sin(along*.82+.55*Math.sin(along*1.63+j)),crestUpper=Math.min(1,crest+.85826*Math.abs(8+turns*2)*ds*.5),peakS=Math.max(s0,Math.min(s1,.5)),ends=Math.pow(Math.max(0,Math.sin(peakS*Math.PI)),.65);
    const maxWidth=width*hierarchy*(.30+.42*Math.pow(Math.max(0,crestUpper),1.3))*(.42+.58*ends),dx=next[0]-previous[0],dy=next[1]-previous[1],dz=next[2]-previous[2];
    let support=.5*Math.sqrt(dx*dx+dy*dy+dz*dz)+chordError+warp+2.5*maxWidth+roundoff,x=(previous[0]+next[0])*.5,y=(previous[1]+next[1])*.5,z=(previous[2]+next[2])*.5;
    if(weapon>=0){const at=weapon*4,ox=weaponSides[at+1]*weaponAxes[at+2]-weaponSides[at+2]*weaponAxes[at+1],oy=weaponSides[at+2]*weaponAxes[at]-weaponSides[at]*weaponAxes[at+2],oz=weaponSides[at]*weaponAxes[at+1]-weaponSides[at+1]*weaponAxes[at];
     const ss=weaponSides[at]**2+weaponSides[at+1]**2+weaponSides[at+2]**2,aa=weaponAxes[at]**2+weaponAxes[at+1]**2+weaponAxes[at+2]**2,sa=weaponSides[at]*weaponAxes[at]+weaponSides[at+1]*weaponAxes[at+1]+weaponSides[at+2]*weaponAxes[at+2],det=Math.max(1e-8,ss*aa-sa*sa),sx=aa*x-sa*y,ay=ss*y-sa*x;
     support*=1.00001/Math.sqrt(Math.max(1e-8,Math.min(det,.5*(ss+aa-Math.hypot(ss-aa,2*sa)))));
     [x,y,z]=[weaponOrigins[at]+(weaponSides[at]*sx+weaponAxes[at]*ay+ox*z)/det,weaponOrigins[at+1]+(weaponSides[at+1]*sx+weaponAxes[at+1]*ay+oy*z)/det,weaponOrigins[at+2]+(weaponSides[at+2]*sx+weaponAxes[at+2]*ay+oz*z)/det];}
    data.set([x,y,z,support],count++*4);previous=next;
   }
  }
 }
 if(bodyEnabled)coil(seed,Math.max(.2,f(r.height)),f(r.radius),f(r.width),f(r.turns),f(r.waveAmplitude),-1);
 for(let j=0;j<weaponCount;j++){const at=j*4;coil(f(seed+f(j*2.13)),Math.max(.2,weaponOrigins[at+3]),f(weaponAxes[at+3]+f(r.weaponRadius)),f(r.weaponWidth),f(r.weaponTurns),f(f(r.waveAmplitude)*.25),j);}
 return {data,count};
}
