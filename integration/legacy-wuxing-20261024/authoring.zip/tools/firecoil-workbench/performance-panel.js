import {measureGpu} from './gpu-benchmark.mjs';

const $=id=>document.getElementById(id);
const download=(value,name)=>{const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
function difference(a,b){let square=0,absolute=0,active=0,max=0;for(let i=0;i<a.length;i+=4){const delta=Math.max(Math.abs(a[i]-b[i]),Math.abs(a[i+1]-b[i+1]),Math.abs(a[i+2]-b[i+2]));if(delta||Math.max(a[i],a[i+1],a[i+2])>40)active++;max=Math.max(max,delta);for(let c=0;c<3;c++){const d=a[i+c]-b[i+c];square+=d*d;absolute+=Math.abs(d);}}return {rmse255:Math.sqrt(square/(a.length/4*3)),meanAbsolute255:absolute/(a.length/4*3),maxChannel255:max,activePixels:active};}

export function attachPerformancePanel(preview){
 let report=null;
 $('quality').addEventListener('change',()=>preview.setQuality($('quality').value));
 $('export-performance').addEventListener('click',()=>{if(report)download(report,`异火性能对照-${Date.now()}.json`);});
 $('benchmark').addEventListener('click',async()=>{
  if(preview.benchmarking)return;
  const button=$('benchmark'),out=$('performance-result'),quality=preview.quality,wasPaused=preview.paused;
  const stamp=()=>JSON.stringify([preview.recipe,preview.camera,preview.layers,preview.moving,preview.firstPerson,preview.canvas.clientWidth,preview.canvas.clientHeight]);
  preview.paused=true;preview.benchmarking=true;preview.updateVisibility();button.disabled=true;$('quality').disabled=true;$('export-performance').disabled=true;
  out.textContent='冻结同一时刻，准备 GPU 对照…';delete out.dataset.report;report=null;
  try{
   preview.setTime(Number($('sample-time').value));const scene=stamp();
   const debug=preview.gl.getExtension('WEBGL_debug_renderer_info');
   report={scope:'完整工作台绘制：场景、复制、体积、光晕、余烬；非游戏 FPS',gpu:debug?preview.gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):preview.gl.getParameter(preview.gl.RENDERER),time:preview.simulation.previousTime,recipe:{...preview.recipe},camera:{...preview.camera},layers:{...preview.layers},moving:preview.moving,firstPerson:preview.firstPerson,modes:{},images:{},createdAt:new Date().toISOString()};
   const images={};
   for(const mode of ['reference','native','balanced']){
    preview.quality=mode;
    const result=await measureGpu(preview.gl,()=>{if(stamp()!==scene)throw new Error('画面或参数变化，本轮测量已作废，请重试。');preview.render();},{warmup:2,samples:5,onProgress:p=>{out.textContent=`${mode==='reference'?'完整计算原生':mode==='native'?'优化原生':'均衡'}：${p.phase==='warmup'?'预热':'采样'} ${p.completed}/${p.total}`;}});
    if(!result.supported){out.textContent=result.reason;report=null;return;}
    // Readback and image comparison are outside all GPU query intervals.
    preview.render();const pixels=new Uint8Array(preview.canvas.width*preview.canvas.height*4);preview.gl.readPixels(0,0,preview.canvas.width,preview.canvas.height,preview.gl.RGBA,preview.gl.UNSIGNED_BYTE,pixels);images[mode]=pixels;
    report.modes[mode]={...result,...preview.getStats(),gpuRenderer:result.renderer};
   }
   report.images.nativeVsReference=difference(images.reference,images.native);report.images.balancedVsReference=difference(images.reference,images.balanced);
   report.reductionPercent=100*(1-report.modes.native.medianMs/report.modes.reference.medianMs);
   report.balancedReductionPercent=100*(1-report.modes.balanced.medianMs/report.modes.reference.medianMs);
   out.textContent=`完整计算原生 ${report.modes.reference.medianMs.toFixed(2)} ms → 当前默认原生 ${report.modes.native.medianMs.toFixed(2)} ms（GPU 中位数下降 ${report.reductionPercent.toFixed(1)}%）\n${report.modes.native.canvasSize.join('×')} 输出 / ${report.modes.native.integrationSize.join('×')} 积分，${preview.recipe.segments} 步；每组预热 2 帧、测 5 帧。\n可选半尺寸 ${report.modes.balanced.medianMs.toFixed(2)} ms，会损失细焰细节。`;
   out.dataset.report=JSON.stringify(report);$('export-performance').disabled=false;
  }catch(error){report=null;out.textContent=`测量未完成：${error.message}`;delete out.dataset.report;}
  finally{preview.quality=quality;preview.benchmarking=false;preview.paused=wasPaused;preview.updateVisibility();preview.requestRender();button.disabled=false;$('quality').disabled=false;}
 });
}
