"""Import the user's ordered six-face references, preserving pixel art at 32x32."""
from pathlib import Path
import json
import shutil
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'source-assets/soul-healing-room-20261008'
OUT.mkdir(parents=True,exist_ok=True)
ASSETS=ROOT/'src/main/resources/assets/wuxingxiantu'
REFERENCES={
    'front':'a7c1d9c3-ad3d-461f-9f6b-292a9896ce82',
    'back':'f4f24c03-ad84-42c4-bd7e-d778870b52dc',
    'left':'075ef3c9-a562-403a-a30e-df07e7801deb',
    'right':'2cc39f29-9503-4ef3-b724-0608bab6c336',
    'top':'9ed502fd-f21d-461c-8d59-a05b31006d87',
    'bottom':'316ce821-5530-4aab-8116-035029df7a71',
}
preview=Image.new('RGB',(576,416),(28,36,40))
draw=ImageDraw.Draw(preview)
manifest={}
for i,(face,identifier) in enumerate(REFERENCES.items()):
    source=OUT/f'{face}-original.png'
    if not source.exists():
        shutil.copy2(Path('C:/Users/NOSTZE~1/AppData/Local/Temp')/f'codex-clipboard-{identifier}.png',source)
    original=Image.open(source).convert('RGBA')
    texture=original.resize((32,32),Image.Resampling.NEAREST)
    assert texture.getchannel('A').getextrema()==(255,255),f'{face}: block face has transparent holes'
    target=ASSETS/'textures/block'/f'soul_healing_room_{face}.png'
    if target.exists() and not (OUT/f'before-{face}.png').exists():shutil.copy2(target,OUT/f'before-{face}.png')
    texture.save(target)
    x=(i%3)*192;y=(i//3)*208
    preview.paste(texture.resize((192,192),Image.Resampling.NEAREST),(x,y))
    draw.text((x+8,y+194),face,fill=(220,240,240))
    manifest[face]={'source_size':original.size,'texture_size':texture.size,'source':source.name}
preview.save(OUT/'six-faces-preview.png')
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('PASS: six opaque 32x32 block faces in user-supplied order')
