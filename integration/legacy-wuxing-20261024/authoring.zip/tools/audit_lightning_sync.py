from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parent.parent
skills=[Path('C:/Users/Nostzephert/.codex/skills/minecraft-lightning'),Path('E:/着色器渲染/skill/minecraft-lightning')]
report=[]
def record(name,ok):
    report.append({'check':name,'passed':ok})
def normalized(p):
    return p.read_text(encoding='utf-8').replace('cn.blockforge.generated.generatedmod.client.tribulation','dev.lightninglab').replace('cn.blockforge.generated.generatedmod.GeneratedMod.MOD_ID','LightningLab.MOD_ID').replace('wuxingxiantu','lightninglab').replace('\r\n','\n').strip()
local=root/'src/main/java/cn/blockforge/generated/generatedmod/client/tribulation/LightningHalo.java'
for skill in skills:
    forge=skill/'assets/forge-1.20.1/src/main'
    record(str(skill)+' joint/core union',normalized(local)==normalized(forge/'java/dev/lightninglab/LightningHalo.java'))
    for file in ['bolt_halo.fsh','bolt_halo.json']:
        record(str(skill)+' '+file,normalized(root/'src/main/resources/assets/wuxingxiantu/shaders/core'/file)==normalized(forge/'resources/assets/lightninglab/shaders/core'/file))
    for file in ['gpu.js','presets/white-core-magenta-cyan.json']:
        record(str(skill)+' workbench '+file,normalized(root/'deliverables/electric-preview-20261010/workbench'/file)==normalized(skill/'assets/workbench'/file))
installed=Path('D:/MC/库/red.ghs.axolotl/profiles/测试 (1)/mods/wuxingxiantu-0.2-ui-lightning-20261010.jar')
artifact=root/'deliverables/wuxingxiantu-0.2-ui-lightning-20261010.jar'
record('installed JAR matches delivered JAR',hashlib.sha256(installed.read_bytes()).digest()==hashlib.sha256(artifact.read_bytes()).digest())
with zipfile.ZipFile(installed) as jar:
    for file in [*sorted((root/'src/main/resources/assets/wuxingxiantu/tribulation').glob('0*.json')),*sorted((root/'src/main/resources/assets/wuxingxiantu/shaders/core').glob('bolt_halo.*'))]:
        record('installed '+file.name,jar.read(file.relative_to(root/'src/main/resources').as_posix())==file.read_bytes())
    record('installed LightningHalo.drawCore',b'drawCore' in jar.read('cn/blockforge/generated/generatedmod/client/tribulation/LightningHalo.class'))
path=root/'reports/lightning-sync-audit-20261010.json'
path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
for item in report: print(('PASS' if item['passed'] else 'FAIL')+' '+item['check'])
raise SystemExit(0 if all(i['passed'] for i in report) else 1)
