"""Refine the existing UV atlas and keep the first-person grip fixed. No game build."""
from pathlib import Path
from PIL import Image, ImageDraw
import json
import math
import base64

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
SOURCE = ROOT / 'source-assets/heart_sword-original.png'
TARGET = ASSETS / 'textures/item/heart_sword.png'

def main():
    blockbench_path = ROOT / 'source-assets/heart_sword.bbmodel'
    blockbench = json.loads(blockbench_path.read_text(encoding='utf-8-sig'))
    if len(blockbench.get('textures', [])) > 1:
        raise SystemExit('Heart sword 2.0 uses multiple materials. Use tools/import_heart_sword_v2.py; this v1 tool must not overwrite its textures or transforms.')
    original = Image.open(SOURCE).convert('RGBA')
    result = original.copy()
    # Keep every UV island and its alpha coverage; deepen crystal facets without adding noise.
    for y in range(result.height):
        for x in range(result.width):
            r, g, b, a = original.getpixel((x, y))
            luminance = (r + g + b) / 3 / 255
            t = min(1, max(0, (luminance - .60) / .40)) ** 1.35
            low, high = (39, 94, 119), (239, 255, 251)
            color = tuple(round(lo + (hi-lo)*t) for lo, hi in zip(low, high))
            result.putpixel((x, y), (*color, a))
    draw = ImageDraw.Draw(result)
    # Existing blade islands: narrow luminous ridge, separated from darker bevels.
    for cx in (30, 84):
        draw.line([(cx, 16), (cx, 205)], fill=(219, 255, 244, 255), width=1)
        for y in (76, 113, 150):
            draw.line([(cx-2,y), (cx,y-4), (cx+2,y), (cx,y+4), (cx-2,y)], fill=(173,231,223,255))
    # Warm pale-metal accent on the two guard medallions, inside their existing UV rings.
    for cy in (49,145):
        draw.ellipse((197,cy-9,215,cy+9), outline=(224,218,166,255), width=1)
    result.putalpha(original.getchannel('A'))
    result.save(TARGET)
    blockbench['textures'][0]['source'] = 'data:image/png;base64,' + base64.b64encode(TARGET.read_bytes()).decode('ascii')
    blockbench_path.write_text(json.dumps(blockbench, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    model_path = ASSETS / 'models/item/heart_sword.json'
    model = json.loads(model_path.read_text(encoding='utf-8-sig'))
    rx, rz = math.radians(-12), math.radians(-14)
    # ItemTransform rotates XYZ, then ItemRenderer shifts by (-.5,-.5,-.5).
    # Cancel R*S*(grip - .5) for the OBJ grip (0,-.2,0), retaining its prior anchor.
    x, y, z = .5, .7, .5
    x, y = x*math.cos(rz)-y*math.sin(rz), x*math.sin(rz)+y*math.cos(rz)
    y, z = y*math.cos(rx)-z*math.sin(rx), y*math.sin(rx)+z*math.cos(rx)
    for hand in ('firstperson_righthand', 'firstperson_lefthand'):
        model['display'][hand] = {'rotation': [-12, 0, -14],
            'translation': [round(v*.55*16, 6) for v in (x,y,z)], 'scale': [.55]*3}
    model_path.write_text(json.dumps(model, indent=2)+'\n', encoding='utf-8')
    preview = Image.new('RGB', (1024,512), (25,32,37))
    preview.paste(original.resize((512,512),Image.Resampling.NEAREST),(0,0))
    preview.paste(result.resize((512,512),Image.Resampling.NEAREST),(512,0))
    preview.save(ROOT/'source-assets/heart_sword-texture-comparison.png')
    assert original.size == result.size and original.getchannel('A').tobytes() == result.getchannel('A').tobytes()
    print('Atlas refined; UV dimensions/alpha preserved; grip-compensated first-person transforms written.')

if __name__ == '__main__':
    main()
