from pathlib import Path
import json, shutil, zipfile, hashlib

ROOT=Path(__file__).resolve().parents[1]
dest=ROOT/'deliverables/玄灵铁砧'
dest.mkdir(parents=True,exist_ok=True)
jar=ROOT/'build/libs/wuxingxiantu-0.2.jar'
resources=ROOT/'src/main/resources'
model_path=resources/'assets/wuxingxiantu/models/block/xuanling_anvil.json'
model=json.loads(model_path.read_text(encoding='utf-8'))
assert len(model['elements'])==390
for element in model['elements']:
    assert all(-16<=v<=32 for p in ['from','to'] for v in element[p])
    assert all(element['from'][i]<element['to'][i] for i in range(3))
    assert all(0<=v<=16 for f in element['faces'].values() for v in f['uv'])
required=[
 'assets/wuxingxiantu/models/block/xuanling_anvil.json',
 'assets/wuxingxiantu/textures/block/xuanling_anvil.png',
 'assets/wuxingxiantu/models/item/xuanling_anvil.json',
 'assets/wuxingxiantu/blockstates/xuanling_anvil.json',
 'data/wuxingxiantu/recipes/xuanling_anvil.json',
 'data/wuxingxiantu/loot_tables/blocks/xuanling_anvil.json']
with zipfile.ZipFile(jar) as z:
    for entry in required:assert z.read(entry)==(resources/entry).read_bytes(),entry
    for name in ['XuanlingAnvilBlock','XuanlingAnvilMenu','client/XuanlingAnvilScreen','balance/XuanlingAnvilBalance']:
        assert 'cn/blockforge/generated/generatedmod/'+name+'.class' in z.namelist()
    assert not any('XuanlingAnvilGameTests' in entry for entry in z.namelist())
    assert json.loads(z.read('assets/wuxingxiantu/lang/zh_cn.json'))['block.wuxingxiantu.xuanling_anvil']=='玄灵铁砧'
for source,name in [(jar,'wuxingxiantu-0.2-20261012-xuanling-anvil.jar'),
    (ROOT/'source-assets/xuantie-spirit-anvil/reference-textured/玄灵铁砧.bbmodel','玄灵铁砧.bbmodel'),
    (ROOT/'source-assets/xuantie-spirit-anvil/reference-textured/reference_albedo.png','玄灵铁砧贴图.png'),
    (ROOT/'source-assets/xuantie-spirit-anvil/玄灵铁砧玩法说明.md','玩法说明.md')]:shutil.copy2(source,dest/name)
report={'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'cubes':390,'verified_resources':required,
        'build':'passed','server_gametests':'4/4 passed','resource_tests':'14/14 passed',
        'client_visual_test':'not run','installed':False}
(dest/'验证报告.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
