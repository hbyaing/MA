"""Verify the built artifact contains original-resolution crops, then stage it for manual testing."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports/ui-reference-install-20261007"
JAR = ROOT / "build/libs/wuxingxiantu-0.2.jar"
TARGET = ROOT / "deliverables/wuxingxiantu-0.2-20261007-ui-reference-domain.jar"
PREFIX = "assets/wuxingxiantu/textures/gui/wuxia/reference/"


def main():
    def log_text(name):
        raw=(REPORT / name).read_bytes()
        return raw.decode("utf-16" if raw.startswith((b"\xff\xfe",b"\xfe\xff")) else "utf-8-sig",errors="replace")
    assert (REPORT / "build.exit").read_text().strip() == "0"
    assert "BUILD SUCCESSFUL" in log_text("build.log")
    assert "All 10 required tests passed" in log_text("domain-tests.log")
    assert "PASS: 20" in log_text("layout.log")
    assets=json.loads((REPORT / "assets.json").read_text(encoding="utf-8"))
    assert assets["icon_resampling"] is False and assets["redrawn_icons"] is False
    with zipfile.ZipFile(JAR) as archive:
        names=set(archive.namelist())
        for asset in assets["assets"]:
            expected=(ROOT / asset["source"]).read_bytes()
            actual=archive.read(PREFIX+asset["path"])
            assert actual==expected, asset["path"]
            assert hashlib.sha256(actual).hexdigest()==asset["sha256"]
        assert not any(n.startswith(PREFIX+"icons/16/") or n.startswith(PREFIX+"slot/20/") for n in names)
        assert not any("DomainSelectionGameTests" in n or "CultivationUiSmokeTest" in n for n in names)
        assert not any(n.startswith("software/bernie/") for n in names)
        assert "cn/blockforge/generated/generatedmod/client/CultivationReferenceAssets.class" in names
    TARGET.parent.mkdir(exist_ok=True)
    shutil.copy2(JAR,TARGET)
    digest=hashlib.sha256(TARGET.read_bytes()).hexdigest()
    (TARGET.with_suffix(".jar.sha256")).write_text(digest+"  "+TARGET.name+"\n",encoding="ascii")
    report={"artifact":str(TARGET),"size":TARGET.stat().st_size,"sha256":digest,
            "original_crop_images_verified":assets["images"],"pixel_draft_excluded":True,
            "test_fixtures_excluded":True,"geckolib_stubs_excluded":True,
            "build_passed":True,"resource_checks":13,"layout_cases":20,
            "targeted_required_gametests":10,"full_gametest_run":False,"client_runtime_verified":False}
    (REPORT / "artifact-verification.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=="__main__":main()
