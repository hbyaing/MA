"""Verify furnace camera stability, exact GPU output and the release JAR.

Usage: python tools/verify_furnace_stability_release.py artifact.jar [installed.jar]
Evidence defaults to reports/furnace-stability-20261014. Missing or incomplete
evidence is a failure; this script never fills missing fields with defaults.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
import math
from pathlib import Path
import re
import statistics
import struct
import sys
from zipfile import ZipFile
import zlib

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = "cn/blockforge/generated/generatedmod/"
RESOURCES = ROOT / "src/main/resources"
SCENES = (
    "front-left", "front-center", "front-right", "front-return", "north",
    "east", "south", "west", "near-front", "far-front", "high-front",
    "low-front", "diagonal", "near-side", "bob-before", "bob-walking", "bob-stopped",
)


class VerificationError(Exception):
    pass


def check(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def number(value, label: str) -> float:
    check(type(value) in (int, float) and math.isfinite(value), f"{label}: finite number required")
    return float(value)


def vector(value, length: int, label: str) -> list[float]:
    check(isinstance(value, list) and len(value) == length, f"{label}: {length} values required")
    return [number(v, label) for v in value]


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest().upper()


def read_json(path: Path) -> dict:
    check(path.is_file(), f"Missing evidence: {path}")
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    check(isinstance(value, dict), f"Object report required: {path}")
    return value


def verify_png(path: Path) -> None:
    """Read actual image dimensions and check complete, decodable PNG data."""
    check(path.is_file(), f"Missing screenshot: {path}")
    data = path.read_bytes()
    check(data[:8] == b"\x89PNG\r\n\x1a\n", f"Invalid PNG: {path}")
    offset, payloads, header, ended = 8, [], None, False
    while offset + 12 <= len(data):
        length = struct.unpack_from(">I", data, offset)[0]
        tag = data[offset + 4:offset + 8]
        stop = offset + 8 + length
        check(stop + 4 <= len(data), f"Truncated PNG: {path}")
        payload = data[offset + 8:stop]
        crc = struct.unpack_from(">I", data, stop)[0]
        check(zlib.crc32(tag + payload) & 0xFFFFFFFF == crc, f"PNG checksum failure: {path}")
        if tag == b"IHDR":
            check(header is None and length == 13, f"Invalid PNG header: {path}")
            header = struct.unpack(">IIBBBBB", payload)
        elif tag == b"IDAT":
            payloads.append(payload)
        elif tag == b"IEND":
            ended = True
            break
        offset = stop + 4
    check(ended and header is not None and payloads, f"Incomplete PNG: {path}")
    width, height, bits, color, compression, filtering, interlace = header
    check((width, height) == (1280, 900), f"Screenshot is {width} x {height}, expected 1280 x 900: {path}")
    check(bits == 8 and color in (2, 6) and (compression, filtering, interlace) == (0, 0, 0),
          f"Unexpected screenshot PNG layout: {path}")
    pixels = zlib.decompress(b"".join(payloads))
    channels = 3 if color == 2 else 4
    row_size = 1 + width * channels
    check(len(pixels) == height * row_size, f"PNG pixel payload incomplete: {path}")
    check(all(pixels[y * row_size] <= 4 for y in range(height)), f"PNG row filter invalid: {path}")
    check(len(set(pixels)) > 8, f"Screenshot pixel payload appears empty: {path}")


def verify_jar(source: Path, installed: Path | None) -> dict:
    check(source.is_file(), f"Artifact does not exist: {source}")
    if installed is not None:
        check(installed.is_file(), f"Installed JAR does not exist: {installed}")
        check(digest(source) == digest(installed), "Installed JAR differs from the validated artifact")
    with ZipFile(source) as jar:
        names = set(jar.namelist())
        for name in ("VolumeGpu", "FurnaceFireVolume", "FireCornerCache", "FireBedNoiseCache"):
            check(PACKAGE + "client/furnacevolume/" + name + ".class" in names, f"Missing production class: {name}")
        gpu = jar.read(PACKAGE + "client/furnacevolume/VolumeGpu.class")
        check(b"FireBedNoiseCache" in gpu and b"InverseLocalProjection" in gpu,
              "VolumeGpu lacks the new noise-cache or local-projection integration")
        bed = "assets/wuxingxiantu/shaders/furnacevolume/bed_noise.glsl"
        check(bed in names and jar.read(bed), "Missing bed_noise.glsl resource")
        # Derive exact QA class prefixes from non-production source sets, including nested classes.
        qa_prefixes = set()
        for directory in (ROOT / "src").iterdir():
            if not directory.is_dir() or directory.name == "main":
                continue
            for file in directory.rglob("*.java"):
                match = re.search(r"^\s*package\s+([\w.]+)\s*;", file.read_text(encoding="utf-8-sig"), re.M)
                if match:
                    qa_prefixes.add(match.group(1).replace(".", "/") + "/" + file.stem)
        qa_tokens = ("GameTests", "ClientCapture", "DomainUiCapture", "VolumePerformanceProbe",
                     "BaselineHostScan", "FurnaceMotionFixture", "Regression")
        for name in names:
            if name.endswith(".class"):
                check(not any(token in name for token in qa_tokens), f"QA class leaked into JAR: {name}")
                check(not any(name == prefix + ".class" or name.startswith(prefix + "$") for prefix in qa_prefixes),
                      f"Non-production source-set class leaked into JAR: {name}")
        checked = 0
        for file in RESOURCES.rglob("*"):
            if not file.is_file():
                continue
            name = file.relative_to(RESOURCES).as_posix()
            # Forge expands the metadata placeholders during processResources.
            expected = ROOT / "build/resources/main" / name if name == "META-INF/mods.toml" else file
            check(expected.is_file(), f"Missing processed metadata: {expected}")
            check(name in names and jar.read(name) == expected.read_bytes(), f"Resource differs from current main source: {name}")
            checked += 1
    return {"source": str(source), "installed": str(installed) if installed else None,
            "sha256": digest(source), "resourcesVerified": checked, "qaClassesAbsent": True}


def verify_captures(folder: Path, expected_count: int) -> dict:
    check((folder / "complete.txt").is_file(), f"Capture did not complete: {folder}")
    check(not (folder / "failure.txt").exists(), f"Capture failure marker exists: {folder}")
    report = read_json(folder / "captures.json")
    check(report["isolated"] is True and report["failures"] == [], f"Capture is not isolated or failed: {folder}")
    rows = report["captures"]
    check(report["captureCount"] == expected_count and len(rows) == expected_count,
          f"Wrong capture count: {folder}")
    check(len({row["name"] for row in rows}) == expected_count, f"Duplicate captures: {folder}")
    for row in rows:
        label = f"{folder.name}/{row['name']}"
        check(row["glError"] == 0 and row["bottomVolumeDraws"] > 0, f"Actual furnace draw failed: {label}")
        check(Path(row["name"]).name == row["name"], f"Invalid screenshot name: {label}")
        verify_png(folder / row["name"])
    return report


def verify_aged(folder: Path, expected_fires: set[str], expected_clock: float = 339277.95) -> dict:
    report = verify_captures(folder, 11)
    names = {row["name"] for row in report["captures"]}
    check(names == {f"furnace-tier-{tier}.png" for tier in range(1, 10)}
          | {"furnace-nirvana-310.png", "furnace-nirvana-325.png"}, f"Aged capture scenes incomplete: {folder}")
    paired = read_json(folder / "paired-gpu.json")
    cases = paired["cases"]
    check(len(cases) == 9 and {case["fire"] for case in cases} == expected_fires,
          f"Nine distinct catalog flames required: {folder}")
    check(paired["renderer"] and "GL_TIME_ELAPSED" in paired["measurement"], f"GPU timing metadata missing: {folder}")
    for row in cases:
        label = f"{folder.name}/{row['fire']}"
        check((row["width"], row["height"]) == (1280, 900), f"Wrong paired viewport: {label}")
        check(row["samplesPerVersion"] == 24 and row["activeChannels"] > 0, f"GPU comparison has no real output: {label}")
        check(row["glError"] == 0 and row["bedCacheEnabled"] is True, f"Noise cache inactive or GL failure: {label}")
        check(row["cornerCacheEnabled"] is True and row["bottomSpecialization"] is True, f"Expected shader specialization inactive: {label}")
        check(abs(number(row["timeSeconds"], label) - expected_clock) <= .03, f"Long-running clock not exercised: {label}")
        error = number(row["maxFloatError"], label)
        check(0 <= error <= 1e-5, f"Float output mismatch: {label}: {error}")
        rmse = number(row["rmse"], label)
        check(0 <= rmse <= error + 1e-8, f"Invalid RMSE: {label}")
        before, after = number(row["baselineGpuMs"], label), number(row["optimizedGpuMs"], label)
        check(0 < after < before, f"No measured GPU improvement: {label}: {before} -> {after}")
    return {"captures": 11, "pairedCases": 9, "clockSeconds": [row["timeSeconds"] for row in cases],
            "medianSavedPercent": statistics.median((1 - row["optimizedGpuMs"] / row["baselineGpuMs"]) * 100 for row in cases),
            "medianBaselineGpuMs": statistics.median(row["baselineGpuMs"] for row in cases),
            "medianOptimizedGpuMs": statistics.median(row["optimizedGpuMs"] for row in cases),
            "maxFloatError": max(row["maxFloatError"] for row in cases)}


def verify_motion(folder: Path) -> dict:
    report = verify_captures(folder, 18)
    check(report["test"] == "furnace-fixed-field-real-camera-motion", f"Wrong motion fixture: {folder}")
    rows = report["captures"]
    expected_names = {f"furnace-motion-{index:02d}-{scene}.png" for index, scene in enumerate(SCENES, 1)}
    expected_names.add("furnace-motion-02-front-slide-mid.png")
    check({row["name"] for row in rows} == expected_names, f"Motion scenes incomplete: {folder}")
    summary = report["furnaceMotionValidation"]
    check(summary["expectedCaptures"] == 18 and summary["observedCaptures"] == 18, f"Motion summary incomplete: {folder}")
    check(summary["walkingBugExercised"] is True, f"Real walking did not exercise the previous bug: {folder}")
    check(summary["sameFrameAlignmentObservations"] >= 18 and summary["walkingBobFrames"] > 0,
          f"Same-frame walking observations missing: {folder}")
    check(number(summary["walkingDistanceBlocks"], folder.name) > .1, f"Player did not actually walk: {folder}")
    check(number(summary["maxWalkingVirtualEyeOffsetBlocks"], folder.name) > .005
          and number(summary["maxWalkingOldRayMissBlocks"], folder.name) > .005,
          f"Walking did not expose projection-induced physical-origin error: {folder}")
    for key in ("maxWalkingNewRayMissBlocks", "maxRayDistanceBlocks"):
        check(0 <= number(summary[key], key) < .0005, f"Fixed ray misses the world-space field: {folder}/{key}")
    check(0 <= number(summary["maxProjectionErrorPixels"], folder.name) <= .06, f"Projection error too large: {folder}")
    check(0 <= number(summary["anchorErrorBlocks"], folder.name) <= 1e-8, f"Furnace anchor moved: {folder}")
    fires, frames, sequences = set(), [], []
    for row in rows:
        detail = row["furnaceMotion"]
        label = f"{folder.name}/{row['name']}"
        check(detail["name"] == row["name"] and detail["scene"] in SCENES, f"Diagnostic/capture pairing differs: {label}")
        check(detail["renderFrame"] == detail["eventFrame"] == detail["probeFrame"] > 0,
              f"Projection and shader data are from different frames: {label}")
        check(detail["cameraEntityExpected"] is True, f"Wrong camera entity: {label}")
        for actual_key, requested_key in (("cameraYawDegrees", "requestedYawDegrees"),
                                           ("cameraPitchDegrees", "requestedPitchDegrees")):
            delta = (number(detail[actual_key], label) - number(detail[requested_key], label) + 180) % 360 - 180
            check(abs(delta) < .01, f"Camera direction differs from the requested view: {label}")
        check(detail["viewport"] == [1280, 900], f"Wrong shader viewport: {label}")
        check(detail["worldAnchor"] == [.5, 121, .5], f"Wrong world anchor: {label}")
        check(abs(number(detail["fixedTimeSeconds"], label) - 12) <= 1e-5
              and abs(number(detail["fixedPhase"], label) - .5) <= 1e-5, f"Field animation was not frozen: {label}")
        check(0 <= number(detail["maxRayDistanceBlocks"], label) < .0005, f"Fixed ray error: {label}")
        check(0 <= number(detail["maxProjectionErrorPixels"], label) <= .06, f"Fixed projection error: {label}")
        check(0 < number(detail["coverage"], label) <= 1 and number(detail["drawCpuMs"], label) >= 0, f"No actual projected draw area: {label}")
        for key in ("cameraEye", "virtualEyeLocal", "physicalEyeLocal"):
            vector(detail[key], 3, label + "/" + key)
        for key in ("eventBodyProjection", "shaderInverseLocalProjection", "eventProjection", "eventPose"):
            vector(detail[key], 16, label + "/" + key)
        check(detail["referencePoints"], f"No world reference points: {label}")
        for point in detail["referencePoints"]:
            vector(point["local"], 3, label); vector(point["world"], 3, label)
            expected, actual = vector(point["expectedPixel"], 2, label), vector(point["shaderPixel"], 2, label)
            check(math.dist(expected, actual) <= .061, f"Reference point projection differs: {label}")
            check(0 <= number(point["newRayMissBlocks"], label) < .0005, f"Reference point ray misses: {label}")
            check(number(point["oldRayMissBlocks"], label) >= 0, f"Old ray comparison invalid: {label}")
        if detail["scene"].startswith("bob-"):
            check(detail["bobEnabled"] is True and detail["cameraIsPlayer"] is True, f"Bob test did not use actual player camera: {label}")
        if detail["scene"] == "bob-walking":
            check(number(detail["walkDistanceDelta"], label) > .1, f"Walking capture contains no movement: {label}")
        fires.add(detail["fire"]); frames.append(detail["renderFrame"]); sequences.append(detail["drawSequence"])
    check(len(fires) == 1 and frames == sorted(set(frames)) and sequences == sorted(set(sequences)),
          f"Fire changed, repeated or out-of-order frame/draw pairing: {folder}")
    return {"captures": 18, "walkingDistanceBlocks": summary["walkingDistanceBlocks"],
            "walkingBugExercised": True, "sameFrameAlignmentObservations": summary["sameFrameAlignmentObservations"],
            "oldWalkingRayMissBlocks": summary["maxWalkingOldRayMissBlocks"],
            "fixedWalkingRayMissBlocks": summary["maxWalkingNewRayMissBlocks"],
            "maxRayDistanceBlocks": summary["maxRayDistanceBlocks"],
            "maxProjectionErrorPixels": summary["maxProjectionErrorPixels"]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jar", type=Path)
    parser.add_argument("installed", type=Path, nargs="?")
    parser.add_argument("--report-dir", type=Path, default=ROOT / "reports/furnace-stability-20261014")
    args = parser.parse_args()
    report_dir = args.report_dir.resolve()
    source, installed = args.jar.resolve(), args.installed.resolve() if args.installed else None
    try:
        artifact = verify_jar(source, installed)
        catalog = (ROOT / "src/main/java/cn/blockforge/generated/generatedmod/fire/FireCatalog.java").read_text(encoding="utf-8-sig")
        definitions = re.findall(r'new Definition\("([^"\\]+)",\s*(\d+),', catalog)
        check(len(definitions) == 9 and {int(tier) for _, tier in definitions} == set(range(1, 10)), "Current fire catalog does not contain nine tiers")
        fires = {"wuxingxiantu:" + name for name, _ in definitions}
        aged = {name: verify_aged(report_dir / name, fires) for name in ("aged-native", "aged-solas")}
        aged["older-native"] = verify_aged(report_dir / "older-native", fires, 600000)
        motion = {name: verify_motion(report_dir / name) for name in ("motion-native", "motion-solas")}
        result = {"artifact": artifact, "evidenceDirectory": str(report_dir), "aged": aged, "motion": motion,
                  "actualScreenshotsVerified": 69, "pairedGpuCasesVerified": 27,
                  "visualComparisonScope": "Paired RGBA32F full-resolution draw output; GPU timings are not whole-game FPS"}
        output = report_dir / ("installed-verification.json" if installed else "artifact-verification.json")
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (VerificationError, OSError, KeyError, TypeError, ValueError, zlib.error) as error:
        print(f"VERIFICATION FAILED: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
