"""Bake model-space clearance from actual convex OBJ parts, never from screen depth.

The compact R16F lattice loads once. It excludes solid model volumes and a
small conservative interpolation margin; it does not reduce fire sampling.
"""
from pathlib import Path
import hashlib,json
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
MODEL=ROOT/'src/main/resources/assets/wuxingxiantu/models/block/cauldron_structure.obj'
OUT=ROOT/'src/main/resources/assets/wuxingxiantu/shaders/furnacevolume/surface-clearance.r16f'
N=128
LOW=np.array([-2.8,0,-2.8]);HIGH=np.array([2.8,2.65,2.8]);SPAN=HIGH-LOW

def meshes():
    vertices=[];parts=[];current=None
    for line in MODEL.read_text().splitlines():
        words=line.split()
        if not words:continue
        if words[0]=='o':current={'name':words[1],'faces':[]};parts.append(current)
        elif words[0]=='v':vertices.append(list(map(float,words[1:4])))
        elif words[0]=='f':current['faces'].append([int(w.split('/')[0])-1 for w in words[1:]])
    vertices=np.array(vertices)
    return vertices,parts

def main():
    vertices,parts=meshes();field=np.full((N,N,N),.2,dtype=np.float32);used=0;skipped=[]
    for part in parts:
        ids=sorted({i for face in part['faces'] for i in face});v=vertices[ids]
        if len(v)<4:continue
        lo,hi=v.min(0),v.max(0)
        if np.any(lo>HIGH+.15) or np.any(hi<LOW-.15):continue
        centre=v.mean(0);planes=[]
        for face in part['faces']:
            a,b,c=vertices[face[:3]];normal=np.cross(b-a,c-a);length=np.linalg.norm(normal)
            if length<1e-10:continue
            normal/=length;offset=-normal@a
            if normal@centre+offset>0:normal=-normal;offset=-offset
            if np.max(v@normal+offset)>1e-4:skipped.append(part['name']);planes=[];break
            if not any(np.linalg.norm(normal-n)<1e-5 and abs(offset-d)<1e-5 for n,d in planes):planes.append((normal,offset))
        if len(planes)<4:continue
        start=np.maximum(0,np.floor((lo-.15-LOW)/SPAN*N-.5).astype(int))
        end=np.minimum(N,np.ceil((hi+.15-LOW)/SPAN*N+.5).astype(int)+1)
        if np.any(end<=start):continue
        # GL x varies fastest; the binary lattice uses z/y/x order.
        z,y,x=np.meshgrid(np.arange(start[2],end[2]),np.arange(start[1],end[1]),np.arange(start[0],end[0]),indexing='ij')
        points=np.stack((x,y,z),axis=-1);points=LOW+(points+.5)/N*SPAN
        distance=np.full(points.shape[:-1],-100.,dtype=np.float32)
        for normal,offset in planes:distance=np.maximum(distance,np.einsum('...i,i->...',points,normal)+offset)
        section=field[start[2]:end[2],start[1]:end[1],start[0]:end[0]]
        np.minimum(section,distance,out=section);used+=1
    OUT.write_bytes(field.astype('<f2').tobytes())
    report={'modelSha256':hashlib.sha256(MODEL.read_bytes()).hexdigest(),'lattice':[N,N,N],'low':LOW.tolist(),'high':HIGH.tolist(),'convexParts':used,'nonConvexSkipped':sorted(set(skipped)),
            'byteSize':OUT.stat().st_size,'minimum':float(field.min()),'maximum':float(field.max())}
    report['fieldSha256']=hashlib.sha256(OUT.read_bytes()).hexdigest()
    dest=ROOT/'reports/alchemy-followup-20261014/surface-clearance.json';dest.write_text(json.dumps(report,indent=2))
    OUT.with_suffix('.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report))
if __name__=='__main__':main()
