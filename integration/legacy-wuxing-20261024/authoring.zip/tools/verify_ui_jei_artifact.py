"""Stage the spacing adjustment without replacing the prior delivered JAR."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports/ui-jei-spacing-20261007"
TARGET = ROOT / "deliverables/wuxingxiantu-0.2-20261007-ui-jei-spacing.jar"


def read_log(name):
    raw=(REPORT / name).read_bytes()
    return raw.decode("utf-16" if raw.startswith((b"\xff\xfe",b"\xfe\xff")) else "utf-8-sig",errors="replace")


def main():
    assert (REPORT / "build.exit").read_text().strip()=="0"
    assert "BUILD SUCCESSFUL" in read_log("build.log")
    assert "PASS: 20" in read_log("layout.log")
    jar=ROOT / "build/libs/wuxingxiantu-0.2.jar"
    assets=json.loads((ROOT / "reports/ui-reference-install-20261007/assets.json").read_text(encoding="utf-8"))
    with zipfile.ZipFile(jar) as archive:
        for asset in assets["assets"]:
            assert archive.read("assets/wuxingxiantu/textures/gui/wuxia/reference/"+asset["path"])==(ROOT / asset["source"]).read_bytes()
    shutil.copy2(jar,TARGET)
    digest=hashlib.sha256(TARGET.read_bytes()).hexdigest()
    TARGET.with_suffix(".jar.sha256").write_text(digest+"  "+TARGET.name+"\n",encoding="ascii")
    result={"artifact":str(TARGET),"sha256":digest,"size":TARGET.stat().st_size,
            "window_max_gui_size":[500,300],"original_crop_images_unchanged":assets["images"],
            "layout_cases":20,"build_passed":True,"client_runtime_verified":False,
            "domain_selection":"unchanged from preceding delivery; no additional runtime claim"}
    (REPORT / "artifact-verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=="__main__":main()
