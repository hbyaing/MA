"""Export the approved reference-textured Blockbench cubes to a static Java block model."""
from pathlib import Path
import json, shutil, base64

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'source-assets/xuantie-spirit-anvil/reference-textured'
RES = ROOT / 'src/main/resources'
ASSETS = RES / 'assets/wuxingxiantu'
DATA = RES / 'data'
def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

source = json.loads((SOURCE / '玄铁灵砧_原图贴图.bbmodel').read_text(encoding='utf-8'))
parts = json.loads((SOURCE.parent/'work/geometry.json').read_text(encoding='utf-8'))['parts']
def geometry_key(c):return tuple(round(v,5) for k in ('from','to') for v in c[k])
part_by_geometry={geometry_key(p):p for p in parts}
parts=[part_by_geometry[geometry_key(c)] for c in source['elements']]
cubes = source['elements']
width = max(c['to'][0] for c in cubes)-min(c['from'][0] for c in cubes)
height = max(c['to'][1] for c in cubes)
def point(p, cube):
    # Vanilla's footprint is 12x12. The former shared X/Z fit made our base only 6.8 deep.
    base = cube['to'][1] <= 4.56
    return [round(p[0]*16/width*(1.17 if base else 1)+8,6),
            round(p[1]*16/height,6), round(p[2]*16/width*1.5*(1.18 if base else 1)+8,6)]
elements=[]
for cube in cubes:
    assert cube['type']=='cube' and not any(cube.get('rotation',[0,0,0]))
    faces={face: {'uv':[round(v/64,6) for v in info['uv']], 'texture':'#0'}
           for face,info in cube['faces'].items() if info.get('texture') is not None}
    elements.append({'from':point(cube['from'],cube), 'to':point(cube['to'],cube), 'shade':False, 'faces':faces})
model={'ambientocclusion':False, 'textures':{'0':'wuxingxiantu:block/xuanling_anvil','particle':'wuxingxiantu:block/xuanling_anvil'},
       'elements':elements, 'display':{'gui':{'rotation':[30,225,0],'translation':[0,0,0],'scale':[.62,.62,.62]},
       'ground':{'translation':[0,3,0],'scale':[.25,.25,.25]},
       'fixed':{'scale':[.5,.5,.5]}, 'thirdperson_righthand':{'rotation':[75,45,0],'translation':[0,2.5,0],'scale':[.375,.375,.375]},
       'firstperson_righthand':{'rotation':[0,45,0],'scale':[.4,.4,.4]}}}
# A generated material sheet is sampled directly, without resizing its pixels.
# Its top panel has a round motif; use equal physical pixel density in both axes.
adapted = SOURCE/'adapted_materials.png'
if adapted.exists():
    model['textures']['1']='wuxingxiantu:block/xuanling_anvil_adapted'
    for i,(cube,el,part) in enumerate(zip(cubes,elements,parts)):
        circular=part['group'].startswith('09_') and max(abs(cube[k][a]) for k in ('from','to') for a in (0,2))<=4
        if circular:
            for bound in ('from','to'):
                el[bound][2]=round(8+(el[bound][2]-8)/1.5,6)
        if circular:
            # The inset crop excludes the atlas's bottom swatches. Pixel-space
            # ring diameter is ~400x420: compensate that small source asymmetry.
            x0,y0,z0=el['from'];x1,y1,z1=el['to']
            uv=[(724+(x0-8)*90)*16/1448,(358+(z0-8)*94.5)*16/1086,
                (724+(x1-8)*90)*16/1448,(358+(z1-8)*94.5)*16/1086]
            el['faces']['up']={'uv':uv,'texture':'#1'}
            # The adapted inset owns the entire motif. Rendering the old raised
            # ring/core as well duplicates the pattern at almost the same depth.
            el['faces']={}
        if (cube['to'][1]<=4.56 or cube['from'][1]>=15.7) and part['material'] in ('iron','iron_dark','steel'):
            # 16 px per world unit; square cells remain square on every step.
            for face,info in el['faces'].items():
                if face not in ('up','down'):continue
                x0,y0,z0=el['from'];x1,y1,z1=el['to']
                # Base ledges are dark iron, including the former steel wear strips.
                offset=362 if part['material']=='steel' and cube['to'][1]>4.56 else 0
                info.update(texture='#1',uv=[(offset+181+(x0-8)*16)*16/1448,
                    (900+(z0-8)*16)*16/1086,(offset+181+(x1-8)*16)*16/1448,
                    (900+(z1-8)*16)*16/1086])
    shutil.copy2(adapted,ASSETS/'textures/block/xuanling_anvil_adapted.png')
    # A dedicated inset carries the circular motif at its own physical scale.
    # It avoids stretching that motif across the widened rectangular head.
    # Four disjoint arms: no cross intersection, no overlap with the inset.
    for bounds,uv in [(([7.7,16.01,2],[8.3,16.02,5.4]),[704,4,744,204]),
                      (([7.7,16.01,10.6],[8.3,16.02,14]),[704,510,744,710]),
                      (([0,16.01,7.7],[5.4,16.02,8.3]),[10,338,480,378]),
                      (([10.6,16.01,7.7],[16,16.02,8.3]),[968,338,1438,378])]:
        elements.append({'from':bounds[0],'to':bounds[1],'shade':False,
            'faces':{'up':{'texture':'#1','uv':[uv[0]*16/1448,uv[1]*16/1086,uv[2]*16/1448,uv[3]*16/1086]}}})
    elements.append({'from':[5.4,16.01,5.4],'to':[10.6,16.02,10.6],'shade':False,
        'faces':{'up':{'texture':'#1','uv':[(724-234)*16/1448,(358-245.7)*16/1086,
            (724+234)*16/1448,(358+245.7)*16/1086]}}})
# Java's model parser rejects cubes with an empty face object. Hidden source
# decoration stays editable in Blockbench but is omitted from the baked model.
model['elements']=[el for el in elements if el['faces']]
save(ASSETS/'models/block/xuanling_anvil.json',model)
(ASSETS/'textures/block').mkdir(parents=True,exist_ok=True)
shutil.copy2(SOURCE/'reference_albedo.png',ASSETS/'textures/block/xuanling_anvil.png')
variants={}
for face,rotation in [('north',0),('east',90),('south',180),('west',270)]:
    for damage in range(4): variants[f'facing={face},damage={damage}']={'model':'wuxingxiantu:block/xuanling_anvil','y':rotation}
save(ASSETS/'blockstates/xuanling_anvil.json',{'variants':variants})
save(ASSETS/'models/item/xuanling_anvil.json',{'parent':'wuxingxiantu:block/xuanling_anvil'})
save(DATA/'wuxingxiantu/recipes/xuanling_anvil.json',{'type':'minecraft:crafting_shaped','pattern':['DDD','ASA','III'],
     'key':{'D':{'item':'wuxingxiantu:dark_iron_block'},'A':{'item':'wuxingxiantu:aura_crystal'},
            'S':{'item':'wuxingxiantu:spirit_stone_block'},'I':{'item':'wuxingxiantu:dark_iron'}},
     'result':{'item':'wuxingxiantu:xuanling_anvil'}})
save(DATA/'wuxingxiantu/loot_tables/blocks/xuanling_anvil.json',{'type':'minecraft:block','pools':[{'rolls':1,
    'entries':[{'type':'minecraft:item','name':'wuxingxiantu:xuanling_anvil','functions':[{'function':'minecraft:copy_state',
        'block':'wuxingxiantu:xuanling_anvil','properties':['damage']}]}], 'conditions':[{'condition':'minecraft:survives_explosion'}]}]})
for name in ['mineable/pickaxe','needs_iron_tool']:
    path=DATA/f'minecraft/tags/blocks/{name}.json'
    tag=json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else {'replace':False,'values':[]}
    if 'wuxingxiantu:xuanling_anvil' not in tag['values']:tag['values'].append('wuxingxiantu:xuanling_anvil')
    save(path,tag)
catalog_path=ASSETS/'item_text_catalog.json'
catalog=json.loads(catalog_path.read_text(encoding='utf-8-sig'))
catalog['xuanling_anvil']={'nameColor':0x6ECFFF,'gradeColor':0x6ECFFF,'visibility':'player','actions':2}
save(catalog_path,catalog)
zh={
 'block.wuxingxiantu.xuanling_anvil':'玄灵铁砧',
 'gui.wuxingxiantu.anvil_price':'灵力消耗：%s', 'gui.wuxingxiantu.anvil_exhausted':'砧体损坏，需修复',
 'message.wuxingxiantu.anvil_intact':'玄灵铁砧完好，无需修复',
 'message.wuxingxiantu.anvil_mana_missing':'修复砧体需要 %s 点灵力',
 'message.wuxingxiantu.anvil_restored':'已修复一档砧体损伤，消耗 %s 点灵力',
 'message.wuxingxiantu.anvil_exhausted':'砧体严重损坏；空手潜行右键消耗 %s 点灵力修复一档',
 'tooltip.wuxingxiantu.anvil_costs':'每级费用：%s 点灵力；每档砧体修复：%s 点灵力',
 'tooltip.wuxingxiantu.anvil_wear':'砧体损伤：%s / 3',
 'tooltip.wuxingxiantu.intro.xuanling_anvil.category':'灵力工坊',
 'tooltip.wuxingxiantu.intro.xuanling_anvil.lore':'玄铁为骨，灵纹为脉，借修士灵力重铸万物。',
 'tooltip.wuxingxiantu.intro.xuanling_anvil.action.0':'右键修复、合并附魔或改名；以灵力替代经验等级，保留原版过于昂贵限制。',
 'tooltip.wuxingxiantu.intro.xuanling_anvil.action.1':'空手潜行右键修复一档砧体损伤；严重损坏后暂停工作，挖起再放保留损伤。'}
en={
 'block.wuxingxiantu.xuanling_anvil':'Xuanling Anvil',
 'gui.wuxingxiantu.anvil_price':'Mana cost: %s', 'gui.wuxingxiantu.anvil_exhausted':'Anvil needs restoration',
 'message.wuxingxiantu.anvil_intact':'The anvil needs no restoration',
 'message.wuxingxiantu.anvil_mana_missing':'Restoration requires %s mana',
 'message.wuxingxiantu.anvil_restored':'Restored one wear stage for %s mana',
 'message.wuxingxiantu.anvil_exhausted':'Anvil exhausted. Sneak and use with an empty hand to restore one stage for %s mana',
 'tooltip.wuxingxiantu.anvil_costs':'%s mana per level; %s mana per wear stage restored',
 'tooltip.wuxingxiantu.anvil_wear':'Anvil wear: %s / 3',
 'tooltip.wuxingxiantu.intro.xuanling_anvil.category':'Spiritual workshop',
 'tooltip.wuxingxiantu.intro.xuanling_anvil.lore':'Dark iron and spiritual runes reshape equipment with a cultivator\'s mana.',
 'tooltip.wuxingxiantu.intro.xuanling_anvil.action.0':'Use to repair, merge enchantments or rename; mana replaces XP levels, with the vanilla too-expensive limit.',
 'tooltip.wuxingxiantu.intro.xuanling_anvil.action.1':'Sneak and use with an empty hand to restore one wear stage. Exhaustion pauses work; mining retains wear.'}
for lang,entries in [('zh_cn',zh),('en_us',en)]:
    path=ASSETS/f'lang/{lang}.json'
    table=json.loads(path.read_text(encoding='utf-8-sig'));table.update(entries);save(path,table)
source['name']='玄灵铁砧'
for group in source.get('groups',[]):
    if group.get('name')=='玄铁灵砧':group['name']='玄灵铁砧'
save(SOURCE/'玄灵铁砧.bbmodel',source)
wide=json.loads(json.dumps(source))
if adapted.exists():
    tex=json.loads(json.dumps(wide['textures'][0]))
    tex.update(name='adapted_materials.png',width=1448,height=1086,uv_width=1024,uv_height=1024,
               uuid='827eb2ed-d23b-4797-999b-345c5d2af184',source='data:image/png;base64,'+base64.b64encode(adapted.read_bytes()).decode(),render_mode='default')
    wide['textures'].append(tex)
for cube, element in zip(wide['elements'],elements):
    cube['from']=[element['from'][0]-8,element['from'][1],element['from'][2]-8]
    cube['to']=[element['to'][0]-8,element['to'][1],element['to'][2]-8]
    for face in cube['faces']:
        if face not in element['faces']:cube['faces'][face]['texture']=None
    for face,info in element['faces'].items():
        if info['texture']=='#1':cube['faces'][face].update(texture=1,uv=[v*64 for v in info['uv']])
if adapted.exists():
  for idx,inset in enumerate(elements[len(cubes):]):
    uuid=f'ed7c5c73-ef45-4e59-a9e8-1916cb1d4e2{idx}'
    wide['elements'].append({'name':'圆形灵纹独立贴图','type':'cube','uuid':uuid,
        'from':[inset['from'][0]-8,inset['from'][1],inset['from'][2]-8],
        'to':[inset['to'][0]-8,inset['to'][1],inset['to'][2]-8],
        'faces':{face:({'texture':1,'uv':[v*64 for v in inset['faces']['up']['uv']]}
            if face=='up' else {'texture':None,'uv':[0,0,0,0]})
            for face in ('north','south','east','west','up','down')}})
    wide.setdefault('outliner',[]).append(uuid)
save(SOURCE/'玄灵铁砧_加宽.bbmodel',wide)
print(f'Imported {len(elements)} cubes; widened base ~14x12, top ~16x12, height16; opaque 1024px reference texture.')

