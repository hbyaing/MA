"""Static asset/layout inspection only; not a game screenshot."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parents[1]
folder=root/'src/main/resources/assets/wuxingxiantu/textures/gui/refining'
nav=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/navigation'
report=root/'reports/refining-navigation-v2-20261011'
report.mkdir(parents=True,exist_ok=True)
S=3
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',24)
def sprite(canvas,path,x,y,w,h,box=None):
    im=Image.open(path).convert('RGBA')
    if box:im=im.crop(box)
    canvas.alpha_composite(im.resize((w*S,h*S),Image.Resampling.NEAREST),(x*S,y*S))
def frame(canvas,name,x,y,w,h,e,d):
    path=folder/(name+'.png');im=Image.open(path)
    sx=[0,e,im.width-e,im.width];sy=[0,e,im.height-e,im.height]
    dx=[0,d,w-d,w];dy=[0,d,h-d,h]
    for r in range(3):
        for c in range(3):
            if r==c==1:continue
            sprite(canvas,path,x+dx[c],y+dy[r],dx[c+1]-dx[c],dy[r+1]-dy[r],(sx[c],sy[r],sx[c+1],sy[r+1]))
def text(canvas,s,x,y,color='#e4c88b',center=False):
    draw=ImageDraw.Draw(canvas)
    if center:x-=draw.textlength(s,font=font)/(2*S)
    draw.text((int(x*S),y*S),s,font=font,fill=color)
def refining(names):
    canvas=Image.new('RGBA',(452*S,302*S),(10,24,33,255))
    sprite(canvas,folder/'landscape.png',3,3,446,296)
    canvas=Image.alpha_composite(canvas,Image.new('RGBA',canvas.size,(5,17,27,100)))
    frame(canvas,'panel',0,0,452,302,48,11)
    sprite(canvas,folder/'title.png',128,7,196,18)
    sprite(canvas,folder/'separator.png',14,31,424,6)
    sprite(canvas,folder/'close.png',426,8,18,18)
    text(canvas,'所需材料',18,40)
    sprite(canvas,folder/'material_rule.png',72,41,362,5)
    text(canvas,'炼器配方 4/7',226,55,'#9db1c6',True)
    frame(canvas,'output',197,74,58,58,24,6)
    item=root/'src/main/resources/assets/wuxingxiantu/textures/item/mingjue_sword/inventory.png'
    sprite(canvas,item,210,87,32,32)
    text(canvas,'产出：明魂剑',226,140,center=True)
    sprite(canvas,folder/'previous.png',164,95,26,26)
    sprite(canvas,folder/'next.png',264,95,26,26)
    rows=(len(names)+1)//2
    for i,(name,qty,color) in enumerate(names):
        x=16 if i<rows else 298;y=52+i%rows*30
        ImageDraw.Draw(canvas).rectangle((x*S,y*S,(x+138)*S,(y+26)*S),fill=(16,32,43,210))
        frame(canvas,'card',x,y,138,26,16,4)
        item_name=['dark_iron_sword.png','dark_iron.png','aura_crystal.png'][i%3]
        sprite(canvas,root/'src/main/resources/assets/wuxingxiantu/textures/item'/item_name,x+7,y+5,16,16)
        text(canvas,name,x+30,y+9,'#ddeaf6')
        tw=ImageDraw.Draw(canvas).textlength(qty,font=font)/S
        text(canvas,qty,x+129-tw,y+9,color)
    for y,h,asset in [(178,20,'info'),(201,27,'info_tall')]:
        ImageDraw.Draw(canvas).rectangle((16*S,y*S,436*S,(y+h)*S),fill=(16,32,43,220))
        frame(canvas,asset,16,y,420,h,12,3)
    for name,x,y,w,h in [('aura_icon',21,180,14,16),('time_icon',272,181,12,15),('pedestal_icon',21,206,14,18),('fire_icon',300,204,16,20)]:
        sprite(canvas,folder/(name+'.png'),x,y,w,h)
    text(canvas,'灵力消耗：70（当前：1320000）',40,184,'#b8dfff')
    text(canvas,'炼制时间：12秒',291,184)
    text(canvas,'承华台：3 台承载中 · 周围 4 格内取材',40,209,'#9fe0c8')
    text(canvas,'9阶·涅槃神火',321,204,'#ec88b2')
    text(canvas,'异火阶位：9 / 需求 1',321,216,'#7be0a0')
    ImageDraw.Draw(canvas).rectangle((16*S,231*S,436*S,257*S),fill=(28,41,54,255))
    frame(canvas,'button',16,231,420,26,22,5)
    sprite(canvas,folder/'button_left.png',21,236,35,16)
    sprite(canvas,folder/'button_right.png',391,236,40,16)
    text(canvas,'开始炼器',226,239,'#e4c88b',True)
    text(canvas,'承华台缺少：玄铁剑×1、铁锭×6',226,267,'#ff9088',True)
    return canvas
base=[('玄铁剑','0/1','#ff9088'),('铁锭','0/6','#ff9088'),('灵力结晶','4/4','#7be0a0')]
refining(base).save(report/'refining-3-material-preview.png')
refining(base+[('赤炎石','2/2','#7be0a0'),('玄冰砂','0/3','#ff9088'),('灵木髓','5/5','#7be0a0'),('星辉玉','1/2','#ff9088'),('龙纹骨','0/1','#ff9088')]).save(report/'refining-8-material-layout-preview.png')
canvas=Image.new('RGBA',(240*S,60*S),(10,24,33,255))
for i,state in enumerate(['normal','selected','hover']):
    x=i*80+10;y=10
    sprite(canvas,nav/(state+'_background.png'),x+2,y+2,56,28)
    sprite(canvas,nav/(state+'_frame.png'),x,y,60,32)
    sprite(canvas,nav/'icon_inventory.png',x+5,y+4,24,24)
    sprite(canvas,nav/'center_rule.png',x+31,y+7,2,18)
    text(canvas,'背包',x+36,y+12,'#e8c88b' if state=='selected' else '#e6e3d5')
    sprite(canvas,nav/'separator.png',x+4,y+32,52,4)
    text(canvas,{'normal':'未选中','selected':'已选中','hover':'悬停'}[state],x+30,48,center=True)
canvas.save(report/'navigation-state-preview.png')
print('Saved static refining and navigation previews')
