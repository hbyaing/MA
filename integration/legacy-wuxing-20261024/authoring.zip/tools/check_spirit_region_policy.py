"""Exercise the actual pure Java policy/traversal in source-launcher mode, without building the mod."""
from pathlib import Path
import subprocess
import re
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'reports/spirit-regions-20261008'
OUT.mkdir(parents=True, exist_ok=True)
JAVA = Path('C:/tmp/temurin17/jdk-17.0.20.1+1/bin/java.exe')
sources = []
for name in ['WildRarity', 'SpiritPlantQuota', 'ConnectedBiomeRegion']:
    text = (ROOT / f'src/main/java/cn/blockforge/generated/generatedmod/plants/{name}.java').read_text(encoding='utf-8')
    text = re.sub(r'^package .*?;\s*', '', text)
    text = re.sub(r'^import .*?;\s*', '', text, flags=re.M)
    text = text.replace('public final class ', 'final class ').replace('public enum ', 'enum ')
    sources.append(text)
harness = r'''
import java.util.*;
import java.util.function.LongFunction;
import java.io.*;
public class RegionPolicyChecks {
    static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        Map<String,WildRarity> species=new LinkedHashMap<>();
        species.put("common_a",WildRarity.COMMON);species.put("common_b",WildRarity.COMMON);
        species.put("uncommon_a",WildRarity.UNCOMMON);species.put("uncommon_b",WildRarity.UNCOMMON);
        species.put("rare_a",WildRarity.RARE);species.put("rare_b",WildRarity.RARE);
        species.put("very_rare",WildRarity.VERY_RARE);species.put("dragon",WildRarity.SPECIAL);
        Map<String,WildRarity> reversed=new LinkedHashMap<>();
        var keys=new ArrayList<>(species.keySet());Collections.reverse(keys);
        for(String key:keys)reversed.put(key,species.get(key));
        int[] pass=new int[3];Random seeds=new Random(20261008);
        for(int i=0;i<100000;i++) {
            long seed=seeds.nextLong();
            for(int mode=0;mode<3;mode++) {
                var p=SpiritPlantQuota.choose(seed,mode==2,mode==1,species);
                check(p.equals(SpiritPlantQuota.choose(seed,mode==2,mode==1,reversed)),"order changed plan");
                if(p.target()>0)pass[mode]++;
                check(p.target()<=3,"target overflow");
                int total=0,rare=0;
                for(var e:p.limits().entrySet()) {
                    total+=e.getValue();var rarity=species.get(e.getKey());
                    check(e.getValue()<=(rarity==WildRarity.COMMON?2:1),"species overflow");
                    if(rarity==WildRarity.RARE||rarity==WildRarity.VERY_RARE)rare+=e.getValue();
                    check((mode==2)==(rarity==WildRarity.SPECIAL),"dimension leakage");
                }
                check(total<=p.target()&&total<=3&&rare<=1,"regional overflow");
                if(mode==2&&p.target()>0)check(p.limits().get("dragon")==1,"end probability applied twice");
            }
        }
        check(Math.abs(pass[0]/100000.0-.60)<.006,"ordinary gate");
        check(Math.abs(pass[1]/100000.0-.35)<.006,"restricted gate");
        check(Math.abs(pass[2]/100000.0-.08)<.006,"end gate");
        System.out.println("PASS: 300000 allocations; caps, dimension, load order, deterministic draws, gates "+Arrays.toString(pass));
        Set<Long> shape=new HashSet<>();
        for(int x=-40;x<=40;x++)for(int z=-3;z<=3;z++)shape.add(ConnectedBiomeRegion.pack(x,z));
        // A long, one-block-wide neck crosses multiple chunks and joins a distant lobe.
        for(int x=40;x<=180;x++)shape.add(ConnectedBiomeRegion.pack(x,0));
        for(int x=180;x<=220;x++)for(int z=-3;z<=3;z++)shape.add(ConnectedBiomeRegion.pack(x,z));
        long isolated=ConnectedBiomeRegion.pack(300,0);
        LongFunction<String> sample=p->shape.contains(p)||p==isolated?"forest":"plains";
        Set<Long> members=new HashSet<>(),examined=new HashSet<>();ArrayDeque<Long> frontier=new ArrayDeque<>();
        long origin=ConnectedBiomeRegion.pack(-30,0);frontier.add(origin);examined.add(origin);
        ConnectedBiomeRegion.step("forest",members,examined,frontier,sample,17,Long.MAX_VALUE);
        check(!frontier.isEmpty(),"must remain incomplete before boundary closure");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(ObjectOutputStream out=new ObjectOutputStream(bytes)){out.writeObject(members);out.writeObject(examined);out.writeObject(frontier);}
        try(ObjectInputStream in=new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()))) {
            members=(Set<Long>)in.readObject();examined=(Set<Long>)in.readObject();frontier=(ArrayDeque<Long>)in.readObject();
        }
        while(!frontier.isEmpty())ConnectedBiomeRegion.step("forest",members,examined,frontier,sample,13,Long.MAX_VALUE);
        check(members.equals(shape),"missed a distant connected lobe or included an isolated biome");
        check(!members.contains(isolated),"merged separate forests");
        long negative=ConnectedBiomeRegion.pack(-123,-987);
        check(ConnectedBiomeRegion.x(negative)==-123&&ConnectedBiomeRegion.z(negative)==-987,"negative coordinate collision");
        int count=members.size();frontier.add(origin);
        ConnectedBiomeRegion.step("forest",members,examined,frontier,sample,1,Long.MAX_VALUE);
        check(members.size()==count,"duplicate membership");
        System.out.println("PASS: complete connected region, narrow bridge, disjoint biome, negative coordinates, resumed frontier");
        for(int tileX:new int[]{-1,0,1}) {
            members=new HashSet<>();examined=new HashSet<>();frontier=new ArrayDeque<>();
            long start=ConnectedBiomeRegion.pack(tileX*256+113,-141);
            long tile=ConnectedBiomeRegion.tile(start);frontier.add(start);examined.add(start);
            int visits=0;
            while(!frontier.isEmpty()){
                visits+=ConnectedBiomeRegion.step("plains",members,examined,frontier,p->{
                    check(ConnectedBiomeRegion.tile(p)==tile,"sample escaped tile");return "plains";
                },128,Long.MAX_VALUE,tile);
                check(visits<=65536,"single-biome search did not terminate");
            }
            check(members.size()==65536,"bounded region missed cells");
            check(ConnectedBiomeRegion.tile(ConnectedBiomeRegion.pack(tileX*256,-256))==tile,"negative tile boundary");
        }
        System.out.println("PASS: bounded single-biome traversal terminates at 65536 cells, including negative tiles");
    }
}
'''
path = OUT / 'RegionPolicyChecks.java'
path.write_text(harness+'\n'+'\n'.join(sources), encoding='utf-8')
result = subprocess.run([str(JAVA), str(path)], cwd=ROOT, capture_output=True, text=True)
(OUT / 'policy.log').write_text(result.stdout+result.stderr, encoding='utf-8')
print(result.stdout+result.stderr)
raise SystemExit(result.returncode)
