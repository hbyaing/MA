"""Prove this patch changes only furnace client rendering against the installed release."""
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

root = Path(__file__).resolve().parents[1]
old_path, new_path = map(Path, sys.argv[1:3])
report = root / 'reports/furnace-stability-20261014'
prefix = 'cn/blockforge/generated/generatedmod/client/furnacevolume/'
allowed_classes = ('VolumeGpu', 'FurnaceFireVolume', 'FireCornerCache', 'FireBedNoiseCache')
allowed_resources = {'assets/wuxingxiantu/shaders/furnacevolume/volume.fsh',
                     'assets/wuxingxiantu/shaders/furnacevolume/bed_noise.glsl'}

def allowed(name):
    return name in allowed_resources or any(name == prefix + cls + '.class'
        or name.startswith(prefix + cls + '$') and name.endswith('.class') for cls in allowed_classes)

with ZipFile(old_path) as old, ZipFile(new_path) as new:
    before = {name: old.read(name) for name in old.namelist() if not name.endswith('/')}
    after = {name: new.read(name) for name in new.namelist() if not name.endswith('/')}
    changed = sorted(name for name in before.keys() & after.keys() if before[name] != after[name])
    added, removed = sorted(after.keys() - before.keys()), sorted(before.keys() - after.keys())
    unexpected = [name for name in changed + added + removed if not allowed(name)]
    if unexpected:
        raise SystemExit('Unexpected production changes: ' + repr(unexpected))
    baseline_name = 'assets/wuxingxiantu/shaders/furnacevolume/volume.fsh'
    if before[baseline_name] != (report / 'baseline/volume.fsh').read_bytes():
        raise SystemExit('Baseline shader does not match the previous installed release')
    def core(text):
        return text.replace('\r\n', '\n').split('// SHARED_VOLUME_CORE_BEGIN', 1)[1].split('// SHARED_VOLUME_CORE_END', 1)[0]
    if core(before[baseline_name].decode('utf-8')) != core((report / 'baseline/camera-corrected.fsh').read_text(encoding='utf-8')):
        raise SystemExit('Comparison shader changes the baseline field formula')
    presets = [f'assets/wuxingxiantu/shaders/furnacevolume/{name}.json' for name in ('recipe', 'nine-flames')]
    for name in presets:
        if before[name] != after[name]:
            raise SystemExit('Visual recipe changed: ' + name)
    result = {
        'previousJar': str(old_path.resolve()), 'currentJar': str(new_path.resolve()),
        'previousSha256': sha256(old_path.read_bytes()).hexdigest().upper(),
        'currentSha256': sha256(new_path.read_bytes()).hexdigest().upper(),
        'changed': changed, 'added': added, 'removed': removed,
        'unchangedEntries': sum(before[name] == after[name] for name in before.keys() & after.keys()),
        'visualPresetsUnchanged': presets, 'comparisonBaselineFieldUnchanged': True,
        'onlyFurnaceClientRenderingChanged': True,
        'baselineShaderSha256': sha256(before[baseline_name]).hexdigest(),
        'referenceShaderSha256': sha256((report / 'baseline/camera-corrected.fsh').read_bytes()).hexdigest(),
    }
    (report / 'release-scope.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
