const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve('deliverables/electric-preview-20261010/workbench');
fs.mkdirSync(path.dirname(root),{recursive:true});fs.cpSync('deliverables/tribulation-final-rain-20261010/workbench',root,{recursive:true});
const ctx={};vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'recipe.js'),'utf8')+';globalThis.validate=validateRecipe;',ctx);
const base=JSON.parse(fs.readFileSync('src/main/resources/assets/wuxingxiantu/tribulation/01.json','utf8'));
const recipes={},labels={};
recipes.paralysis={...base,mode:'orbit',seed:1337,orbitAnimation:'grow',rodLength:1.8,rodRadius:.32,emitterSpread:.08,strands:12,samples:24,arcLength:.65,throttle:.85,pulseInterval:5,orbitWobble:.06,orbitFlow:1.8,orbitNoiseFrequency:.75,orbitDirection:1,orbitExtendSpeed:20,lengthRandomness:.65,currentWidth:.009,glowWidth:.045,coreGain:2,glowGain:1.3,coreColor:'#C7ECFF',glowColor:'#488CFF',gradientEnabled:false,orbitHeight:0};
labels.paralysis='麻痹 · 身体纵轴电流（游戏参数）';
for(const [key,count,diameter,stagger] of [['domain',9,12,1.4],['domainStrong',15,20,.9]]){
 recipes[key]={...base,mode:'rain',rainStyle:'cluster',rainCount:count,rainSpread:diameter,rainDepthSpread:diameter,rainStagger:stagger,strikeHeight:32,strikeDisplacement:2.2,strikeWidth:.024,glowWidth:.085,coreGain:2.2,glowGain:1.5,coreColor:'#E5F4FF',glowColor:'#6A99FF',gradientEnabled:true,gradientStart:'#B2D8FF',gradientEnd:'#DED0FF',rainMaxBranchDepth:0,rainMaxBranches:0,rainBranchProbability:0,maxSegments:512,branchLimit:0,impactRadius:1.35,impactDuration:12,impactRays:8,impactSparks:10,durationTicks:13,progressionTicks:1.2,restrikeCount:1};
 labels[key]=`天雷领域 · ${diameter}格范围 / ${count}束 · ${stagger} tick错峰`;
}
const names=['练气','筑基','金丹','元婴','化神','炼虚','合体','大乘'];
for(let i=0;i<8;i++){
 const key=String(i+1).padStart(2,'0'),r=JSON.parse(fs.readFileSync(`src/main/resources/assets/wuxingxiantu/tribulation/${key}.json`,'utf8'));
 recipes[key]={...r,mode:'strike',strikeWidth:r.strikeWidth*.55,glowWidth:r.glowWidth,coreGain:r.coreGain,glowGain:r.glowGain};labels[key]=`${names[i]} · 主雷优化（核心55% / 原亮度）`;
 recipes['old'+key]={...r,mode:'strike'};labels['old'+key]=`${names[i]} · 当前主雷（对照）`;
}
for(const [k,r] of Object.entries(recipes)){ctx.validate(r);fs.writeFileSync(path.join(root,'presets',k+'.json'),JSON.stringify(r,null,2));}
fs.writeFileSync(path.join(root,'final-rain-recipes.js'),'const finalRainRecipes='+JSON.stringify(recipes)+';\n');
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
html=html.replace(/<select id="tribulationPreset">[\s\S]*?<\/select>/,'<select id="tribulationPreset">'+Object.keys(labels).map(k=>`<option value="${k}">${labels[k]}</option>`).join('')+'</select>');
html=html.replace(/<select id="formStage">[\s\S]*?<\/select>/,'<select id="formStage"><option value="normal">单道展示 · 固定种子</option></select>');
html=html.replace('终劫雷场待接入游戏；覆盖直径随境界增长。每束位置由种子确定，短间隔连续落下。','麻痹参数与游戏一致；参照轴竖直展示。天雷领域与细主雷均为待实装预设；原版/优化可同种子对比。');
fs.writeFileSync(path.join(root,'index.html'),html);
let app=fs.readFileSync(path.join(root,'app.js'),'utf8').replace('finalRainRecipes["01"]','finalRainRecipes.paralysis').replace('time=2.7','time=3');
app=app.replace('function project(p){','function project(p){if(recipe.mode==="orbit"&&recipe.orbitAnimation!=="ring")p=[p[1],p[0],p[2]];');
app=app.replace('Math.max(6.4,recipe.rodLength*.75)','Math.max(2.8,recipe.rodLength*.75)');
app=app.replace("LightningForms.build(recipe,$('tribulationPreset').value,$('formStage').value)",'LightningCore.bolt(recipe)');
app=app.replace('LightningForms.sample(recipe,cachedBolt,time)','LightningCore.clip(recipe,cachedBolt,time)');
app=app.replace('time=recipe.progressionTicks+(recipe.rainCount-1)*recipe.rainStagger+.8;','time=recipe.mode===\'orbit\'?3:recipe.progressionTicks+.8;');
fs.writeFileSync(path.join(root,'app.js'),app);
console.log(root);

