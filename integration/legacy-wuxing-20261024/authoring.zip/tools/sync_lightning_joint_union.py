from pathlib import Path
import re, json

roots = [Path('deliverables/electric-preview-20261010/workbench'), Path('C:/Users/Nostzephert/.codex/skills/minecraft-lightning/assets/workbench'), Path('E:/着色器渲染/skill/minecraft-lightning/assets/workbench')]
for root in roots:
    if not root.exists(): continue
    p = root/'gpu.js'
    s = p.read_text(encoding='utf-8')
    s = s.replace("(usesGradient(r,false)||(r.gradientEnabled&&r.gradientTarget==='glow'))", 'usesGradient(r,false)')
    s = re.sub(r'   let joins=null;.*?   for\(let i=0;i\+1<run.length;i\+\+\)\{', '   for(let i=0;i+1<run.length;i++){', s, flags=re.S)
    s = s.replace('sa=halo?normals[i].map(v=>v*radii[i].rendered):joins[i],sb=halo?normals[i].map(v=>v*radii[i+1].rendered):joins[i+1]', 'sa=normals[i].map(v=>v*radii[i].rendered),sb=normals[i].map(v=>v*radii[i+1].rendered)')
    s = s.replace('   if(halo)for(let i=1;', '   for(let i=1;')
    s = s.replace('outColor=vec4(top>0.?color.rgb/top:vec3(0.),clamp(a*Gain*top,0.,1.));', 'float opacity=clamp(a*Gain*top,0.,1.);outColor=vec4(top>0.?color.rgb/top*opacity:vec3(0.),opacity);')
    s = s.replace('(color.rgb*Gain/max(1.,max(color.r*Gain,max(color.g*Gain,color.b*Gain))))', 'clamp(color.rgb*Gain,0.,1.)')
    s = s.replace('outColor=vec4(texture(Image,uv).rgb,Scene);', 'outColor=Scene<0.?texture(Image,uv):vec4(texture(Image,uv).rgb,Scene);')
    start=s.index(' draw(segments,r,project){'); end=s.index(' finish(ctx){',start)
    s=s[:start]+''' draw(segments,r,project){
  const gl=this.gl,groups=LightningMaterial.paths(segments,project);
  gl.enable(gl.BLEND);
  // Union segment/joint overlaps before compositing either material.
  for(const halo of [true,false])for(const runs of groups){
   if((halo?r.glowGain:r.coreGain)<=0)continue;
   const mesh=LightningMaterial.mesh(runs,r,halo),e=mesh.extent,w=this.canvas.width,h=this.canvas.height;
   const x=Math.max(0,Math.floor(e[0]-1)),y=Math.max(0,Math.floor(h-e[3]-1)),right=Math.min(w,Math.ceil(e[2]+1)),top=Math.min(h,Math.ceil(h-e[1]+1));
   if(right<=x||top<=y)continue;
   gl.bindFramebuffer(gl.FRAMEBUFFER,this.fbo);gl.enable(gl.SCISSOR_TEST);gl.scissor(x,y,right-x,top-y);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);
   gl.blendFunc(gl.ONE,gl.ONE);gl.blendEquation(gl.MAX);this.upload(mesh,r,halo);
   gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.blendEquation(gl.FUNC_ADD);gl.useProgram(this.copy);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.texture);
   gl.blendFuncSeparate(gl.ONE,!halo&&LightningMaterial.vividCore(r)?gl.ONE_MINUS_SRC_ALPHA:gl.ONE,gl.ZERO,gl.ONE);
   gl.uniform1i(gl.getUniformLocation(this.copy,'Image'),0);gl.uniform1f(gl.getUniformLocation(this.copy,'Scene'),-1);gl.drawArrays(gl.TRIANGLES,0,3);gl.disable(gl.SCISSOR_TEST);
   if(!halo)this.stats.paths++;
  }
 }
'''+s[end:]
    p.write_text(s,encoding='utf-8')

for root in [Path('src/main/resources/assets/wuxingxiantu/shaders/core'),Path('C:/Users/Nostzephert/.codex/skills/minecraft-lightning/assets/forge-1.20.1/src/main/resources/assets/lightninglab/shaders/core'),Path('E:/着色器渲染/skill/minecraft-lightning/assets/forge-1.20.1/src/main/resources/assets/lightninglab/shaders/core')]:
    p=root/'bolt_halo.fsh'
    s=p.read_text(encoding='utf-8').replace('// Compress by the peak channel instead of clipping each channel to white.', '// Preserve recipe gain; MAX already prevents joint accumulation.').replace('radiance/max(1.0,max(radiance.r,max(radiance.g,radiance.b)))','clamp(radiance,0.0,1.0)')
    p.write_text(s,encoding='utf-8')

p=roots[0]/'custom-recipes.js';s=p.read_text(encoding='utf-8');prefix=s[:s.index('=')+1];v=json.loads(s[s.index('=')+1:].strip().rstrip(';'))
for key,r in v.items():
    if not key.startswith('old') and isinstance(r,dict) and r.get('gradientTarget')=='glow':r['glowColor']='#FFFFFF'
p.write_text(prefix+json.dumps(v,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
