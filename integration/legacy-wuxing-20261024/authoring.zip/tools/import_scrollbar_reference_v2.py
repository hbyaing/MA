"""Extract the supplied gold scrollbar into the existing rail/thumb atlas."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageChops
import shutil,json
root=Path(__file__).resolve().parents[1]
source=Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-30da5802-edde-4e53-961b-ed5b25fe39f7.png')
archive=root/'source-assets/scrollbar-reference-v2-20261011'
archive.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,archive/'reference-original.png')
im=Image.open(source).convert('RGBA')
sx,sy=im.width/683,im.height/2048
def extract(box,size,polygon=None):
    out=im.crop(tuple(round(v*(sx if i%2==0 else sy)) for i,v in enumerate(box)))
    for y in range(out.height):
        for x in range(out.width):
            r,g,b,a=out.getpixel((x,y))
            alpha=max(0,min(255,round(min(r-45,(r-b)*3)*2))) if r>g and g-b>18 and r-b>40 else 0
            out.putpixel((x,y),(r,g,b,alpha) if alpha else (0,0,0,0))
    if polygon:
        mask=Image.new('L',out.size)
        ImageDraw.Draw(mask).polygon([(round(x*out.width/(box[2]-box[0])),round(y*out.height/(box[3]-box[1]))) for x,y in polygon],fill=255)
        out.putalpha(ImageChops.multiply(out.getchannel('A'),mask))
    return out.resize(size,Image.Resampling.LANCZOS)
atlas=Image.new('RGBA',(84,1384))
cap=extract((304,70,377,164),(42,100))
rail=extract((304,300,377,304),(42,1184))
atlas.alpha_composite(cap,(0,0))
atlas.alpha_composite(rail,(0,100))
atlas.alpha_composite(cap.transpose(Image.Transpose.FLIP_TOP_BOTTOM),(0,1284))
thumb_cap=extract((310,589,371,642),(42,40),[(31,0),(61,28),(61,53),(0,53),(0,28)])
atlas.alpha_composite(thumb_cap,(42,0))
atlas.alpha_composite(extract((310,642,371,1365),(42,240)),(42,40))
atlas.alpha_composite(thumb_cap.transpose(Image.Transpose.FLIP_TOP_BOTTOM),(42,280))
target=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/scrollbar_reference.png'
if not (archive/'before-tip-cleanup.png').exists():
    shutil.copy2(target,archive/'before-tip-cleanup.png')
atlas.save(target)
target.with_suffix('.png.mcmeta').write_text('{"texture":{"blur":true,"clamp":true}}')
# Show both ends and a movable thumb using the renderer's source regions.
preview=Image.new('RGBA',(84,768),'#172730')
for x,top in [(16,18),(52,414)]:
    preview.alpha_composite(cap.resize((18,18)),(x,0))
    preview.alpha_composite(atlas.crop((0,500,42,501)).resize((18,732)),(x,18))
    preview.alpha_composite(cap.transpose(Image.Transpose.FLIP_TOP_BOTTOM).resize((18,18)),(x,750))
    preview.alpha_composite(atlas.crop((42,0,84,40)).resize((18,12)),(x,top))
    preview.alpha_composite(atlas.crop((42,40,84,280)).resize((18,300)),(x,top+12))
    preview.alpha_composite(atlas.crop((42,280,84,320)).resize((18,12)),(x,top+312))
preview.save(archive/'preview.png')
(archive/'manifest.json').write_text(json.dumps({'atlas_size':atlas.size,'rail_caps_mirrored':True,'background_removed':True,'runtime_width_unchanged':6},indent=2))
print('Imported gold rail, diamond end caps and separate thumb')
