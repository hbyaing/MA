"""Synchronize the two existing fire identities without changing render budgets."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
PALETTES = {
    'cold_ash': ('slot3', 'DCE3EB', '9194AD', '444052'),
    'sun_saint': ('slot7', 'FFF3C4', 'FFD34F', 'CB791B'),
}

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

path = ASSETS / 'shaders/furnacevolume/nine-flames.json'
data = json.loads(path.read_text(encoding='utf-8-sig'))
for name, (slot, core, body, edge) in PALETTES.items():
    row = next(p for p in data['palettes'] if p['id'] == slot)
    row.update(fireCore='#'+core.lower(), fireMid='#'+body.lower(), fireEdge='#'+edge.lower())
    row['style'] = name + (' · 冷银灰与灰紫' if name == 'cold_ash' else ' · 暖白与日金')
    profile_path = ASSETS / 'weapon_flames' / (name + '.json')
    profile = json.loads(profile_path.read_text(encoding='utf-8-sig'))
    profile['colors'].update(coreColor='#'+core, bodyColor='#'+body, edgeColor='#'+edge,
                             sparkColor='#'+core, glowColor='#'+body)
    write(profile_path, profile)
write(path, data)
path = ASSETS / 'item_text_catalog.json'
data = json.loads(path.read_text(encoding='utf-8-sig'))
for name, (_, core, body, edge) in PALETTES.items():
    key = 'exotic_fire_' + ('cold_bone' if name == 'cold_ash' else name)
    data[key].update(nameColor=int(body,16), gradeColor=int(body,16))
write(path, data)
for relative in ('tools/make_weapon_flames.py', 'tools/add_fire_descriptions_20261011.py'):
    path = ROOT / relative
    text = path.read_text(encoding='utf-8-sig')
    text = text.replace('E1E1D0', 'DCE3EB').replace('D2D2B4', '9194AD').replace('777D83', '444052')
    text = text.replace("'sun_saint','FFFFFF','FFFADC','B49349'", "'sun_saint','FFF3C4','FFD34F','CB791B'")
    text = text.replace('0xFFFADC', '0xFFD34F')
    path.write_text(text, encoding='utf-8')
print('Updated cold/sun palettes; names, alpha, geometry and motion unchanged.')
