from pathlib import Path
import json, shutil
root=Path(__file__).resolve().parents[1]
base=root/'src/main/java/cn/blockforge/generated/generatedmod'
dest=base/'client/tribulation'
dest.mkdir(parents=True,exist_ok=True)
skill=Path(r'C:/Users/Nostzephert/.codex/skills/minecraft-lightning/assets/forge-1.20.1')
for p in (skill/'src/main/java/dev/lightninglab').glob('*.java'):
    if p.stem in ['LightningClient','LightningGpuProbe','LightningLab']: continue
    text=p.read_text(encoding='utf-8').replace('package dev.lightninglab;','package cn.blockforge.generated.generatedmod.client.tribulation;').replace('LightningLab.MOD_ID','cn.blockforge.generated.generatedmod.GeneratedMod.MOD_ID').replace('lightninglab:','wuxingxiantu:')
    (dest/p.name).write_text(text,encoding='utf-8')
assets=root/'src/main/resources/assets/wuxingxiantu'
for p in (skill/'src/main/resources/assets/lightninglab').rglob('*'):
    if p.is_file():
        out=assets/p.relative_to(skill/'src/main/resources/assets/lightninglab');out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(p.read_text(encoding='utf-8').replace('lightninglab:','wuxingxiantu:'),encoding='utf-8')
recipes=assets/'tribulation';recipes.mkdir(exist_ok=True)
for p in (root/'deliverables/tribulation-lightning-v2-20261010/recipes').glob('*.json'):shutil.copy2(p,recipes/p.name)
shutil.copy2(skill.parent/'workbench/THIRD_PARTY_NOTICES.md',recipes/'THIRD_PARTY_NOTICES.md')
channel=base/'network/NetworkChannel.java';text=channel.read_text(encoding='utf-8').replace('VERSION = "71"','VERSION = "72"')
text=text.replace('public static void register() {','public static void register() {\n        s2c(75,cn.blockforge.generated.generatedmod.tribulation.TribulationVisualPacket.class,cn.blockforge.generated.generatedmod.tribulation.TribulationVisualPacket::encode,cn.blockforge.generated.generatedmod.tribulation.TribulationVisualPacket::decode,cn.blockforge.generated.generatedmod.tribulation.TribulationVisualPacket::handle);')
channel.write_text(text,encoding='utf-8')
p=base/'ClientPacketSink.java';text=p.read_text(encoding='utf-8').replace('public final class ClientPacketSink {','public final class ClientPacketSink {\n    public static Consumer<cn.blockforge.generated.generatedmod.tribulation.TribulationVisualPacket> tribulationVisual=packet->{};');p.write_text(text,encoding='utf-8')
p=base/'client/WuXingClientPackets.java';text=p.read_text(encoding='utf-8').replace('public static void register() {','public static void register() {\n        ClientPacketSink.tribulationVisual=cn.blockforge.generated.generatedmod.client.tribulation.TribulationEffects::accept;');p.write_text(text,encoding='utf-8')
# Expand persisted trial state without changing old saves' completed strike count.
p=base/'TribulationState.java';text=p.read_text(encoding='utf-8').replace('int countdownTicks,strikesDone,strikeDelay;','int countdownTicks,strikesDone,strikeDelay;\n        long visualSeed=java.util.concurrent.ThreadLocalRandom.current().nextLong();\n        boolean testing, harmless;')
text=text.replace('t.putInt("Countdown",countdownTicks);','t.putLong("VisualSeed",visualSeed);t.putBoolean("Testing",testing);t.putBoolean("Harmless",harmless);\n            t.putInt("Countdown",countdownTicks);')
text=text.replace('trial.countdownTicks=Math.max','if(t.contains("VisualSeed"))trial.visualSeed=t.getLong("VisualSeed");trial.testing=t.getBoolean("Testing");trial.harmless=t.getBoolean("Harmless");\n            trial.countdownTicks=Math.max')
p.write_text(text,encoding='utf-8')
print('Migrated complete skill renderer, shaders and recipes; packet bridge and persistence installed.')
