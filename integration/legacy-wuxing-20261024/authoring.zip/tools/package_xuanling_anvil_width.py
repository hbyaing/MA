from pathlib import Path
import json, zipfile, shutil

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables/玄灵铁砧加宽'
OUT.mkdir(parents=True,exist_ok=True)
resource=ROOT/'src/main/resources/assets/wuxingxiantu/models/block/xuanling_anvil.json'
model=json.loads(resource.read_text(encoding='utf-8'))
elements=model['elements']
def bounds(rows):return [round(max(e['to'][i] for e in rows)-min(e['from'][i] for e in rows),3) for i in range(3)]
base=bounds([e for e in elements if e['to'][1]<=4.5])
total=bounds(elements)
assert len(elements)==390 and 14<base[0]<14.3 and 12<base[2]<12.2 and total[1]==16
jar=ROOT/'build/libs/wuxingxiantu-0.2.jar'
with zipfile.ZipFile(jar) as z:
    assert z.read('assets/wuxingxiantu/models/block/xuanling_anvil.json')==resource.read_bytes()
    assert not any('ShieldImpactCapture' in n for n in z.namelist())
assert 'BUILD SUCCESSFUL' in (ROOT/'reports/xuanling-anvil-size-build.log').read_text(encoding='utf-8',errors='replace')
assert (ROOT/'reports/anvil-size-client/anvil-size-complete.txt').exists()
assert not (ROOT/'reports/anvil-size-client/failure.txt').exists()
shutil.copy2(jar,OUT/'wuxingxiantu-0.2-20261012-xuanling-anvil-wide.jar')
shutil.copy2(ROOT/'source-assets/xuantie-spirit-anvil/reference-textured/玄灵铁砧_加宽.bbmodel',OUT/'玄灵铁砧_加宽.bbmodel')
shutil.copy2(ROOT/'reports/anvil-size-client/anvil-size-comparison.png',OUT/'原版对比.png')
report={'vanilla_base_xyz':[12,4,12],'xuanling_base_xyz':base,'xuanling_total_xyz':total,
        'height_preserved':True,'collision_updated':True,'texture_uvs_preserved':True,
        'build':'passed','real_client_comparison':'passed','installed':False}
(OUT/'尺寸验证.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
