"""Static composition preview, not a Minecraft screenshot."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parents[1]
assets=root/'src/main/resources/assets/wuxingxiantu/textures/gui/refining'
out=root/'reports/refining-ui-20261011';out.mkdir(parents=True,exist_ok=True)
S=3
canvas=Image.new('RGBA',(452*S,282*S),(10,24,33,255))
def sprite(name,x,y,w,h,source=None):
    im=Image.open(assets/(name+'.png')).convert('RGBA')
    if source:im=im.crop(source)
    canvas.alpha_composite(im.resize((w*S,h*S),Image.Resampling.LANCZOS),(x*S,y*S))
def frame(name,x,y,w,h,e,d):
    im=Image.open(assets/(name+'.png'))
    sx=[0,e,im.width-e,im.width];sy=[0,e,im.height-e,im.height]
    dx=[0,d,w-d,w];dy=[0,d,h-d,h]
    for r in range(3):
        for c in range(3):
            if r==c==1:continue
            sprite(name,x+dx[c],y+dy[r],dx[c+1]-dx[c],dy[r+1]-dy[r],(sx[c],sy[r],sx[c+1],sy[r+1]))
sprite('landscape',3,3,446,276)
overlay=Image.new('RGBA',canvas.size,(5,17,27,60))
canvas=Image.alpha_composite(canvas,overlay)
frame('panel',0,0,452,282,48,11)
sprite('title',161,9,130,17);sprite('separator',24,21,404,6)
sprite('previous',22,48,26,26);sprite('next',404,48,26,26);sprite('close',426,8,18,18)
frame('output',209,44,34,34,12,4)
for x in [26,162,298]:
    ImageDraw.Draw(canvas).rectangle((x*S,111*S,(x+128)*S,157*S),fill=(24,38,49,220))
    frame('card',x,111,128,46,12,4)
sprite('separator',24,186,404,6)
ImageDraw.Draw(canvas).rectangle((40*S,231*S,412*S,257*S),fill=(28,41,54,255))
frame('button',40,231,372,26,22,5)
sprite('button_left',45,236,35,16);sprite('button_right',367,236,40,16)
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',24)
draw=ImageDraw.Draw(canvas)
def text(s,x,y,color='#e4c88b',center=False):
    if center:x-=draw.textlength(s,font=font)/(2*S)
    draw.text((int(x*S),y*S),s,font=font,fill=color)
text('炼器配方 4/7',226,32,'#9db1c6',True)
text('产出：明魂剑',226,82,center=True);text('所需材料',26,99)
for x,name,amount,color in [(26,'玄铁剑','0/1','#ff9088'),(162,'铁锭','0/6','#ff9088'),(298,'灵力结晶','4/4','#7be0a0')]:
    text(name,x+30,125,'#ddeaf6');text(amount,x+30,137,color)
text('灵力消耗：70（当前：1320000）',26,165,'#b8dfff')
time='炼制时间：12秒';text(time,426-draw.textlength(time,font=font)/S,165)
text('承华台：3 台承载中 · 周围4格内取材',226,179,'#9fe0c8',True)
text('9阶·涅槃神火',226,198,'#ec88b2',True);text('异火阶位：9 / 需求 1',226,214,'#7be0a0',True)
text('开始炼器',226,239,'#8c9aa5',True);text('承华台缺少：玄铁剑×1、铁锭×6',226,263,'#ff9088',True)
canvas.save(out/'layout-preview.png')
sheet=Image.open(root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/scrollbar_reference.png')
preview=Image.new('RGBA',(168,1384),(12,24,33,255))
for col,y in [(0,80),(84,650)]:
    preview.alpha_composite(sheet.crop((0,0,42,1384)),(col,0))
    preview.alpha_composite(sheet.crop((42,0,84,320)),(col,y))
preview.save(out/'scrollbar-preview.png')
print('Saved static layout and two-position scrollbar previews')
