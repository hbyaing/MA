from pathlib import Path
import json
root=Path(__file__).resolve().parents[1];java=root/'src/main/java/cn/blockforge/generated/generatedmod'
def edit(path,old,new):
    t=path.read_text(encoding='utf-8');assert old in t,(path,old[:50]);path.write_text(t.replace(old,new),encoding='utf-8')
p=java/'network/NetworkChannel.java'
edit(p,'VERSION = "69"','VERSION = "70"')
edit(p,'    public static void register() {','''    public static void register() {
        c2s(74,cn.blockforge.generated.generatedmod.realmflight.RealmFlightTogglePacket.class,
                cn.blockforge.generated.generatedmod.realmflight.RealmFlightTogglePacket::encode,
                cn.blockforge.generated.generatedmod.realmflight.RealmFlightTogglePacket::decode,
                cn.blockforge.generated.generatedmod.realmflight.RealmFlightTogglePacket::handle);''')
p=root/'tools/network-message-ids.json';ids=json.loads(p.read_text(encoding='utf-8'));ids.append(dict(id=74,type='cn.blockforge.generated.generatedmod.realmflight.RealmFlightTogglePacket',direction='C2S'));p.write_text(json.dumps(ids,indent=2)+'\n',encoding='utf-8')
p=java/'client/CultivationVisionPage.java'
edit(p,'int inset=icon==null?4:20;','int inset=20; // Reserve the same icon column for merit until its icon is added.')
edit(p,'int meritWidth=Math.min(b.w()/2,Math.max(42,font.width(merit)+7));','int meritWidth=b.w()-half;')
edit(p,'CultivationUi.fit(g,effect.getDisplayName(),b.x()+28,y+1,b.w()-40,CultivationUi.TEXT,mx,my);\n            CultivationUi.fit(g,Component.literal("Lv."+(instance.getAmplifier()+1)),b.x()+28,y+14,26,color,mx,my);\n            var duration=MobEffectUtil.formatDuration(instance,1.0F);CultivationUi.fit(g,duration,b.x()+56,y+14,Math.max(12,b.w()-68),CultivationUi.GOLD,mx,my);','''Component name=Component.translatable(effect.getDescriptionId()).append(" Lv."+(instance.getAmplifier()+1));
            CultivationUi.fit(g,name,b.x()+28,y+1,b.w()-40,CultivationUi.TEXT,mx,my);
            var duration=MobEffectUtil.formatDuration(instance,1.0F);CultivationUi.fit(g,duration,b.x()+28,y+14,Math.max(12,b.w()-40),CultivationUi.GOLD,mx,my);''')
edit(p,'CultivationUi.tooltip(effect.getDisplayName().copy().append(" · Lv."+(instance.getAmplifier()+1)+"\\n").append(duration));','CultivationUi.tooltip(name.copy().append("\\n").append(effect.getDisplayName()).append("\\n").append(duration));')
p=java/'client/DipperRitualEffects.java'
for old,new in [
 ('Math.cos(a)*3.5','Math.cos(a)*17.5'),('Math.sin(a)*3.5','Math.sin(a)*17.5'),
 ('center,3.5,.018,CYAN,.26F','center,17.5,.07,CYAN,.72F'),
 ('center,3.22,.011,GOLD,.15F','center,16.1,.045,GOLD,.56F'),
 ('Math.cos(a)*3.35','Math.cos(a)*16.75'),('Math.sin(a)*3.35','Math.sin(a)*16.75'),
 ('p,.24,a,runeCell','p,.7,a,runeCell'),('CYAN,.3F*strength','CYAN,.75F*strength'),
 ('done?.64F:current?.9F:.23F','done?.9F:current?1F:.65F'),
 ('current?.48:.32','current?.95:.65'),('side,up,.14,32,WHITE','side,up,.25,32,WHITE'),
 ('current?.4:.25,current?.025:.012','current?.65:.4,current?.06:.035'),
 ('alpha*.65F','alpha*.9F'),('.57,.023,CYAN,alpha*.6F','.9,.06,CYAN,alpha*.9F'),
 ('.33,now*.012,runeCell(frame),WHITE,alpha*.55F','.55,now*.012,runeCell(frame),WHITE,alpha*.85F'),
 ('linked?.025:.009','linked?.07:.04'),('linked?.62F:.12F','linked?.95F:.6F'),
 ('side,up,.08,32,m.color,fade*.72F','side,up,.14,32,m.color,fade*.95F'),
 ('width<.05','width<.1'),('alpha*.14F','alpha*.32F')]:edit(p,old,new)
print('Protocol 70 / 75 messages; aligned merit, short effect titles, larger and brighter Dipper')
