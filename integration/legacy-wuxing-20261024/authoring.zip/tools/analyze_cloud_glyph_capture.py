"""Review real-client cloud-glint captures; compose cropped, unchanged GPU frames."""
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
captures = root / 'reports/cloud-glyph-client'
output = root / 'reports/guard-cloud-20261013'
output.mkdir(parents=True, exist_ok=True)
metadata = json.loads((captures / 'captures.json').read_text(encoding='utf-8'))
assert (captures / 'complete.txt').exists() and not metadata['failures']
assert metadata['initialShaderIdentity'] != 0
assert metadata['reloadedShaderIdentity'] not in (0, metadata['initialShaderIdentity'])
assert all(row['glError'] == 0 for row in metadata['captures'])

def array(name):
    return np.asarray(Image.open(captures / name).convert('RGB')).astype(np.int16)

def difference(a, b, box=None):
    if box:
        x0, y0, x1, y1 = box
        a, b = a[y0:y1, x0:x1], b[y0:y1, x0:x1]
    return np.max(np.abs(a-b), axis=2)

def blue_pixels(name, box):
    im = array(name)
    x0, y0, x1, y1 = box
    im = im[y0:y1, x0:x1]
    return int(np.count_nonzero((im[...,2]-im[...,0]>28) & (im[...,2]-im[...,1]>8)))

torso = (555, 280, 724, 471)
moving = [difference(array('iron-cloud-front-80.png'), array(f'iron-cloud-front-{n}.png'), torso)
          for n in (88, 96, 104, 112, 120)]
assert all(np.count_nonzero(delta > 12) > 100 for delta in moving)
# The stone wall completely occludes the player. Lighting/arrow/shadow animation
# can still differ elsewhere, so inspect the entire central wall area for blue
# light plus meaningful RGB changes, rather than promising identical frames.
wall_box = (180, 120, 1060, 730)
wall_diff = difference(array('wall-occlusion-cloud.png'), array('wall-occlusion-off.png'), wall_box)
wall_blue = blue_pixels('wall-occlusion-cloud.png', wall_box)
x0,y0,x1,y1 = wall_box
wall_rgb_delta = (array('wall-occlusion-cloud.png')-array('wall-occlusion-off.png'))[y0:y1,x0:x1]
chromatic_wall_changes = int(np.count_nonzero(wall_rgb_delta.max(axis=2)-wall_rgb_delta.min(axis=2)>4))
assert wall_blue == 0 and chromatic_wall_changes == 0

plain = next(row for row in metadata['captures'] if row['name']=='01-iron-plain-front.png')
mixed = next(row for row in metadata['captures'] if row['name']=='iron-mixed-slots-front.png')
assert all(level == 0 for level in plain['guardLevels'].values())
assert mixed['guardLevels'] == {'head':0, 'chest':0, 'legs':0, 'feet':3}
assert mixed['foilSlots']['legs'] and mixed['foilSlots']['feet']
contacts = (captures/'contacts.txt').read_text(encoding='utf-8').splitlines()
assert len(contacts) == 2
assert all((captures/f'impact-{i}-peak.png').exists() for i in (1,2))
report = {'scope':'Forge 1.20.1 / 47.4.10 isolated real client, worn player armor',
          'captured_frames':metadata['captureCount'], 'gpu_errors':0,
          'shader_replaced_on_reload':True, 'confirmed_server_contacts':contacts,
          'front_moving_pixels':[int(np.count_nonzero(delta>12)) for delta in moving],
          'central_wall_blue_pixels':wall_blue,
          'central_wall_changed_pixels_over_4':int(np.count_nonzero(wall_diff>4)),
          'central_wall_chromatic_changed_pixels_over_4':chromatic_wall_changes,
          'mixed_slot_guard_levels':mixed['guardLevels'],
          'ordinary_enchanted_leggings_has_foil':mixed['foilSlots']['legs'],
          'texture_size':[1024,512], 'mask_edge_aa_pixels':.32,
          'limitations':['Arbitrary third-party armor UVs keep their original glint; only local hits use captured geometry.',
                         'Inventory item / held / dropped armor item glint is unchanged.',
                         'No external shader pack compatibility acceptance was performed.']}
(output/'runtime-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

font = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 22)
small = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 16)
# Crop the occupied viewport for readability, preserving actual pixels/colors.
panels = [('netherite-cloud-front-288.png','常态云篆 · 笔形锐化'),
          ('impact-2-peak.png','真实箭击 · 局部波纹'),
          ('iron-mixed-slots-front.png','仅御体靴子 · 按装备分开')]
review = Image.new('RGB',(1170,650),'#101927')
draw=ImageDraw.Draw(review)
draw.text((18,12),'灵力御体 · 云篆护纹实机验收',font=font,fill='#c8e7ff')
for i,(name,label) in enumerate(panels):
    im=Image.open(captures/name).convert('RGB').crop((380,60,820,710))
    im.thumbnail((376,560),Image.Resampling.LANCZOS)
    review.paste(im,(i*390+(390-im.width)//2,80))
    draw.text((i*390+22,48),label,font=small,fill='#b9d7ed')
review.save(output/'cloud-glyph-game-review.png')

frames=[]
for n in (80,88,96,104,112,120):
    im=Image.open(captures/f'iron-cloud-front-{n}.png').convert('RGB').crop((410,60,860,710))
    im.thumbnail((450,650),Image.Resampling.LANCZOS)
    frame=Image.new('RGB',(480,700),'#101927')
    d=ImageDraw.Draw(frame)
    d.text((18,8),'云篆护纹 · 实机逐笔流动',font=font,fill='#c8e7ff')
    frame.paste(im,((480-im.width)//2,45))
    frames.append(frame)
frames[0].save(output/'cloud-glyph-game-motion.gif',save_all=True,append_images=frames[1:],duration=400,loop=0,optimize=False)
print(json.dumps(report,ensure_ascii=False,indent=2))
