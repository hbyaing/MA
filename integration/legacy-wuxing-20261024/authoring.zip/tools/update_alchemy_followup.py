from pathlib import Path
import json
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'src/main/java/cn/blockforge/generated/generatedmod'
RES=ROOT/'src/main/resources'
def edit(path,old,new):
    s=path.read_text(encoding='utf-8-sig')
    if old not in s:raise ValueError(f'missing target {path}: {old[:70]}')
    path.write_text(s.replace(old,new),encoding='utf-8')

edit(JAVA/'client/CultivationVisionPage.java','if(isHoveredOrFocused()){','if(isMouseOver(mx,my)){')
# Focus from the last root click must not override unrelated pointer tooltips.
edit(JAVA/'client/CultivationVisionPage.java','if(isHoveredOrFocused())CultivationUi.tooltip(DomainTooltips.describe','if(isMouseOver(mx,my))CultivationUi.tooltip(DomainTooltips.describe')
for old,new in [('if (isHoveredOrFocused() && font.width(getMessage())','if (isMouseOver(mx,my) && font.width(getMessage())'),
                ('else if (isHoveredOrFocused()) tooltip(getMessage());','else if (isMouseOver(mx,my)) tooltip(getMessage());'),
                ('if (isHoveredOrFocused()) tooltip(hint.get());','if (isMouseOver(mx,my)) tooltip(hint.get());'),
                ('if (isHoveredOrFocused()) tooltip(getMessage().copy()','if (isMouseOver(mx,my)) tooltip(getMessage().copy()')]:
    edit(JAVA/'client/CultivationUi.java',old,new)

langs={
 'zh_cn':{'item.wuxingxiantu.pill_ash':'丹灰','quality.wuxingxiantu.special':'特殊',
 'tooltip.wuxingxiantu.intro.pill_ash.category':'炼丹副产物',
 'tooltip.wuxingxiantu.intro.pill_ash.lore':'炼制失败后留下的药灰，残余药性仍可调入灵墨。',
 'tooltip.wuxingxiantu.intro.pill_ash.action.0':'炼丹失败产出；一份丹灰与一瓶灵液可合成一瓶灵墨。'},
 'en_us':{'item.wuxingxiantu.pill_ash':'Pill Ash','quality.wuxingxiantu.special':'Special',
 'tooltip.wuxingxiantu.intro.pill_ash.category':'Alchemy By-product',
 'tooltip.wuxingxiantu.intro.pill_ash.lore':'Ash from a failed batch retains traces of medicinal essence.',
 'tooltip.wuxingxiantu.intro.pill_ash.action.0':'Produced by failed alchemy. Combine one ash with one spirit liquid bottle to craft spirit ink.'}}
for lang,keys in langs.items():
 p=RES/f'assets/wuxingxiantu/lang/{lang}.json';data=json.loads(p.read_text(encoding='utf-8-sig'));data.update(keys)
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=RES/'assets/wuxingxiantu/item_text_catalog.json';data=json.loads(p.read_text(encoding='utf-8-sig'))
data['pill_ash']={'nameColor':12632256,'gradeColor':12632256,'visibility':'player','actions':1}
p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
source=Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-07167de0-12e7-47a6-af32-7473953969ae.png')
assets=ROOT/'source-assets/alchemy-followup-20261014';assets.mkdir(parents=True,exist_ok=True)
im=Image.open(source).convert('RGBA');im.save(assets/'pill-ash-reference.png')
# The supplied image already has a true alpha channel; only crop transparent margins and resize.
im=im.crop(im.getbbox());im.thumbnail((30,30),Image.Resampling.LANCZOS)
out=Image.new('RGBA',(32,32));out.alpha_composite(im,((32-im.width)//2,(32-im.height)//2))
out.save(RES/'assets/wuxingxiantu/textures/item/pill_ash.png')
out.resize((256,256),Image.Resampling.NEAREST).save(assets/'pill-ash-preview.png')
