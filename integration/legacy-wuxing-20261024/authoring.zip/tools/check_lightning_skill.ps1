$env:JAVA_HOME='C:/tmp/temurin17/jdk-17.0.20.1+1'
$env:PATH="$env:JAVA_HOME/bin;$env:PATH"
$env:TEMP='C:/gradle-tmp'
$env:TMP='C:/gradle-tmp'
$outputDirectory=Join-Path (Split-Path $PSScriptRoot -Parent) 'reports/tribulation-install-20261010'
Set-Location -LiteralPath 'C:/Users/Nostzephert/.codex/skills/minecraft-lightning/assets/forge-1.20.1'
& ./gradlew.bat lightningCheck build --offline '-Dorg.gradle.jvmargs=-Xmx3G -Dfile.encoding=UTF-8 -Djava.io.tmpdir=C:/gradle-tmp' *> (Join-Path $outputDirectory 'skill-joint-check.log')
$LASTEXITCODE | Set-Content (Join-Path $outputDirectory 'skill-joint-check.exit')
