from pathlib import Path
import subprocess,webbrowser,urllib.request,time

root=Path(__file__).resolve().parent
runtime=Path('C:/Users/Nostzephert/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
url='http://127.0.0.1:8830/'
try:urllib.request.urlopen(url+'api/state',timeout=2)
except OSError:
    subprocess.Popen([str(runtime),str(root/'serve.py')],cwd=root,creationflags=subprocess.CREATE_NO_WINDOW)
    for _ in range(30):
        try:urllib.request.urlopen(url+'api/state',timeout=1);break
        except OSError:time.sleep(.2)
webbrowser.open(url)
