from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, unquote
import json, argparse, importlib.util

ROOT=Path(__file__).resolve().parent
MODEL=Path('E:/着色器渲染/alchemy-vfx-lab/model').resolve()
spec=importlib.util.spec_from_file_location('recipe',ROOT/'recipe.py')
recipe=importlib.util.module_from_spec(spec);spec.loader.exec_module(recipe)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kw):super().__init__(*args,directory=str(ROOT),**kw)
    def log_message(self,*args):pass
    def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
    def translate_path(self,path):
        relative=unquote(urlparse(path).path)
        if relative.startswith('/model/'):
            target=(MODEL/relative[7:]).resolve()
            if target.is_relative_to(MODEL):return str(target)
            return str(ROOT/'not-found')
        return super().translate_path(path)
    def send_json(self,code,value):
        data=json.dumps(value,ensure_ascii=False).encode('utf-8');self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def do_GET(self):
        path=urlparse(self.path).path
        if path in ['/api/state','/api/flame-palettes']:
            self.send_json(200,json.loads((ROOT/('workbench.json' if path=='/api/state' else 'nine-flames.json')).read_text(encoding='utf-8')))
        else:super().do_GET()
    def do_POST(self):
        try:
            local={f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
            if self.headers.get('Host') not in local or self.headers.get('Origin') not in {None,*('http://'+host for host in local)}:raise ValueError('只接受本地工作台请求')
            if self.path!='/api/state':self.send_json(404,{'error':'接口不存在'});return
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<65536:raise ValueError('配置过大')
            value=json.loads(self.rfile.read(size))
            if set(value)!={'bottom','upper'}:raise ValueError('须包含底火和上层配置')
            for key in value:value[key]=recipe.loads(json.dumps(value[key]))
            staging=ROOT/'workbench.pending.json';staging.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');staging.replace(ROOT/'workbench.json')
            self.send_json(200,{'ok':True})
        except (ValueError,OSError) as error:self.send_json(400,{'ok':False,'error':str(error)})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8830);args=parser.parse_args()
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler);server.daemon_threads=True
    print(f'http://127.0.0.1:{server.server_port}/',flush=True);server.serve_forever()
