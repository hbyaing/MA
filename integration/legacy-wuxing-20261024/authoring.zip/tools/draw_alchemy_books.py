"""Deterministic 32px alchemy covers and aura-pill recipe; Pillow only."""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'src/main/resources/assets/wuxingxiantu/textures/item'
BOOKS = [
    ('introduction', '#467b72', '#91d5b7'),
    ('nourishing', '#315d90', '#8ae9f0'),
    ('guarding', '#70404d', '#efaa86'),
    ('body', '#49515d', '#dfb579'),
    ('breakthrough', '#543c7d', '#dcb8f2'),
    ('aptitude', '#34724a', '#c2e882'),
    ('complete', '#752f37', '#ffdf83'),
]
OUT.mkdir(parents=True, exist_ok=True)
images = []
for n, (name, base, accent) in enumerate(BOOKS):
    im = Image.new('RGBA', (32, 32))
    d = ImageDraw.Draw(im)
    d.polygon([(5,3),(25,3),(28,6),(28,28),(7,29),(3,25),(3,6)], fill='#172832')
    d.rectangle((7,6,26,27), fill='#ae9c80')
    d.rectangle((8,7,26,25), fill='#e2ddc4')
    for y in (9,13,17,21,25): d.line((9,y,26,y),fill='#b7b4a0')
    d.polygon([(5,3),(24,3),(25,5),(25,25),(5,26)], fill=base)
    d.rectangle((4,5,7,25),fill='#243c45')
    d.line((9,5,23,5,23,23,9,23,9,5),fill=accent)
    for y in (7,12,17,22):
        d.line((4,y,8,y),fill='#e1cf9d')
        d.point((5,y+1),fill='#8e856d')
    d.rectangle((20,24,22,29),fill=accent)
    # Crucible, circulating qi, shield, hammer, gate, root, trigrams.
    if n == 0:
        d.rectangle((13,12,20,17),fill=accent)
        d.line((12,11,21,11),fill=accent)
        d.rectangle((14,18,15,19),fill=accent); d.rectangle((18,18,19,19),fill=accent)
        d.line((16,10,17,8,18,10),fill='#eaf4d7')
    elif n == 1:
        d.arc((12,9,21,20),30,310,fill=accent,width=2)
        d.polygon([(20,9),(22,13),(18,12)],fill=accent)
        d.rectangle((16,13,18,16),fill='#eefcff')
    elif n == 2:
        d.polygon([(12,10),(17,8),(22,10),(21,16),(17,20),(13,16)],fill=accent)
        d.polygon([(14,11),(17,10),(20,11),(19,16),(17,18),(15,16)],fill=base)
        d.line((17,11,17,16),fill='#ffe4ba')
    elif n == 3:
        d.line((14,19,20,10),fill=accent,width=3)
        d.polygon([(13,9),(16,7),(22,12),(20,15)],fill=accent)
        d.line((12,20,22,20),fill=accent)
    elif n == 4:
        d.rectangle((12,10,14,20),fill=accent); d.rectangle((20,10,22,20),fill=accent)
        d.line((11,9,23,9),fill=accent,width=2)
        d.line((17,19,17,12),fill='#fcf4ff',width=2)
        d.polygon([(15,14),(18,10),(20,14)],fill='#fcf4ff')
    elif n == 5:
        d.line((17,19,17,10),fill=accent,width=2)
        d.polygon([(16,14),(12,12),(12,9),(16,10)],fill=accent)
        d.polygon([(18,12),(22,9),(22,13),(18,15)],fill='#ecf5b8')
        d.line((13,21,17,18,21,21),fill=accent)
    else:
        d.polygon([(17,7),(23,11),(23,17),(17,21),(11,17),(11,11)],outline=accent,width=1)
        for y in (11,14,17): d.line((14,y,20,y),fill=accent)
        d.rectangle((16,13,17,15),fill=base)
        for x,y in ((10,6),(22,6),(10,22),(22,22)): d.point((x,y),fill='#fff4ba')
    im.save(OUT / f'alchemy_{name}.png')
    images.append(im)

im=Image.new('RGBA',(32,32)); d=ImageDraw.Draw(im)
d.polygon([(7,4),(24,4),(26,8),(24,27),(6,27),(7,23)],fill='#263b45')
d.rectangle((8,5,23,25),fill='#e8e1be')
d.rectangle((10,6,22,24),fill='#f7edcc')
for y in (4,25):
    d.rectangle((4,y,26,y+2),fill='#766747')
    d.line((5,y,25,y),fill='#d2bf82')
    d.rectangle((3,y-1,5,y+3),fill='#375e60')
    d.rectangle((26,y-1,28,y+3),fill='#375e60')
d.ellipse((11,8,21,18),fill='#264f65')
d.ellipse((13,9,20,16),fill='#48aab5')
d.rectangle((14,10,16,12),fill='#d0ffff')
d.arc((9,7,23,20),10,170,fill='#479883',width=1)
for y,x in ((20,11),(22,10)):
    d.line((x,y,18,y),fill='#897c60'); d.point((20,y),fill='#897c60')
d.rectangle((21,21,23,23),fill='#aa454b');d.point((22,22),fill='#efd3a0')
im.save(OUT/'aura_pill_formula.png');images.append(im)

sheet=Image.new('RGB',(8*144,176),'#20282e')
for i,im in enumerate(images):
    large=im.resize((128,128),Image.Resampling.NEAREST)
    sheet.paste(large,(i*144+8,8),large)
    ImageDraw.Draw(sheet).text((i*144+10,148), BOOKS[i][0] if i<7 else 'aura formula',fill='white')
preview=ROOT/'reports/alchemy_texture_preview.png';preview.parent.mkdir(exist_ok=True)
sheet.save(preview)
print('Wrote 8 RGBA sprites at 32x32 and reports/alchemy_texture_preview.png')
