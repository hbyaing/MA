param([switch]$CompileOnly,[switch]$ShowWindow)
$ErrorActionPreference='Stop'
$projectRoot=Split-Path $PSScriptRoot -Parent
Set-Location -LiteralPath $projectRoot
$env:JAVA_HOME='C:/tmp/temurin17/jdk-17.0.20.1+1'
$env:PATH="$env:JAVA_HOME/bin;$env:PATH"
$env:TEMP='C:/gradle-tmp'
$env:TMP='C:/gradle-tmp'
$env:JAVA_OPTS='-Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8'
$OutputEncoding=[System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
$reportRoot=Join-Path $projectRoot 'reports/shield-shatter-client'
New-Item -ItemType Directory -Force -Path $reportRoot | Out-Null
# Cached offline dependencies do not need ForgeGradle's separate remote preflight probe.
$taskArguments=@('--offline','-Dnet.minecraftforge.gradle.check.certs=false','-Dorg.gradle.java.home=C:/tmp/temurin17/jdk-17.0.20.1+1',
    '-Dorg.gradle.jvmargs=-Xmx3G -Dfile.encoding=UTF-8 -Djava.io.tmpdir=C:/gradle-tmp','-PshieldShatterCapture')
if($ShowWindow){$taskArguments+='-PshieldShatterShowWindow'}
$taskName=if($CompileOnly){'compileShieldShatterClientTestJava'}else{'runClient'}
$taskArguments+=$taskName
$logName=if($CompileOnly){'compile-fixture.log'}else{'client.log'}
$ErrorActionPreference='Continue'
& (Join-Path $projectRoot 'gradlew.bat') @taskArguments 2>&1 | Out-File -LiteralPath (Join-Path $reportRoot $logName) -Encoding utf8
$taskExit=$LASTEXITCODE
$taskExit | Set-Content -LiteralPath (Join-Path $reportRoot ($logName+'.exit')) -Encoding ASCII
exit $taskExit
