"""Full-resolution crops. Only border-connected paper becomes transparent; RGB is untouched."""
from pathlib import Path
from PIL import Image, ImageDraw
from collections import deque
import json, hashlib, shutil

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r'C:\Users\Nostzephert\Desktop\新建文件夹\第二页.png')
OUT = ROOT / 'source-assets/cultivation-vision-reference-v2'
RUNTIME = ROOT / 'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision/roots'
OUT.mkdir(parents=True, exist_ok=True)
RUNTIME.mkdir(parents=True, exist_ok=True)
shutil.copy2(SOURCE, OUT / 'reference-original.png')
source = Image.open(SOURCE).convert('RGBA')
boxes = {'gold':(772,511,844,590), 'wood':(852,511,926,590),
         'water':(932,511,1006,590), 'fire':(1013,511,1089,590), 'earth':(1098,511,1171,590)}
manifest = {'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(), 'crops':{}}
preview = Image.new('RGBA',(430,115),(225,215,191,255))
for i,(name,box) in enumerate(boxes.items()):
    crop = source.crop(box)
    px = crop.load(); w,h=crop.size
    seen=set(); queue=deque([(x,y) for x in range(w) for y in (0,h-1)] + [(x,y) for y in range(h) for x in (0,w-1)])
    while queue:
        x,y=queue.popleft()
        if (x,y) in seen or not (0<=x<w and 0<=y<h): continue
        seen.add((x,y)); r,g,b,a=px[x,y]
        if (r+g+b)/3 > 75 and b/max(1,r) > .62:
            px[x,y]=(r,g,b,0)
            queue.extend(((x-1,y),(x+1,y),(x,y-1),(x,y+1)))
    remaining={(x,y) for y in range(h) for x in range(w) if px[x,y][3]}
    groups=[]
    while remaining:
        todo=[remaining.pop()]; group=set(todo)
        while todo:
            x,y=todo.pop()
            for neighbor in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
                if neighbor in remaining:
                    remaining.remove(neighbor); group.add(neighbor); todo.append(neighbor)
        groups.append(group)
    keep=max(groups,key=len)
    for group in groups:
        if group is not keep:
            for x,y in group:
                r,g,b,a=px[x,y]; px[x,y]=(r,g,b,0)
    path=RUNTIME/(name+'.png'); crop.save(path)
    (RUNTIME/(name+'.png.mcmeta')).write_text('{"texture":{"blur":true,"clamp":true}}',encoding='utf-8')
    crop.save(OUT/(name+'.png'))
    preview.alpha_composite(crop,(i*85+5,8))
    manifest['crops'][name]={'box':box,'size':crop.size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
preview.save(OUT/'roots-preview.png')
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Five original-resolution root crops prepared; no resize or recoloring.')
