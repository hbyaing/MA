from pathlib import Path
p=Path('E:/五行仙途/tools/firecoil-workbench')
s=(p/'preview.js').read_text('utf-8')
at=s.index('const hexColor=')
s=s[:at]+'''const GLOW_FRAGMENT=`#version 300 es
precision highp float;
in vec2 screenUV;out vec4 fragColor;
uniform sampler2D Flame,SceneDepth;uniform vec2 Pixel;
void main(){
 vec4 flame=texture(Flame,screenUV);vec3 glow=vec3(0);float total=0.;
 float d0=texture(SceneDepth,screenUV).r;
 for(int ring=1;ring<=3;ring++)for(int ray=0;ray<12;ray++){
  float a=float(ray)*6.2831853/12.+float(ring)*.31;
  vec2 uv=screenUV+vec2(cos(a),sin(a))*Pixel*float(ring)*3.3;
  float d=texture(SceneDepth,uv).r;
  float w=exp(-float(ring*ring)*.24)*exp(-abs(d-d0)/max(.000001,1.-d0)*25.);
  vec3 c=texture(Flame,uv).rgb;glow+=c*w;total+=w;
 }
 glow/=max(total,.0001);
 // Premultiplied source, with a restrained additive halo and preserved chroma.
 vec3 color=flame.rgb+glow*.31;
 fragColor=vec4(color/(1.+max(vec3(0),color-vec3(1.2))*.30),flame.a);
}`;
function makeFlameTarget(gl,width,height){
 const hdr=!!gl.getExtension('EXT_color_buffer_float'),color=gl.createTexture(),fbo=gl.createFramebuffer();
 gl.bindTexture(gl.TEXTURE_2D,color);gl.texImage2D(gl.TEXTURE_2D,0,hdr?gl.RGBA16F:gl.RGBA8,width,height,0,gl.RGBA,hdr?gl.HALF_FLOAT:gl.UNSIGNED_BYTE,null);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
 gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);
 if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('火焰光晕缓冲创建失败');
 gl.bindFramebuffer(gl.FRAMEBUFFER,null);return {color,fbo,width,height,hdr};
}
''' + s[at:]
s=s.replace('this.sceneTarget=null;','this.sceneTarget=null;this.flameTarget=null;this.glowProgram=program(gl,FULLSCREEN_VERTEX,GLOW_FRAGMENT);this.glowUniforms=uniformLocations(gl,this.glowProgram);')
s=s.replace('this.sceneTarget=makeSceneTarget(gl,width,height);','this.sceneTarget=makeSceneTarget(gl,width,height);if(this.flameTarget){gl.deleteTexture(this.flameTarget.color);gl.deleteFramebuffer(this.flameTarget.fbo);}this.flameTarget=makeFlameTarget(gl,width,height);')
s=s.replace('if(volumeActive){gl.useProgram(this.volumeProgram);','if(volumeActive){gl.bindFramebuffer(gl.FRAMEBUFFER,this.flameTarget.fbo);gl.disable(gl.SCISSOR_TEST);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);gl.clearColor(.025,.031,.044,1);gl.disable(gl.BLEND);gl.useProgram(this.volumeProgram);')
s=s.replace('gl.disable(gl.DEPTH_TEST);gl.depthMask(false);gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.enable(gl.SCISSOR_TEST);','gl.disable(gl.DEPTH_TEST);gl.depthMask(false);gl.disable(gl.BLEND);gl.enable(gl.SCISSOR_TEST);')
s=s.replace('gl.drawArrays(gl.TRIANGLES,0,3);gl.disable(gl.SCISSOR_TEST);}', '''gl.drawArrays(gl.TRIANGLES,0,3);gl.disable(gl.SCISSOR_TEST);
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.useProgram(this.glowProgram);this.bindTexture(0,this.flameTarget.color);this.bindTexture(1,this.sceneTarget.depth);this.setUniform(this.glowUniforms,'Flame',0);this.setUniform(this.glowUniforms,'SceneDepth',1);this.setUniform(this.glowUniforms,'Pixel',[1/width,1/height]);gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.drawArrays(gl.TRIANGLES,0,3);}''')
s=s.replace('draws:3+(volumeActive?1:0)','draws:3+(volumeActive?2:0)').replace("renderer:'3d-volume'","renderer:'flowing-flame-review/2'")
(p/'preview.js').write_text(s,'utf-8')
s=(p/'index.html').read_text('utf-8').replace('<button id="reset-camera">复位视角</button>','<button id="reset-camera">复位视角</button><button id="front-view">正面</button><button id="side-view">侧面</button><button id="capture-image">保存画面</button>')
s=s.replace('游戏按实际异火换色，并使用已有武器挂点。游戏体积以 1/3 分辨率积分，再按深度合成；网页为原生精度参考。','第二轮流焰审查：不规则主副焰、折叠薄焰、连续剥离火舌和局部光晕。此版仅在工作台迭代，尚未同步到游戏。')
s=s.replace('保存到 测试 (1)','游戏实装暂缓').replace('三维密度 / 代理人形深度遮挡','流焰迭代 II / 仅工作台审查')
(p/'index.html').write_text(s,'utf-8')
s=(p/'editor.js').read_text('utf-8')
s=s.replace('hasRuntime=!!value.compatibleRuntime','hasRuntime=false').replace('测试 (1) 需要升级异火宿主 Mod 至异火缠绕版，当前先检查新画面。','当前为第二轮工作台候选，游戏实装暂缓。')
s+='''
$('front-view').addEventListener('click',()=>preview?.setCamera({yaw:0,pitch:.10,distance:4.5}));
$('side-view').addEventListener('click',()=>preview?.setCamera({yaw:Math.PI/2,pitch:.10,distance:4.5}));
$('capture-image').addEventListener('click',()=>{if(!preview)return;preview.render();$('preview').toBlob(blob=>{if(!blob)return;const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download='异火流焰-审查.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});});
'''
(p/'editor.js').write_text(s,'utf-8')
