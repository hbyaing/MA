"""Split supplied transparent three-stage plant sheets without resampling."""
from pathlib import Path
from PIL import Image
import json,shutil
root=Path(__file__).resolve().parents[1]
assets=root/'src/main/resources/assets/wuxingxiantu'
imports=[('blood_spirit_flower','7f7a8742-227b-4270-b62e-a282341ac2bc',[(100,0,600,724),(740,0,1370,724),(1440,0,2172,724)]),
         ('vein_mending_vine','8f9bc5b0-c2aa-4c7b-9b93-0cdd809c6cd5',[(500,0,820,724),(930,0,1220,724),(1370,0,1710,724)]),
         ('red_sun_grass','2404406a-c9b2-42e3-8482-42573a381c99',[(100,0,600,724),(660,0,1320,724),(1370,0,2172,724)]),
         ('adamantine_vine','e55b8333-23bf-48c6-9cfd-af84c4a73b00',[(260,0,610,724),(840,0,1310,724),(1520,0,2040,724)]),
         ('dark_water_weed','a07eade4-7989-4031-bd65-13585d480b4f',[(90,0,480,724),(710,0,1240,724),(1380,0,2172,724)]),
         ('thunder_vein_grass','6af9ff8d-c706-41a6-a141-f3f0b2decf05',[(140,0,600,724),(720,0,1320,724),(1390,0,2172,724)]),
         ('starlight_flower','d3b38375-dafd-4d89-b8dd-3f2aafad7163',[(250,0,680,724),(780,0,1310,724),(1400,0,1960,724)])]
for plant,reference,boxes in imports:
    source=Path(r'C:/Users/NOSTZE~1/AppData/Local/Temp')/('codex-clipboard-'+reference+'.png')
    out=root/'source-assets'/(plant+'-20261008'+('-v2' if plant=='dark_water_weed' else ''));out.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,out/'reference-original.png')
    im=Image.open(source).convert('RGBA');preview=Image.new('RGBA',(768,256),(45,49,45,255));manifest={}
    for i,(stage,suffix,box) in enumerate(zip(['young','growing','mature'],['_low','_mid',''],boxes)):
        crop=im.crop(box);bounds=crop.getbbox();crop=crop.crop(bounds)
        crop.save(out/(stage+'-crop.png'))
        tile=Image.new('RGBA',(1024,1024));x=(1024-crop.width)//2;y=1024-crop.height
        tile.alpha_composite(crop,(x,y))
        name=plant+({'young':'_young','growing':'_growing','mature':''}[stage])
        tile.save(assets/'textures/block'/(name+'.png'))
        path=assets/'models/block'/(plant+suffix+'.json');model=json.loads(path.read_text())
        model['textures']['cross']='wuxingxiantu:block/'+name
        u=x/64;v=y/64;right=(x+crop.width)/64
        for element in model['elements']:
            for face_name,face in element['faces'].items():
                face['uv']=[u,v,right,16] if face_name=='north' else [right,v,u,16]
        path.write_text(json.dumps(model,indent=2)+'\n')
        art=crop.copy();art.thumbnail((220,230),Image.Resampling.NEAREST)
        preview.alpha_composite(art,(i*256+(256-art.width)//2,250-art.height))
        manifest[stage]={'source_box':box,'crop_bounds':bounds,'tile':[1024,1024]}
        if stage=='mature':
            # Item UV covers a square: use a tight square so the icon is not shrunken by atlas padding.
            side=max(crop.size);icon=Image.new('RGBA',(side,side));icon.alpha_composite(crop,((side-crop.width)//2,(side-crop.height)//2))
            icon.save(assets/'textures/item'/(plant+'.png'))
    (assets/'models/item'/(plant+'.json')).write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'wuxingxiantu:item/'+plant}},indent=2)+'\n')
    preview.save(out/'preview.png');(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print('Imported',plant)
