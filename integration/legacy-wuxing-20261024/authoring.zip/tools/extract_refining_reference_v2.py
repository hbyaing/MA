"""Extract the second supplied refining reference, excluding its sample values."""
from pathlib import Path
from PIL import Image
import json, shutil, hashlib
root=Path(__file__).resolve().parents[1]
source=Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-f97ce3af-6b45-47c5-a988-d34ce2d9bd34.png')
archive=root/'source-assets/refining-ui-reference-v2-20261011'
runtime=root/'src/main/resources/assets/wuxingxiantu/textures/gui/refining'
archive.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,archive/'reference-original.png')
im=Image.open(source).convert('RGBA')
assert im.size==(1536,1024),im.size
sizes={}
def save(name,box,mask=None):
    out=im.crop(box)
    if mask:
        for y in range(out.height):
            for x in range(out.width):
                r,g,b,a=out.getpixel((x,y))
                if mask=='gold':
                    a=max(0,min(255,round(min(r-55,(r-b)*2.5)*2))) if r>g and g>b else 0
                else:
                    a=max(0,min(255,(max(r,g,b)-65)*3))
                if name=='panel':
                    edge=x<14 or x>=out.width-14 or y<14 or y>=out.height-14
                    corner=(x<48 or x>=out.width-48) and (y<48 or y>=out.height-48)
                    if not(edge or corner):a=0
                if name=='separator' and x>=1375 and y<10:a=0
                out.putpixel((x,y),(r,g,b,a))
    out.save(runtime/(name+'.png'))
    (runtime/(name+'.png.mcmeta')).write_text('{"texture":{"blur":false,"clamp":true}}')
    sizes[name]=list(out.size)
save('panel',(18,18,1518,994),'gold')
save('title',(435,42,1100,104),'gold')
save('separator',(45,105,1490,128),'gold')
save('material_rule',(224,140,1490,163),'gold')
save('card',(53,176,524,264),'gold')
save('output',(668,248,869,437),'gold')
save('previous',(552,318,637,403))
save('next',(898,318,984,403))
save('close',(1420,38,1496,113))
save('button',(55,783,1482,879),'gold')
save('button_left',(62,793,250,865),'gold')
save('button_right',(1290,793,1474,865),'gold')
save('info',(54,600,1483,672))
save('info_tall',(54,677,1483,772))
save('aura_icon',(70,607,119,663),'light')
save('time_icon',(921,612,961,663),'gold')
save('pedestal_icon',(70,690,120,754),'light')
save('fire_icon',(1023,682,1091,765),'light')
# Retain the existing text-free landscape extracted from the first reference.
(archive/'manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sizes':sizes,'dynamic_values_drawn_in_java':True},indent=2),encoding='utf-8')
print(json.dumps(sizes))
