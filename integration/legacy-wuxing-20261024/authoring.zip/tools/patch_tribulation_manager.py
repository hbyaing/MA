from pathlib import Path
p=Path('src/main/java/cn/blockforge/generated/generatedmod/TribulationManager.java')
t=p.read_text(encoding='utf-8')
t=t.replace('private static final int STRIKE_INTERVAL = 10;','private static final int STRIKE_INTERVAL = 10; // legacy save compatibility; new schedule uses TribulationPlan')
t=t.replace('tickCraters(server);','tickCraters(server);\n        maintainWeather(server);')
t=t.replace('if(trial.phase==Phase.SUCCESS) {finishSuccess(player,trial);continue;}','if(trial.phase==Phase.SUCCESS) {if(trial.strikeDelay>0){trial.strikeDelay--;continue;}finishSuccess(player,trial);continue;}')
t=t.replace('trial.countdownTicks--;','trial.countdownTicks--;\n                    skyWarning(player,trial);')
start=t.index('                int strike=++trial.strikesDone;')
end=t.index('                applySpectatorFear(server,trial,player);',start)
t=t[:start]+'''                var plan=cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.class;
                int remaining=trial.totalStrikes()-trial.strikesDone;
                boolean pillar=remaining==1;
                int amount=pillar?1:cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.count(trial.realm,trial.strikesDone);
                if(amount>=remaining)amount=remaining-1;
                if(pillar)amount=1;
                strikeWave(level,player,trial,amount,pillar);
                if(!player.isAlive()) {finishFailure(player,trial,true);continue;}
                if(trial.strikesDone>=trial.totalStrikes()) {trial.phase=Phase.SUCCESS;trial.strikeDelay=40;}
                else if(trial.totalStrikes()-trial.strikesDone==1)trial.strikeDelay=cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.DURATION[trial.realm]+24;
                else trial.strikeDelay=cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.interval(trial.realm,trial.strikesDone)-1+Math.floorMod(cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.seed(trial.visualSeed,trial.strikesDone),5)-2;
''' +t[end:]
start=t.index('    private static void strike(ServerLevel')
end=t.index('    private static void finishSuccess',start)
t=t[:start]+'''    private static void strikeWave(ServerLevel level,ServerPlayer player,Trial trial,int amount,boolean pillar) {
        int first=trial.strikesDone+1;float damage=0;
        for(int i=0;i<amount;i++)damage+=cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.damage(trial.realm,first+i);
        trial.strikesDone+=amount;
        var end=player.position();double cloud=level.dimension()==net.minecraft.world.level.Level.OVERWORLD?193:end.y+48;
        cloud=Math.max(cloud,end.y+24);
        visual(player,trial,pillar?2:0,amount,first,new net.minecraft.world.phys.Vec3(end.x,cloud,end.z),end);
        if(!trial.harmless){
            var protection=player.getEffect(ModEffects.PILL_TRIBULATION.get());
            if(protection!=null)damage*=1-.1F*Math.min(4,protection.getAmplifier()+1);
            player.getPersistentData().putBoolean("wuxingxiantu_tribulation_strike",true);
            try {player.setAbsorptionAmount(0);player.invulnerableTime=0;player.hurt(level.damageSources().fellOutOfWorld(),damage);}
            finally{player.getPersistentData().remove("wuxingxiantu_tribulation_strike");}
            destroyStrikeBlocks(level,player.blockPosition(),trial);
        }
        level.playSound(null,player.blockPosition(),net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_THUNDER,net.minecraft.sounds.SoundSource.WEATHER,2,1);
        level.playSound(null,player.blockPosition(),net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_IMPACT,net.minecraft.sounds.SoundSource.WEATHER,1,1);
        player.displayClientMessage(Component.literal((pillar?"终劫·天罚光柱 ":"天雷 ")+trial.strikesDone+"/"+trial.totalStrikes()),true);
    }
    private static void destroyStrikeBlocks(ServerLevel level,BlockPos center,Trial trial) {
        int realm=trial.realm;double progress=trial.strikesDone/(double)trial.totalStrikes(),scale=.5+.5*progress;
        double radius=cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.RADIUS[realm]*scale;
        int cap=Math.max(1,(int)Math.ceil(cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.BLOCKS[realm]*scale)),depth=realm<4?1:2;
        var candidates=new ArrayList<BlockPos>();int bound=(int)Math.ceil(radius);
        for(BlockPos point:BlockPos.betweenClosed(center.offset(-bound,-depth,-bound),center.offset(bound,0,bound))) {
            double dx=point.getX()-center.getX(),dz=point.getZ()-center.getZ();if(dx*dx+dz*dz<=radius*radius)candidates.add(point.immutable());
        }
        candidates.sort(java.util.Comparator.comparingDouble(q->q.distSqr(center)));int changed=0;
        var journal=TribulationState.get(level.getServer());
        var protectedTag=net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.BLOCK,new net.minecraft.resources.ResourceLocation(GeneratedMod.MOD_ID,"tribulation_protected"));
        for(var point:candidates){if(changed>=cap)break;if(!level.hasChunkAt(point))continue;var block=level.getBlockState(point);float hardness=block.getDestroySpeed(level,point);
            if(block.isAir()||!block.getFluidState().isEmpty()||block.hasBlockEntity()||hardness<0||hardness>cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.HARDNESS[realm]||block.is(protectedTag))continue;
            if(!net.minecraftforge.common.ForgeHooks.onBlockBreakEvent(level,playerGameMode(level,trial),level.getServer().getPlayerList().getPlayer(trial.playerId()),point).equals(0)) {}
            if(journal.recordCrater(level.dimension(),point,block,level.getServer().overworld().getGameTime()+12000)){level.setBlock(point,Blocks.AIR.defaultBlockState(),3);changed++;}
        }
    }
    private static void visual(ServerPlayer player,Trial trial,int kind,int count,int index,net.minecraft.world.phys.Vec3 start,net.minecraft.world.phys.Vec3 end){
        long id=trial.visualSeed^((long)index<<8)^kind;var packet=new cn.blockforge.generated.generatedmod.tribulation.TribulationVisualPacket(player.getUUID(),player.level().dimension().location().toString(),id,trial.realm,kind,count,cn.blockforge.generated.generatedmod.tribulation.TribulationPlan.seed(trial.visualSeed,index+kind*10000),player.level().getGameTime(),start,end);
        for(var watcher:player.serverLevel().players())if(watcher.distanceToSqr(player)<256*256)Network.sendToPlayer(watcher,packet);
    }
    private static void skyWarning(ServerPlayer player,Trial trial){
        int t=trial.countdownTicks,interval=t>200?30:t>100?16:t>20?8:6;if(t%interval!=0)return;
        int count=t>200?1:t>100?2:t>20?3:5;double y=Math.max(player.level().dimension()==net.minecraft.world.level.Level.OVERWORLD?191:player.getY()+48,player.getY()+24);
        var random=new java.util.Random(trial.visualSeed+t);
        for(int i=0;i<count;i++){double a=random.nextDouble()*Math.PI*2,d=24+random.nextDouble()*48;var start=new net.minecraft.world.phys.Vec3(player.getX()+Math.cos(a)*d,y+random.nextDouble()*3,player.getZ()+Math.sin(a)*d);var end=start.add(Math.cos(a+1.7)*(24+random.nextDouble()*40),random.nextDouble()*3-1.5,Math.sin(a+1.7)*32);visual(player,trial,1,1,-t*8-i,start,end);}
        if(t%40==0)player.serverLevel().playSound(null,player.blockPosition(),net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_THUNDER,net.minecraft.sounds.SoundSource.WEATHER,.6F,1);
    }
    private static final java.util.Set<net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level>> STORM_LEVELS=new java.util.HashSet<>();
    private static void maintainWeather(MinecraftServer server){
        var active=new java.util.HashSet<net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level>>();
        for(var trial:TribulationState.get(server).trials.values())if(!trial.settled())active.add(trial.dimension);
        for(var dimension:active){var level=server.getLevel(dimension);if(level!=null){level.setWeatherParameters(0,200,true,true);STORM_LEVELS.add(dimension);}}
        for(var dimension:new java.util.ArrayList<>(STORM_LEVELS))if(!active.contains(dimension)){var level=server.getLevel(dimension);if(level!=null){level.setWeatherParameters(12000,0,false,false);level.setRainLevel(0);level.setThunderLevel(0);}STORM_LEVELS.remove(dimension);}
    }
    public static boolean startTest(ServerPlayer player,int realm,boolean harmful){
        if(isActive(player))return false;realm=Math.max(0,Math.min(7,realm));var data=GeneratedMod.data(player);
        var trial=new Trial(player.getUUID(),player.level().dimension(),player.blockPosition(),realm,18+realm*9,player.getMaxHealth(),data==null?0:CultivationLogic.maxAura(data));trial.testing=true;trial.harmless=!harmful;
        TribulationState.get(player.server).trials.put(player.getUUID(),trial);checkpoint(player,trial);maintainWeather(player.server);return true;
    }
    public static void stopTest(ServerPlayer player){
        var state=TribulationState.get(player.server);var trial=state.trials.get(player.getUUID());if(trial==null||!trial.testing)return;
        trial.settled(true);visual(player,trial,3,0,Integer.MAX_VALUE,player.position(),player.position());checkpoint(player,trial);maintainWeather(player.server);
    }

''' +t[end:]
# Remove accidental placeholder; use Forge break event cancellation for protection.
t=t.replace('            if(!net.minecraftforge.common.ForgeHooks.onBlockBreakEvent(level,playerGameMode(level,trial),level.getServer().getPlayerList().getPlayer(trial.playerId()),point).equals(0)) {}','            var owner=level.getServer().getPlayerList().getPlayer(trial.playerId());if(owner==null)continue;\n            if(net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new net.minecraftforge.event.level.BlockEvent.BreakEvent(level,point,block,owner)))continue;')
t=t.replace('        CultivationData data = GeneratedMod.data(player);\n        if (data == null || trial.settled()) return;', '        if(trial.testing){trial.settled(true);player.displayClientMessage(Component.literal("雷劫测试结束"),false);return;}\n        CultivationData data = GeneratedMod.data(player);\n        if (data == null || trial.settled()) return;')
t=t.replace('        if (trial.settled()) return;\n        CultivationData data', '        if (trial.settled()) return;\n        if(trial.testing){trial.settled(true);visual(player,trial,3,0,Integer.MAX_VALUE,player.position(),player.position());return;}\n        CultivationData data')
t=t.replace('if(level.getBlockState(key.pos()).is(Blocks.BLACK_CONCRETE))','if(level.getBlockState(key.pos()).isAir()||level.getBlockState(key.pos()).is(Blocks.BLACK_CONCRETE))')
p.write_text(t,encoding='utf-8')
print('Installed waves, pillar, realm damage/craters, sky warnings, weather and test lifecycle.')
