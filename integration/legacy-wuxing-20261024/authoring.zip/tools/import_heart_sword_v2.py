"""Import the authored heart sword mesh/embedded PNGs, without rebuilding the mod.

Usage: python tools/import_heart_sword_v2.py [path/to/model.bbmodel]
No texture repainting, display-transform changes, or Gradle invocation occurs here.
The 64px inventory icon is rasterized directly from the imported mesh and UVs.
"""
from __future__ import annotations

import argparse
import base64
from collections import Counter
import hashlib
import io
import json
import math
from pathlib import Path
import shutil

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
SOURCE_COPY = ROOT / 'source-assets/heart_sword.bbmodel'
ARCHIVE = ROOT / 'source-assets/archive/heart_sword_v1'
OBJ = ASSETS / 'models/item/heart_sword.obj'
MTL = ASSETS / 'models/item/heart_sword.mtl'
ICON = ASSETS / 'textures/item/heart_sword_inventory.png'
REPORT = ROOT / 'source-assets/contracts/heart_sword_v2_import.json'
PREVIEW = ROOT / 'reports/heart_sword_v2_preview.png'
MATERIAL_NAMES = ('heart_sword', 'heart_sword_crystal', 'heart_sword_light', 'heart_sword_gem')
SOURCE_GRIP = (0.0, -2.75, 0.0)
TARGET_GRIP = (0.0, -0.2, 0.0)
TARGET_LENGTH = 1.875


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path):
    return path.relative_to(ROOT).as_posix()


def bounds(vertices):
    return [[f(v[i] for v in vertices) for i in range(3)] for f in (min, max)]


def rotate_xyz(vertex, angles):
    # Blockbench/THREE Euler XYZ: Rz acts first, then Ry, then Rx.
    v = list(vertex)
    for axis in (2, 1, 0):
        angle = math.radians(angles[axis])
        c, s = math.cos(angle), math.sin(angle)
        i, j = ((1, 2), (2, 0), (0, 1))[axis]
        v[i], v[j] = v[i] * c - v[j] * s, v[i] * s + v[j] * c
    return v


def group_rotation(vertex, node):
    origin = node.get('origin', (0, 0, 0))
    rotated = rotate_xyz([vertex[i] - origin[i] for i in range(3)], node.get('rotation', (0, 0, 0)))
    return [rotated[i] + origin[i] for i in range(3)]


def read_meshes(source):
    group_by_id = {group['uuid']: group for group in source.get('groups', [])}
    parents = {}

    def visit(node, chain):
        if isinstance(node, str):
            parents[node] = chain
            return
        group = group_by_id.get(node['uuid'], node)
        for child in node.get('children', []):
            visit(child, chain + [group])

    for root in source.get('outliner', []):
        visit(root, [])
    meshes = []
    for element in source['elements']:
        chain = parents.get(element['uuid'], [])
        if not all(n.get('export', True) and n.get('visibility', True) for n in chain + [element]):
            continue
        if element.get('type') != 'mesh':
            raise ValueError('This importer expects the authored mesh elements: ' + element['name'])
        points = {}
        for key, vertex in element['vertices'].items():
            # Mesh coordinates are local to the element origin; group pivots are world coordinates.
            vertex = rotate_xyz(vertex, element.get('rotation', (0, 0, 0)))
            vertex = [vertex[i] + element.get('origin', (0, 0, 0))[i] for i in range(3)]
            for parent in reversed(chain):
                vertex = group_rotation(vertex, parent)
            points[key] = vertex
        meshes.append({'name': element['name'], 'vertices': points, 'faces': element['faces'],
                       'groups': [node.get('name', node['uuid']) for node in chain]})
    return meshes


def archive_previous():
    # A completed import is reproducible; never replace the original archive on rerun.
    if (ARCHIVE / 'manifest.json').exists():
        return
    paths = [SOURCE_COPY, OBJ, MTL, ICON, ASSETS / 'textures/item/heart_sword.png',
             ROOT / 'source-assets/heart_sword-original.png',
             ROOT / 'source-assets/heart_sword-texture-comparison.png',
             ROOT / 'reports/heart_sword_64_contract.json', ROOT / 'reports/heart_sword_64_preview.png']
    manifest = {}
    for path in paths:
        if not path.exists():
            continue
        target = ARCHIVE / relative(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.copyfile(path, target)
        manifest[relative(path)] = digest(target)
    (ARCHIVE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')


def face_normal(points):
    # Newell's method preserves each original face's winding and flat-shaded facets.
    normal = [0.0, 0.0, 0.0]
    for a, b in zip(points, points[1:] + points[:1]):
        normal[0] += (a[1] - b[1]) * (a[2] + b[2])
        normal[1] += (a[2] - b[2]) * (a[0] + b[0])
        normal[2] += (a[0] - b[0]) * (a[1] + b[1])
    length = math.sqrt(sum(v * v for v in normal))
    return tuple(v / length for v in normal) if length > 1e-15 else (0.0, 0.0, 1.0)


def export_obj(meshes, textures, normalize):
    lines = ['# Imported from the user-authored heart sword 2.0 Blockbench model.',
             '# Tip +Y, width +X; grip (0,-0.2,0); total length 1.875 blocks.',
             'mtllib heart_sword.mtl']
    vertex_count = uv_count = normal_count = 0
    triangles = []
    mesh_reports = []
    for mesh in meshes:
        points = {key: normalize(vertex) for key, vertex in mesh['vertices'].items()}
        indices = {}
        lines.append('g ' + mesh['name'])
        for key, vertex in points.items():
            vertex_count += 1
            indices[key] = vertex_count
            lines.append('v ' + ' '.join(f'{value:.9f}' for value in vertex))
        material = None
        material_counts = Counter()
        for face in mesh['faces'].values():
            texture_id = face.get('texture')
            if texture_id is None or texture_id is False or len(face['vertices']) < 3:
                continue
            texture_id = int(texture_id)
            name = MATERIAL_NAMES[texture_id]
            material_counts[name] += 1
            if name != material:
                lines.append('usemtl ' + name)
                material = name
            keys = face['vertices']
            face_points = [points[key] for key in keys]
            normal = face_normal(face_points)
            normal_count += 1
            lines.append('vn ' + ' '.join(f'{value:.9f}' for value in normal))
            # OBJ uses bottom-up V; the Forge model must keep flip_v=true.
            face_uvs = [(face['uv'][key][0] / textures[texture_id]['uv_width'],
                         1 - face['uv'][key][1] / textures[texture_id]['uv_height']) for key in keys]
            face_refs = []
            for key, uv in zip(keys, face_uvs):
                uv_count += 1
                lines.append(f'vt {uv[0]:.9f} {uv[1]:.9f}')
                face_refs.append(f'{indices[key]}/{uv_count}/{normal_count}')
            lines.append('f ' + ' '.join(face_refs))
            for i in range(1, len(keys) - 1):
                triangles.append((texture_id, [face_points[j] for j in (0, i, i + 1)],
                                  [face_uvs[j] for j in (0, i, i + 1)]))
        bb = bounds(list(points.values()))
        mesh_reports.append({'name': mesh['name'], 'groups': mesh['groups'],
                             'vertices': len(points), 'faces': dict(material_counts),
                             'bounds': bb, 'center': [(lo + hi) / 2 for lo, hi in zip(*bb)]})
    OBJ.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return triangles, mesh_reports, {'vertices': vertex_count, 'faces': normal_count,
                                    'triangles': len(triangles), 'uvs': uv_count}


def rasterize(triangles, textures, width=64, height=64, angles=(0, 12, -42), padding=5, outline=False):
    # Depth-sorted alpha layers and emissive presentation. Native 64px for the icon.
    # Separate renders only; original PNGs are never recolored or alpha-modified.
    rotated = [(material, [rotate_xyz(p, angles) for p in points], uvs)
               for material, points, uvs in triangles]
    vertices = [p for _, points, _ in rotated for p in points]
    lo, hi = bounds(vertices)
    scale = min((width - 2 * padding) / (hi[0] - lo[0]), (height - 2 * padding) / (hi[1] - lo[1]))
    cx, cy = (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2
    fragments = [[] for _ in range(width * height)]
    for material, points, uvs in rotated:
        a, b, c = [((p[0] - cx) * scale + (width - 1) / 2,
                   (height - 1) / 2 - (p[1] - cy) * scale, p[2]) for p in points]
        denominator = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
        if abs(denominator) < 1e-10:
            continue
        texture = textures[material]
        for y in range(max(0, math.floor(min(a[1], b[1], c[1]))), min(height, math.ceil(max(a[1], b[1], c[1])))):
            for x in range(max(0, math.floor(min(a[0], b[0], c[0]))), min(width, math.ceil(max(a[0], b[0], c[0])))):
                wa = ((b[1] - c[1]) * (x + .5 - c[0]) + (c[0] - b[0]) * (y + .5 - c[1])) / denominator
                wb = ((c[1] - a[1]) * (x + .5 - c[0]) + (a[0] - c[0]) * (y + .5 - c[1])) / denominator
                weights = (wa, wb, 1 - wa - wb)
                if min(weights) < -1e-7:
                    continue
                z = sum(w * p[2] for w, p in zip(weights, (a, b, c)))
                u, v = [sum(w * uv[i] for w, uv in zip(weights, uvs)) for i in range(2)]
                color = texture.getpixel((min(texture.width - 1, max(0, int(u * texture.width))),
                                          min(texture.height - 1, max(0, int((1 - v) * texture.height)))))
                alpha = color[3] / 255
                if material in (2, 3):
                    alpha = min(1, alpha * (21 if material == 2 else 9))
                fragments[y * width + x].append((z, color[:3], alpha))
    icon = Image.new('RGBA', (width, height))
    for i, layers in enumerate(fragments):
        if not layers:
            continue
        rgb, alpha = [0.0, 0.0, 0.0], 0.0
        for _, color, opacity in sorted(layers):
            rgb = [c * opacity + prev * (1 - opacity) for c, prev in zip(color, rgb)]
            alpha = opacity + alpha * (1 - opacity)
        if alpha:
            icon.putpixel((i % width, i // width), (*[round(c / alpha) for c in rgb], round(alpha * 255)))
    if not outline:
        return icon
    outlined = icon.copy()
    for y in range(1, height - 1):
        for x in range(1, width - 1):
            if not icon.getpixel((x, y))[3] and any(icon.getpixel((x + dx, y + dy))[3] > 32
                                                   for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                outlined.putpixel((x, y), (24, 54, 83, 220))
    return outlined


def write_preview(triangles, images, icon):
    """Authoring preview from actual mesh/UVs; not a game screenshot or runtime check."""
    front = rasterize(triangles, images, 210, 740, (0, 0, 0), 12)
    oblique = rasterize(triangles, images, 210, 740, (0, 40, 0), 12)
    guard = [triangle for triangle in triangles
             if all(-.11 < point[1] < .07 for point in triangle[1])]
    detail = rasterize(guard, images, 280, 240, (0, 0, 0), 18)
    canvas = Image.new('RGBA', (760, 820), (17, 25, 34, 255))
    draw = ImageDraw.Draw(canvas)
    draw.text((24, 18), 'HEART SWORD 2.0 | Authored mesh + original embedded textures', fill=(201, 230, 255))
    draw.text((66, 52), 'FRONT', fill=(155, 183, 207))
    draw.text((265, 52), 'OBLIQUE 40 DEG', fill=(155, 183, 207))
    draw.text((488, 82), 'FLOATING CRESCENT GUARD', fill=(155, 183, 207))
    canvas.alpha_composite(front, (18, 70))
    canvas.alpha_composite(oblique, (238, 70))
    canvas.alpha_composite(detail, (463, 105))
    draw.text((485, 390), '64 PX INVENTORY ICON (3X)', fill=(155, 183, 207))
    canvas.alpha_composite(icon.resize((192, 192), Image.Resampling.NEAREST), (505, 425))
    draw.text((475, 690), 'Geometry / UVs / 4 textures preserved', fill=(155, 183, 207))
    draw.text((475, 712), 'Light & gem gain applied in rendering', fill=(155, 183, 207))
    draw.text((475, 734), 'Authoring render - not in-game output', fill=(155, 183, 207))
    canvas.convert('RGB').save(PREVIEW)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, nargs='?', default=SOURCE_COPY)
    args = parser.parse_args()
    raw_source = args.source.read_bytes()
    source = json.loads(raw_source.decode('utf-8-sig'))
    if len(source.get('textures', [])) != len(MATERIAL_NAMES):
        raise ValueError('Expected the four authored 2.0 materials; source was not replaced.')
    meshes = read_meshes(source)
    raw_bounds = bounds([p for mesh in meshes for p in mesh['vertices'].values()])
    scale = TARGET_LENGTH / (raw_bounds[1][1] - raw_bounds[0][1])

    def normalize(point):
        return [(point[i] - SOURCE_GRIP[i]) * scale + TARGET_GRIP[i] for i in range(3)]

    archive_previous()
    SOURCE_COPY.write_bytes(raw_source)
    images, materials = [], []
    mtl = ['# Original embedded heart sword 2.0 textures; alpha is preserved byte-for-byte.']
    output_paths = [SOURCE_COPY, OBJ, MTL, ICON, PREVIEW]
    for index, texture in enumerate(source['textures']):
        material_name = MATERIAL_NAMES[index]
        path = ASSETS / f'textures/item/{material_name}.png'
        payload = base64.b64decode(texture['source'].split(',', 1)[1])
        image = Image.open(io.BytesIO(payload)).convert('RGBA')
        path.write_bytes(payload)
        output_paths.append(path)
        images.append(image)
        emissive = texture.get('render_mode') == 'emissive'
        materials.append({'index': index, 'name': material_name, 'source_name': texture['name'],
                          'path': relative(path), 'size': list(image.size),
                          'alpha_range': image.getchannel('A').getextrema(), 'emissive': emissive,
                          'double_sided': texture.get('render_sides') == 'double', 'sha256': digest(path)})
        mtl.extend([f'newmtl {material_name}', 'Ka 1 1 1' if emissive else 'Ka .15 .15 .15',
                    'Kd 1 1 1', 'forge_TintIndex -1', f'map_Kd wuxingxiantu:item/{material_name}', ''])
    MTL.write_text('\n'.join(mtl), encoding='utf-8')
    triangles, mesh_reports, counts = export_obj(meshes, source['textures'], normalize)
    icon = rasterize(triangles, images, outline=True)
    icon.save(ICON)
    PREVIEW.parent.mkdir(parents=True, exist_ok=True)
    write_preview(triangles, images, icon)
    report = {
        'source': relative(SOURCE_COPY), 'source_sha256': hashlib.sha256(raw_source).hexdigest(),
        'source_model_name': source.get('name'), 'format': source.get('meta'),
        'archive': relative(ARCHIVE), 'normalization': {'source_grip': SOURCE_GRIP,
        'runtime_grip': TARGET_GRIP, 'scale': scale, 'translation': normalize((0, 0, 0)),
        'length': TARGET_LENGTH, 'axes': {'tip': '+Y', 'width': '+X', 'front_back': '+/-Z'}},
        'source_bounds': raw_bounds, 'runtime_bounds': [normalize(p) for p in raw_bounds],
        'counts': counts, 'materials': materials, 'meshes': mesh_reports,
        'anchors': {item['name']: item['center'] for item in mesh_reports if item['name'] in (
            'guard_heart_crystal', 'heart_node_1', 'heart_node_2', 'heart_node_3',
            'pommel_heart_crystal', 'crescent_left', 'crescent_right')},
        'inventory_icon': {'size': [64, 64], 'source': 'native mesh and UV rasterization',
                           'view_rotation': [0, 12, -42], 'outline': 'one pixel blue-black',
                           'emission_alpha_gain': {'light': 21, 'gem': 9}},
        'output_sha256': {relative(path): digest(path) for path in output_paths if path != PREVIEW},
        'notes': ['No mesh simplification or atlas repainting.', 'Original display transforms retained.',
                  'The low authored light/gem alpha requires emissive rendering, not opaque cutout.',
                  'No build, tests, or game launch performed by this importer.']}
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'meshes': len(meshes), **counts, 'bounds': report['runtime_bounds'],
                      'report': relative(REPORT)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
