from PIL import Image
from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
im=Image.open('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-64cfe614-5dc4-45cf-9936-0d5d465b8066.png').convert('RGBA')
assert im.size==(941,1672),im.size
rail=im.crop((860,158,902,1542))
# The reference rail includes a sample thumb at y=261..530. Replace that band
# with an empty section of the same rail; the moving thumb is drawn separately.
empty=rail.crop((0,500,42,501)).resize((42,282))
rail.paste(empty,(0,96))
rail.paste(rail.crop((0,0,42,100)).transpose(Image.Transpose.FLIP_TOP_BOTTOM),(0,rail.height-100))
thumb=im.crop((863,261,899,530)).resize((42,320),Image.Resampling.LANCZOS)
thumb.paste(thumb.crop((0,0,42,40)).transpose(Image.Transpose.FLIP_TOP_BOTTOM),(0,280))
out=Image.new('RGBA',(84,1384));out.paste(rail,(0,0));out.paste(thumb,(42,0))
out.save(root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/scrollbar_reference.png')
lang=json.loads((root/'src/main/resources/assets/wuxingxiantu/lang/zh_cn.json').read_text(encoding='utf-8'))
src=(root/'src/main/java/cn/blockforge/generated/generatedmod/ArtCatalog.java').read_text(encoding='utf-8')
for name,tier in re.findall(r'new Entry\("([^"]+)", (\d)',src):
    print(tier,lang.get('item.wuxingxiantu.'+name,name))
