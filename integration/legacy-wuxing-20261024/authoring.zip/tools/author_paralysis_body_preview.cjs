const fs=require('fs');const root='deliverables/electric-preview-20261010/workbench/';
let text=fs.readFileSync(root+'final-rain-recipes.js','utf8');let recipes=JSON.parse(text.slice(text.indexOf('=')+1).replace(/;\s*$/,''));
Object.assign(recipes.paralysis,{orbitAnimation:'ring',orbitRadius:.36,orbitHeight:0,strands:3,samples:32,arcLength:1.15,orbitWobble:.055,pulseInterval:7,throttle:.8,currentWidth:.006,glowWidth:.035,coreGain:2,glowGain:1.3,orbitExtendSpeed:12,lengthRandomness:.35});
fs.writeFileSync(root+'final-rain-recipes.js','const finalRainRecipes='+JSON.stringify(recipes)+';\n');fs.writeFileSync(root+'presets/paralysis.json',JSON.stringify(recipes.paralysis,null,2));
fs.writeFileSync(root+'body-preview.js',`const ParalysisBodyPreview={
 attachments:[[0,.42,0,.36,.22],[0,.05,0,.35,-.3],[0,-.27,0,.30,.3],[-.43,.14,0,.145,.45],[.43,.14,0,.145,-.45],[-.16,-.62,0,.14,.22],[.16,-.62,0,.14,-.22]],
 sample(r,t){let out=[];this.attachments.forEach((p,i)=>{let local={...r,seed:r.seed+i*7919,orbitRadius:p[3],arcLength:p[3]*3.5,orbitWobble:i<3?.055:.03};for(const s of LightningCore.orbit(local,t+i*.7)){let point=a=>[a[0]+p[0],a[1]+a[2]*Math.sin(p[4])+p[1],a[2]*Math.cos(p[4])+p[2]];out.push({...s,a:point(s.a),b:point(s.b),path:s.path+i*100});}});return out;},
 draw(ctx,project){for(const [x,y,z,w,h,d] of [[0,.68,0,.45,.45,.45],[0,.12,0,.6,.68,.3],[-.43,.12,0,.24,.68,.26],[.43,.12,0,.24,.68,.26],[-.16,-.61,0,.26,.74,.28],[.16,-.61,0,.26,.74,.28]]){let v=[];for(let i=0;i<8;i++)v.push(project([x+(i&1?w/2:-w/2),y+(i&2?h/2:-h/2),z+(i&4?d/2:-d/2)]));ctx.strokeStyle='#5e8499';ctx.lineWidth=1;for(let i=0;i<8;i++)for(const bit of [1,2,4])if(!(i&bit)&&v[i]&&v[i|bit]){ctx.beginPath();ctx.moveTo(v[i][0],v[i][1]);ctx.lineTo(v[i|bit][0],v[i|bit][1]);ctx.stroke();}}}
};`);
let html=fs.readFileSync(root+'index.html','utf8').replace('<script src="app.js"></script>','<script src="body-preview.js"></script><script src="app.js"></script>').replace('麻痹 · 身体纵轴电流（游戏参数）','麻痹重设计 · 躯干与四肢贴身电弧');fs.writeFileSync(root+'index.html',html);
let app=fs.readFileSync(root+'app.js','utf8');
app=app.replace("if(recipe.orbitAnimation==='ring'){\n    if(center)","if($('tribulationPreset').value==='paralysis'){ParalysisBodyPreview.draw(ctx,project);}else if(recipe.orbitAnimation==='ring'){\n    if(center)");
app=app.replace('active=LightningCore.orbit(recipe,time);','active=$("tribulationPreset").value===\'paralysis\'?ParalysisBodyPreview.sample(recipe,time):LightningCore.orbit(recipe,time);');
app=app.replace('Math.max(4,recipe.orbitRadius*3)','($("tribulationPreset").value===\'paralysis\'?2.5:Math.max(4,recipe.orbitRadius*3))');
app=app.replace("$('modeTitle').textContent=recipe.mode", "$('modeTitle').textContent=recipe.mode");
fs.writeFileSync(root+'app.js',app);
console.log('Body attachment preview authored: 7 anchors, skill ring arcs, 672 segment ceiling');
