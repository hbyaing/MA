param([switch]$Client,[switch]$ServerTests)
$env:JAVA_HOME='C:\tmp\temurin17\jdk-17.0.20.1+1'
$env:PATH="$env:JAVA_HOME\bin;$env:PATH"
$env:TEMP='C:\gradle-tmp'
$env:TMP='C:\gradle-tmp'
Set-Location -LiteralPath (Split-Path $PSScriptRoot -Parent)
$taskArgs=@('--offline','-Dorg.gradle.java.home=C:\tmp\temurin17\jdk-17.0.20.1+1','-Dorg.gradle.jvmargs=-Xmx3G -Dfile.encoding=UTF-8 -Djava.io.tmpdir=C:\gradle-tmp','-PpythonExecutable=C:\Users\Nostzephert\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')
if($Client){$taskArgs+=@('runClient','-PtribulationCapture');$taskLog='reports/tribulation-install-20261010/client.log'}elseif($ServerTests){$taskArgs+=@('runGameTestServer','-PtribulationOnly');$taskLog='reports/tribulation-install-20261010/server-tests.log'}else{$taskArgs+=@('build');$taskLog='reports/tribulation-install-20261010/build.log'}
& .\gradlew.bat @taskArgs *> $taskLog
$LASTEXITCODE | Set-Content -LiteralPath ($taskLog+'.exit')
