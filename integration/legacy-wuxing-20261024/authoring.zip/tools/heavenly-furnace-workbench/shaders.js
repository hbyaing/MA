// All effect geometry, glyphs, plasma, clouds and sparks are generated on the GPU.
// The reference image is displayed only in the comparison panel, never sampled by a shader.
export const common=`
const float PI=3.14159265359, TAU=6.28318530718;
float hash(float x){return fract(sin(x*127.1+19.19)*43758.5453123);}
float hash3(vec3 p){p=fract(p*.1031);p+=dot(p,p.yzx+33.33);return fract((p.x+p.y)*p.z);}
float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(hash3(i),hash3(i+vec3(1,0,0)),f.x),mix(hash3(i+vec3(0,1,0)),hash3(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash3(i+vec3(0,0,1)),hash3(i+vec3(1,0,1)),f.x),mix(hash3(i+vec3(0,1,1)),hash3(i+vec3(1,1,1)),f.x),f.y),f.z);}
float fbm(vec3 p){return .5333*noise(p)+.2667*noise(p*2.03+13.7)+.1333*noise(p*4.11-9.4)+.0667*noise(p*8.27+4.6);}
mat3 rx(float a){float c=cos(a),s=sin(a);return mat3(1,0,0,0,c,s,0,-s,c);}
mat3 ry(float a){float c=cos(a),s=sin(a);return mat3(c,0,-s,0,1,0,s,0,c);}
mat3 rz(float a){float c=cos(a),s=sin(a);return mat3(c,s,0,-s,c,0,0,0,1);}
float segment(vec2 p,vec2 a,vec2 b){vec2 d=b-a;return length(p-a-d*clamp(dot(p-a,d)/dot(d,d),0.,1.));}
#ifndef VERTEX_STAGE
float ink(float d,float w){float aa=max(fwidth(d),.0006);return 1.-smoothstep(w-aa,w+aa,d);}
#endif
float bell(float x,float s){return exp(-x*x*s);}
`;
export const fullscreenVertex=`#version 300 es
precision highp float;out vec2 vUV;
void main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);vUV=p;gl_Position=vec4(p*2.-1.,0,1);}`;

export const surfaceVertex=`#version 300 es
#define VERTEX_STAGE
precision highp float;
layout(location=0) in vec2 aUV;
uniform mat4 uVP;
uniform float uTime,uRadius,uHeight,uTilt,uSpin,uSwirl,uWisp,uSparks;
uniform vec3 uRight,uUp;
uniform int uKind,uOffset;
out vec2 vUV;out vec3 vLocal;out float vSeed;flat out int vKind;flat out int vID;
${common}
mat3 orbit(float id){return ry(.25+uTime*.045*uSpin)*rx((id<.5?1.:-1.)*uTilt);}
void main(){
 float id=float(gl_InstanceID+uOffset),u=aUV.x,v=aUV.y,t=uTime*uSpin;vec3 p=vec3(0);vSeed=hash(id+float(uKind)*57.);vUV=aUV;vKind=uKind;vID=gl_InstanceID+uOffset;
 if(uKind==11){
  float a=u*TAU-t*.09,r=2.13*uRadius;
  p=vec3(cos(a)*r,1.65*uHeight+(v-.5)*.17,sin(a)*r);
 }else if(uKind==10){
  float r=(2.13+(id<.5?.145:-.145))*uRadius,a=u*TAU+t*.08;
  p=vec3(cos(a)*r,-1.5*uHeight-(v*.14+.006),sin(a)*r);
 }else if(uKind==0||uKind==8){
  float ringID=uKind==8?floor(id/3.):id;
  float rail=uKind==8?mod(id,3.):0.;
  float r=(ringID<1.5?2.13:1.96)*uRadius;
  float width=(ringID<1.5?.29:.24)*uRadius;
  float a=u*TAU+t*(ringID<.5?-.09:ringID<1.5?.08:ringID<2.5?.15:-.13);
  if(uKind==8){r+=(rail-1.)*.18*uRadius+(.21*uRadius);width=.017*uRadius;}
  // The blue hoops are belts: their broad inner face points at the furnace.
  // The top/bottom discs retain radial width; the hoops use axial width.
  if(ringID>=1.5&&uKind==0)p=vec3(cos(a)*r,(v-.5)*width,sin(a)*r);
  else p=vec3(cos(a)*(r+(v-.5)*width),0,sin(a)*(r+(v-.5)*width));
  if(ringID<1.5)p.y=(ringID<.5?1.65:-1.5)*uHeight;
  else p=orbit(ringID-2.)*p;
  if(uKind==8)vUV=vec2(u,v);
 }else if(uKind==1){
  float arm=mod(id,3.),braid=floor(id/3.);
  float r=(.045+pow(1.-u,1.1)*1.13)*uSwirl;
  float a=u*TAU*1.35+t*.85+arm*TAU/3.+braid*.17;
  float width=(.035+.19*sin(PI*u))*(1.-braid*.12)*uSwirl;
  r+=(v-.5)*width;
  r+=sin(a*3.+u*9.-t*1.2)*.035*sin(PI*u);
  float ripple=sin(a*5.-t*2.+u*11.)*.045*sin(PI*u);
  float shell=sqrt(max(0.,1.24*1.24*uSwirl*uSwirl-r*r))*.68;
  p=vec3(cos(a)*r,sin(a)*r,(braid<.5?1.:-1.)*shell+ripple);
  if(braid>1.5)p=ry(PI*.5)*p;
  p=ry(t*.075)*rx(.16)*p;p.y+=.06;
 }else if(uKind==2){
  float family=floor(id/10.),strand=mod(id,10.);
  float a=u*TAU+t*(family<.5?.28:-.24)+strand*1.49;
  float radial=1.96+(.07+.11*hash(strand+4.))*sin(a*3.-t*.8+strand*2.3);
  radial+=.055*(strand-4.5);
  float width=(.03+.055*hash(strand+6.))*pow(max(0.,sin(PI*u)),.35);
  p=vec3(cos(a)*(radial+(v-.5)*width),.055*sin(a*5.+t+strand),sin(a)*(radial+(v-.5)*width))*uRadius;
  p=orbit(family)*p;
 }else if(uKind==3){
  bool dark=id>=18.;float seed=dark?id-18.:id;
  float a=seed*TAU/18.+sin(u*5.-t*.7+seed)*.16+u*(dark?1.6:-1.1)+t*(dark?.12:-.07);
  float r=(dark?mix(1.5,.58,pow(u,.8)):mix(1.65,.15,pow(u,1.4)))*uRadius;
  r+=sin(u*11.+seed*2.-t*.8)*.1*sin(PI*u);
  float w=(dark?.32:.16)*uWisp*sin(PI*clamp(u*.95+.025,0.,1.))*(.7+.5*sin(seed+u*7.));
  p=vec3(cos(a)*r,(dark?(-1.5+u*1.6):(1.65-u*1.6))*uHeight,sin(a)*r);
  p+=vec3(cos(a+.7),.13*sin(u*8.+seed),sin(a+.7))*(v-.5)*w;
 }else if(uKind==6){
  float a=id*TAU/14.+u*.65+sin(u*5.-t*.3+id)*.2;
  float r=(1.15+.35*sin(id+u*4.+t*.2)+u*.4)*uRadius;
  float w=.36*uWisp*pow(max(0.,sin(PI*u)),.6);
  p=vec3(cos(a)*(r+(v-.5)*w),(1.65+u*1.2)*uHeight,sin(a)*(r+(v-.5)*w));
 }else if(uKind==4){
  float seed=id+21.,family=mod(id,4.);vec3 q;float phase=fract(hash(seed*7.)+uTime*(.025+.035*hash(seed)));
  float a=hash(seed+2.)*TAU+t*(.05+.08*hash(seed+1.));
  if(family<.5){float r=sqrt(hash(seed+9.))*2.08*uRadius;q=vec3(cos(a)*r,(1.9-phase*3.6)*uHeight,sin(a)*r);}
  else if(family<1.5){float r=(1.85+hash(seed+7.)*.5)*uRadius;q=orbit(mod(id,2.))*vec3(cos(a)*r,sin(a*4.+seed)*.16,sin(a)*r);}
  else if(family<2.5){float r=(.2+hash(seed+3.))*uSwirl;float aa=a+t*.65+r*5.;q=vec3(cos(aa)*r,sin(aa)*r,.3*(hash(seed+8.)-.5));}
  else{float r=(1.8+hash(seed+4.)*.65)*uRadius;q=vec3(cos(a)*r,(hash(seed+5.)*3.6-1.8)*uHeight,sin(a)*r);}
  float size=(.006+pow(hash(seed+11.),9.)*.033)*uSparks;
  p=q+(uRight*(u-.5)+uUp*(v-.5))*size*4.;
  vSeed=seed;
 }else if(uKind==5){
  float a=hash(id+8.)*TAU,r=(.35+hash(id+42.)*1.65)*uRadius;
  float lengthY=(.4+hash(id+14.)*1.9)*uHeight;
  p=vec3(cos(a)*r+(v-.5)*.004,1.65*uHeight-u*lengthY,sin(a)*r);
  vSeed=id;
 }else if(uKind==7){
  float a=u*TAU,b=v*PI;float r=.125*uSwirl*(1.+.07*sin(a*9.+t*4.)*sin(b*5.-t*3.));
  p=vec3(sin(b)*cos(a),cos(b),sin(b)*sin(a))*r+vec3(0,.06,0);
 }
 vLocal=p;gl_Position=uVP*vec4(p,1);
}`;

export const surfaceFragment=`#version 300 es
precision highp float;precision highp int;
in vec2 vUV;in vec3 vLocal;in float vSeed;flat in int vKind;flat in int vID;
uniform float uTime,uSpin,uGoldPower,uBluePower,uFirePower,uWispPower,uGlyph,uSparkPower;
uniform vec3 uGold,uBlue,uFire;
uniform sampler2D uPrevDepth;
uniform vec2 uResolution;
uniform int uPeel;
out vec4 fragColor;
${common}
// Angular meander, constructed from distances to straight line segments.
float glyph(vec2 p,float variant){
 if(mod(variant,2.)>.5)p.x=1.-p.x;
 float d=segment(p,vec2(.10,.16),vec2(.90,.16));
 d=min(d,segment(p,vec2(.90,.16),vec2(.90,.83)));
 d=min(d,segment(p,vec2(.90,.83),vec2(.27,.83)));
 d=min(d,segment(p,vec2(.27,.83),vec2(.27,.39)));
 d=min(d,segment(p,vec2(.27,.39),vec2(.69,.39)));
 d=min(d,segment(p,vec2(.69,.39),vec2(.69,.61)));
 d=min(d,segment(p,vec2(.69,.61),vec2(.47,.61)));
 return ink(d,.043*uGlyph);
}
void main(){
 if(uPeel>0&&gl_FragCoord.z<=texture(uPrevDepth,gl_FragCoord.xy/uResolution).r+.00000012)discard;
 float t=uTime*uSpin,u=vUV.x,v=vUV.y;vec3 color=vec3(0);float alpha=0.;
 if(vKind==0||vKind==10||vKind==11){
  float id=vKind==10?1.:vKind==11?0.:float(vID),cells=id<1.5?32.:28.;
  vec2 p=vec2(fract(u*cells),clamp((v-.23)/.54,0.,1.));
  float cell=floor(u*cells);
  float g=glyph(p,cell)*step(.23,v)*step(v,.77);
  // Eight larger square seals sit at the cardinal and diagonal divisions.
  float largeCell=u*8.,sealLocal=fract(largeCell);
  float marker=1.-smoothstep(.048,.056,abs(sealLocal-.5));
  vec2 s=vec2((sealLocal-.5)*8.5+.5,(v-.16)/.68);
  float seal=glyph(s,0.)*step(0.,s.x)*step(s.x,1.)*step(0.,s.y)*step(s.y,1.);
  g=mix(g,seal,marker);
  float rails=ink(abs(v-.10),.014)+ink(abs(v-.90),.014)+ink(abs(v-.20),.008)+ink(abs(v-.80),.008);
  float edge=smoothstep(0.,.045,v)*(1.-smoothstep(.955,1.,v));
  float traveling=pow(.5+.5*sin(u*TAU*3.-t*.9),24.);
  vec3 tint=id<.5?uGold:id<1.5?vec3(.61,.65,.76):uBlue;
  float power=id<.5?uGoldPower:id<1.5?.65*uGoldPower:uBluePower;
  float emission=rails*2.2+g*2.5;
  color=tint*(.12+emission*(1.+traveling*.7))*power+vec3(1)*pow(emission*.3,3.)*power*.28;
  alpha=edge*(id>.5&&id<1.5?.94:clamp(.12+g*.88+rails*.85,0.,1.));
  if(id>.5&&id<1.5){
   // Ink-black body. Symbols reflect cold light instead of emitting white bloom.
   color=vec3(.0007,.0009,.0022)+vec3(.13,.15,.21)*(g*.48+rails*.12);
   color+=vec3(.15,.18,.25)*seal*marker*.42;
   alpha=edge*.995;
  }
 }else if(vKind==8){
  float ring=floor(float(vID)/3.),rail=mod(float(vID),3.);
  float pulse=pow(.5+.5*sin(u*TAU*7.-t*.5+rail),16.);
  float edge=pow(max(0.,1.-abs(v*2.-1.)),1.4);
  vec3 tint=ring<.5?uGold:ring<1.5?vec3(.008,.009,.016):uBlue;
  color=tint*(1.1+pulse*2.)*(ring<1.5?uGoldPower:uBluePower);
  alpha=edge*(rail<.5?.55:rail<1.5?.32:.17);
  if(rail>1.5)alpha*=smoothstep(.2,.65,sin(u*TAU*53.));
 }else if(vKind==1){
  vec3 q=vec3(u*22.-t*.9,v*4.5,float(vID)*2.3);
  float n=fbm(q),curl=noise(q*2.5+vec3(0,t*.5,0));
  float edge=pow(max(0.,1.-abs((v-.5)*2.+(n-.5)*.55)),1.1);
  float l=abs(sin(v*PI*4.+n*5.+u*12.-t*1.3));
  float vein=pow(1.-l,9.);
  float stria=pow(1.-abs(sin(v*21.+u*85.+n*8.-t*2.)),18.);
  float hot=vein+stria*.75;
  float broken=smoothstep(.14,.66,n+curl*.25);
  color=mix(uFire*vec3(.42,.06,.003),uFire*vec3(1.65,.42,.015),broken)*uFirePower;
  color+=mix(uFire,vec3(1,.31,.012),.7)*hot*4.*uFirePower;
  alpha=edge*(.08+broken*.35+hot*.65)*smoothstep(0.,.07,u)*(1.-smoothstep(.98,1.,u));
 }else if(vKind==2){
  float n=fbm(vec3(u*18.-t*.3,v*3.,vSeed*13.));
  float edge=pow(max(0.,1.-abs(v*2.-1.+(n-.5)*.3)),1.7);
  float filament=pow(1.-abs(sin(v*13.+u*37.+n*5.-t*2.)),12.);
  float split=pow(1.-abs(sin(v*25.+n*9.-u*52.+t)),19.);
  color=(uBlue*(1.+filament*2.)+vec3(.48,.73,1)*split*3.)*uBluePower;
  alpha=edge*(.10+filament*.6+split*.5)*pow(max(0.,sin(PI*u)),.5);
 }else if(vKind==3||vKind==6){
  bool dark=vID>=18;float n=fbm(vec3(u*10.-t*.75,v*3.,vSeed*11.));
  float w=sin(v*12.+u*19.-t+5.*n),thread=pow(1.-abs(w),10.);
  float micro=pow(1.-abs(sin(v*31.-u*46.+n*8.+t)),20.);
  float edge=pow(max(0.,1.-abs(v*2.-1.+(n-.5)*.45)),1.3);
  float ends=pow(max(0.,sin(PI*u)),.4);
  if(dark){color=vec3(.001,.002,.007)+vec3(.15,.17,.30)*(thread*.9+micro*.6)*uWispPower;alpha=edge*ends*(.68+n*.65)*uWispPower;}
  else{color=(uGold*.56+vec3(.38,.43,.56))*(.7+thread*1.8+micro*1.6)*uWispPower;alpha=edge*ends*(.05+n*.09+thread*.35+micro*.25);}
 }else if(vKind==4){
  vec2 p=(vUV-.5)*2.;float d=length(p),core=exp(-d*d*30.);
  float star=exp(-abs(p.x)*95.-abs(p.y)*5.)+exp(-abs(p.y)*95.-abs(p.x)*5.);
  float sparkle=.25+.75*pow(.5+.5*sin(uTime*(1.+hash(vSeed)*3.)+vSeed),3.);
  float family=mod(float(vID),4.);
  color=(family<.5?uGold:family<1.5?uBlue:family<2.5?uFire:vec3(.30,.35,.63))*3.*uSparkPower;
  alpha=(core+star*.75+exp(-d*d*7.)*.12)*sparkle;
 }else if(vKind==5){
  float phase=fract(u*1.6+uTime*.18+hash(vSeed));
  float pulse=pow(1.-phase,16.);
  float edge=pow(max(0.,1.-abs(v*2.-1.)),2.);
  color=uGold*(.35+pulse*4.)*uGoldPower;
  alpha=edge*(.045+pulse*.75)*(1.-smoothstep(.65,1.,u));
 }else if(vKind==7){
  float n=fbm(vLocal*55.+vec3(uTime,-uTime*2.,0));
  color=(vec3(4.,2.8,.8)+uFire*4.*n)*uFirePower;alpha=.95;
 }
 if(alpha<.002)discard;
 fragColor=vec4(color,clamp(alpha,0.,1.));
}`;

export const atmosphereFragment=`#version 300 es
precision highp float;precision highp int;
in vec2 vUV;out vec4 fragColor;
uniform vec2 uResolution;
uniform vec3 uEye,uRight,uUp,uForward;
uniform float uTime,uAspect,uTanFov,uRadius,uHeight,uSpin,uSmoke,uMist,uFirePower,uSwirl,uBackdrop;
uniform vec3 uFire,uGold;
uniform int uSteps;
uniform vec4 uLayers;
${Array.from({length:8},(_,i)=>`uniform sampler2D uPeelColor${i},uPeelDepth${i};`).join('\n')}
${common}
vec3 sky(vec3 rd){
 float horizon=smoothstep(-.70,-.05,rd.y);
 vec3 col=mix(vec3(.25,.065,.035),vec3(.006,.017,.048),horizon);
 vec2 p=rd.xz/max(.12,abs(rd.y)+.35);
 float clouds=fbm(vec3(p*2.5,rd.y*3.+uTime*.004));
 float thin=fbm(vec3(p*6.+clouds*2.,rd.y*7.));
 float cloud=smoothstep(.47,.72,clouds+thin*.18);
 vec3 cloudCol=mix(vec3(.30,.10,.04),vec3(.012,.020,.046),smoothstep(-.45,.03,rd.y));
 col=mix(col,cloudCol,cloud*.58);
 col+=vec3(.025,.008,.004)*pow(max(0.,dot(rd,normalize(vec3(-.7,-.18,-.4)))),12.);
 vec2 s=rd.xy/(.5+abs(rd.z))*290.;vec2 cell=floor(s);vec2 pt=fract(s)-.5;
 float st=hash3(vec3(cell,3.));col+=vec3(.35,.43,.65)*step(.997,st)*exp(-dot(pt,pt)*100.)*smoothstep(.1,.7,rd.y);
 return mix(vec3(.006,.011,.028),col,uBackdrop);
}
vec4 medium(vec3 p){
 float t=uTime*uSpin;vec3 q=p/vec3(uRadius,uHeight,uRadius);float r=length(q.xz),a=atan(q.z,q.x);
 float density=0.;vec3 light=vec3(0);
 if(q.y<.35&&q.y>-1.8&&r<2.){
  float h=clamp((q.y+1.55)/1.9,0.,1.);
  float winding=a*7.+h*8.-t*.7+sin(h*5.-t*.3)*1.3;
  float target=1.32-h*.63+.10*sin(a*3.+h*11.-t*.7);
  float field=bell(r-target,19.)*pow(.5+.5*sin(winding),2.);
  float n=fbm(q*5.+vec3(sin(a+t*.3),-t*.85,cos(a+t*.3)));
  float fold=pow(1.-abs(sin(winding+n*7.)),10.);
  float d=field*smoothstep(.20,.62,n)*pow(max(0.,sin(PI*h)),.6)*uSmoke*uLayers.z;
  density+=d*5.4;
  light+=d*(vec3(.006,.007,.016)+vec3(.12,.12,.22)*fold*.8);
 }
 if(q.y>.1&&q.y<1.95&&r<2.5){
  float h=clamp((q.y-.1)/1.85,0.,1.);
  float target=.2+h*1.65;
  float swirl=a*5.-q.y*7.+t*.5;
  float n=fbm(q*4.8+vec3(0,t*.5,0));
  float d=bell(r-target,18.)*pow(.5+.5*sin(swirl+n*4.),4.)*smoothstep(.38,.72,n)*uMist*uLayers.y;
  d*=1.-smoothstep(1.65,1.95,q.y);
  float cap=bell(q.y-1.75-sin(a*3.+r*4.+t*.5)*.1,55.)*smoothstep(.2,1.6,r)*(1.-smoothstep(1.65,2.25,r))*.04;
  d+=cap*pow(n,2.)*uMist*uLayers.y;
  density+=d*.85;light+=d*uGold*(.25+pow(n,4.)*2.);
 }
 if(uLayers.x>.5){
  vec3 c=rx(-.16)*ry(-t*.075)*(p-vec3(0,.06,0));
  c/=uSwirl;float radius=length(c),rr=length(c.xy),angle=atan(c.y,c.x);
  if(radius<1.38){
   float n=fbm(c*7.+vec3(t*.3,-t*.5,t*.1));
   float latitude=acos(clamp(c.z/max(radius,.001),-1.,1.));
   float phase=angle*3.+latitude*5.2-t*2.2+n*2.;
   float arm=pow(max(0.,.5+.5*sin(phase)),9.);
   float shell=exp(-abs(radius-(.82+(n-.5)*.22))*34.);
   float inner=exp(-radius*radius*3.)*.10;
   float d=shell*(.10+arm*2.4)+inner;
   float filament=pow(1.-abs(sin(phase*2.+n*5.)),14.);
   density+=d*2.6;
   vec3 red=uFire*vec3(.65,.3,.06);
   vec3 hot=vec3(3.4,.54,.008)*(arm+filament*.9);
   light+=d*(red+hot)*uFirePower;
   float glow=exp(-dot(c,c)*55.);density+=glow*2.;light+=glow*vec3(10.,4.4,.4)*uFirePower;
  }
 }
 if(isnan(density)||isinf(density)||any(isnan(light))||any(isinf(light)))return vec4(0);
 return vec4(light,max(0.,density));
}
void main(){
 vec2 uv=vUV*2.-1.;vec3 rd=normalize(uForward+uRight*uv.x*uAspect*uTanFov+uUp*uv.y*uTanFov);
 vec3 bg=sky(rd);
 vec4 surfaces[8];float surfaceDistance[8];
 ${Array.from({length:8},(_,i)=>`surfaces[${i}]=texture(uPeelColor${i},vUV);{float z=texture(uPeelDepth${i},vUV).r*2.-1.;surfaceDistance[${i}]=10./(100.05-z*99.95)/max(.001,dot(rd,uForward));}`).join('\n')}
 int surfaceIndex=0;
 float bound=max(3.6*max(uRadius,uHeight),1.7*uSwirl);
 float b=dot(uEye,rd),c=dot(uEye,uEye)-bound*bound,h=b*b-c;
 if(h<0.){fragColor=vec4(bg,1);return;}
 float lo=max(0.,-b-sqrt(h)),hi=-b+sqrt(h);
 float dt=(hi-lo)/float(uSteps),dist=lo+dt*.5,trans=1.;vec3 col=vec3(0);
 for(int i=0;i<768;i++){
  if(i>=uSteps)break;
  vec4 m=medium(uEye+rd*dist);float extinction=1.-exp(-m.a*dt*2.3);
  col+=trans*(m.rgb/max(m.a,.0001))*extinction;
  trans*=1.-extinction;
  for(int j=0;j<8;j++){
   if(surfaceIndex>=8)break;
   if(surfaceDistance[surfaceIndex]>dist+dt*.5)break;
   vec4 s=surfaces[surfaceIndex];col+=trans*s.rgb*s.a;trans*=1.-s.a;surfaceIndex++;
  }
  dist+=dt;
 }
 fragColor=vec4(col+trans*bg,1);
}`;

export const downsampleFragment=`#version 300 es
precision highp float;in vec2 vUV;out vec4 fragColor;uniform sampler2D uSource;uniform vec2 uTexel;uniform float uThreshold;
void main(){
 vec3 c=texture(uSource,vUV).rgb*.20;
 c+=(texture(uSource,vUV+uTexel*vec2(1,1)).rgb+texture(uSource,vUV+uTexel*vec2(-1,1)).rgb+texture(uSource,vUV+uTexel*vec2(1,-1)).rgb+texture(uSource,vUV+uTexel*vec2(-1,-1)).rgb)*.10;
 c+=(texture(uSource,vUV+uTexel*vec2(2,0)).rgb+texture(uSource,vUV+uTexel*vec2(-2,0)).rgb+texture(uSource,vUV+uTexel*vec2(0,2)).rgb+texture(uSource,vUV+uTexel*vec2(0,-2)).rgb)*.10;
 float br=max(c.r,max(c.g,c.b));float contribution=max(br-uThreshold,0.)/max(br,.001);fragColor=vec4(c*(uThreshold>0.?contribution:1.),1);
}`;
export const blurFragment=`#version 300 es
precision highp float;in vec2 vUV;out vec4 fragColor;uniform sampler2D uSource;uniform vec2 uDirection;
void main(){vec3 c=texture(uSource,vUV).rgb*.227027;
 c+=(texture(uSource,vUV+uDirection*1.384615).rgb+texture(uSource,vUV-uDirection*1.384615).rgb)*.316216;
 c+=(texture(uSource,vUV+uDirection*3.230769).rgb+texture(uSource,vUV-uDirection*3.230769).rgb)*.070270;
 fragColor=vec4(c,1);}`;
export const compositeFragment=`#version 300 es
precision highp float;in vec2 vUV;out vec4 fragColor;
uniform sampler2D uScene,uBloom0,uBloom1,uBloom2,uBloom3,uBloom4;
uniform float uBloom,uExposure,uVignette;
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
void main(){
 vec3 c=texture(uScene,vUV).rgb;
 vec3 glow=texture(uBloom0,vUV).rgb*.25+texture(uBloom1,vUV).rgb*.28+texture(uBloom2,vUV).rgb*.27+texture(uBloom3,vUV).rgb*.24+texture(uBloom4,vUV).rgb*.19;
 c+=glow*uBloom;c=aces(c*uExposure);c=pow(c,vec3(1./2.2));
 vec2 p=(vUV-.5)*2.;c*=1.-uVignette*.28*dot(p,p);
 fragColor=vec4(c,1);
}`;
