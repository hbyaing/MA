import * as S from './shaders.js';

const $=id=>document.getElementById(id);
const defaults={radius:1,height:1,tilt:31,swirl:1,spin:1,wisp:1,goldPower:1.8,bluePower:2.0,firePower:2.0,wispPower:1,smoke:1.5,mist:1.25,sparks:1,sparkPower:1.2,glyph:1,bloom:.85,exposure:.95,vignette:.55,backdrop:1,steps:256,resolution:1,gold:'#ffe0ba',blue:'#2164ff',fire:'#ff3808',top:true,orbits:true,core:true,white:true,black:true,stars:true,curtain:true};
const fieldGroups=[
 ['天环与地环',[
  ['radius','阵环半径',.65,1.45,.01],['height','天地间距',.65,1.45,.01],['glyph','符纹笔画',.5,1.65,.01],['goldPower','白金辉度',.2,4,.05],['gold','天环色泽','color']]],
 ['蓝轨与赤心',[
  ['tilt','轨环倾角',12,65,1,'°'],['bluePower','蓝轨辉度',.2,5,.05],['swirl','旋涡尺度',.5,1.55,.01],['firePower','赤心辉度',.2,5,.05],['spin','能量流转',0,2,.01],['blue','轨环色泽','color'],['fire','炉心色泽','color']]],
 ['烟纱与微芒',[
  ['wisp','气丝宽度',.3,2,.01],['wispPower','气丝辉度',.2,2.5,.01],['smoke','黑焰浓度',0,3,.01],['mist','天穹烟纱',0,3,.01],['sparks','微芒大小',.3,2,.01],['sparkPower','微芒辉度',.1,3,.01]]],
 ['光与成像',[
  ['bloom','光晕强度',0,3,.01],['exposure','画面曝光',.3,2,.01],['vignette','边缘收光',0,1,.01],['backdrop','暮空亮度',0,1,.01],['steps','烟气积分',128,768,64,' 步'],['resolution','渲染倍率',.5,2,.25,' ×']]]
];
let state={...defaults},camera={yaw:.13,pitch:.035,distance:8.4,target:[0,.05,0]},time=12,playing=true,autoOrbit=false,speed=1;
try{const saved=JSON.parse(localStorage.getItem('heavenly-furnace-v1')||'null');if(saved)state=validate(saved);}catch{}
function validate(data){const d={...defaults};if(data?.parameters)data=data.parameters;if(!data||typeof data!=='object'||Array.isArray(data))throw Error('配方必须是参数对象');for(const [k,v] of Object.entries(defaults)){if(!(k in data))continue;if(typeof v==='boolean'){if(typeof data[k]!=='boolean')throw Error(k+' 应为开关');d[k]=data[k];}else if(typeof v==='string'){if(!/^#[0-9a-f]{6}$/i.test(data[k]))throw Error(k+' 色值无效');d[k]=data[k];}else{const f=fieldGroups.flatMap(g=>g[1]).find(f=>f[0]===k);if(!Number.isFinite(data[k])||data[k]<f[2]||data[k]>f[3])throw Error(k+' 超出范围');d[k]=data[k];}}return d;}
function persist(){localStorage.setItem('heavenly-furnace-v1',JSON.stringify(state));}
function makeControls(){
 $('controls').replaceChildren();
 for(const [name,fields]of fieldGroups){let group=document.createElement('details');group.open=true;let summary=document.createElement('summary');summary.textContent=name;group.append(summary);
  for(const [key,label,min,max,step,suffix='']of fields){let row=document.createElement('div');row.className='field';let l=document.createElement('label');l.htmlFor='p-'+key;l.append(document.createTextNode(label));let input=document.createElement('input');input.id='p-'+key;input.dataset.key=key;
   if(min==='color'){input.type='color';input.value=state[key];l.append(input);row.append(l);}else{input.type='range';Object.assign(input,{min,max,step,value:state[key]});let out=document.createElement('output');out.htmlFor=input.id;out.textContent=format(state[key])+suffix;l.append(out);row.append(l,input);input.addEventListener('input',()=>out.textContent=format(+input.value)+suffix);}
   input.addEventListener('input',()=>{state[key]=min==='color'?input.value:+input.value;persist();dirty=true;});group.append(row);
  }$('controls').append(group);
 }
 $('layers').replaceChildren();for(const [key,name,color]of [['top','天环地环','#ffe0ba'],['orbits','交错蓝轨','#4386ff'],['core','赤心旋涡','#ff742e'],['white','白金烟纱','#dedbe4'],['black','玄阴黑焰','#77758e'],['stars','散逸微芒','#acc8fd'],['curtain','垂落光雨','#f7d8b5']]){const label=document.createElement('label'),box=document.createElement('input'),dot=document.createElement('i');box.type='checkbox';box.checked=state[key];box.dataset.layer=key;dot.style.background=color;label.append(box,dot,document.createTextNode(name));box.addEventListener('change',()=>{state[key]=box.checked;persist();dirty=true;});$('layers').append(label);}
}
function format(n){return Number.isInteger(n)?String(n):n.toFixed(2);}
function notice(message){$('notice').textContent=message;}
function download(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);}
makeControls();
document.querySelector('.panel-foot').append($('lastCapture'));
const canvas=$('view'),gl=canvas.getContext('webgl2',{alpha:false,antialias:false,preserveDrawingBuffer:true,powerPreference:'high-performance'});
let renderer,dirty=true,raf=0,last=performance.now(),frames=0,lastStats=last,fps=0;
function showError(err){$('error').hidden=false;$('error').textContent=err.stack||String(err);$('status').textContent='演境载入失败';console.error(err);}
function updatePlay(){$('play').textContent=playing?'Ⅱ':'▶';$('play').ariaLabel=playing?'暂停动画':'播放动画';}
function tick(now){
 try{const dt=Math.min((now-last)/1000,.1);last=now;
  if(playing&&!document.hidden){time=(time+dt*speed)%120;dirty=true;}
  if(autoOrbit&&!document.hidden){camera.yaw+=dt*.14;dirty=true;}
  if(dirty&&!document.hidden){renderer.render(state,camera,time);dirty=false;frames++;}
  if(now-lastStats>1000){fps=Math.round(frames*1000/(now-lastStats));frames=0;lastStats=now;$('status').textContent=`${playing?'流转中':'已定格'} · ${canvas.width} × ${canvas.height} · ${fps} 帧/秒`;}
  $('time').value=time;$('timeRead').textContent=time.toFixed(2)+' s';
  raf=requestAnimationFrame(tick);
 }catch(err){showError(err);cancelAnimationFrame(raf);}
}
const views={hero:{yaw:.13,pitch:.035,distance:8.4},front:{yaw:0,pitch:0,distance:8.4},side:{yaw:Math.PI/2,pitch:.035,distance:8.4},top:{yaw:0,pitch:1.47,distance:8.6}};
function setView(name){Object.assign(camera,views[name]);document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));dirty=true;}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
$('play').onclick=()=>{playing=!playing;updatePlay();dirty=true;};$('time').oninput=e=>{time=+e.target.value;playing=false;updatePlay();dirty=true;};$('speed').onchange=e=>speed=+e.target.value;
$('orbit').onclick=()=>{autoOrbit=!autoOrbit;$('orbit').ariaPressed=String(autoOrbit);};
$('reference').onclick=()=>$('referencePane').hidden=!$('referencePane').hidden;$('closeReference').onclick=()=>$('referencePane').hidden=true;
function beauty(on){document.body.classList.toggle('beauty',on);$('exitBeauty').hidden=!on;dirty=true;}
$('beauty').onclick=()=>beauty(true);$('exitBeauty').onclick=()=>beauty(false);
$('reset').onclick=()=>{state={...defaults};time=12;playing=true;autoOrbit=false;$('orbit').ariaPressed='false';updatePlay();setView('hero');persist();makeControls();notice('已还原参考图初稿。');};
$('export').onclick=()=>download(new Blob([JSON.stringify({schema:'heavenly-furnace/1',parameters:state,camera,time},null,2)],{type:'application/json'}),'天地为炉-配方.json');
$('import').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>65536)throw Error('配方文件过大');const data=JSON.parse(await file.text());state=validate(data);if(data.camera){const c=data.camera;if(Number.isFinite(c.yaw)&&Number.isFinite(c.pitch)&&Number.isFinite(c.distance))camera={...camera,yaw:c.yaw,pitch:Math.max(-1.5,Math.min(1.5,c.pitch)),distance:Math.max(3.5,Math.min(20,c.distance))};}if(Number.isFinite(data.time))time=Math.max(0,Math.min(120,data.time));persist();makeControls();dirty=true;notice('配方已载入。');}catch(err){notice('载入失败：'+err.message);}e.target.value='';};
$('capture').onclick=()=>{const size=$('exportSize').value,viewport=size==='preview'?null:{width:+size,height:Math.round(+size*9/16)};renderer.render(state,camera,time,viewport);const capturedTime=time;$('lastCapture').href=canvas.toDataURL('image/png');$('lastCapture').hidden=false;canvas.toBlob(blob=>{if(blob){download(blob,'天地为炉-'+capturedTime.toFixed(2)+'s.png');notice('已保存当前画面。');}else notice('画面导出失败。');},'image/png');dirty=true;};
window.addEventListener('keydown',e=>{if(e.code==='Space'&&!['INPUT','SELECT'].includes(e.target.tagName)){e.preventDefault();playing=!playing;updatePlay();dirty=true;}if(e.code==='Escape'){beauty(false);$('referencePane').hidden=true;}});
let drag=null;canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,yaw:camera.yaw,pitch:camera.pitch};canvas.setPointerCapture(e.pointerId);});canvas.addEventListener('pointermove',e=>{if(!drag)return;camera.yaw=drag.yaw-(e.clientX-drag.x)*.006;camera.pitch=Math.max(-1.48,Math.min(1.48,drag.pitch+(e.clientY-drag.y)*.006));document.querySelectorAll('[data-view]').forEach(b=>b.classList.remove('active'));dirty=true;});for(const event of ['pointerup','pointercancel'])canvas.addEventListener(event,()=>drag=null);
canvas.addEventListener('wheel',e=>{e.preventDefault();camera.distance=Math.max(3.5,Math.min(20,camera.distance*Math.exp(e.deltaY*.001)));dirty=true;},{passive:false});
new ResizeObserver(()=>dirty=true).observe($('stage'));document.addEventListener('visibilitychange',()=>{last=performance.now();dirty=true;});canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelAnimationFrame(raf);notice('图形上下文已暂停，正在等待恢复。');});canvas.addEventListener('webglcontextrestored',()=>location.reload());

// Small, dependency-free matrix implementation; all scene surfaces remain shader generated.
function normalize(v){const l=Math.hypot(...v);return v.map(x=>x/l);}function cross(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}function dot(a,b){return a.reduce((s,x,i)=>s+x*b[i],0);}
function multiply(a,b){const r=new Float32Array(16);for(let j=0;j<4;j++)for(let i=0;i<4;i++)for(let k=0;k<4;k++)r[j*4+i]+=a[k*4+i]*b[j*4+k];return r;}
function projection(aspect,fov){const f=1/Math.tan(fov/2),near=.05,far=100;return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)/(near-far),-1,0,0,2*far*near/(near-far),0]);}
function look(eye,target){const back=normalize(eye.map((x,i)=>x-target[i])),right=normalize(cross([0,1,0],back)),up=cross(back,right);return{right,up,forward:back.map(x=>-x),matrix:new Float32Array([right[0],up[0],back[0],0,right[1],up[1],back[1],0,right[2],up[2],back[2],0,-dot(right,eye),-dot(up,eye),-dot(back,eye),1])};}
function rgb(hex){return[1,3,5].map(i=>{const c=parseInt(hex.slice(i,i+2),16)/255;return c<=.04045?c/12.92:Math.pow((c+.055)/1.055,2.4);});}

function Renderer(gl,canvas){
 this.gl=gl;this.canvas=canvas;this.width=0;this.height=0;this.targets=[];this.errors=[];this.renderCount=0;
 if(!gl.getExtension('EXT_color_buffer_float'))throw Error('需要支持浮点颜色缓冲的 WebGL 2 显卡驱动');gl.getExtension('OES_texture_float_linear');
 this.programs={surface:this.program(S.surfaceVertex,S.surfaceFragment,'三维曲面'),atmosphere:this.program(S.fullscreenVertex,S.atmosphereFragment,'体积烟气'),down:this.program(S.fullscreenVertex,S.downsampleFragment,'光晕提取'),blur:this.program(S.fullscreenVertex,S.blurFragment,'光晕卷积'),composite:this.program(S.fullscreenVertex,S.compositeFragment,'画面合成')};
 this.meshes={ring:this.mesh(512,3),ribbon:this.mesh(320,10),wisp:this.mesh(192,12),spark:this.mesh(1,1),curtain:this.mesh(24,1),sphere:this.mesh(64,32)};this.empty=gl.createVertexArray();
}
Renderer.prototype.program=function(vs,fs,label){const gl=this.gl;function compile(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(label+'着色器编译失败\n'+gl.getShaderInfoLog(s));return s;}const a=compile(gl.VERTEX_SHADER,vs),b=compile(gl.FRAGMENT_SHADER,fs),p=gl.createProgram();gl.attachShader(p,a);gl.attachShader(p,b);gl.linkProgram(p);gl.deleteShader(a);gl.deleteShader(b);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(label+'链接失败\n'+gl.getProgramInfoLog(p));const uniforms={};for(let i=0;i<gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS);i++){const u=gl.getActiveUniform(p,i);uniforms[u.name]={location:gl.getUniformLocation(p,u.name),type:u.type};}return{p,uniforms};};
Renderer.prototype.use=function(program,values={}){const gl=this.gl;gl.useProgram(program.p);for(const[k,v]of Object.entries(values)){const u=program.uniforms[k];if(!u)continue;switch(u.type){case gl.INT:case gl.SAMPLER_2D:gl.uniform1i(u.location,v);break;case gl.FLOAT:gl.uniform1f(u.location,v);break;case gl.FLOAT_VEC2:gl.uniform2fv(u.location,v);break;case gl.FLOAT_VEC3:gl.uniform3fv(u.location,v);break;case gl.FLOAT_VEC4:gl.uniform4fv(u.location,v);break;case gl.FLOAT_MAT4:gl.uniformMatrix4fv(u.location,false,v);break;default:throw Error('未支持的 uniform '+k);}}};
Renderer.prototype.mesh=function(nx,ny){const gl=this.gl,vertices=[],indices=[];for(let y=0;y<=ny;y++)for(let x=0;x<=nx;x++)vertices.push(x/nx,y/ny);for(let y=0;y<ny;y++)for(let x=0;x<nx;x++){const i=y*(nx+1)+x;indices.push(i,i+1,i+nx+2,i,i+nx+2,i+nx+1);}const vao=gl.createVertexArray();gl.bindVertexArray(vao);const vbo=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vbo);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,8,0);const ibo=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ibo);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint32Array(indices),gl.STATIC_DRAW);gl.bindVertexArray(null);return{vao,count:indices.length,vbo,ibo};};
Renderer.prototype.target=function(width,height,withDepth=false){const gl=this.gl,texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,width,height,0,gl.RGBA,gl.HALF_FLOAT,null);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);const fbo=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);let depth=null;if(withDepth){depth=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,depth);gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,width,height,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,depth,0);}if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('HDR 缓冲创建失败');const target={fbo,texture,depth,width,height};this.targets.push(target);return target;};
Renderer.prototype.resize=function(w,h){if(w===this.width&&h===this.height)return;const gl=this.gl;for(const t of this.targets){gl.deleteFramebuffer(t.fbo);gl.deleteTexture(t.texture);if(t.depth)gl.deleteTexture(t.depth);}this.targets=[];this.width=w;this.height=h;this.canvas.width=w;this.canvas.height=h;this.scene=this.target(w,h);this.peels=Array.from({length:8},()=>this.target(w,h,true));this.bloom=[];for(let i=0;i<5;i++)this.bloom.push([this.target(Math.max(1,w>>(i+1)),Math.max(1,h>>(i+1))),this.target(Math.max(1,w>>(i+1)),Math.max(1,h>>(i+1)))]);};
Renderer.prototype.bind=function(target){const gl=this.gl;gl.bindFramebuffer(gl.FRAMEBUFFER,target?.fbo||null);gl.viewport(0,0,target?.width||this.width,target?.height||this.height);};
Renderer.prototype.texture=function(texture,index){const gl=this.gl;gl.activeTexture(gl.TEXTURE0+index);gl.bindTexture(gl.TEXTURE_2D,texture);};
Renderer.prototype.full=function(program,values,target){const gl=this.gl;this.bind(target);this.use(program,values);gl.bindVertexArray(this.empty);gl.drawArrays(gl.TRIANGLES,0,3);};
Renderer.prototype.draw=function(kind,mesh,count=1,offset=0){const gl=this.gl;this.use(this.programs.surface,{uKind:kind,uOffset:offset});gl.bindVertexArray(this.meshes[mesh].vao);gl.drawElementsInstanced(gl.TRIANGLES,this.meshes[mesh].count,gl.UNSIGNED_INT,0,count);};
Renderer.prototype.surfaces=function(s){
 if(s.black)this.draw(3,'wisp',18,18);
 if(s.white){this.draw(3,'wisp',18,0);this.draw(6,'wisp',14,0);}
 if(s.curtain)this.draw(5,'curtain',96);
 if(s.core){this.draw(1,'ribbon',9);this.draw(7,'sphere');}
 if(s.orbits){this.draw(2,'ribbon',20);this.draw(0,'ring',2,2);this.draw(8,'ring',6,6);}
 if(s.top){this.draw(0,'ring',2,0);this.draw(10,'ring',2,0);this.draw(11,'ring');this.draw(8,'ring',6,0);}
 if(s.stars)this.draw(4,'spark',1700);
};
Renderer.prototype.render=function(s,c,time,viewport=null){
 const gl=this.gl,rect=this.canvas.getBoundingClientRect(),scale=(window.devicePixelRatio||1)*s.resolution,w=viewport?.width||Math.max(2,Math.round(rect.width*scale)),h=viewport?.height||Math.max(2,Math.round(rect.height*scale));this.resize(w,h);this.renderCount++;
 const aspect=w/h,dist=c.distance*Math.max(1,.88/aspect),target=c.target||[0,.05,0],eye=[Math.sin(c.yaw)*Math.cos(c.pitch)*dist+target[0],Math.sin(c.pitch)*dist+target[1],Math.cos(c.yaw)*Math.cos(c.pitch)*dist+target[2]],v=look(eye,target),fov=Math.PI*42/180;
 const values={uTime:time,uRadius:s.radius,uHeight:s.height,uTilt:s.tilt*Math.PI/180,uSpin:s.spin,uSwirl:s.swirl,uWisp:s.wisp,uSparks:s.sparks,uRight:v.right,uUp:v.up,uGoldPower:s.goldPower,uBluePower:s.bluePower,uFirePower:s.firePower,uWispPower:s.wispPower,uGlyph:s.glyph,uSparkPower:s.sparkPower,uGold:rgb(s.gold),uBlue:rgb(s.blue),uFire:rgb(s.fire),uVP:multiply(projection(aspect,fov),v.matrix)};
 gl.disable(gl.CULL_FACE);gl.disable(gl.BLEND);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LESS);gl.depthMask(true);gl.clearDepth(1);
 // Eight peeled front-to-back surfaces per pixel. Smoke integrates between these depths,
 // so flames, symbols and crossing hoops cannot show through nearer dark matter.
 for(let i=0;i<8;i++){
  this.bind(this.peels[i]);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  this.texture(this.peels[(i+7)%8].depth,0);
  this.use(this.programs.surface,{...values,uPeel:i,uPrevDepth:0,uResolution:[w,h]});this.surfaces(s);
 }
 gl.disable(gl.DEPTH_TEST);
 const peeled={};for(let i=0;i<8;i++){this.texture(this.peels[i].texture,i*2);this.texture(this.peels[i].depth,i*2+1);peeled['uPeelColor'+i]=i*2;peeled['uPeelDepth'+i]=i*2+1;}
 this.full(this.programs.atmosphere,{...values,...peeled,uResolution:[w,h],uEye:eye,uForward:v.forward,uAspect:aspect,uTanFov:Math.tan(fov/2),uSmoke:s.smoke,uMist:s.mist,uBackdrop:s.backdrop,uSteps:s.steps,uLayers:[+s.core,+s.white,+s.black,0]},this.scene);
 let source=this.scene;
 for(let i=0;i<5;i++){const [a,b]=this.bloom[i];this.texture(source.texture,0);this.full(this.programs.down,{uSource:0,uTexel:[1/source.width,1/source.height],uThreshold:i===0?.75:0},a);this.texture(a.texture,0);this.full(this.programs.blur,{uSource:0,uDirection:[1.2/a.width,0]},b);this.texture(b.texture,0);this.full(this.programs.blur,{uSource:0,uDirection:[0,1.2/a.height]},a);source=a;}
 this.texture(this.scene.texture,0);const samplers={uScene:0,uBloom:s.bloom,uExposure:s.exposure,uVignette:s.vignette};for(let i=0;i<5;i++){this.texture(this.bloom[i][0].texture,i+1);samplers['uBloom'+i]=i+1;}this.full(this.programs.composite,samplers,null);
 const err=gl.getError();if(err!==gl.NO_ERROR){this.errors.push(err);throw Error('WebGL 绘制错误 '+err);}
};
Renderer.prototype.diagnostics=function(){return{width:this.width,height:this.height,frames:this.renderCount,glErrors:[...this.errors],programs:Object.keys(this.programs),targetCount:this.targets.length,proceduralOnly:true};};

try{if(!gl)throw Error('当前浏览器不支持 WebGL 2');renderer=new Renderer(gl,canvas);window.furnace={get state(){return {...state};},get camera(){return {...camera};},get time(){return time;},get playing(){return playing;},get diagnostics(){return renderer.diagnostics();},setTime(t){time=Math.max(0,Math.min(120,t));dirty=true;},setState(p){state=validate({...state,...p});makeControls();dirty=true;},setCamera(p){Object.assign(camera,p);dirty=true;},pause(){playing=false;updatePlay();},render(){renderer.render(state,camera,time);}};requestAnimationFrame(tick);}catch(err){showError(err);}
