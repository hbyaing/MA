// Deterministic port of the reviewed workbench shaders. Never edits the workbench.
import * as S from './shaders.js';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../../src/main/resources/assets/wuxingxiantu/heavenly/shaders');
fs.mkdirSync(root,{recursive:true});
function desktop(s){return s.replace('#version 300 es','#version 150').replaceAll(/precision highp (?:float|int);/g,'').replace('layout(location=0) in vec2 aUV;','in vec2 aUV;');}
let vertex=desktop(S.surfaceVertex);
let fragment=desktop(S.surfaceFragment).replace('uniform int uPeel;','uniform int uPeel;\nuniform sampler2D uWorldDepth;');
fragment=fragment.replace('void main(){','void main(){\n if(gl_FragCoord.z>texture(uWorldDepth,gl_FragCoord.xy/uResolution).r+.0000001)discard;');
let atmosphere=desktop(S.atmosphereFragment);
atmosphere=atmosphere.replace('uniform int uSteps;','uniform int uSteps;\nuniform mat4 uInvVP;\nuniform sampler2D uWorldDepth;\nuniform float uCoreStrength;\nvec3 unproject(vec2 uv,float z){vec4 p=uInvVP*vec4(uv*2.-1.,z*2.-1.,1.);return p.xyz/p.w;}');
// World-space unprojection supports arbitrary Minecraft projection and view bob.
atmosphere=atmosphere.replace('vec2 uv=vUV*2.-1.;vec3 rd=normalize(uForward+uRight*uv.x*uAspect*uTanFov+uUp*uv.y*uTanFov);','vec3 rd=normalize(unproject(vUV,1.)-uEye);');
atmosphere=atmosphere.replace('vec3 bg=sky(rd);','vec3 bg=vec3(0);');
for(let i=0;i<8;i++){
 const old=`{float z=texture(uPeelDepth${i},vUV).r*2.-1.;surfaceDistance[${i}]=10./(100.05-z*99.95)/max(.001,dot(rd,uForward));}`;
 const next=`{float z=texture(uPeelDepth${i},vUV).r;surfaceDistance[${i}]=z>.999999?1e8:dot(unproject(vUV,z)-uEye,rd);}`;
 if(!atmosphere.includes(old))throw Error('Depth port contract changed');
 atmosphere=atmosphere.replace(old,next);
}
atmosphere=atmosphere.replace('if(h<0.){fragColor=vec4(bg,1);return;}','if(h<0.){fragColor=vec4(0);return;}');
atmosphere=atmosphere.replace('float lo=max(0.,-b-sqrt(h)),hi=-b+sqrt(h);','float lo=max(0.,-b-sqrt(h)),hi=-b+sqrt(h);\n float worldZ=texture(uWorldDepth,vUV).r;\n if(worldZ<.999999)hi=min(hi,dot(unproject(vUV,worldZ)-uEye,rd));\n if(hi<=lo){fragColor=vec4(0);return;}');
atmosphere=atmosphere.replace('density+=d*2.6;','density+=d*2.6*uCoreStrength;').replace('light+=d*(red+hot)*uFirePower;','light+=d*(red+hot)*uFirePower*uCoreStrength;').replace('density+=glow*2.;light+=glow*vec3(10.,4.4,.4)*uFirePower;','density+=glow*2.*uCoreStrength;light+=glow*vec3(10.,4.4,.4)*uFirePower*uCoreStrength;');
atmosphere=atmosphere.replace('fragColor=vec4(col+trans*bg,1);','fragColor=vec4(col,1.-trans);');
let composite=desktop(S.compositeFragment).replace('uniform float uBloom,uExposure,uVignette;','uniform float uBloom,uExposure,uVignette,uOpacity;\nuniform sampler2D uWorldDepth;uniform mat4 uInvVP;uniform vec3 uEye;');
composite=composite.replace('void main(){','void main(){\n float worldZ=texture(uWorldDepth,vUV).r;\n if(worldZ<.999999){vec4 w=uInvVP*vec4(vUV*2.-1.,worldZ*2.-1.,1.);vec3 d=w.xyz/w.w-uEye;float dist=length(d);vec3 rd=d/max(dist,.0001);float b=dot(uEye,rd),h=b*b-dot(uEye,uEye)+12.96;if(h>0.&&dist<max(0.,-b-sqrt(h))){fragColor=vec4(0);return;}}');
composite=composite.replace('vec3 c=texture(uScene,vUV).rgb;','vec4 scene=texture(uScene,vUV);vec3 c=scene.rgb;');
composite=composite.replace('c+=glow*uBloom;c=aces(c*uExposure);c=pow(c,vec3(1./2.2));','c=pow(aces(c/max(scene.a,.0001)*uExposure),vec3(1./2.2))*scene.a;\n c+=pow(aces(glow*uBloom*uExposure),vec3(1./2.2))*.55;');
composite=composite.replace('fragColor=vec4(c,1);','fragColor=vec4(c*uOpacity,scene.a*uOpacity);');
const files={'surface.vsh':vertex,'surface.fsh':fragment,'fullscreen.vsh':desktop(S.fullscreenVertex),'volume.fsh':atmosphere,'down.fsh':desktop(S.downsampleFragment),'blur.fsh':desktop(S.blurFragment),'composite.fsh':composite};
for(const [name,source]of Object.entries(files))fs.writeFileSync(path.join(root,name),source,'utf8');
console.log('Exported '+Object.keys(files).length+' reviewed shaders to '+root);
