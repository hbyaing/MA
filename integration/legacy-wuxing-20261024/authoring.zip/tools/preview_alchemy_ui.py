"""Visual QA of source fittings at GUI scale 3; this is not a game screenshot.
Also checks native slot containment and pairwise slot separation.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import re,json,sys
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/alchemy_concept'
OUT=ROOT/'reports'/ (sys.argv[1] if len(sys.argv)>1 else 'alchemy-ui-detail-pass-20261012');OUT.mkdir(parents=True,exist_ok=True)
S=3
src=(ROOT/'src/main/java/cn/blockforge/generated/generatedmod/client/AlchemyScreen.java').read_text(encoding='utf-8')
layout=(ROOT/'src/main/java/cn/blockforge/generated/generatedmod/AlchemyUiLayout.java').read_text(encoding='utf-8')
panels=[tuple(map(int,m)) for m in re.findall(r'panel\(g,\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)\)',src)]
assert len(panels)==9
material=[tuple(map(int,m)) for m in re.findall(r'\{(\d+),\s*(\d+)\}',layout)]
assert len(material)==8
cx,cy=map(int,re.search(r'CENTER_X = (\d+), CENTER_Y = (\d+)',layout).groups())
assert cx==132+152//2
for i in range(4):assert material[i][0]+material[i+4][0]+16==2*cx and material[i][1]+material[i+4][1]+16==2*cy
cols=list(map(int,re.search(r'INVENTORY_COLUMNS = \{([^}]+)',layout).group(1).split(',')))
rows=list(map(int,re.search(r'INVENTORY_ROWS = \{([^}]+)',layout).group(1).split(',')))
slots=material+[(302,110),(26,254)]+[(x,y) for y in rows for x in cols]
for i,(x,y) in enumerate(slots):
    assert any(px<=x-1 and py<=y-1 and x+17<=px+w and y+17<=py+h for px,py,w,h in panels),(i,'outside panel')
    for x2,y2 in slots[i+1:]:assert x+18<=x2 or x2+18<=x or y+18<=y2 or y2+18<=y,'overlapping slots'
for name,size in {'panel':(128,128),'formation':(512,512),'preview':(112,112),'material_slot':(72,72),'inventory_slot':(72,72),
                  'button':(256,96),'button_gold':(256,96),'button_selected':(256,96),'header_shadow':(720,72),'section_shadow':(416,48),'cloud_pair':(2172,724),
                  'header_ornaments':(1774,887),'header_corner':(192,92),'header_flourish':(88,28),'divider':(512,24),'progress_backing':(256,48),
                  **{n:(256,48) for n in ('bar_track','bar_border','bar_gold','bar_spirit','bar_danger')}}.items():
    im=Image.open(A/f'{name}.png');assert im.size==size and im.mode=='RGBA'
    assert json.loads((A/f'{name}.png.mcmeta').read_text(encoding='utf-8-sig'))['texture']['blur']
FONT=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',22)
def render(state):
    canvas=Image.open(A/'landscape.png').convert('RGBA').resize((420*S,320*S),Image.Resampling.LANCZOS)
    shade=Image.new('RGBA',canvas.size);ImageDraw.Draw(shade).rectangle((0,24*S,420*S,320*S),fill=(5,24,32,68));canvas.alpha_composite(shade)
    def sprite(name,x,y,w,h,box=None,mirror=False):
        if w<=0 or h<=0:return
        im=Image.open(A/f'{name}.png').convert('RGBA')
        if box:im=im.crop(box)
        if mirror:im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        canvas.alpha_composite(im.resize((w*S,h*S),Image.Resampling.BILINEAR),(x*S,y*S))
    def nine(name,x,y,w,h,sw,sh,sc,c):
        c=min(c,w//2,h//2)
        xs=[0,c,w-c,w];ys=[0,c,h-c,h];us=[0,sc,sw-sc,sw];vs=[0,sc,sh-sc,sh]
        for r in range(3):
            for col in range(3):sprite(name,x+xs[col],y+ys[r],xs[col+1]-xs[col],ys[r+1]-ys[r],(us[col],vs[r],us[col+1],vs[r+1]))
    def box(x,y,w,h,color):
        if w<=0 or h<=0:return
        overlay=Image.new('RGBA',canvas.size);ImageDraw.Draw(overlay).rectangle((x*S,y*S,(x+w)*S-1,(y+h)*S-1),fill=color);canvas.alpha_composite(overlay)
    def text(t,x,y,color='#e8cb83',center=False):
        d=ImageDraw.Draw(canvas)
        if center:x-=d.textlength(t,font=FONT)/(2*S)
        d.text((round(x*S),round(y*S)),t,font=FONT,fill=color)
    def rule(x,y,w):
        for dx,dw,u,uw in [(0,8,0,32),(8,w-16,32,448),(w-8,8,480,32)]:
            sprite('divider',x+dx,y-3,dw,6,(u,0,u+uw,24))
    def bar(x,y,w,h,p,spirit=False,danger=False):
        nine('bar_track',x,y,w,h,256,48,12,3)
        fill=round((w-2)*p)
        if fill:nine('bar_danger' if danger else 'bar_spirit' if spirit else 'bar_gold',x+1,y+1,fill,h-2,256,48,12,2)
        nine('bar_border',x,y,w,h,256,48,12,3)
    def button(label,x,y,w,h,gold=False,chosen=False):
        nine('button_gold' if gold else 'button_selected' if chosen else 'button',x,y,w,h,256,96,16,4)
        text(label,x+w/2,y+(h-8)/2,'#302313' if gold else '#e8cb83',True)
    sprite('header_shadow',120,5,180,18)
    atlas=Image.open(ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/alchemy/calligraphy.png').convert('RGBA')
    characters=''.join(json.loads((ROOT/'src/main/resources/assets/wuxingxiantu/font/alchemy.json').read_text())['providers'][0]['chars'])
    glyphs=[]
    for c in '仙品炼丹炉':
        i=characters.index(c);glyph=atlas.crop((i%16*64,i//16*64,i%16*64+64,i//16*64+64))
        bbox=glyph.getchannel('A').getbbox();advance=int(bbox[2]*10/64+.5)+1
        glyphs.append((glyph,advance))
    half=round(sum(adv for _,adv in glyphs)*1.45/2);x=210-half
    for glyph,advance in glyphs:
        tint=Image.new('RGBA',glyph.size,'#eed08a');tint.putalpha(glyph.getchannel('A'))
        size=round(10*1.45*S)
        canvas.alpha_composite(tint.resize((size,size),Image.Resampling.BILINEAR),(round(x*S),round(6*S)))
        x+=advance*1.45
    sprite('divider',210-half-6,20,2*half+12,6,(32,0,480,24))
    sprite('header_flourish',210-half-26,17,22,7)
    sprite('header_flourish',210+half+4,17,22,7,mirror=True)
    if 'Component.literal("丹方选择")' in src:
        sprite('section_shadow',16,12,104,12);text('丹方选择',68,16,center=True)
    for x,y,w,h in panels:
        box(x+1,y+1,w-2,h-2,(8,24,32,235));nine('panel',x,y,w,h,128,128,32,8)
    nine('progress_backing',8,218,276,12,256,48,12,3)
    for x,y,w in [(144,40,128),(298,42,106),(298,103,106),(298,156,106)]:rule(x,y,w)
    sprite('formation',cx-64,cy-64,128,128)
    sprite('cloud_pair',140,174,136,20,(0,240,2172,560))
    for i,(x,y) in enumerate(slots):sprite('material_slot' if i<10 else 'inventory_slot',x-1,y-1,18,18)
    sprite('preview',cx-14,cy-14,28,28)
    text('预览',cx,137,'#8fd5d8',True);text('八卦炼丹',cx,29,center=True)
    text('已选：修为丹 · 0阶',cx,44,'#a5b1ae',True)
    for (x,y),label in zip(material,'乾兑坎艮坤震巽离'):
        text(label,x+8,y+3,'#9c8858',True)
    button('按丹方',12,31,54,14,gold=True);button('自由炼制',70,31,54,14)
    box(12,48,112,16,(7,21,30,255));text('搜索丹方…',16,51,'#a5b1ae')
    for i in range(6):
        button('',12,64+i*22,112,21,chosen=i==0)
        sprite('material_slot',15,66+i*22,16,16)
        text(f'修为丹 · {i}阶',35,66+i*22)
        text('材料不足',35,76+i*22,'#a5b1ae')
        duration=f'{[87,109,130,152,174,196][i]}秒'
        edge=120-ImageDraw.Draw(canvas).textlength(duration,font=FONT)/S
        text(duration,edge,76+i*22,'#a5b1ae')
    button('<',12,198,32,14);button('>',92,198,32,14);text('1 / 5',68,201,'#a5b1ae',True)
    button('一键放入',144,196,62,16);button('一键清空',212,196,62,16)
    text('炉核心',33,239,center=True);button('升阶',12,274,42,18);text('高阶核心',33,302,'#a5b1ae',True)
    for t,x,y in [('品阶概率',298,32),('当前异火',298,93),('异火吸收药力',298,146),('注灵',298,241)]:text(t,x,y)
    box(351,47,1,30,(100,85,55,255));box(351,171,1,41,(76,80,58,255))
    for i,(label,value) in enumerate(zip(['下品','中品','上品','极品'],['8%','22%','50%','20%'])):
        x=298+i%2*55;y=48+i//2*17
        text(label,x,y,'#e6e3d8');text(value,x+52-ImageDraw.Draw(canvas).textlength(value,font=FONT)/S,y,'#e8cb83')
    text('九幽冥火',363,114,'#e6e3d8',True)
    text('存量 / 本炉增量',298,160,'#a5b1ae')
    for i,t in enumerate(['金 0/—','木 252/—','水 152/—','火 0/—','土 0/—','阴 0/—','阳 0/—','魂 0/—']):text(t,298+i%2*55,172+i//2*11,'#e6e3d8')
    text('成功吸收 · 重复丹方衰减',298,217,'#a5b1ae')
    fuel=1 if state=='idle' else .05;progress=0 if state=='idle' else .65
    bar(56,219,220,9,progress)
    text('待炼制' if state=='idle' else '炼制',16,219)
    if progress:text('65%',166,219,'#e6e3d8',True)
    bar(298,256,62,12,fuel,True,state!='idle')
    text('100%' if state=='idle' else '5%',329,258,'#102632' if state=='idle' else '#e6e3d8',True)
    text('余200秒' if state=='idle' else '余10秒',334,241,'#a5b1ae')
    button('长按注灵',366,253,40,18)
    text('材料不足' if state=='idle' else '异火将熄，及时注灵',353,283,'#a5b1ae' if state=='idle' else '#f1aa81',True)
    button('开始炼丹' if state=='idle' else '炼制中…',298,296,110,16)
    frame=ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/outer_frame_v2'
    for name,x,y,w,h in [('top',13,0,394,3),('bottom',13,317,394,3),('left',0,13,3,294),('right',417,13,3,294)]:
        rail=Image.open(frame/f'{name}.png').convert('RGBA').resize((w*S,h*S),Image.Resampling.BILINEAR)
        canvas.alpha_composite(rail,(x*S,y*S))
    original=Image.open(frame/'tl.png').convert('RGBA');clean=Image.new('RGBA',(39,39))
    clean.alpha_composite(original.crop((0,0,39,15)),(0,0));clean.alpha_composite(original.crop((0,15,15,39)),(0,15))
    for x,y,fx,fy in [(0,0,False,False),(407,0,True,False),(0,307,False,True),(407,307,True,True)]:
        tile=clean
        if fx:tile=tile.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        if fy:tile=tile.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        canvas.alpha_composite(tile,(x*S,y*S))
    sprite('header_corner',3,2,48,23)
    sprite('header_corner',369,2,48,23,mirror=True)
    canvas.save(OUT/f'composition-{state}.png')
render('idle');render('low-fuel')
(OUT/'visual-audit.json').write_text(json.dumps({'slots':len(slots),'panels':len(panels),'containment':'pass','slot_overlaps':0,
    'fittings':21,'preview':'static composition using source assets; not game screenshot'},ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS: 46 slots contained, no overlaps, twenty-one fittings validated; two composition previews saved')
