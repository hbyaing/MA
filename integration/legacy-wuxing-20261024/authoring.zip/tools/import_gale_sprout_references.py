"""Import the supplied three-stage artwork at its original pixel resolution."""
from pathlib import Path
import json
import shutil
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
IMPORTS = [
    ('gale_grass', 'e7df8ee5-60f1-47df-bfff-fbfe790eaf87', [0, 580, 1320, 2172]),
    ('spirit_sprout_grass', '3e58d36a-c1a5-4631-845b-1acff15ce679', [0, 550, 1110, 1774]),
]

for plant, reference, boundaries in IMPORTS:
    source = Path('C:/Users/NOSTZE~1/AppData/Local/Temp') / f'codex-clipboard-{reference}.png'
    out = ROOT / 'source-assets' / f'{plant}-20261008'
    out.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, out / 'reference-original.png')
    sheet = Image.open(source).convert('RGBA')
    preview = Image.new('RGBA', (900, 320), (45, 49, 45, 255))
    manifest = {}
    for index, (stage, model_suffix, texture_suffix) in enumerate([
        ('young', '_low', '_young'), ('growing', '_mid', '_growing'), ('mature', '', '')
    ]):
        box = (boundaries[index], 0, boundaries[index + 1], sheet.height)
        crop = sheet.crop(box)
        # Ignore isolated near-transparent sheet noise when finding the artwork bounds.
        bounds = crop.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
        crop = crop.crop(bounds)
        crop.save(out / f'{stage}-crop.png')
        tile = Image.new('RGBA', (1024, 1024))
        x, y = (1024 - crop.width) // 2, 1024 - crop.height
        tile.alpha_composite(crop, (x, y))
        texture = plant + texture_suffix
        tile.save(ASSETS / 'textures/block' / f'{texture}.png')
        if stage == 'mature':
            tile.save(ASSETS / 'textures/block' / f'{plant}_mature.png')
            side = max(crop.size)
            icon = Image.new('RGBA', (side, side))
            icon.alpha_composite(crop, ((side - crop.width) // 2, (side - crop.height) // 2))
            icon.save(ASSETS / 'textures/item' / f'{plant}.png')
        path = ASSETS / 'models/block' / f'{plant}{model_suffix}.json'
        model = json.loads(path.read_text(encoding='utf-8'))
        model['textures']['cross'] = f'wuxingxiantu:block/{texture}'
        height = [8, 12, 16][index]
        width = height * crop.width / crop.height
        for element in model['elements']:
            element['from'] = [8 - width / 2, 0, 8]
            element['to'] = [8 + width / 2, height, 8]
            for face_name, face in element['faces'].items():
                face['uv'] = [x / 64, y / 64, (x + crop.width) / 64, 16] if face_name == 'north' else [(x + crop.width) / 64, y / 64, x / 64, 16]
        path.write_text(json.dumps(model, indent=2) + '\n', encoding='utf-8')
        art = crop.copy()
        art.thumbnail((280, 300), Image.Resampling.NEAREST)
        preview.alpha_composite(art, (index * 300 + (300 - art.width) // 2, 310 - art.height))
        manifest[stage] = {'source_box': box, 'crop_bounds': bounds, 'crop_size': crop.size, 'model_height': height, 'model_width': width}
    (ASSETS / 'models/item' / f'{plant}.json').write_text(json.dumps({'parent': 'minecraft:item/generated', 'textures': {'layer0': f'wuxingxiantu:item/{plant}'}}, indent=2) + '\n')
    preview.save(out / 'preview.png')
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(plant, manifest)
