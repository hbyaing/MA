"""Split the supplied seven empty-slot backgrounds; no game resources are changed."""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r"C:\Users\NOSTZE~1\AppData\Local\Temp\codex-clipboard-a33a903b-8284-468f-9053-c29134286956.png")
OUT = ROOT / "source-assets" / "equipment-slot-backgrounds-v1"
# Pixel bounds of the gold outer frame; right/bottom are exclusive.
SLOTS = [
    ("helmet", "头盔槽", "vanilla_armor_head", (447, 84, 661, 286)),
    ("chestplate", "胸甲槽", "vanilla_armor_chest", (447, 317, 661, 525)),
    ("leggings", "护腿槽", "vanilla_armor_legs", (447, 559, 661, 764)),
    ("boots", "靴子槽", "vanilla_armor_feet", (447, 800, 661, 1004)),
    ("dao_robe", "道袍槽", "custom_dao_robe", (791, 178, 1005, 389)),
    ("flying_sword", "御剑槽", "custom_flying_sword", (791, 433, 1005, 647)),
    ("vanilla_shield", "原版盾槽", "vanilla_offhand", (791, 691, 1005, 896)),
]
SIZES = (256, 128, 64, 32, 18)


def font(size: int):
    return ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", size)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, OUT / "reference-original.png")
    source = Image.open(SOURCE).convert("RGBA")
    manifest = {
        "version": 1,
        "source": "reference-original.png",
        "source_size": list(source.size),
        "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "bounds_format": "left,top,right,bottom; right/bottom exclusive",
        "normalized_sizes": list(SIZES),
        "normalization": "Expand frame bounds by 2px, then resize full crop to square with Lanczos. No redrawing.",
        "alpha": "Source is flattened. Slot backgrounds are opaque; atlas unused cell is transparent.",
        "runtime_changed": False,
        "slots": [],
    }
    preview = Image.new("RGB", (1120, 750), "#0d1b24")
    draw = ImageDraw.Draw(preview)
    draw.text((28, 18), "七个空槽背景 · 拆分预览", font=font(26), fill="#e5c58a")
    draw.text((28, 58), "保留原图图案；下方展示统一尺寸与 18px 缩小效果", font=font(17), fill="#bac3c6")
    atlas = Image.new("RGBA", (256, 128), (0, 0, 0, 0))
    for index, (name, label, role, frame_box) in enumerate(SLOTS):
        left, top, right, bottom = frame_box
        crop_box = (left - 2, top - 2, right + 2, bottom + 2)
        crop = source.crop(crop_box)
        raw_path = OUT / "raw" / f"slot_{name}.png"
        raw_path.parent.mkdir(parents=True, exist_ok=True)
        crop.save(raw_path)
        outputs = {}
        for size in SIZES:
            path = OUT / "textures" / str(size) / f"slot_{name}.png"
            path.parent.mkdir(parents=True, exist_ok=True)
            resized = crop.resize((size, size), Image.Resampling.LANCZOS)
            resized.save(path)
            outputs[str(size)] = path.relative_to(OUT).as_posix()
        tile_x, tile_y = (index % 4) * 64, (index // 4) * 64
        atlas.paste(Image.open(OUT / outputs["64"]), (tile_x, tile_y))
        manifest["slots"].append({
            "name": name, "label": label, "role": role,
            "frame_bounds": list(frame_box), "crop_bounds": list(crop_box),
            "raw_size": list(crop.size), "raw": raw_path.relative_to(OUT).as_posix(),
            "textures": outputs, "atlas_bounds": [tile_x, tile_y, tile_x + 64, tile_y + 64],
        })
        x, y = 28 + (index % 4) * 276, 104 + (index // 4) * 310
        preview.paste(crop.resize((218, 218), Image.Resampling.LANCZOS).convert("RGB"), (x, y))
        draw.text((x, y + 224), label, font=font(20), fill="#e5c58a")
        draw.text((x, y + 255), "32px", font=font(14), fill="#bac3c6")
        preview.paste(Image.open(OUT / outputs["32"]).convert("RGB"), (x + 48, y + 253))
        draw.text((x + 105, y + 255), "18px", font=font(14), fill="#bac3c6")
        preview.paste(Image.open(OUT / outputs["18"]).convert("RGB"), (x + 153, y + 260))
    (OUT / "atlas").mkdir(exist_ok=True)
    atlas.save(OUT / "atlas" / "equipment_slots_64.png")
    manifest["atlas"] = {"path": "atlas/equipment_slots_64.png", "size": [256, 128], "tile_size": 64, "columns": 4}
    (OUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    preview.save(OUT / "contact-sheet.png")
    (OUT / "README.md").write_text("""# 装备空槽背景素材

按用户提供的原图直接裁切，未使用生图重绘，未改动 Java 或运行时资源。

左列从上到下：头盔 helmet、胸甲 chestplate、护腿 leggings、靴子 boots。
右列从上到下：道袍 dao_robe、御剑 flying_sword、原版盾 vanilla_shield。
盾槽对应原版副手槽位语义，实装时仍保留副手原有物品行为。

## 文件

- raw/：原尺寸裁片，完整保留原图形状与背景。
- textures/256、128、64、32、18：每套七张正方形 PNG；将含 2px 安全边距的整张裁片缩放，不重新绘制。
- atlas/equipment_slots_64.png：256×128 图集，64px 单格，顺序与 manifest 一致，第八格透明。
- manifest.json：名称、用途、原图坐标、输出路径、图集坐标。
- contact-sheet.png：七个槽位及实际 32px/18px 缩小效果。

图片包含深色底、金色边框和空槽图案，保持不透明。原图没有真实透明通道。
后续实装时建议仅在空槽显示中央装备图案，物品与数量交由 Minecraft 渲染。
18px 下复杂线条会因缩小变弱；正式接入时应结合实际槽位显示尺寸调整，尚未游戏内验证。
""", encoding="utf-8")
    checks = []
    for slot in manifest["slots"]:
        frame = slot["frame_bounds"]
        raw = Image.open(OUT / slot["raw"])
        assert raw.tobytes() == source.crop(slot["crop_bounds"]).tobytes()
        for size, path in slot["textures"].items():
            im = Image.open(OUT / path)
            assert im.size == (int(size), int(size)) and im.mode == "RGBA"
            assert im.getextrema()[3] == (255, 255)
        checks.append({"name": slot["name"], "raw_exact_crop": True, "normalized_sizes_valid": True})
    assert len(manifest["slots"]) == 7
    assert atlas.crop((192, 64, 256, 128)).getbbox() is None
    validation = {"asset_count": 7, "texture_count": 35, "raw_exact_crops": True, "atlas_unused_cell_transparent": True, "minecraft_runtime_verified": False, "checks": checks}
    (OUT / "validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8")
    archive = OUT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(OUT.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(OUT.parent))
    print(json.dumps({"output": str(OUT), "zip": str(archive), "seven_slots": True, "normalized_textures": 35}, ensure_ascii=False))


if __name__ == "__main__":
    main()
