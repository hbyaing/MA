"""Import the supplied transparent Yang spirit purity icon without recoloring."""
from pathlib import Path
from PIL import Image
import shutil
root=Path(__file__).resolve().parents[1]
source=Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-c269b4fe-a627-4790-9505-fc51f099ac0b.png')
archive=root/'source-assets/purity-icon-20261011'
archive.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,archive/'reference-original.png')
im=Image.open(source).convert('RGBA')
im=im.crop(im.getchannel('A').getbbox())
im.thumbnail((60,60),Image.Resampling.LANCZOS)
out=Image.new('RGBA',(64,64))
out.alpha_composite(im,((64-im.width)//2,(64-im.height)//2))
folder=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision/components'
shutil.copy2(folder/'purity.png',archive/'purity-before.png')
out.save(folder/'purity.png')
(folder/'purity.png.mcmeta').write_text('{"texture":{"blur":false,"clamp":true}}')
preview=Image.new('RGBA',(192,192),'#e5dbc5')
preview.alpha_composite(out.resize((192,192),Image.Resampling.NEAREST))
preview.save(archive/'preview.png')
print('Imported 64x64 transparent purity icon')
