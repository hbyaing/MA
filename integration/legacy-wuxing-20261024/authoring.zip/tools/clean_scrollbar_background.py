"""Extract the gold rail and thumb, discarding screenshot background pixels."""
from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parents[1]
path=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/scrollbar_reference.png'
archive=root/'source-assets/scrollbar-transparent-20261011'
archive.mkdir(parents=True,exist_ok=True)
before=archive/'before.png'
if not before.exists():before.write_bytes(path.read_bytes())
im=Image.open(before).convert('RGBA')
for y in range(im.height):
    for x in range(im.width):
        r,g,b,a=im.getpixel((x,y))
        alpha=max(0,min(a,round(min(r-45,(r-b)*3)*2))) if r>=g and g>b else 0
        im.putpixel((x,y),(r,g,b,alpha))
im.save(path)
path.with_suffix('.png.mcmeta').write_text('{"texture":{"blur":false,"clamp":true}}')
print('Extracted transparent gold rail and thumb')
