"""Validate all 13 real-client guard-tier captures and publish honest previews.

PNG panels contain 1:1 RGB crops of the captured frames: no scaling, recoloring,
retouching, frame synthesis, or effect compositing. GIF is only a convenience
preview; its unavoidable 256-color quantization error is measured and reported.
The raw captures and lossless PNG panels remain the color acceptance evidence.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
CROP = (470, 330, 810, 900)
SLOTS = ("head", "chest", "legs", "feet")
ROMAN = ("I", "II", "III", "IV")
TIER_NAMES = ("初护", "成纹", "云篆", "护篆")
STROKES = (16, 21, 25, 33)
# These regions stay within the armor rather than counting animated arms,
# moving shadows, sky pixels, or the red vanilla damage flash as glyph motion.
MOTION_BOXES = ((574, 536, 710, 675), (580, 722, 700, 820), (574, 377, 707, 420))
SLOT_BOXES = {
    "head": (553, 356, 728, 444),
    "chest": (573, 536, 709, 632),
    "legs": (573, 714, 708, 817),
    "feet": (563, 820, 718, 900),
}
STABLE_CHEST_BOX = (580, 536, 690, 632)
BG = "#101927"
FG = "#d2ebff"
MUTED = "#a6bfd2"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def rgb_array(image: Image.Image) -> np.ndarray:
    return np.asarray(image, dtype=np.int16)


def cyan(image: np.ndarray) -> np.ndarray:
    # Detect the whole lake-blue/teal/azure/silver-blue family in daylight or
    # shadow; the previous bright-cyan-only threshold rejected genuine dark blue.
    return ((image[..., 2] - image[..., 0] > 20)
            & (image[..., 1] - image[..., 0] > 8)
            & (np.maximum(image[..., 1], image[..., 2]) > 35))


def crop_array(image: np.ndarray, box: tuple[int, int, int, int]) -> np.ndarray:
    x0, y0, x1, y1 = box
    return image[y0:y1, x0:x1]


def image_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fonts() -> tuple[ImageFont.FreeTypeFont, ImageFont.FreeTypeFont]:
    font_path = Path("C:/Windows/Fonts/msyh.ttc")
    return ImageFont.truetype(str(font_path), 23), ImageFont.truetype(str(font_path), 17)


def save_panels(output: Path, filename: str, title: str, subtitle: str,
                panels: list[tuple[Image.Image, str, str]],
                font: ImageFont.FreeTypeFont, small: ImageFont.FreeTypeFont) -> dict:
    width, height = CROP[2] - CROP[0], CROP[3] - CROP[1]
    gutter, margin, top = 18, 24, 106
    canvas = Image.new("RGB", (margin * 2 + len(panels) * width
                               + (len(panels) - 1) * gutter, top + height + 66), BG)
    draw = ImageDraw.Draw(canvas)
    draw.text((margin, 12), title, font=font, fill=FG)
    draw.text((margin, 48), subtitle, font=small, fill=MUTED)
    positions = []
    for i, (source, label, footer) in enumerate(panels):
        x = margin + i * (width + gutter)
        original = source.crop(CROP)
        draw.text((x, 78), label, font=small, fill=FG)
        canvas.paste(original, (x, top))
        draw.text((x, top + height + 10), footer, font=small, fill=MUTED)
        positions.append({"paste_xy": [x, top], "crop_xyxy": list(CROP)})
        # A real equality check guards against accidentally introducing resizing
        # or decorative overlays within the original captured pixels.
        require(np.array_equal(np.asarray(canvas.crop((x, top, x + width, top + height))),
                               np.asarray(original)), f"Changed pixels in {filename}")
    canvas.save(output / filename)
    return {"file": filename, "source_pixel_scale": 1, "rgb_crop_exact": True,
            "panels": positions}


def save_gif(output: Path, filename: str, title: str,
             sources: list[Image.Image], labels: list[str],
             font: ImageFont.FreeTypeFont, small: ImageFont.FreeTypeFont) -> dict:
    frames = []
    error = []
    for source, label in zip(sources, labels):
        frame = Image.new("RGB", (388, 716), BG)
        draw = ImageDraw.Draw(frame)
        draw.text((24, 12), title, font=font, fill=FG)
        draw.text((24, 48), label, font=small, fill=MUTED)
        frame.paste(source.crop(CROP), (24, 92))
        draw.text((24, 674), "实机采样 · GIF 256 色预览", font=small, fill=MUTED)
        # No dithering: no false animated noise or fabricated intermediate frame.
        paletted = frame.quantize(colors=256, method=Image.Quantize.MEDIANCUT,
                                 dither=Image.Dither.NONE)
        source_rgb = rgb_array(frame)[92:662, 24:364]
        gif_rgb = rgb_array(paletted.convert("RGB"))[92:662, 24:364]
        difference = np.abs(source_rgb - gif_rgb)
        error.append({"mean_rgb_absolute_error": float(difference.mean()),
                      "max_rgb_absolute_error": int(difference.max()),
                      "unchanged_pixel_fraction": float(np.all(difference == 0, axis=2).mean())})
        frames.append(paletted)
    frames[0].save(output / filename, save_all=True, append_images=frames[1:],
                   duration=400, loop=0, optimize=False, disposal=2)
    return {"file": filename, "sampled_frames": len(frames), "duration_ms_per_frame": 400,
            "interpolated_frames": 0, "dithering": False, "palette_quantization": error}


def diagnostic_crops(output: Path, images: dict[str, Image.Image],
                     font: ImageFont.FreeTypeFont, small: ImageFont.FreeTypeFont) -> dict:
    """Separate labeled debug crops and masks; never part of beauty previews."""
    names = [f"tier-{tier}-dynamic-a.png" for tier in range(1, 5)]
    names.append("mixed-slots-1-2-3-4.png")
    labels = [f"全套 {roman}" for roman in ROMAN] + ["混装 I/II/III/IV"]
    canvas = Image.new("RGB", (1040, 604), BG)
    draw = ImageDraw.Draw(canvas)
    draw.text((24, 12), "诊断 · 各 slot 原始裁剪 · 相同 shader clock 6020", font=font, fill=FG)
    for column, label in enumerate(labels):
        draw.text((114 + column * 184, 65), label, font=small, fill=FG)
    for row, slot in enumerate(SLOTS):
        box = SLOT_BOXES[slot]
        y = 102 + row * 119
        draw.text((24, y + 12), slot, font=small, fill=FG)
        for column, name in enumerate(names):
            original = images[name].crop(box)
            canvas.paste(original, (114 + column * 184, y))
    draw.text((24, 574), "原始像素1:1；诊断范围不代替整件装备。胸甲范围避开动画手臂。", font=small, fill=MUTED)
    canvas.save(output / "diagnostic-slot-crops.png")

    box = (480, 484, 795, 714)
    chest_names = ("tier-2-dynamic-a.png", "mixed-slots-1-2-3-4.png", "tier-3-dynamic-a.png")
    panel = Image.new("RGB", (1029, 358), BG)
    draw = ImageDraw.Draw(panel)
    draw.text((24, 12), "诊断 · 胸甲全套 II / 混装 / 全套 III · shader clock 6020", font=font, fill=FG)
    for index, (name, label) in enumerate(zip(chest_names, ("全套 II", "混装：胸 II / 腿 III", "全套 III"))):
        x = 24 + index * 333
        draw.text((x, 61), label, font=small, fill=FG)
        panel.paste(images[name].crop(box), (x, 91))
    draw.text((24, 330), "仅原帧裁剪。手臂姿态不同；稳定胸中心与边缘纹路分别核对。", font=small, fill=MUTED)
    panel.save(output / "diagnostic-chest-II-mixed-III.png")

    mixed_array = rgb_array(images["mixed-slots-1-2-3-4.png"])
    center_box = SLOT_BOXES["chest"]
    x0, y0, x1, y1 = center_box
    masks = []
    diagnostic = {"shader_clock_wrapped": 6020, "chest_region_xyxy": list(center_box),
                  "stable_chest_core_region_xyxy": list(STABLE_CHEST_BOX),
                  "rule": "cyan in either frame and max absolute RGB delta > 12; cyan=B-R>25,B-G>5,G>130",
                  "files": ["diagnostic-slot-crops.png", "diagnostic-chest-II-mixed-III.png", "diagnostic-chest-blue-diff.png"]}
    for tier in (2, 3):
        reference = rgb_array(images[f"tier-{tier}-dynamic-a.png"])
        a, b = crop_array(reference, center_box), crop_array(mixed_array, center_box)
        changed = (np.abs(a - b).max(axis=2) > 12) & (cyan(a) | cyan(b))
        ys, xs = np.nonzero(changed)
        bbox = ([int(xs.min() + x0), int(ys.min() + y0), int(xs.max() + x0 + 1), int(ys.max() + y0 + 1)]
                if len(xs) else None)
        entry = {"changed_cyan_pixels": int(changed.sum()), "changed_cyan_bbox_xyxy": bbox,
                 "mixed_only_cyan_pixels": int((changed & cyan(b) & ~cyan(a)).sum()),
                 "reference_only_cyan_pixels": int((changed & cyan(a) & ~cyan(b)).sum()),
                 "both_cyan_changed_pixels": int((changed & cyan(a) & cyan(b)).sum())}
        stable_reference, stable_mixed = (crop_array(im, STABLE_CHEST_BOX) for im in (reference, mixed_array))
        stable_changed = ((np.abs(stable_reference - stable_mixed).max(axis=2) > 12)
                          & (cyan(stable_reference) | cyan(stable_mixed)))
        entry["stable_chest_core_changed_cyan_pixels"] = int(stable_changed.sum())
        diagnostic[f"mixed_vs_tier_{tier}"] = entry
        # Synthetic mask uses diagnostic colors only and is explicitly labeled.
        heat = np.zeros((*changed.shape, 3), dtype=np.uint8)
        heat[changed & cyan(b) & ~cyan(a)] = (255, 94, 72)
        heat[changed & cyan(a) & ~cyan(b)] = (76, 204, 255)
        heat[changed & cyan(a) & cyan(b)] = (240, 108, 255)
        masks.append(Image.fromarray(heat))
    heat_canvas = Image.new("RGB", (764, 286), BG)
    draw = ImageDraw.Draw(heat_canvas)
    draw.text((24, 12), "诊断差异掩码 · 仅胸甲蓝纹 · 非游戏效果图", font=font, fill=FG)
    for index, (mask, tier) in enumerate(zip(masks, (2, 3))):
        x = 24 + index * 374
        draw.text((x, 61), f"混装 / 单档 {ROMAN[tier - 1]} 的蓝纹差", font=small, fill=FG)
        heat_canvas.paste(mask, (x, 93))
    draw.text((24, 213), "红：混装新增蓝纹；蓝：单档独有；紫：两图均为蓝纹且变化", font=small, fill=MUTED)
    draw.text((24, 246), "掩码仅用于定位差异；实际观感和颜色以原始截图为准。", font=small, fill=MUTED)
    heat_canvas.save(output / "diagnostic-chest-blue-diff.png")
    (output / "diagnostic-slot-analysis.json").write_text(json.dumps(diagnostic, ensure_ascii=False, indent=2), encoding="utf-8")
    return diagnostic


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--captures", type=Path, default=ROOT / "reports/guard-tier-client")
    parser.add_argument("--output", type=Path, default=ROOT / "reports/guard-tier-20261013")
    args = parser.parse_args()
    captures, output = args.captures.resolve(), args.output.resolve()
    require(captures != output, "Preview output must not replace raw capture evidence")
    require((captures / "complete.txt").exists(), "Capture fixture has not completed")
    metadata = json.loads((captures / "captures.json").read_text(encoding="utf-8"))
    require(metadata.get("test") == "guard-tier-real-client", "Wrong fixture data")
    require(metadata.get("isolated") and metadata.get("tierCapture"), "Not isolated tier captures")
    require(not metadata.get("failures"), f"Client fixture failures: {metadata.get('failures')}")
    require(metadata.get("initialShaderIdentity", 0) != 0, "Guard shader was not loaded")
    expected_names = [f"tier-{tier}-{phase}.png" for tier in range(1, 5)
                      for phase in ("dynamic-a", "dynamic-b", "hit-peak")]
    expected_names.append("mixed-slots-1-2-3-4.png")
    rows = metadata["captures"]
    require(metadata["captureCount"] == len(rows) == 13, "Expected all 13 GPU captures")
    require(len({row["name"] for row in rows}) == 13, "Duplicate capture name")
    require({row["name"] for row in rows} == set(expected_names), "Incomplete expected capture set")
    by_name = {row["name"]: row for row in rows}
    images = {}
    for name in expected_names:
        require((captures / name).is_file(), f"Missing raw PNG: {name}")
        images[name] = Image.open(captures / name).convert("RGB")
        require(images[name].size == (1280, 900), f"Unexpected image dimensions: {name}")
        row = by_name[name]
        require(row["glError"] == 0, f"GPU error in {name}")
        require(row["shaderIdentity"] != 0, f"Guard shader absent in {name}")
        require(row["selfF5View"] and not row["inventoryPreview"], f"Not world third person: {name}")
        require(row["worldDraws"] >= 1 and row["guiDraws"] == 0, f"Missing world armor draw: {name}")
        require(row["canRender"] and row["visualEnabled"], f"Guard rendering disabled: {name}")
        require(row["capturedVertices"] > 0, f"No armor surface was recorded: {name}")
        require("FullyBufferedMultiBufferSource" in row["bufferClass"], f"Not Oculus buffered world: {name}")
        require(all(row["foilSlots"].get(slot) for slot in SLOTS), f"Missing enchanted slot: {name}")
        if name.startswith("tier-"):
            tier = int(name.split("-")[1])
            require(row["guardLevels"] == dict.fromkeys(SLOTS, tier), f"Wrong actual equipment levels: {name}")
    mixed = by_name["mixed-slots-1-2-3-4.png"]
    require(mixed["guardLevels"] == dict(zip(SLOTS, range(1, 5))), "Wrong mixed equipment slot levels")

    contacts = (captures / "contacts.txt").read_text(encoding="utf-8").splitlines()
    require(len(contacts) == 4, "Expected four genuine production hit packets")
    parsed_contacts = []
    for line in contacts:
        match = re.fullmatch(r"tier=(\d+) tick=(\d+) hit=([\d.]+)", line)
        require(match is not None, f"Unexpected contact record: {line}")
        parsed_contacts.append({"tier": int(match[1]), "tick": int(match[2]), "hit_world_time": float(match[3])})
    require([contact["tier"] for contact in parsed_contacts] == list(range(1, 5)), "Missing per-tier hit")

    first_array = rgb_array(images[expected_names[0]])
    roi = np.zeros(first_array.shape[:2], dtype=bool)
    for x0, y0, x1, y1 in MOTION_BOXES:
        roi[y0:y1, x0:x1] = True
    tier_metrics = []
    for tier, contact in zip(range(1, 5), parsed_contacts):
        a_name, b_name, hit_name = (f"tier-{tier}-{phase}.png"
                                    for phase in ("dynamic-a", "dynamic-b", "hit-peak"))
        a, b = rgb_array(images[a_name]), rgb_array(images[b_name])
        changed = np.abs(a - b).max(axis=2) > 12
        cyan_roi = roi & (cyan(a) | cyan(b))
        moving = int(np.count_nonzero(changed & cyan_roi))
        require(moving > 100, f"No meaningful armor glyph motion at tier {tier}: {moving}")
        a_row, b_row, hit_row = (by_name[name] for name in (a_name, b_name, hit_name))
        require(b_row["tick"] - a_row["tick"] == 8, f"Wrong dynamic sample spacing: {tier}")
        require(a_row["shaderClockWrapped"] == 6020 and b_row["shaderClockWrapped"] == 6028,
                f"Different comparison shader phases: {tier}")
        require(a_row["hitAgeTicks"] > 1000 and b_row["hitAgeTicks"] > 1000,
                f"Idle motion contaminated by a hit: {tier}")
        require(hit_row["hitAgeTicks"] == hit_row["worldTime"] - contact["hit_world_time"] == 6,
                f"Hit screenshot does not match observed production packet: {tier}")
        require(contact["tick"] < hit_row["tick"], f"Hit frame precedes packet: {tier}")
        require(hit_row["health"] < b_row["health"], f"No actual damage at tier {tier}")
        tier_metrics.append({"tier": tier, "name": TIER_NAMES[tier - 1], "mask_strokes": STROKES[tier - 1],
                             "motion_cyan_pixels_rgb_delta_over_12": moving,
                             "cyan_pixels_a_in_armor_regions": int(np.count_nonzero(roi & cyan(a))),
                             "cyan_pixels_b_in_armor_regions": int(np.count_nonzero(roi & cyan(b))),
                             "sample_tick_delta": 8, "hit_age_ticks": hit_row["hitAgeTicks"],
                             "health_before_hit": b_row["health"], "health_at_hit_frame": hit_row["health"]})

    # This image comparison is recorded independently of the equipment metadata.
    # If an overlapping armor model adds another slot's glyph, a reviewer must
    # see that discrepancy rather than having it hidden by successful level data.
    mixed_array = rgb_array(images[mixed["name"]])
    slot_comparisons = {}
    for tier, slot in enumerate(SLOTS, 1):
        reference = crop_array(rgb_array(images[f"tier-{tier}-dynamic-a.png"]), SLOT_BOXES[slot])
        actual = crop_array(mixed_array, SLOT_BOXES[slot])
        delta = np.abs(reference - actual)
        changed_cyan = (delta.max(axis=2) > 12) & (cyan(reference) | cyan(actual))
        slot_comparisons[slot] = {"expected_level": tier, "actual_equipment_level": mixed["guardLevels"][slot],
                                  "region_xyxy": list(SLOT_BOXES[slot]),
                                  "same_rgb_pixel_fraction": float(np.all(delta == 0, axis=2).mean()),
                                  "max_rgb_delta": int(delta.max()),
                                  "pixels_rgb_delta_over_12": int(np.count_nonzero(delta.max(axis=2) > 12)),
                                  "cyan_pixels_rgb_delta_over_12": int(changed_cyan.sum())}
    chest_reference = crop_array(rgb_array(images["tier-2-dynamic-a.png"]), STABLE_CHEST_BOX)
    chest_mixed = crop_array(mixed_array, STABLE_CHEST_BOX)
    chest_cyan_changed = ((np.abs(chest_reference - chest_mixed).max(axis=2) > 12)
                          & (cyan(chest_reference) | cyan(chest_mixed)))
    slot_comparisons["chest"]["stable_core_region_xyxy"] = list(STABLE_CHEST_BOX)
    slot_comparisons["chest"]["stable_core_cyan_pixels_rgb_delta_over_12"] = int(chest_cyan_changed.sum())
    visual_review = []
    if int(chest_cyan_changed.sum()) > 100:
        visual_review.append("Mixed stable chest core glyph differs from tier-II reference; review overlapping armor body geometry. Actual equipment levels are I/II/III/IV.")

    output.mkdir(parents=True, exist_ok=True)
    font, small = fonts()
    png_previews, gif_previews = [], []
    for tier in range(1, 5):
        names = [f"tier-{tier}-{phase}.png" for phase in ("dynamic-a", "dynamic-b", "hit-peak")]
        title = f"灵力御体 {ROMAN[tier - 1]} · {TIER_NAMES[tier - 1]} · 真实游戏截图"
        subtitle = f"全套装备实测等级 {ROMAN[tier - 1]} · {STROKES[tier - 1]} 笔资产 · 原帧 1:1 裁剪"
        labels = ["常态 A", "常态 B · 相隔 8 tick", "真实受击 · 包后 6 tick"]
        footers = [f"tick {by_name[name]['tick']} · worldDraws {by_name[name]['worldDraws']}" for name in names]
        png_previews.append(save_panels(output, f"tier-{tier}-preview.png", title, subtitle,
                                        [(images[name], label, footer) for name, label, footer
                                         in zip(names, labels, footers)], font, small))
        gif_previews.append(save_gif(output, f"tier-{tier}-motion.gif",
                                     f"灵力御体 {ROMAN[tier - 1]} · 实机采样",
                                     [images[name] for name in names], labels, font, small))
    png_previews.append(save_panels(output, "guard-tier-game-comparison.png",
                                    "灵力御体 · 四级云篆护纹",
                                    "同一套铁甲的游戏实拍 · 保留装备原有材质",
                                    [(images[f"tier-{tier}-dynamic-a.png"],
                                      f"{ROMAN[tier - 1]} {TIER_NAMES[tier - 1]} · {STROKES[tier - 1]} 笔",
                                      f"等级 {tier} · 常态 A") for tier in range(1, 5)], font, small))
    png_previews.append(save_panels(output, "guard-tier-real-hits.png",
                                    "灵力御体 I / II / III / IV · 四次真实受击",
                                    "四次生产受击包 · 均为包后 6 tick · 红色为原版受伤反馈 · 原帧 1:1 裁剪",
                                    [(images[f"tier-{tier}-hit-peak.png"],
                                      f"{ROMAN[tier - 1]} · 真实受击",
                                      f"tier {tier} · GL error 0") for tier in range(1, 5)], font, small))
    mixed_canvas = Image.new("RGB", (870, 750), BG)
    draw = ImageDraw.Draw(mixed_canvas)
    draw.text((24, 12), "灵力御体 · 每件装备独立等级 · 实机混装", font=font, fill=FG)
    draw.text((24, 49), "头盔 I / 胸甲 II / 护腿 III / 靴子 IV · 读取真实装备附魔", font=small, fill=MUTED)
    original = images[mixed["name"]].crop(CROP)
    mixed_canvas.paste(original, (24, 94))
    require(np.array_equal(np.asarray(mixed_canvas.crop((24, 94, 364, 664))), np.asarray(original)),
            "Mixed preview changed source pixels")
    draw.text((394, 106), "同一角色的装备等级读回", font=font, fill=FG)
    for index, slot in enumerate(SLOTS):
        label = ("头盔", "胸甲", "护腿", "靴子")[index]
        draw.text((394, 158 + index * 38), f"{label}  {ROMAN[index]}  · 实际附魔等级 {mixed['guardLevels'][slot]}", font=small, fill=FG)
    draw.text((394, 346), "Oculus 世界缓冲：已绘制", font=small, fill=MUTED)
    draw.text((394, 379), "worldDraws = 1 / guiDraws = 0", font=small, fill=MUTED)
    draw.text((394, 412), "OpenGL error = 0", font=small, fill=MUTED)
    draw.text((394, 479), "原始 RGB 裁剪；无缩放、调色或补帧", font=small, fill=MUTED)
    if visual_review:
        draw.text((394, 538), "目视复核项：稳定胸中心纹路有差异", font=small, fill="#ffd59d")
        draw.text((394, 568), "请对照单档 II 与护腿 body 遮挡。", font=small, fill="#ffd59d")
    draw.text((24, 694), "原帧保留至屏幕底边；未补画屏幕外部位。", font=small, fill=MUTED)
    mixed_canvas.save(output / "guard-tier-mixed-slots.png")
    png_previews.append({"file": "guard-tier-mixed-slots.png", "rgb_crop_exact": True,
                          "source_pixel_scale": 1, "crop_xyxy": list(CROP), "paste_xy": [24, 94]})
    diagnostics = diagnostic_crops(output, images, font, small)

    report = {"scope": "Forge 1.20.1 / Oculus buffered world / worn iron armor / isolated real client",
              "all_required_capture_checks_passed": True,
              "visual_review_items": visual_review,
              "captured_frames": 13, "gl_errors": 0, "world_draw_frames": 13, "gui_draw_frames": 0,
              "genuine_production_hit_packets": parsed_contacts,
              "actual_equipment_levels_field": "guardLevels",
              "mixed_slot_guard_levels": mixed["guardLevels"],
              "mixed_slot_image_comparisons": slot_comparisons,
              "mixed_slot_visual_diagnostics": diagnostics,
              "tier_metrics": tier_metrics,
              "motion_regions_xyxy": [list(box) for box in MOTION_BOXES],
              "mask_texture_size": [1024, 512], "mask_strokes_per_tier": list(STROKES),
              "png_crop_xyxy": list(CROP), "png_preview_source_pixel_scale": 1,
              "png_preview_rgb_crops_exact": True, "png_previews": png_previews,
              "gif_previews": gif_previews,
              "raw_capture_sha256": {name: image_sha(captures / name) for name in expected_names},
              "limitations": ["GIF palette quantization changes some RGB values; raw captures and PNG previews are the color evidence.",
                              "Two idle frames and one real hit frame per tier are sampled; no continuous-motion recording or synthesized interpolation.",
                              "Captures use Oculus without an external shader pack; external shader pack compatibility is not accepted here.",
                              "This 13-frame fixture does not test shader resource reload, inventory rendering, occlusion, custom armor UVs, or rear/side views.",
                              "The original camera clips the lower boots at the screen bottom; previews retain the existing view."]}
    (output / "runtime-validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    readme = """# 灵力御体 I–IV 实机分级验收

所有图像源于 `reports/guard-tier-client` 的13张真实GPU截图。`tools/analyze_guard_tier_capture.py` 验证全部帧、四次真实生产受击包、全部GL错误为0、世界绘制、四档逐件装备附魔读回，以及每档两个常态帧间可见云纹变化。

- `tier-N-preview.png`：该档常态A、常态B、真实受击三帧。
- `tier-N-motion.gif`：三张真实采样帧，间隔400ms；只循环真实帧，无插值或新增动作。
- `guard-tier-game-comparison.png`：四档相同shader clock的常态A。
- `guard-tier-real-hits.png`：四档真实受击包后6 tick画面。
- `guard-tier-mixed-slots.png`：头盔I、胸甲II、护腿III、靴子IV同一角色混装。
- `runtime-validation.json`：逐档像素变化、四次生产包、等级读回、原图SHA256、PNG原像素相等检查和GIF量化误差。
- `diagnostic-slot-crops.png` 与 `diagnostic-chest-II-mixed-III.png`：各slot及胸甲的原像素诊断对照。
- `diagnostic-chest-blue-diff.png` 与 `diagnostic-slot-analysis.json`：仅蓝纹RGB差>12的定位掩码与原图bbox，属于诊断可视化，不是游戏效果预览。

PNG游戏区域使用原帧1:1 RGB裁剪粘贴，不重采样、不调色、不美化、不绘制特效。标题仅位于截图之外。GIF最多256色，必然存在量化；RGB颜色验收以原始PNG与无损排版PNG为准。两帧常态加一帧受击为抽样展示，不代表完整连续录像。原镜头底边裁掉部分靴子，预览未补画。

本次仅验收Oculus缓冲世界中的铁甲正面；不借用此前guard-cloud测试的重载、遮挡、背面、背包或其他材质证据。外部光影包、任意第三方装备UV不在本次验收范围。
"""
    if visual_review:
        readme += "\n混装目视复核项：稳定胸中心相对单档II出现蓝纹差异，可能涉及护腿body模型的覆盖；装备附魔读回正确不能替代这项像素复核。详见JSON的mixed_slot_image_comparisons。\n"
    (output / "README.md").write_text(readme, encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("captured_frames", "gl_errors", "world_draw_frames",
                      "genuine_production_hit_packets", "mixed_slot_guard_levels", "tier_metrics", "visual_review_items")},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
