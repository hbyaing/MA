"""Archive superseded documentation, retaining recoverable originals and fixing links."""
from pathlib import Path
import shutil,json
root=Path(__file__).resolve().parents[1]
archive=root/'docs/archive/20261008-document-cleanup';archive.mkdir(parents=True,exist_ok=True)
for name in ['README.md','CURRENT_STATUS.md']:
    target=archive/(name+'.before-cleanup')
    if not target.exists():shutil.copy2(root/name,target)
names=['20261007_UI_JEI_SPACING.md','20261007_UI_COMPACT_PASSIVE_THUNDER.md','20261007_REFERENCE_BORDERS_UI.md']
moves=[]
for name in names:
    source=root/'docs/audits/current'/name;target=archive/name
    if source.exists():
        assert source.resolve().is_relative_to(root.resolve()) and target.resolve().is_relative_to(root.resolve())
        shutil.move(str(source),str(target));moves.append(name)
    for base in [root/'docs',root]:
        candidates=base.rglob('*.md') if base==root/'docs' else base.glob('*.md')
        for p in candidates:
            content=p.read_text(encoding='utf-8-sig')
            old='docs/audits/current/'+name;new='docs/archive/20261008-document-cleanup/'+name
            updated=content.replace(old,new).replace('audits/current/'+name,'archive/20261008-document-cleanup/'+name)
            if updated!=content:p.write_text(updated,encoding='utf-8')
readme=root/'README.md';text=readme.read_text(encoding='utf-8-sig')
start=text.index('Java 17、Forge')
tail=text[start:]
# Remove stale release narrative while keeping build and operational instructions.
lines=tail.splitlines();lines=[line for line in lines if not line.startswith(('0.2 封面与异火交接','上一轮已交付：','项目清理记录与恢复方法：'))]
header='''# 五行仙途 0.2 — Forge 1.20.1

当前测试安装成品：`wuxingxiantu-0.2-20261008-blue-mushroom.jar`。包含 UI 与 JEI 调整及近期灵植素材；发光蓝蘑菇采用单一外观和小蘑菇式扩散。客户端实机仍由用户验收。

源码当前说明见 [CURRENT_STATUS.md](CURRENT_STATUS.md)，实现入口见 [AI_SOURCE_MAP.md](AI_SOURCE_MAP.md)。历史构建测试结果仅代表对应版本，不能作为当前版本的全量验证结论。

默认安装目录为 `D:\\MC\\库\\red.ghs.axolotl\\profiles\\测试 (1)\\mods`；使用 `tools/install_test_mod.ps1`，只替换本 mod，并保留备份。

旧版发布叙述与本次清理前完整说明保存在 `docs/archive/20261008-document-cleanup/`。

'''
readme.write_text(header+'\n'.join(lines)+'\n',encoding='utf-8')
(archive/'manifest.json').write_text(json.dumps({'archived_audits':moves,'entry_backups':['README.md.before-cleanup','CURRENT_STATUS.md.before-cleanup'],'code_or_assets_deleted':False},ensure_ascii=False,indent=2),encoding='utf-8')
print('Archived',len(moves),'superseded audit documents; refreshed README and links')
