from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root/'deliverables/task-20261015-soul-herb-lookback';out.mkdir(parents=True,exist_ok=True)
textures=root/'src/main/resources/assets/wuxingxiantu/textures/block';backup=out/'source-texture-backup';backup.mkdir(exist_ok=True)
for p in textures.glob('soul_healing_room*.png'):
 target=backup/p.name
 if not target.exists():shutil.copy2(p,target)
 # A previous backup is never overwritten by an already-replaced source.
src=Path('C:/Users/Nostzephert/.codex/generated_images/01a13ad0-66f9-7730-9197-507bb5d273ab/exec-a632619e-8c34-48fa-af00-c5eea3063f3b.png')
shutil.copy2(src,out/'愈魂室-生产图集.png');atlas=Image.open(src).convert('RGBA');w,h=atlas.size;assert w*2==h*3
faces=['top','front','left','right','back','bottom'];preview=Image.new('RGB',(864,170),(24,29,37));d=ImageDraw.Draw(preview);font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',16);audit=[]
for i,face in enumerate(faces):
 x=i%3*w//3;y=i//3*h//2;im=atlas.crop((x,y,x+w//3,y+h//2)).resize((64,64),Image.Resampling.NEAREST)
 p=textures/f'soul_healing_room_{face}.png';im.save(p);im.save(out/f'soul_healing_room_{face}-64px.png')
 preview.paste(im.resize((128,128),Image.Resampling.NEAREST),(i*144+8,8));d.text((i*144+8,143),['顶面','正面','左侧','右侧','背面','底面'][i],font=font,fill='white')
 audit.append({'face':face,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':[64,64]})
preview.save(out/'愈魂室-最终六面贴图.png');(out/'texture-verification.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
assets=root/'src/main/resources/assets/wuxingxiantu'
for lang in ['zh_cn','en_us']:
 p=assets/'lang'/f'{lang}.json';v=json.loads(p.read_text(encoding='utf-8'))
 zh={'gui.wuxingxiantu.herb_processing_table.input':'原灵药','gui.wuxingxiantu.herb_processing_table.output':'预处理','gui.wuxingxiantu.herb_processing_table.time':'每株耗时5秒，无需燃料','gui.wuxingxiantu.herb_processing_table.bonus':'按用量比例减少废丹率，最多6%','tooltip.wuxingxiantu.herb_prepared_name':'预处理·%s','tooltip.wuxingxiantu.herb_prepared':'药性已稳定：用于原丹方，减少废丹率。','tooltip.wuxingxiantu.intro.herb_processing_table.action.0':'右键投入灵药，5秒处理1株；按炼丹实际用量最多降低6个百分点废丹率。','tooltip.wuxingxiantu.intro.herb_processing_table.action.1':'无需燃料，漏斗可进出料；已处理材料不能重复加工。'}
 en={'gui.wuxingxiantu.herb_processing_table.input':'Raw Herb','gui.wuxingxiantu.herb_processing_table.output':'Prepared','gui.wuxingxiantu.herb_processing_table.time':'5 seconds per herb; no fuel','gui.wuxingxiantu.herb_processing_table.bonus':'Waste chance -6% at full ratio','tooltip.wuxingxiantu.herb_prepared_name':'Prepared %s','tooltip.wuxingxiantu.herb_prepared':'Stabilized: original recipes accepted; less pill waste.','tooltip.wuxingxiantu.intro.herb_processing_table.action.0':'Prepare one herb in 5 seconds; consumed prepared herbs reduce pill waste by up to 6 percentage points.','tooltip.wuxingxiantu.intro.herb_processing_table.action.1':'No fuel; hopper input/output. Prepared herbs cannot be processed again.'}
 v.update(zh if lang=='zh_cn' else en);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Soul-healing cube faces exported; original textures backed up; processing translations saved.')
