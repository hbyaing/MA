"""Import supplied fragment and essence references as transparent 64x64 icons."""
from pathlib import Path
import json
import shutil
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
OUT = ROOT / 'source-assets/fragments-essence-20261008'
OUT.mkdir(parents=True, exist_ok=True)
REFERENCES = {
    'da_pin_tian_xian_jue_fragment_one': '9e061618-be5e-4753-adf8-3d5d3a13aeec',
    'da_pin_tian_xian_jue_fragment_two': 'cfb17c55-105f-42ac-93c5-2336ca99ad0e',
    'five_essence': '999af895-fec0-427d-819e-ba972373e1ca',
    'yin_fu_jing_yi_shen_fragment': '99171a2a-623b-4920-b152-c4efeb70fb53',
}
manifest = {}
preview = Image.new('RGBA', (320 * len(REFERENCES), 320), (42, 45, 44, 255))
for index, (name, reference) in enumerate(REFERENCES.items()):
    source = OUT / f'{name}-original.png'
    if not source.exists():
        shutil.copy2(Path('C:/Users/NOSTZE~1/AppData/Local/Temp') / f'codex-clipboard-{reference}.png', source)
    original = Image.open(source).convert('RGBA')
    bounds = original.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
    assert bounds is not None
    crop = original.crop(bounds)
    crop.save(OUT / f'{name}-crop.png')
    icon = crop.copy()
    icon.thumbnail((60, 60), Image.Resampling.NEAREST)
    texture = Image.new('RGBA', (64, 64))
    texture.paste(icon, ((64-icon.width)//2, (64-icon.height)//2))
    texture_path = ASSETS / 'textures/item' / f'{name}.png'
    model_path = ASSETS / 'models/item' / f'{name}.json'
    for file in (texture_path, model_path):
        backup = OUT / f'before-{file.name}'
        if file.exists() and not backup.exists():
            shutil.copy2(file, backup)
    texture.save(texture_path)
    model_path.write_text(json.dumps({'parent': 'minecraft:item/generated',
        'textures': {'layer0': f'wuxingxiantu:item/{name}'}}, indent=2)+'\n', encoding='utf-8')
    check = Image.open(texture_path).convert('RGBA')
    assert check.size == (64, 64) and check.getchannel('A').getextrema()[0] == 0
    assert check.getchannel('A').getextrema()[1] >= 128
    preview.alpha_composite(texture.resize((320, 320), Image.Resampling.NEAREST), (index*320, 0))
    manifest[name] = {'source_size': original.size, 'crop_bounds': bounds,
        'icon_size': icon.size, 'texture_size': texture.size, 'resampling': 'NEAREST'}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
preview.save(OUT / 'preview.png')
print('PASS: fragment and essence references imported as independent transparent 64x64 icons')
