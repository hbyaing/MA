from pathlib import Path
import zipfile,json,hashlib,shutil
root=Path(__file__).resolve().parents[1]
report=root/'reports/ui-jei-overlay-20261007'
assert (report/'build.exit').read_text().strip()=='0'
assert 'BUILD SUCCESSFUL' in (report/'build.log').read_text(encoding='utf-16')
jar=root/'build/libs/wuxingxiantu-0.2.jar'
with zipfile.ZipFile(jar) as current,zipfile.ZipFile(root/'deliverables/wuxingxiantu-0.2-20261007-ui-reference-borders.jar') as previous:
    for name in previous.namelist():
        if name.endswith('.class') and '/client/' not in name:assert current.read(name)==previous.read(name),name
        if name.startswith('assets/wuxingxiantu/textures/gui/wuxia/') and name.endswith('.png'):assert current.read(name)==previous.read(name),name
target=root/'deliverables/wuxingxiantu-0.2-20261007-ui-jei-overlay.jar'
shutil.copy2(jar,target)
digest=hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.jar.sha256').write_text(digest+'  '+target.name+'\n')
result={'sha256':digest,'window':[480,294],'layout_cases':80,'nonclient_bytecode_unchanged':True,'existing_png_unchanged':True,'client_runtime_verified':False}
(report/'artifact-verification.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
