from pathlib import Path
import json,shutil
root=Path('E:/五行仙途');p=root/'tools/firecoil-workbench'
shutil.copy(root/'src/main/resources/assets/wuxingxiantu/firecoil/levels.json',p/'levels.json')
s=(p/'editor.js').read_text('utf-8')
s=s.replace("let recipe=validateRecipe", "let previewLevel=4,levelProfiles=[];\nfunction levelRecipe(r){if(!levelProfiles.length)return r;const l=levelProfiles[previewLevel-1],v={...r};for(const [key,c,min,max] of [['width','width',.04,.65],['rotationSpeed','speed',-2,2],['wispRate','wisps',0,80],['emberRate','embers',0,160],['intensity','intensity',.2,4],['weaponWidth','weaponWidth',.02,.5],['weaponStrength','weaponStrength',0,3],['weaponTurns','turns',.25,5]])v[key]=Math.max(min,Math.min(max,v[key]*l[c]));v.strands=Math.max(1,Math.min(8,Math.round(r.strands*l.strands)));return v;}\nlet recipe=validateRecipe")
s=s.replace('preview.setRecipe(valid)','preview.setRecipe(levelRecipe(valid))')
s += "\nfetch('./levels.json').then(r=>r.json()).then(v=>{levelProfiles=v;preview?.setRecipe(levelRecipe(recipe));});\n$('enchant-level').addEventListener('change',()=>{previewLevel=Number($('enchant-level').value);preview?.setRecipe(levelRecipe(recipe));preview?.reset();});\n"
# Explicit custom preset avoids falsely labelling edited or palette-selected recipes.
s=s.replace("if(matching)$('preset').value=matching[0];", "$('preset').value=matching?matching[0]:'custom';")
s=s.replace("$('apply-preset').addEventListener('click',()=>{const select=$('preset');setRecipe", "$('apply-preset').addEventListener('click',()=>{const select=$('preset');if(select.value==='custom')return;setRecipe")
(p/'editor.js').write_text(s,'utf-8')
s=(p/'index.html').read_text('utf-8').replace('<option value="blue"','<option value="custom">自定义</option><option value="blue"',1)
s=s.replace('<div id="parameters"', '<label>附魔等级预览 <select id="enchant-level"><option value="1">I · 单缕初焰</option><option value="2">II · 单缕凝焰</option><option value="3">III · 双流缠绕</option><option value="4" selected>IV · 双流灵焰</option><option value="5">V · 三流盛焰</option></select></label><p>防具按四槽附魔等级之和，最高 V；武器按自身附魔等级。参数栏是基础配方，等级预览单独叠加，导出不会重复累乘。</p><div id="parameters"')
(p/'index.html').write_text(s,'utf-8')
r=json.loads((p/'current-recipe.json').read_text('utf-8'));pal=json.loads((p/'nine-flames.json').read_text('utf-8'))['palettes'][4]
for a,b in [('coreColor','fireCore'),('midColor','fireMid'),('edgeColor','fireEdge')]:r[a]=pal[b]
(p/'current-recipe.json').write_text(json.dumps(r,indent=2),'utf-8')
