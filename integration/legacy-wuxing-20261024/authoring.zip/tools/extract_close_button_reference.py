from pathlib import Path
from PIL import Image
import shutil,json,hashlib
root=Path(__file__).resolve().parents[1]
source=Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-d88269e7-9ab6-4de8-97cd-8d0724099d0c.png')
archive=root/'source-assets/close-button-reference-20261011';archive.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,archive/'reference-original.png')
im=Image.open(source).convert('RGBA')
crop=im.crop((1556,388,1812,644))
out=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/close_reference.png'
crop.save(out)
out.with_suffix('.png.mcmeta').write_text('{"texture":{"blur":true,"clamp":true}}')
(archive/'manifest.json').write_text(json.dumps({'crop':[1556,388,1812,644],'size':list(crop.size),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2))
print('Extracted 256x256 close button')
