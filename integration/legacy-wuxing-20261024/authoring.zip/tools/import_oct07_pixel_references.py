"""Import the user's enlarged pixel sprites into native 32px game textures."""
from pathlib import Path
from PIL import Image
import json
root=Path(__file__).resolve().parents[1]
temp=root/'source-assets/oct07-gameplay-references'
assets=root/'src/main/resources/assets/wuxingxiantu'
def sprite(path,box,size,height=30):
    im=Image.open(path).convert('RGBA').crop(box)
    # Black is the supplied sheet background, not part of the sprite.
    data=[]
    for r,g,b,a in im.getdata():data.append((r,g,b,0 if max(r,g,b)<14 or a<64 else 255))
    im.putdata(data);bounds=im.getbbox();im=im.crop(bounds)
    width=max(1,round(im.width*height/im.height));width=min(width,size-2)
    im=im.resize((width,height),Image.Resampling.NEAREST)
    canvas=Image.new('RGBA',(size,size));canvas.alpha_composite(im,((size-width)//2,size-height));return canvas
dragon=temp/'dragon_scale_grass.png'
im=Image.open(dragon);w,h=im.size
gale=temp/'gale_grass.png'
gw,gh=Image.open(gale).size
sprout=temp/'spirit_sprout_grass.png'
sw,sh=Image.open(sprout).size
outputs=[]
for name,source,boxes in [('dragon_scale_grass',dragon,[(0,0,w*.28,h),(w*.28,0,w*.57,h),(w*.57,0,w,h)]),
                         ('gale_grass',gale,[(gw*.21,0,gw*.44,gh),(gw*.44,0,gw*.69,gh),(gw*.69,0,gw,gh)]),
                         ('spirit_sprout_grass',sprout,[(0,0,sw*.29,sh),(sw*.29,0,sw*.62,sh),(sw*.62,0,sw,sh)])]:
    for i,(suffix,box) in enumerate(zip(['young','growing','mature'],boxes)):
        image=sprite(source,box,32,[17,24,30][i]);p=assets/f'textures/block/{name}_{suffix}.png';image.save(p);outputs.append((name+' '+suffix,image))
        model='' if i==2 else '_low' if i==0 else '_mid'
        p=assets/f'models/block/{name}{model}.json';d=json.loads(p.read_text(encoding='utf-8'));d['textures']['cross']=f'wuxingxiantu:block/{name}_{suffix}';p.write_text(json.dumps(d,indent=2),encoding='utf-8')
        if i==2:image.save(assets/f'textures/item/{name}.png')
for name,file in [('insect_carapace_fragment','insect_carapace_fragment.png'),('spirit_devourer_sac','spirit_devourer_sac.png')]:
    path=temp/file;im=Image.open(path);image=sprite(path,(0,0,im.width,im.height),32,29);image.save(assets/f'textures/item/{name}.png');outputs.append((name,image))
preview=Image.new('RGBA',(len(outputs)*160,160),(35,39,42,255))
buff=temp/'dunguang.png'
bi=Image.open(buff);sprite(buff,(0,0,bi.width,bi.height),32,30).save(assets/'textures/mob_effect/dunguang.png')
for i,(_,im) in enumerate(outputs):preview.alpha_composite(im.resize((128,128),Image.Resampling.NEAREST),(i*160+16,16))
p=root/'reports/spirit-devourer-20261007/pixel-import-preview.png';p.parent.mkdir(parents=True,exist_ok=True);preview.save(p)
print('Imported',len(outputs),'32x32 sprites; preview',p)
