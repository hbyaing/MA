"""Rasterize the new straight-path SVG for review; no source image is edited."""
from pathlib import Path
from PIL import Image,ImageDraw
import re,sys,xml.etree.ElementTree as ET
folder=Path(__file__).resolve().parents[1]/'source-assets/outer-frame-generated-20261011'
name=sys.argv[1] if len(sys.argv)>1 else 'frame-preview'
root=ET.parse(folder/(name+'.svg')).getroot()
scale=4
image=Image.new('RGBA',(1468*scale,897*scale))
draw=ImageDraw.Draw(image)
def paths(data):
    segments=[]; points=[]; x=y=0
    for command,number in re.findall(r'([MLHV])\s*([\d .]+)',data):
        values=[float(n) for n in number.split()]
        if command=='M':
            if points:segments.append(points)
            x,y=values;points=[(x,y)]
        elif command=='H':x=values[0];points.append((x,y))
        elif command=='V':y=values[0];points.append((x,y))
        elif command=='L':x,y=values;points.append((x,y))
    if points:segments.append(points)
    return segments
ns={'s':'http://www.w3.org/2000/svg'}
def gold_color(opacity=1):
    # Match the bright gold trim used by the existing overview panel.
    return (250,219,139,round(255*opacity))
for path in root.findall('s:g/s:path',ns):
    color=gold_color(float(path.attrib.get('stroke-opacity','1')))
    width=round(float(path.attrib.get('stroke-width','1.5'))*scale)
    for points in paths(path.attrib['d']):draw.line([(round(x*scale),round(y*scale)) for x,y in points],fill=color,width=width)
corner=root.find('s:defs/s:g',ns)
for ox,oy,sx,sy in [(10,7,1,1),(1449,7,-1,1),(10,887,1,-1),(1449,887,-1,-1)]:
    current=root.find("s:defs/s:g[@id='corner_clean']",ns) if sx==-1 and sy==1 else corner
    if current is None:current=corner
    for path in current:
        for points in paths(path.attrib['d']):
            color=gold_color(float(path.attrib.get('stroke-opacity','1')))
            width=round(float(path.attrib.get('stroke-width',corner.attrib['stroke-width']))*scale)
            draw.line([(round((ox+sx*x)*scale),round((oy+sy*y)*scale)) for x,y in points],fill=color,width=width)
image.resize((1468,897),Image.Resampling.LANCZOS).save(folder/(name+'.png'))
image.crop((0,0,64*scale,64*scale)).save(folder/(name+'-corner.png'))
print('Rendered transparent frame preview from native vector paths')
