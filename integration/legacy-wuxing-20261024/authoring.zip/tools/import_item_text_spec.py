"""Import the approved player text table; gameplay-owned numbers remain dynamic."""
import argparse
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PALETTE = {"凡品": 0xB7B0A3, "下品": 0x79C58B, "中品": 0x80D9F2,
           "上品": 0xE2A7F5, "极品": 0xFFC94A, "仙品": 0xFF6B6B,
           "黄阶": 0xF4E8D0, "玄阶": 0x80D9F2, "地阶": 0xE2A7F5, "天阶": 0xFFC94A}
SELF_DETAILS = {"experience_crystal", "cultivation_insight", "hualing_pei", "alchemy_formula",
                "talisman", "seal", "carving_knife", "creature_compass", "heart_sword",
                "soul_pearl", "broken_soul_pearl", "myriad_soul_pearl", "soul_energy_pearl",
                "destroy_soul_pearl", "creative_myriad_soul_pearl", "creative_soul_energy_pearl",
                "soul_capture_pearl", "creation_pill", "wanfa_guizong"}
PLANTS = {"adamantine_vine", "blood_spirit_flower", "clear_heart_lotus", "dark_water_weed",
          "dew_drop_flower", "dragon_scale_grass", "gale_grass", "glowing_blue_mushroom",
          "red_sun_grass", "spirit_ginseng", "spirit_sprout_grass", "starlight_flower",
          "thunder_vein_grass", "vein_mending_vine"}

# English variants are deliberately concise; gameplay-owned details remain in the item tooltip.
EN_CATEGORIES = {
    "灵材": "Spiritual material", "稀有灵材": "Rare spiritual material", "五行灵材": "Elemental material",
    "矿材": "Raw ore", "矿石": "Ore", "玄铁储块": "Dark iron storage", "永燃灵煤储块": "Eternal spirit coal storage",
    "灵煤储块": "Spirit coal storage", "灵石储块": "Spirit stone storage", "灵脉矿石": "Spirit vein ore",
    "容器": "Container", "灵植辅材": "Cultivation aid", "灵液": "Spirit liquid", "灵壤": "Spirit soil",
    "异火容器": "Exotic fire vessel", "桃木": "Peach wood", "入门灵剑": "Starter spirit sword",
    "灵剑": "Spirit sword", "上乘灵剑": "Advanced spirit sword", "顶阶灵剑": "Supreme spirit sword",
    "长兵": "Polearm", "本命心剑": "Bonded heart sword", "炼器设施": "Forging facility",
    "炼器灵材": "Forging material", "心法": "Heart method", "品质随丹成变化": "Pill quality",
    "丹道典籍": "Alchemy book", "内丹": "Beast core", "炼丹炉核心": "Alchemy furnace core",
    "破碎魂魄": "Broken soul", "魂魄道具": "Soul item", "魂道法器": "Soul artifact",
    "魂道设施": "Soul facility", "魂魄容器": "Soul vessel", "神通传承": "Divine art inheritance",
    "符箓工具": "Talisman tool", "上乘符墨": "Fine spiritual ink", "寻踪法器": "Tracking artifact",
    "制符设施": "Talisman facility", "品质随符箓变化": "Talisman quality", "符箓材料": "Talisman material",
    "洞府法器": "Cave artifact", "修行心得": "Cultivation insight", "修炼设施": "Cultivation facility",
    "灵器": "Spiritual artifact", "进阶修炼设施": "Advanced cultivation facility",
    "灵力转化设施": "Spiritual conversion facility", "灵植": "Spiritual herb", "内部方块": "Internal block",
    "创造/测试": "Creative / test", "彩蛋物品": "Easter egg", "灌顶典籍": "Knowledge transmission book",
}
EN_LORE = {
    "aura_crystal": "A crystal formed from pure spiritual energy.",
    "dark_iron": "Spiritual energy has made this dark metal stronger than ordinary iron.",
    "eternal_spirit_coal": "Refined spiritual coal with a steady, lasting flame.",
    "experience_crystal": "A small crystal formed from lingering soul energy.",
    "five_essence": "An essence combining the spiritual nature of all five elements.",
    "glazed_crystal": "A clear crystal that can hold exotic fire and medicinal energy.",
    "raw_dark_iron": "Freshly mined dark iron, still mixed with stone and impurities.",
    "spirit_coal": "Coal infused with spiritual energy and a gentle flame.",
    "spirit_stone": "A common currency and source of spiritual energy.",
    "yue_coin": "A curious coin that still bears the mark of a falling anvil.",
    "dark_iron_block": "Nine pieces of dark iron pressed into a solid block.",
    "eternal_spirit_coal_block": "Compressed eternal spirit coal retains a lasting inner heat.",
    "spirit_coal_block": "Compressed spirit coal, convenient for storage and transport.",
    "spirit_coal_ore": "Ore containing coal crystals infused with spiritual energy.",
    "spirit_ore": "A tough vein of rock containing dark iron.",
    "spirit_stone_block": "A dense store of spirit stones for cultivation buildings.",
    "spirit_vein_ore": "Ore formed where a spirit vein has gathered concentrated energy.",
    "empty_spirit_liquid_pot": "A reusable vessel made to carry spirit liquid.",
    "spirit_fertilizer": "Bone meal enriched with the vitality of spirit liquid.",
    "spirit_liquid_bottle": "A small bottle of clear, spiritually charged liquid.",
    "spirit_liquid_bucket": "A bucket of spirit liquid for transport and placement.",
    "spirit_liquid_pot": "A vessel that keeps spirit liquid concentrated for drinking.",
    "spirit_soil": "Fertile soil nourished by spiritual energy over many years.",
    "empty_fire_seed_bottle": "A glazed-crystal vessel capable of containing exotic fire essence.",
    "bixue_yinqiang": "A silver spear whose long reach can hold close enemies at bay.",
    "chenghua_pedestal": "A pedestal that supports materials during forging.",
    "heart_sword": "A blade forged from the cultivator's own will and sword intent.",
    "refining_forge_core": "The core that coordinates flame, materials and forging.",
    "rune_stone": "A stone engraved with stable runes to guide spiritual energy.",
    "alchemy_formula": "A formula sheet carrying the method for a particular pill.",
    "broken_soul_pearl": "A dim, unstable pearl holding a severely damaged soul.",
    "destroy_soul_pearl": "A dark pearl made to sever a soul bond permanently.",
    "human_emperor_banner": "A banner with an inner soul realm that houses and commands captured souls.",
    "myriad_soul_pearl": "A layered soul vessel that holds intact and broken souls.",
    "soul_binding_pearl": "A pearl that binds a merchant's soul while preserving its trade memory.",
    "soul_capture_pearl": "A vessel that draws out a creature's soul through a capturing beam.",
    "soul_energy_pearl": "A reserve of pure soul energy for maintaining soul servants.",
    "soul_healing_room": "Gentle formations stabilize and repair damaged souls here.",
    "soul_pearl": "A pearl in which an intact soul still glimmers.",
    "soul_refining_furnace": "A furnace that refines soul essence and repairs damaged souls.",
    "spirit_dismantling_furnace": "A furnace that breaks soul materials down into usable resources.",
    "carving_knife": "A fine dark-iron blade for engraving talisman runes.",
    "cinnabar_ink": "Cinnabar gives this spiritual ink a stronger affinity for talismans.",
    "creature_compass": "This compass follows living creatures rather than north.",
    "drawing_platform": "A table for laying paper and drawing talisman runes.",
    "engraving_platform": "A platform for fixing talisman runes with a carving knife.",
    "rubbing_platform": "A platform for copying engraved runes onto talisman paper.",
    "seal": "A reusable master impression containing a talisman pattern.",
    "spirit_ink": "Spiritual ink leaves marks that can conduct energy through a talisman.",
    "talisman": "A single-use vessel of spell power, released when its runes are invoked.",
    "talisman_paper": "Prepared paper that holds ink and talisman runes steadily.",
    "cave_token": "A token used to define a protected cultivation dwelling.",
    "cultivation_insight": "A predecessor's notes contain insights gained through cultivation.",
    "gathering_array": "A formation that gathers nearby spiritual energy.",
    "hualing_pei": "A jade pendant that converts spiritual energy into experience.",
    "meditation_cushion": "A simple cushion for quiet meditation and breathing exercises.",
    "meditation_platform": "A stable platform for meditation in a cultivation dwelling.",
    "spirit_cushion": "A spiritually infused cushion that helps focus the mind.",
    "spirit_platform": "A runic platform for gently transforming materials with spiritual energy.",
    "spirit_liquid": "The internal block form of spirit liquid.",
    "human_emperor_banner_stand": "The support created when a Human Emperor Banner is planted.",
    "creation_pill": "A creative-mode pill for quickly testing cultivation systems.",
    "creative_myriad_soul_pearl": "A test soul vessel with unlimited capacity.",
    "creative_soul_energy_pearl": "An unlimited reserve of soul energy for creative testing.",
    "wanfa_guizong": "A fragment containing the principles behind talisman crafting.",
    "dev_test_robe": "A developer's testing robe, outside normal survival progression.",
    "guanding_manual": "A manual for imparting learned heart methods to another cultivator.",
}
EN_ACTIONS = {
    "aura_crystal": ["Used in alchemy, forging and cultivation facilities."],
    "dark_iron": ["A base material for spirit swords, artifacts and talisman tools."],
    "eternal_spirit_coal": ["A high-quality fuel for alchemy, forging and soul furnaces."],
    "five_essence": ["Used in advanced alchemy, forging and formations."],
    "glazed_crystal": ["Used for exotic fire vessels and some advanced alchemy materials."],
    "raw_dark_iron": ["Smelt to obtain dark iron."],
    "spirit_coal": ["A common fuel for cultivation furnaces."],
    "spirit_stone": ["Used for trade, alchemy, forging and cultivation."],
    "dark_iron_block": ["Stores dark iron and can be used for building."],
    "eternal_spirit_coal_block": ["A fuel reserve for advanced furnaces."],
    "spirit_coal_ore": ["Mine to obtain spirit coal resources."],
    "spirit_ore": ["A source of dark iron."],
    "spirit_stone_block": ["Stores spirit stones and can be used for cultivation buildings."],
    "spirit_vein_ore": ["A source of spirit stones and spiritual materials."],
    "spirit_fertilizer": ["Accelerates spiritual herbs and ordinary crops."],
    "spirit_liquid_bottle": ["Drink to restore 5% of maximum mana."],
    "spirit_liquid_pot": ["Drink to restore 20% of maximum mana; the empty pot is reusable."],
    "spirit_soil": ["Required by some advanced spiritual herbs."],
    "empty_fire_seed_bottle": ["Use on an exotic fire source to collect it."],
    "peach_blossom": ["Used for decoration or to obtain peach petals."],
    "peach_leaves": ["Suitable for peach groves and cultivation gardens."],
    "peach_petals": ["Used in calming and mind-cleansing pills."],
    "peach_planks": ["Craft into peach-wood building components."],
    "peach_sapling": ["Plant to grow a peach tree."],
    "peach_sword": ["Supports learned sword techniques, but cannot be ridden in sword flight."],
    "peach_wood": ["A base material for peach-wood buildings and items."],
    "bixue_yinqiang": ["Offers greater attack reach than ordinary swords."],
    "refining_forge_core": ["Used to build a complete refining forge."],
    "alchemy_aptitude": ["Read to unlock Root Awakening and Foundation pill formulas."],
    "alchemy_body": ["Read to unlock Vein Mending, Diamond Body and Golden Wound formulas."],
    "alchemy_breakthrough": ["Read to unlock Breakthrough and Tribulation formulas."],
    "alchemy_complete": ["Creative players or administrators can read it to unlock all pill formulas."],
    "alchemy_guarding": ["Read to unlock Clear Heart, Calming and Profound Water formulas."],
    "alchemy_introduction": ["Read to unlock the basic pill formulas of a mortal-grade furnace."],
    "alchemy_nourishing": ["Read to unlock Aura, Cultivation, Gathering, Bigu and Gale formulas."],
    "human_emperor_banner": ["Capture souls with a Soul Capture Pearl; sneak-use to open the banner.","Sneak-use on a block to plant the banner."],
    "soul_binding_pearl": ["Use on a villager or wandering trader to bind its soul; sneak-use in air to trade."],
    "soul_healing_room": ["Repairs broken souls and replenishes some soul resources."],
    "soul_refining_furnace": ["Used for soul repair and refinement."],
    "spirit_dismantling_furnace": ["Breaks down and converts soul materials."],
    "guanding_manual": ["Use on another player to impart some of your learned heart methods."],
    "cinnabar_ink": ["Reusable for drawing talismans; improves their strength."],
    "drawing_platform": ["Used to draw talisman runes."],
    "engraving_platform": ["Used to engrave talisman runes."],
    "rubbing_platform": ["Used to copy talismans from a seal."],
    "spirit_ink": ["Reusable for drawing talismans."],
    "talisman_paper": ["The base medium for crafting talismans."],
    "cave_token": ["Place or use it to establish a protected dwelling."],
    "gathering_array": ["Used to gather energy for cultivation."],
    "meditation_cushion": ["Used for meditation."],
    "meditation_platform": ["Used for meditation."],
    "spirit_cushion": ["Used for more advanced meditation."],
    "spirit_platform": ["Transforms materials into spirit fertilizer, eternal spirit coal and other resources."],
}


def english_text(item, row):
    category = row["category"]
    grades = {"凡品": "Mortal", "下品": "Low-grade", "中品": "Mid-grade", "上品": "High-grade", "极品": "Perfect-grade", "仙品": "Immortal"}
    if category in EN_CATEGORIES:
        title = EN_CATEGORIES[category]
    elif category.endswith("阶异火"):
        numbers = dict(zip("一二三四五六七八九", range(1, 10)))
        title = f"Tier {numbers[category[0]]} exotic fire"
    elif category.endswith("阶功法"):
        title = {"黄": "Yellow", "玄": "Profound", "地": "Earth", "天": "Heaven"}[category[0]] + "-tier art"
    else:
        grade = next(label for label in grades if category.startswith(label))
        title = grades[grade] + " " + EN_CATEGORIES[category[len(grade):]].lower()
    lore = EN_LORE.get(item)
    actions = EN_ACTIONS.get(item, [])
    if item in PLANTS:
        lore = "A spiritual herb used as an alchemy material and grown with careful cultivation."
    elif item.startswith("art_"):
        lore = "A cultivation manual recording a technique powered by spiritual energy."
    elif item.startswith("heart_method_"):
        lore = "A manual of inner cultivation, guiding the flow of energy and the focus of the mind."
    elif item.endswith("_pill") and lore is None:
        lore = "A pill that channels medicinal energy through the body."
    elif item.endswith("_sword") and lore is None:
        lore = "A spirit sword that channels spiritual energy through its blade."
    elif item.startswith("fire_seed_"):
        lore = "A glazed vessel holding the essence of an exotic fire."
    elif item.startswith("exotic_fire_"):
        lore = "An exotic fire source in the world."
    elif item.startswith("peach_"):
        lore = "A peach-wood item suited to gardens and cultivation dwellings."
    elif item.startswith("inner_core_"):
        lore = "A beast's vitality and cultivation condensed into a spiritual core."
        actions = ["Used in alchemy, forging and breakthrough preparations."]
    elif re.match(r"(low|mid|high|perfect)_(gold|wood|water|fire|earth)_", item):
        element = item.split("_")[1]
        lore = f"A spiritual material formed from condensed {element} energy."
        actions = ["Used in elemental alchemy, forging and cultivation."]
    elif item.startswith("alchemy_furnace"):
        lore = "A furnace core that coordinates flame and medicinal energy."
        actions = ["Used to build an alchemy furnace of the corresponding grade."]
    elif item.startswith("alchemy_") and lore is None:
        lore = "An alchemy book recording pill formulas and the principles of refinement."
    elif item.endswith("_spawn_egg"):
        lore = "Summons a boss for development or creative-mode testing."
        actions = ["For creative mode and testing only."]
    elif item.endswith("_fragment") or item.endswith("_fragment_one") or item.endswith("_fragment_two") or item=="gangdou_starmap":
        lore = "An inherited fragment recording a divine art."
        actions = ["Read to learn the divine art recorded in this fragment."]
    assert lore, f"Missing English introduction {item}"
    # Every visible action needs a localized counterpart with the same number of lines.
    if row["action"]:
        assert len(actions)==len(row["action"]), f"English action count {item}"
    return title, lore, actions


def read_rows(path):
    visibility = "player"
    rows = {}
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        if line.startswith("## 三、"):
            visibility = "internal"
        elif line.startswith("## 四、"):
            visibility = "creative"
        elif line.startswith("## 五、"):
            break
        cells = [cell.strip().strip("`") for cell in line.strip().strip("|").split("|")]
        if not line.startswith("|"):
            continue
        if len(cells) == 5 and cells[0].isdigit():
            _, item, name, color, text = cells
        elif len(cells) == 4 and re.fullmatch(r"[a-z_]+", cells[0]):
            item, name, color, text = cells
        else:
            continue
        assert item not in rows, f"Duplicate item {item}"
        parts = [part.strip() for part in text.split("<br>")]
        category = parts[0].strip("【】")
        lore = parts[1] if len(parts) > 1 else ""
        action = parts[2:]
        # The table is editorial guidance, not an authority for contradictory gameplay claims.
        if item == "peach_sword":
            lore = "以桃木为骨、灵力为锋的轻巧灵剑，适合初学练剑。"
            action = ["可施展已学习的剑诀；不能用于御剑飞行。"]
        elif item.startswith("fire_seed_"):
            action = []  # Current bottle tier/essence/refinement are supplied by FireSeedItem.
        elif item.startswith(("art_", "heart_method_")):
            action = []  # Current catalogue supplies the effect, mana and learning state.
        elif item.endswith("_pill") or item in SELF_DETAILS or item.endswith("_sword") or item in PLANTS:
            action = []  # Item classes supply actual numbers and mutable attributes.
        if item == "alchemy_complete":
            visibility_for_item = "creative"
            action = ["创造模式或管理员可研读，解锁全部丹方。"]
        else:
            visibility_for_item = visibility
        if visibility_for_item == "internal":
            action = []  # Hide implementation details from the player-facing tooltip.
        rows[item] = dict(name=name, color=color, category=category, lore=lore,
                          action=action, visibility=visibility_for_item)
    assert len(rows) == 227, f"Expected 227 approved items, got {len(rows)}"
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("spec", type=Path)
    args = parser.parse_args()
    rows = read_rows(args.spec)
    lang_path = ROOT / "src/main/resources/assets/wuxingxiantu/lang/zh_cn.json"
    lang = {key:value for key,value in json.loads(lang_path.read_text(encoding="utf-8")).items()
            if not key.startswith("tooltip.wuxingxiantu.intro.")}
    metadata = {}
    for item, row in rows.items():
        prefix = f"tooltip.wuxingxiantu.intro.{item}"
        lang[prefix + ".category"] = row["category"]
        lang[prefix + ".lore"] = row["lore"]
        for index, action in enumerate(row["action"]):
            lang[prefix + f".action.{index}"] = action
        name_keys = [f"{kind}.wuxingxiantu.{item}" for kind in ("item", "block")]
        assert any(key in lang for key in name_keys), f"Unknown registered name {item}"
        for key in name_keys:
            if key in lang:
                lang[key] = row["name"]
        raw_color = row["color"]
        color = int(raw_color[1:], 16) if re.fullmatch(r"#[0-9A-Fa-f]{6}", raw_color) else 0xD6D6D6
        grade_color = next((value for label, value in PALETTE.items()
                            if row["category"].startswith(label)), color)
        metadata[item] = dict(nameColor=color, gradeColor=grade_color,
                              visibility=row["visibility"], actions=len(row["action"]))
    # Correct heart-method descriptions wherever the same catalogue is used by the UI.
    for item, row in rows.items():
        if not item.startswith("heart_method_"):
            continue
        full_text = next(line for line in args.spec.read_text(encoding="utf-8-sig").splitlines()
                         if f"`{item}`" in line and line.startswith("|"))
        parts = full_text.strip().strip("|").split("|")[-1].strip().split("<br>")
        lang["gui.wuxingxiantu.heart_method.description." + item.removeprefix("heart_method_")] = parts[2]
    for key in list(lang):
        if key.startswith(("tooltip.", "pill.")):
            lang[key] = re.sub(r"§[0-9a-fk-or]", "", lang[key], flags=re.I)
    lang.update({
        "tooltip.wuxingxiantu.creative_test_badge": "🧪 创造/测试专属",
        "tooltip.wuxingxiantu.internal_badge": "🔒 内部物品",
        "tooltip.wuxingxiantu.art_tier": "%s功法",
        "tooltip.wuxingxiantu.art_cost": "灵力消耗：固定 %s + 最大灵力 %s%%",
        "tooltip.wuxingxiantu.fire_rarity": "稀有度：%s",
        "fire_rarity.wuxingxiantu.common": "普通",
        "fire_rarity.wuxingxiantu.rare": "稀有",
        "fire_rarity.wuxingxiantu.very_rare": "史诗",
        "fire_rarity.wuxingxiantu.unique": "唯一",
        "tooltip.wuxingxiantu.no_extra_bonus": "当前版本暂无额外加成",
        "tooltip.wuxingxiantu.fire_final": "九火之巅，已达最高阶位",
        "tooltip.wuxingxiantu.fire_no_route": "暂无进一步蜕变之路",
        "tooltip.wuxingxiantu.knowledge_requirement": "研读境界：%s",
        "tooltip.wuxingxiantu.study_art": "右键研读，习得后可配置功法",
        "tooltip.wuxingxiantu.study_heart": "右键研读，习得并装备此心法",
        "tooltip.wuxingxiantu.book_source": "获取：开阔水域钓鱼 / %s级及以上灵修者交易",
        **{f"art_tier.wuxingxiantu.{i}":name for i,name in enumerate(("黄阶","玄阶","地阶","天阶"),1)},
    })
    # Keep existing English translations and add concise English editorial variants.
    english_path = lang_path.with_name("en_us.json")
    english = {key:value for key,value in json.loads(english_path.read_text(encoding="utf-8")).items()
               if not key.startswith("tooltip.wuxingxiantu.intro.")}
    for item, row in rows.items():
        title, lore, actions = english_text(item,row)
        prefix = f"tooltip.wuxingxiantu.intro.{item}"
        english[prefix+".category"] = title
        english[prefix+".lore"] = lore
        for index in range(len(row["action"])):
            english[prefix+f".action.{index}"] = actions[index]
    for key, value in lang.items():
        if key not in english and not key.startswith("tooltip.wuxingxiantu.intro."):
            english[key] = value
    english.update({
        "tooltip.wuxingxiantu.creative_test_badge": "🧪 Creative / test only",
        "tooltip.wuxingxiantu.internal_badge": "🔒 Internal item",
        "tooltip.wuxingxiantu.art_tier": "%s art",
        "tooltip.wuxingxiantu.art_cost": "Mana cost: %s + %s%% of maximum mana",
        "tooltip.wuxingxiantu.fire_rarity": "Rarity: %s",
        "fire_rarity.wuxingxiantu.common": "Common",
        "fire_rarity.wuxingxiantu.rare": "Rare",
        "fire_rarity.wuxingxiantu.very_rare": "Epic",
        "fire_rarity.wuxingxiantu.unique": "Unique",
        "tooltip.wuxingxiantu.fire_final": "The pinnacle of the nine fires; maximum tier reached",
        "tooltip.wuxingxiantu.fire_no_route": "No further evolution route",
        "tooltip.wuxingxiantu.no_extra_bonus": "No additional bonus in this version",
        "tooltip.wuxingxiantu.knowledge_requirement": "Required realm: %s",
        "tooltip.wuxingxiantu.study_art": "Use to study; then equip the learned art",
        "tooltip.wuxingxiantu.study_heart": "Use to study and equip this heart method",
        "tooltip.wuxingxiantu.book_source": "Source: open-water fishing / level %s+ Spirit Cultivator trades",
        **{f"art_tier.wuxingxiantu.{i}":name for i,name in enumerate(("Yellow-tier","Profound-tier","Earth-tier","Heaven-tier"),1)},
    })
    english_heart = {
        "yuan_hun":"Maximum mana +%1$s%%; cultivation gains +%2$s%%.",
        "tiangang":"Attack +%1$s%%; incoming damage reduced by %2$s%%.",
        "burning_heaven":"Flame Wave and your fire damage +%1$s%%; melee hits ignite for %2$s seconds.",
        "thick_earth":"Maximum health +%1$s%%; incoming damage reduced by %2$s%%; knockback resistance +%3$s.",
        "gathering":"While meditating: mana regeneration +%1$s%% and cultivation gains +%2$s%%.",
        "taixu":"Movement speed +%1$s%%; mana regeneration +%2$s%%.",
        "wanling":"Maximum health, attack, mana and movement speed +%1$s%%; mana regeneration +%2$s%%; cultivation gains +%3$s%%.",
        "nine_turns":"Cultivation gains +%1$s%%; breakthrough mana cost reduced by %2$s%%; mastery gains doubled.",
        "xuanshui":"Incoming damage reduced by %1$s%%; swimming speed +%2$s%%; grants underwater breathing.",
        "beast_taming":"Use an empty hand on animals; costs 10 mana. Effectiveness depends on realm and wood roots.",
    }
    chinese_heart = {
        "yuan_hun":"最大灵力+%1$s%%，修为收益+%2$s%%。",
        "tiangang":"攻击力+%1$s%%，所受伤害降低%2$s%%。",
        "burning_heaven":"烈焰波及由你造成的火焰伤害+%1$s%%；近战命中点燃%2$s秒。",
        "thick_earth":"最大生命+%1$s%%，所受伤害降低%2$s%%，击退抗性+%3$s。",
        "gathering":"打坐时灵力回复+%1$s%%，修为收益+%2$s%%。",
        "taixu":"移动速度+%1$s%%，灵力回复+%2$s%%。",
        "wanling":"最大生命、攻击力、最大灵力与移动速度+%1$s%%；灵力回复+%2$s%%，修为收益+%3$s%%。",
        "nine_turns":"修为收益+%1$s%%，突破灵力消耗降低%2$s%%；功法、剑诀与御剑熟练度收益翻倍。",
        "xuanshui":"所受伤害降低%1$s%%，游泳速度+%2$s%%，可在水下呼吸。",
        "beast_taming":"空手右键动物，消耗10点灵力；驯服、成长与繁殖效果随境界和木灵根品质提升。",
    }
    for item,description in chinese_heart.items():
        lang["gui.wuxingxiantu.heart_method.description."+item]=description
    art_functions = {
        "art_flame_wave": ("向前方释放扇形烈焰波，命中后点燃敌人4秒。", "Unleash a cone of flames ahead; successful hits ignite enemies for 4 seconds."),
        "art_immobilize": ("束缚自身周围3格内的敌人，短暂定身。", "Briefly immobilize enemies within 3 blocks around you."),
        "art_purification": ("恢复生命并清除自身负面状态。", "Restore health and remove harmful effects from yourself."),
        "art_sword_pierce": ("飞星贯日：役使一把剑突刺准心目标，命中后归阵。", "Flying Star: send one sword at the crosshair target; it returns after striking."),
    }
    for item,(zh_text,en_text) in art_functions.items():
        key="art.wuxingxiantu.function."+item
        lang[key]=zh_text
        english[key]=en_text
    lang["divine.wuxingxiantu.function.yuan_shen_chu_qiao"] = "灵魂离体，可飞行和穿越地形，不可攻击或交互。启动%1$s灵力；每秒维持消耗为%2$s×（1＋距本体格数÷%3$s），向上取整。离本体越远消耗越高，无固定距离上限。"
    english["divine.wuxingxiantu.function.yuan_shen_chu_qiao"] = "Leave your body to fly and pass through terrain; cannot attack or interact. Activation: %1$s mana. Upkeep per second: %2$s × (1 + distance from your body / %3$s), rounded up. Farther travel costs more; no fixed distance limit."
    lang["tooltip.wuxingxiantu.divine_soul_cost"] = "启动%1$s灵力；每秒维持：%2$s×（1＋距本体格数÷%3$s）"
    english["tooltip.wuxingxiantu.divine_soul_cost"] = "Activation: %1$s mana; upkeep per second: %2$s × (1 + distance from body / %3$s)"
    for item,description in english_heart.items():
        english["gui.wuxingxiantu.heart_method.description."+item]=description
    english_path.write_text(json.dumps(english, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lang_path.write_text(json.dumps(lang, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    catalog = ROOT / "src/main/resources/assets/wuxingxiantu/item_text_catalog.json"
    catalog.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Imported {len(rows)} item introductions; gameplay-owned dynamic values preserved.")


if __name__ == "__main__":
    main()
