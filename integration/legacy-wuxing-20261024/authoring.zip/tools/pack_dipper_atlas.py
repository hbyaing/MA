"""Pack existing node/rune 4x4 sheets and soft spark into one 8x8 VFX atlas."""
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
atlas=Image.new('RGBA',(1024,1024))
source=ROOT/'source-assets/formation-particle-library-v1/textures/formations'
for name,offset in [('spirit_01_node_sheet.png',0),('spirit_01_rune_sheet.png',4)]:
    sheet=Image.open(source/name).convert('RGBA')
    assert sheet.size==(2048,2048)
    for frame in range(16):
        x=frame%4;y=frame//4
        image=sheet.crop((x*512,y*512,(x+1)*512,(y+1)*512)).resize((128,128),Image.Resampling.LANCZOS)
        atlas.paste(image,((offset+x)*128,y*128))
assets=ROOT/'src/main/resources/assets/wuxingxiantu'
spark=Image.open(assets/'textures/particle/arts/spark_soft.png').convert('RGBA').resize((128,128),Image.Resampling.LANCZOS)
atlas.paste(spark,(0,512))
atlas.paste(Image.new('RGBA',(128,128),(255,255,255,255)),(128,512))
atlas.save(assets/'textures/effect/dipper_ritual_atlas.png')
print('PASS: node/rune 16-frame sequences, spark cell 32, solid cell 33; 1024x1024 atlas')
