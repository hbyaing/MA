"""Verify the built artifact and full-resolution root pixels before staging a new JAR."""
from pathlib import Path
import json, zipfile, shutil, hashlib
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'reports/ui-vision-layout-20261007'
TARGET=ROOT/'deliverables/wuxingxiantu-0.2-20261007-vision-layout.jar'
def log(name):
    raw=(REPORT/name).read_bytes()
    return raw.decode('utf-16' if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig',errors='replace')
assert (REPORT/'build.exit').read_text().strip()=='0' and 'BUILD SUCCESSFUL' in log('build.log')
assert 'PASS: 60' in log('vision-layout.log') and 'PASS: 20' in log('layout.log')
assert (REPORT/'domain-tests.exit').read_text().strip()=='0'
assert 'All 10 required tests passed' in log('domain-tests.log')
source=Image.open(ROOT/'source-assets/cultivation-vision-reference-v2/reference-original.png').convert('RGBA')
manifest=json.loads((ROOT/'source-assets/cultivation-vision-reference-v2/manifest.json').read_text(encoding='utf-8'))
jar=ROOT/'build/libs/wuxingxiantu-0.2.jar'
with zipfile.ZipFile(jar) as z:
    with zipfile.ZipFile(ROOT/'deliverables/wuxingxiantu-0.2-20261007-ui-jei-spacing.jar') as previous:
        gameplay=[name for name in previous.namelist() if name.endswith('.class') and '/client/' not in name]
        for name in gameplay:
            assert z.read(name)==previous.read(name), 'Gameplay/save bytecode unexpectedly changed: '+name
    assets=json.loads((ROOT/'reports/ui-reference-install-20261007/assets.json').read_text(encoding='utf-8'))
    for a in assets['assets']:
        assert z.read('assets/wuxingxiantu/textures/gui/wuxia/reference/'+a['path'])==(ROOT/a['source']).read_bytes()
    for name,entry in manifest['crops'].items():
        path=ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision/roots'/f'{name}.png'
        assert z.read('assets/wuxingxiantu/textures/gui/wuxia/vision/roots/'+name+'.png')==path.read_bytes()
        original=source.crop(entry['box']);crop=Image.open(path).convert('RGBA')
        assert original.size==crop.size==tuple(entry['size'])
        assert all(a[:3]==b[:3] for a,b in zip(original.getdata(),crop.getdata())), 'Original RGB was modified'
shutil.copy2(jar,TARGET)
digest=hashlib.sha256(TARGET.read_bytes()).hexdigest()
TARGET.with_suffix('.jar.sha256').write_text(digest+'  '+TARGET.name+'\n',encoding='ascii')
result={'artifact':str(TARGET),'sha256':digest,'size':TARGET.stat().st_size,'vision_layout_cases':60,
        'shared_layout_cases':20,'gametests':10,'original_assets_retained':34,'full_resolution_root_crops':5,
        'root_rgb_unchanged':True,'gameplay_and_save_classes_unchanged':len(gameplay),'client_runtime_verified':False,
        'save_compatibility':'Same NBT keys; legacy multi-domain saves retain first unlocked domain in gold/wood/water/fire/earth order.'}
(REPORT/'artifact-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
