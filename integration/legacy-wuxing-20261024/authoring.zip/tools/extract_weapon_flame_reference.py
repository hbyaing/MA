"""Extract RGBA materials from the user's reference without repainting its pixels."""
from collections import deque
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / 'reference_assets/weapon-flames-0.2'
TEXTURES = ROOT / 'src/main/resources/assets/wuxingxiantu/textures/effect'


def smoothstep(lo, hi, value):
    t = max(0, min(1, (value - lo) / (hi - lo)))
    return t * t * (3 - 2 * t)


def transparent(image):
    result = image.convert('RGBA')
    pixels = []
    for r, g, b, _ in result.getdata():
        warm = r / 255 - max(b / 255, g / 255 * .55)
        alpha = round(255 * smoothstep(.09, .32, warm) * smoothstep(.18, .48, r / 255))
        pixels.append((r, g, b, alpha))
    result.putdata(pixels)
    return result


def main_fragment(image):
    # Keep the connected flame, excluding unrelated sparks crossing a crop edge.
    alpha = image.getchannel('A')
    active = {(x, y) for y in range(image.height) for x in range(image.width) if alpha.getpixel((x, y)) >= 5}
    largest = set()
    while active:
        seed = min(active)
        active.remove(seed)
        component = {seed}
        queue = deque([seed])
        while queue:
            x, y = queue.popleft()
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)):
                point = x + dx, y + dy
                if point in active:
                    active.remove(point)
                    component.add(point)
                    queue.append(point)
        if len(component) > len(largest):
            largest = component
    result = Image.new('RGBA', image.size)
    for point in largest:
        result.putpixel(point, image.getpixel(point))
    return result.crop(result.getbbox())


def main():
    source_path = REFERENCE / 'reference-original.png'
    source = Image.open(source_path).convert('RGB')
    if source.size != (1672, 941):
        raise ValueError('Expected the original 1672 x 941 reference')
    rgba = transparent(source)
    atlas = Image.new('RGBA', (512, 512))
    regions = [(930, 638, 1100, 748), (916, 746, 1096, 857),
               (1118, 635, 1225, 737), (1110, 729, 1258, 858)]
    for i, region in enumerate(regions):
        fragment = main_fragment(rgba.crop(region))
        x, y = i % 2 * 256, i // 2 * 160
        atlas.paste(fragment, (x + (256 - fragment.width) // 2, y + (160 - fragment.height) // 2))
        fragment.save(REFERENCE / f'shard-{i}.png')
    spark = main_fragment(rgba.crop((1423, 126, 1455, 158)))
    atlas.paste(spark, (16 + (32 - spark.width) // 2, 352 + (32 - spark.height) // 2))
    atlas.save(TEXTURES / 'weapon_flame_reference.png', optimize=True)

    ribbon = Image.new('RGBA', (384, 80))
    for x in range(ribbon.width):
        t = x / (ribbon.width - 1)
        center_y = 665 + 103 * t * t
        for y in range(ribbon.height):
            r, g, b, a = rgba.getpixel((451 + x, round(center_y + y - 40)))
            # Transparent ends separate successive curls; fade rows avoids cut-off glow.
            fade = smoothstep(0, 12, min(x, ribbon.width - 1 - x))
            fade *= smoothstep(0, 5, min(y, ribbon.height - 1 - y))
            ribbon.putpixel((x, y), (r, g, b, round(a * fade)))
    ribbon.save(TEXTURES / 'weapon_flame_ribbon.png', optimize=True)
    ribbon.save(REFERENCE / 'ribbon.png')

    board = Image.new('RGB', (1000, 590), '#17212d')
    draw = ImageDraw.Draw(board)
    draw.text((24, 16), 'REFERENCE PIXELS / TRANSPARENT GAME MATERIALS', fill='white')
    for i in range(4):
        fragment = atlas.crop((i % 2 * 256, i // 2 * 160, i % 2 * 256 + 256, i // 2 * 160 + 160))
        fragment = fragment.resize((460, 250), Image.Resampling.NEAREST)
        board.paste(fragment, (20 + i % 2 * 500, 40 + i // 2 * 260), fragment)
    board.save(REFERENCE / 'materials.png')
    manifest = {'source': 'reference-original.png', 'sha256': hashlib.sha256(source_path.read_bytes()).hexdigest(),
                'atlas': [512, 512], 'shardRegions': regions, 'ribbon': [384, 80],
                'method': 'Original RGB, warm-color alpha mask, connected components, nearest-neighbor ribbon unwrap.'}
    (REFERENCE / 'extraction.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    print('Extracted four fragments, one ember and one unwrapped ribbon from original pixels.')


if __name__ == '__main__':
    main()
