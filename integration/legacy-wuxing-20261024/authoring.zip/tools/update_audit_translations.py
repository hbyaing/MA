"""Synchronize the reviewed, fixed divine costs and current interaction text."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'src/main/resources/assets/wuxingxiantu/lang'
translations={
'zh_cn':{
'message.wuxingxiantu.refining_reopen':'炼器操作会话已失效，请重新打开炼器台。',
'message.wuxingxiantu.compass_cooldown':'司南尚未冷却。',
'message.wuxingxiantu.compass_combat':'心境、渡劫或 Boss 战期间无法使用司南传送。',
'message.wuxingxiantu.banner_servant_limit':'已达到同时激活魂仆的上限（%s）。',
'message.wuxingxiantu.compendium_learned':'你从《%1$s》中掌握了 %2$s 种新的丹方。',
'message.wuxingxiantu.heart_sword_empty_offhand':'心铸与解心需要副手为空。',
'gui.wuxingxiantu.rechallenge':'重新挑战心魔',
'message.wuxingxiantu.rechallenge_ready':'已选择最终心魔重挑战，打坐可进入心境。',
'message.wuxingxiantu.rechallenge_locked':'完成心境主线并结束当前挑战后，方可重新挑战。',
'divine.wuxingxiantu.function.fa_tian_xiang_di':'体型、跳跃高度与触及距离×5；伤害+50%，生命+100%，护甲+20，抗性IV，免疫击退；移速-30%且无法疾跑。启动消耗%1$s灵力，维持每秒%2$s灵力。',
'divine.wuxingxiantu.function.ri_yue_ting_lun':'日月停轮：使半径24格内非玩家实体停止行动6秒；施术者仍可移动攻击，再次释放收束。启动消耗%1$s灵力。',
'divine.wuxingxiantu.function.jin_dou_yun':'驾云飞行，飞行速度提高1000%；再次释放收束。启动消耗%1$s灵力。',
'divine.wuxingxiantu.function.qi_shi_er_bian':'变化为移魂寄魄记录的生灵；按Z收束，按C切换形态。确认变化消耗%1$s灵力。',
'divine.wuxingxiantu.function.ta_gang_bu_dou':'踏罡七星，依次走过七星改变晴天、雨天与雷暴；星环持续15秒。释放消耗%1$s灵力。',
'divine.wuxingxiantu.function.yi_hun_ji_po':'留下一个本体，以半透明灵魂移动；右键生灵寄魄，按X解除附身。游离时右键自己的本体可收束神通。启动%1$s灵力，维持每秒%2$s灵力，距本体最远128格。',
'divine.wuxingxiantu.function.yuan_shen_chu_qiao':'灵魂离体，可飞行和穿越地形，不可攻击或交互。启动%1$s灵力，维持每秒%2$s灵力，距本体最远128格。',
'art.wuxingxiantu.function.art_sword_guard':'六御金罡：最多六剑护身8秒，减免伤害并反弹投射物；灵剑不消耗耐久。'
},
'en_us':{
'message.wuxingxiantu.refining_reopen':'Refining session expired. Reopen the forge.',
'message.wuxingxiantu.compass_cooldown':'Compass is on cooldown.',
'message.wuxingxiantu.compass_combat':'Compass teleport is unavailable during mindscape trials, tribulations or boss combat.',
'message.wuxingxiantu.banner_servant_limit':'Active servant limit reached (%s).',
'message.wuxingxiantu.compendium_learned':'Learned %2$s new formulas from %1$s.',
'message.wuxingxiantu.heart_sword_empty_offhand':'Heart forging and release require an empty offhand.',
'gui.wuxingxiantu.rechallenge':'Challenge Heart Demon Again',
'message.wuxingxiantu.rechallenge_ready':'Final Heart Demon replay selected. Meditate to enter the mindscape.',
'message.wuxingxiantu.rechallenge_locked':'Complete the main trials and finish your current challenge before replaying.',
'divine.wuxingxiantu.function.fa_tian_xiang_di':'Size, jump and reach x5; damage +50%, health +100%, armor +20, Resistance IV and knockback immunity. Movement -30%; sprinting disabled. Costs %1$s mana to activate and %2$s mana per second.',
'divine.wuxingxiantu.function.ri_yue_ting_lun':'Halt Sun and Moon: stop non-player entities within 24 blocks for 6 seconds. You can still move and attack; cast again to end. Costs %1$s mana.',
'divine.wuxingxiantu.function.jin_dou_yun':'Fly on a cloud with +1000% flight speed. Cast again to end. Costs %1$s mana to activate.',
'divine.wuxingxiantu.function.qi_shi_er_bian':'Transform into a recorded possession form. Z ends the transformation and C switches forms. Confirming a form costs %1$s mana.',
'divine.wuxingxiantu.function.ta_gang_bu_dou':'Follow the seven stars to cycle clear skies, rain and thunderstorms; the star ring lasts 15 seconds. Costs %1$s mana.',
'divine.wuxingxiantu.function.yi_hun_ji_po':'Leave one body and move as a translucent soul. Right-click a creature to possess it; X releases the host. Right-click your own body while detached to end the art. Costs %1$s mana plus %2$s per second; maximum range 128 blocks.',
'divine.wuxingxiantu.function.yuan_shen_chu_qiao':'Project your soul to fly through terrain without attacking or interacting. Costs %1$s mana plus %2$s per second; maximum range from the body is 128 blocks.',
'art.wuxingxiantu.function.art_sword_guard':'Six swords guard you for 8 seconds, reducing damage and reflecting projectiles. Spirit swords consume no durability.'
}}
for locale,updates in translations.items():
    path=ROOT/f'{locale}.json';data=json.loads(path.read_text(encoding='utf-8-sig'))
    data.update(updates);path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Updated fixed-cost descriptions, compendium summary and interaction messages in both locales.')
