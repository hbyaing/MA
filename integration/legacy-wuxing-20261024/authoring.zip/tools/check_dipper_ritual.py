"""Generate CPU checks from the actual pattern, packet codec and fade implementation."""
from pathlib import Path
import re
import json
ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'src/main/java/cn/blockforge/generated/generatedmod'
OUT=ROOT/'reports/dipper-implementation-20261008'
OUT.mkdir(parents=True,exist_ok=True)
pattern=(JAVA/'divineart/DipperPattern.java').read_text(encoding='utf-8')
pattern=re.sub(r'^(package|import) .*;\n','',pattern,flags=re.M).replace('public final class DipperPattern','final class DipperPattern')
packet=(JAVA/'network/packet/divineart/DipperVisualPacket.java').read_text(encoding='utf-8')
packet=re.sub(r'^(package|import) .*;\n','',packet,flags=re.M).replace('public record DipperVisualPacket','record DipperVisualPacket')
packet=packet.split('    public static void handle(')[0]+'}\n'
renderer=(JAVA/'client/DipperRitualEffects.java').read_text(encoding='utf-8')
fade=renderer.split('        float strength(double now){',1)[1].split('\n        }',1)[0]
header='''import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import io.netty.buffer.Unpooled;
import java.util.UUID;
'''
main='''public class DipperRuntimeChecks {
    static void check(boolean value,String reason){if(!value)throw new AssertionError(reason);}
    static class Fade {
        int phase;long start,phaseStart;
        float strength(double now){FADE_BODY
        }
    }
    public static void main(String[] args){
        Vec3 anchor=DipperPattern.anchor(new BlockPos(-7,65,-12));
        check(anchor.equals(new Vec3(-6.5,65,-11.5)),"Block-center anchor");
        check(DipperPattern.star(anchor,0,0).equals(new Vec3(-9,66.5,1)),"Five-times first footfall");
        check(DipperPattern.DURATION_TICKS==1200,"60 second ritual");
        double[] radius={6.5,6.5,2,1.25,6.5,17,31.25};
        for(int yaw=-720;yaw<=720;yaw+=15)for(int i=0;i<7;i++){
            Vec3 p=DipperPattern.star(anchor,yaw,i).subtract(anchor);
            check(Math.abs(p.horizontalDistanceSqr()-radius[i]*25)<1e-8,"Five-times rotated star distance");
            check(p.y==1.5,"Star altitude");
        }
        for(int phase=0;phase<3;phase++)for(int step=0;step<=7;step++)for(int age:new int[]{0,20,30,65536,Integer.MAX_VALUE}){
            var p=new DipperVisualPacket(UUID.randomUUID(),new ResourceLocation("minecraft","overworld"),
                new Vec3(29999995.125,-55.5,-29999980.625),-179.75F,123456789L,step,phase,age);
            var buf=new FriendlyByteBuf(Unpooled.buffer());
            try{DipperVisualPacket.encode(p,buf);check(DipperVisualPacket.decode(buf).equals(p),"Packet round trip");
                check(buf.readableBytes()==0,"Trailing bytes");}finally{buf.release();}
        }
        Fade f=new Fade();f.start=100;f.phaseStart=200;
        check(f.strength(100)==0&&f.strength(108)==.5F&&f.strength(116)==1,"Activation fade");
        f.phase=1;check(f.strength(200)==1&&f.strength(215)==.5F&&f.strength(230)==0,"30-tick completion");
        f.phase=2;check(f.strength(200)==1&&f.strength(204)==.5F&&f.strength(208)==0,"8-tick cancellation");
        System.out.println("PASS: 679 rotated stars, 120 packet round trips, activation/completion/cancel fade boundaries");
    }
}
'''.replace('FADE_BODY',fade)
(OUT/'DipperRuntimeChecks.java').write_text(header+main+pattern+packet,encoding='utf-8')
assets=ROOT/'src/main/resources/assets/wuxingxiantu'
model=json.loads((assets/'models/block/soul_healing_room.json').read_text())
assert [model['textures'][side].rsplit('_',1)[-1] for side in ['north','south','east','west','up','down']]==['front','back','left','right','top','bottom']
for name in ['dipper_ritual','dipper_ritual_post']:
    shader=json.loads((assets/f'shaders/core/{name}.json').read_text())
    assert shader['attributes']==['Position','UV0','Color']
    assert shader['blend']['srcrgb']=='srcalpha'
    assert shader['blend']['dstrgb']=='1-srcalpha'
    declared={uniform['name'] for uniform in shader['uniforms']}|{sampler['name'] for sampler in shader['samplers']}
    glsl='\n'.join((assets/f'shaders/core/{name}.{ext}').read_text() for ext in ['vsh','fsh'])
    assert set(re.findall(r'uniform \w+ (\w+);',glsl))==declared
assert 'sendParticles' not in (JAVA/'divineart/DipperEffects.java').read_text().split('public static void emitAura')[0]
print('PASS: six-face mapping and matching atlas shaders; generated actual-source CPU harness')
