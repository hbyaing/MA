from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
for locale in ('zh_cn','en_us'):
    path=root/f'src/main/resources/assets/wuxingxiantu/lang/{locale}.json'
    text=path.read_text(encoding='utf-8');data=json.loads(text);key='divine.wuxingxiantu.function.ta_gang_bu_dou';old=data[key]
    new='踏罡七星，在60秒内依次走过七星改变晴天、雨天与雷暴；七星步阵范围扩大。释放消耗%1$s灵力。' if locale=='zh_cn' else 'Walk the seven stars within 60 seconds to change clear weather, rain and thunder; expanded star formation. Activation costs %1$s mana.'
    text=text.replace(json.dumps(old,ensure_ascii=False),json.dumps(new,ensure_ascii=False));path.write_text(text,encoding='utf-8')
print('Dipper duration descriptions: 60 seconds')
