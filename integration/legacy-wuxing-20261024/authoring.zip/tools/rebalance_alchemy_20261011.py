"""Realm-based startup costs, differentiated quality investment, and slower alchemy."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
mana=[100,300,1000,3200,10000,32000,100000,320000,1000000]
base={'aura_pill':45,'golden_wound_pill':50,'bigu_pill':60,'clear_heart_pill':60,
      'gathering_pill':90,'foundation_pill':120,'continue_vein_pill':90,
      'diamond_body_pill':100,'berserk_pill':75,'gale_pill':60,'profound_water_pill':90,
      'breakthrough_pill':150,'tribulation_pill':180,'calming_pill':120,
      'root_awakening_pill':180,'physique_reset_pill':240}
grades=['LOW','MID','HIGH','PERFECT']
rows=[]
for path in sorted((root/'src/main/resources/data/wuxingxiantu/recipes').glob('*.json')):
    d=json.loads(path.read_text(encoding='utf-8-sig'))
    if d.get('type')!='wuxingxiantu:alchemy':continue
    pill=d['result']['item'].split(':')[-1]
    grade=grades.index(d.get('result_grade','LOW'))
    realm=d.get('minimum_realm',0)
    if pill=='cultivation_pill':
        tier=d.get('cultivation_tier',0)
        # Furnace progression is independent of random output quality.
        d['furnace_tier']=min(5,tier)
        seconds=60+15*tier
    else: seconds=base[pill]
    seconds=round(seconds*(1+.15*grade))
    fraction=8 if pill in ('root_awakening_pill','physique_reset_pill') else 6 if pill in ('cultivation_pill','foundation_pill','breakthrough_pill','tribulation_pill','calming_pill') else 4
    d['aura_cost']=max(2,round(mana[realm]*fraction/100))
    d['time']=seconds*20
    d['fire_essence_multiplier']=round((.5+.25*grade)*(1.5 if fraction>=6 else 1),3)
    path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    rows.append({'recipe':path.stem,'pill':pill,'investment':d.get('result_grade','LOW'),'realm':realm,
                 'furnace':d['furnace_tier'],'seconds':seconds,'startup_mana':d['aura_cost'],
                 'materials':d['ingredients'],'essence_multiplier':d['fire_essence_multiplier']})
report=root/'reports/alchemy-balance-20261011'
report.mkdir(parents=True,exist_ok=True)
(report/'recipes.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'Rebalanced {len(rows)} recipes')
for locale, text in [('zh_cn','恢复最大生命的20% / 35% / 50% / 65%（下品至极品）'),
                     ('en_us','Restores 20% / 35% / 50% / 65% of maximum health (Low to Perfect)')]:
    path=root/f'src/main/resources/assets/wuxingxiantu/lang/{locale}.json'
    d=json.loads(path.read_text(encoding='utf-8-sig'))
    d['pill.wuxingxiantu.effect.golden_wound_pill']=text
    path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
