"""Extract navigation states and icons from the supplied reference."""
from pathlib import Path
from PIL import Image, ImageDraw
import hashlib,json,shutil
root=Path(__file__).resolve().parents[1]
source=Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-5b3bc4bd-f72d-4d08-bca3-3b94113bb557.png')
archive=root/'source-assets/navigation-states-20261011'
runtime=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/navigation'
archive.mkdir(parents=True,exist_ok=True);runtime.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,archive/'reference-original.png')
im=Image.open(source).convert('RGBA')
sx,sy=im.width/683,im.height/2048
def crop(box):return im.crop(tuple(round(v*(sx if i%2==0 else sy)) for i,v in enumerate(box)))
def save(name,im):
    im.save(runtime/(name+'.png'))
    blur='true' if name.endswith('_frame') else 'false'
    (runtime/(name+'.png.mcmeta')).write_text('{"texture":{"blur":'+blur+',"clamp":true}}')
states={'selected':(110,213,578,447),'hover':(110,471,578,705),'normal':(110,740,578,974)}
for name,box in states.items():
    frame=crop(box).resize((512,256),Image.Resampling.LANCZOS)
    # Keep the supplied border and its glow. Delete every sample icon and label.
    for y in range(256):
        for x in range(512):
            r,g,b,a=frame.getpixel((x,y))
            # Extract the gold artwork, rather than retaining screenshot scenery.
            alpha=max(0,min(255,round(min(r-75,(r-b)*2.5)*2))) if r>120 and r>g and g-b>20 and r-b>45 else 0
            frame.putpixel((x,y),(r,g,b,alpha) if alpha else (0,0,0,0))
            if 44<x<468 and 28<y<228:frame.putpixel((x,y),(0,0,0,0))
            if name=='normal' and y>=244:frame.putpixel((x,y),(0,0,0,0))
    # The top-right ornament is authoritative for all four corners.
    right=frame.crop((256,0,512,128))
    top=Image.new('RGBA',(512,128))
    top.paste(right.transpose(Image.Transpose.FLIP_LEFT_RIGHT),(0,0))
    top.paste(right,(256,0))
    frame=Image.new('RGBA',(512,256))
    frame.paste(top,(0,0))
    frame.paste(top.transpose(Image.Transpose.FLIP_TOP_BOTTOM),(0,128))
    # Keep the straight strokes uniform and thin; linear filtering prevents gaps.
    lineY=max(range(8,25),key=lambda y:sum(frame.getpixel((x,y))[3] for x in range(60,452)))
    color=max((frame.getpixel((x,lineY)) for x in range(60,452)),key=lambda p:p[3])
    draw=ImageDraw.Draw(frame)
    draw.rectangle((44,lineY-1,467,lineY+1),fill=color)
    draw.rectangle((44,255-lineY-1,467,255-lineY+1),fill=color)
    save(name+'_frame',frame)
patches={'selected':(370,249,475,277),'hover':(370,499,475,527),'normal':(370,771,475,799)}
for name,box in patches.items():save(name+'_background',crop(box).resize((128,32),Image.Resampling.LANCZOS))
def gold(name,box,size):
    out=crop(box)
    for y in range(out.height):
        for x in range(out.width):
            r,g,b,a=out.getpixel((x,y))
            alpha=max(0,min(255,round(min(r-55,(r-b)*2.5)*2))) if r>g and g>b else 0
            out.putpixel((x,y),(r,g,b,alpha))
    save(name,out.resize(size,Image.Resampling.LANCZOS))
gold('separator',(148,448,540,471),(512,32))
gold('center_rule',(337,284,360,380),(32,128))
icons={'inventory':(152,270,331,402),'vision':(150,503,343,681),'arts':(153,780,337,931),
       'sword':(158,1023,341,1195),'advancements':(167,1286,335,1448),'settings':(172,1541,339,1705)}
for name,box in icons.items():
    # Fit without changing the supplied icon's aspect ratio.
    out=crop(box)
    for y in range(out.height):
        for x in range(out.width):
            r,g,b,a=out.getpixel((x,y))
            alpha=max(0,min(255,round(min(r-55,(r-b)*2.5)*2))) if r>g and g>b else 0
            out.putpixel((x,y),(r,g,b,alpha))
    out.thumbnail((128,128),Image.Resampling.LANCZOS)
    square=Image.new('RGBA',(128,128));square.alpha_composite(out,((128-out.width)//2,(128-out.height)//2))
    save('icon_'+name,square)
(archive/'manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'states':list(states),'sample_labels_removed':True},indent=2))
print('Extracted 3 states, 6 icons, and shared decorations')
