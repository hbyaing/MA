"""Recolor vanilla soul flame without changing pixels, alpha or animation metadata."""
from pathlib import Path
import io, json, zipfile
from PIL import Image

root = Path(__file__).resolve().parents[1]
source = Path.home() / '.gradle/caches/forge_gradle/minecraft_repo/versions/1.20.1/client.jar'
with zipfile.ZipFile(source) as archive:
    name = 'assets/minecraft/textures/particle/soul_fire_flame.png'
    original = Image.open(io.BytesIO(archive.read(name))).convert('RGBA')
    gold = original.copy()
    # Blue soul-fire brightness becomes warm gold edges and ivory-white cores.
    def palette(pixel):
        r, g, b, a = pixel
        if not a:
            return pixel
        heat = max(r, g, b) / 255
        core = r / 255
        return (round(255 * heat), round(heat * (184 + 65 * core)),
                round(heat * (73 + 156 * core)), a)
    gold.putdata([palette(p) for p in original.getdata()])
    target = root / 'src/main/resources/assets/wuxingxiantu/textures/particle/golden_soul_flame.png'
    gold.save(target)
    metadata = name + '.mcmeta'
    if metadata in archive.namelist():
        target.with_suffix('.png.mcmeta').write_bytes(archive.read(metadata))
    assert gold.size == original.size
    assert gold.getchannel('A').tobytes() == original.getchannel('A').tobytes()
    print('Soul flame shape/alpha preserved:', gold.size)

shader = root / 'src/main/resources/assets/wuxingxiantu/shaders/core/world_volume.json'
data = json.loads(shader.read_text(encoding='utf-8'))
if not any(u['name'] == 'LightningFlash' for u in data['uniforms']):
    data['uniforms'].append({'name': 'LightningFlash', 'type': 'float', 'count': 4, 'values': [0, 0, 0, -1]})
shader.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
