"""Render original, coordinate-defined UI fittings at 4x with supersampling.
No generated screenshot text or item pixels are baked into the fittings.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import math, json
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/alchemy_concept'
OUT.mkdir(parents=True,exist_ok=True)
S=16
GOLD='#e8cb83'
LIGHT='#fff0b7'
SHADOW='#5c4829'
def canvas(w,h):return Image.new('RGBA',(w*S,h*S))
def path(d,points,fill,width=.35):
    d.line([(round(x*S),round(y*S)) for x,y in points],fill=fill,width=max(1,round(width*S)),joint='curve')
def rect(d,box,fill):d.rectangle(tuple(round(v*S) for v in box),fill=fill)
def outline(d,w,h,inset,cut,color,width):
    a=inset;b=w-inset;c=h-inset
    path(d,[(a+cut,a),(b-cut,a),(b,a+cut),(b,c-cut),(b-cut,c),(a+cut,c),(a,c-cut),(a,a+cut),(a+cut,a)],color,width)
def save(im,name):
    im=im.resize((im.width//4,im.height//4),Image.Resampling.LANCZOS)
    im.save(OUT/f'{name}.png')
    (OUT/f'{name}.png.mcmeta').write_text('{"texture":{"blur":true,"clamp":true}}')
def panel():
    im=canvas(32,32);d=ImageDraw.Draw(im)
    outline(d,32,32,.6,2.4,SHADOW,1.1)
    outline(d,32,32,.6,2.4,GOLD,.48)
    outline(d,32,32,1.65,1.7,'#9a804a',.26)
    # One compact scroll motif, identically reflected into each corner.
    motif=[(2,7),(2,4.1),(2.5,2.9),(3.5,2.2),(4.7,2),(7,2)]
    spiral=[]
    for i in range(85):
        t=i/84;angle=math.radians(-90+480*t);radius=2.05*(1-t)+.28*t
        spiral.append((4.5+math.cos(angle)*radius,4.55+math.sin(angle)*radius))
    for fx,fy in [(False,False),(True,False),(False,True),(True,True)]:
        path(d,[(32-x if fx else x,32-y if fy else y) for x,y in motif],LIGHT,.32)
        path(d,[(32-x if fx else x,32-y if fy else y) for x,y in spiral],GOLD,.32)
    save(im,'panel')
def slot(name,machine):
    im=canvas(18,18);d=ImageDraw.Draw(im)
    pts=[(2,.7),(16,.7),(17.3,2),(17.3,16),(16,17.3),(2,17.3),(.7,16),(.7,2)]
    d.polygon([(x*S,y*S) for x,y in pts],fill='#091922')
    outline(d,18,18,.7,1.3,LIGHT if machine else '#a58c57',.6 if machine else .32)
    outline(d,18,18,1.7,.9,'#584b32',.25)
    path(d,[(2.6,2.2),(6,2.2)],LIGHT if machine else '#8e7954',.3)
    path(d,[(12,15.8),(15.4,15.8)],'#826b3f',.25)
    save(im,name)
def button(name,gold=False,selected=False):
    im=canvas(64,24);d=ImageDraw.Draw(im)
    # Paint beneath the entire rail, then clip once to its outer silhouette.
    # An inset rectangle leaves a visible crack between the fill and bevel.
    for y in range(24*S):
        t=max(0,min(1,(y/S-2)/20))
        top=(244,219,143) if gold else (33,63,72) if selected else (23,44,55)
        bottom=(179,129,47) if gold else (11,29,38)
        col=tuple(round(a+(b-a)*t) for a,b in zip(top,bottom))+(255,)
        d.line((0,y,64*S,y),fill=col)
    outline(d,64,24,.7,2.5,SHADOW,.95)
    outline(d,64,24,.7,2.5,LIGHT if gold or selected else GOLD,.5)
    outline(d,64,24,2.1,1.7,'#a88949' if gold else '#53664f',.3)
    for fx in [False,True]:
        # Keep corner engraving inside the fixed four-GUI-pixel slice.
        points=[(2,3.8),(2,3),(3,2),(3.8,2)]
        path(d,[(64-x if fx else x,y) for x,y in points],LIGHT if gold else '#c8ac6e',.27)
    path(d,[(5,3),(59,3)],'#fff0b2' if gold else '#7d794e',.25)
    mask=Image.new('L',im.size);md=ImageDraw.Draw(mask)
    md.polygon([(x*S,y*S) for x,y in [(3,.4),(61,.4),(63.6,3),(63.6,21),(61,23.6),(3,23.6),(.4,21),(.4,3)]],fill=255)
    im.putalpha(Image.composite(im.getchannel('A'),Image.new('L',im.size),mask))
    save(im,name)

def bar(name,top,bottom,border=False):
    im=canvas(64,12);d=ImageDraw.Draw(im)
    if top:
        for y in range(12*S):
            t=y/(12*S-1)
            d.line((0,y,64*S,y),fill=tuple(round(a+(b-a)*t) for a,b in zip(top,bottom))+(255,))
        mask=Image.new('L',im.size);md=ImageDraw.Draw(mask)
        md.polygon([(x*S,y*S) for x,y in [(2.5,.5),(61.5,.5),(63.5,2.5),(63.5,9.5),(61.5,11.5),(2.5,11.5),(.5,9.5),(.5,2.5)]],fill=255)
        im.putalpha(Image.composite(im.getchannel('A'),Image.new('L',im.size),mask))
    if border:
        outline(d,64,12,.5,2,GOLD,.4)
        outline(d,64,12,1.2,1.6,'#675630',.23)
        path(d,[(3,1.6),(61,1.6)],'#f0d79d',.2)
    save(im,name)

def progress_backing():
    im=canvas(64,12);d=ImageDraw.Draw(im)
    d.polygon([(x*S,y*S) for x,y in [(2,.5),(62,.5),(63.5,2),(63.5,10),(62,11.5),(2,11.5),(.5,10),(.5,2)]],fill='#0b2029')
    outline(d,64,12,.5,1.5,'#766443',.3)
    save(im,'progress_backing')

def divider():
    im=canvas(128,6);d=ImageDraw.Draw(im)
    # A fine continuous rail, tapered in brightness, with mirrored cloud ends.
    for x in range(7*S,121*S):
        t=(x/S-7)/114;alpha=round(125+90*math.sin(math.pi*t))
        d.line((x,round(3*S),x,round(3.3*S)),fill=(226,195,123,alpha))
    motif=[]
    for i in range(100):
        t=i/99;angle=math.radians(90+450*t);radius=1.25*(1-t)+.12
        motif.append((3+math.cos(angle)*radius,3+math.sin(angle)*radius))
    for flip in (False,True):
        transform=lambda pts:[(128-x if flip else x,y) for x,y in pts]
        path(d,transform(motif),GOLD,.3)
        path(d,transform([(1,4.4),(4,4.4),(5.5,3.2),(7.5,3.2)]),GOLD,.3)
    save(im,'divider')

def curve(d,control,color,width=.35):
    points=[]
    for i in range(97):
        t=i/96;a=1-t
        points.append(tuple(a*a*a*control[0][axis]+3*a*a*t*control[1][axis]+3*a*t*t*control[2][axis]+t*t*t*control[3][axis] for axis in (0,1)))
    path(d,points,color,width)

def curl(d,cx,cy,radius,phase,color,width=.35):
    points=[]
    for i in range(110):
        t=i/109;angle=phase+t*math.pi*2.5;r=radius*(1-t)+.2
        points.append((cx+math.cos(angle)*r,cy+math.sin(angle)*r))
    path(d,points,color,width)

def header_linework():
    # Original flat line ornaments: the same matte palette and stroke weight
    # as the panel rails, with no embossed fill, glow or metallic gradient.
    ink='#c7ad73';subtle='#8e774b'
    im=canvas(48,23);d=ImageDraw.Draw(im)
    curve(d,[(1.8,20.5),(1.2,9.5),(5,3),(16,2.7)],ink,.4)
    curve(d,[(16,2.7),(22,2.8),(28,3.2),(46,2.7)],subtle,.3)
    curve(d,[(2.2,16.5),(4.5,11.5),(4,5.8),(11.5,4.3)],ink,.35)
    curl(d,7.3,7.2,3.2,-math.pi/2,ink,.38)
    curl(d,3.7,13.6,1.7,math.pi/2,ink,.32)
    curl(d,12.2,3.2,1.6,0,ink,.3)
    curve(d,[(9.3,9.5),(14,10),(14,5),(19,4.8)],subtle,.3)
    save(im,'header_corner')
    im=canvas(22,7);d=ImageDraw.Draw(im)
    curl(d,4.6,3.0,1.9,-math.pi/2,ink,.32)
    curl(d,2.1,4.4,1.1,math.pi/2,ink,.3)
    curl(d,8.7,4.7,1.25,0,ink,.3)
    curve(d,[(1,5.7),(5,7),(7.5,5.4),(11,5.5)],ink,.32)
    curve(d,[(11,5.5),(14,6.3),(18,6.1),(21,5.7)],subtle,.3)
    save(im,'header_flourish')
def preview():
    im=canvas(28,28);d=ImageDraw.Draw(im)
    d.polygon([(x*S,y*S) for x,y in [(4,.8),(24,.8),(27.2,4),(27.2,24),(24,27.2),(4,27.2),(.8,24),(.8,4)]],fill='#0b232c')
    outline(d,28,28,.8,3.2,'#89d7db',.55)
    outline(d,28,28,2,2.8,'#345e66',.32)
    outline(d,28,28,5.2,1.5,GOLD,.55)
    outline(d,28,28,6.2,1.1,'#75613a',.28)
    save(im,'preview')
def formation():
    im=canvas(128,128);d=ImageDraw.Draw(im);cx=cy=64
    for radius,col,width in [(29,'#82703f',.32),(31.5,'#bf9e56',.42),(47,'#8d7646',.3),(50,'#e7c477',.6),(52.5,'#9e8247',.32)]:
        d.ellipse(tuple(round(v*S) for v in (cx-radius,cy-radius,cx+radius,cy+radius)),outline=col,width=round(width*S))
    for i in range(64):
        angle=2*math.pi*i/64;ra=48.2;rb=49.2
        path(d,[(cx+math.cos(angle)*ra,cy+math.sin(angle)*ra),(cx+math.cos(angle)*rb,cy+math.sin(angle)*rb)],'#b39150',.22)
    # Inner medallion engraving stays beneath the native preview.
    for i in range(8):
        angle=math.pi*i/4;r=31.5;ux,uy=math.cos(angle),math.sin(angle);tx,ty=-uy,ux
        diamond=[(cx+ux*(r-1.2),cy+uy*(r-1.2)),(cx+ux*r+tx*.75,cy+uy*r+ty*.75),
                 (cx+ux*(r+1.2),cy+uy*(r+1.2)),(cx+ux*r-tx*.75,cy+uy*r-ty*.75)]
        path(d,diamond+[diamond[0]],'#d6b878',.25)
        curl=[]
        for j in range(70):
            t=j/69;phase=math.pi*2*t;radius=3.4*(1-t)+.4
            curl.append((cx+ux*23+math.cos(phase)*radius,cy+uy*23+math.sin(phase)*radius))
        path(d,curl,'#25424a',.25)
    # Labels and slots are native; strokes occupy the gaps between slots.
    for i in range(8):
        phase=math.pi*i/4+math.pi/8
        ux,uy=math.cos(phase),math.sin(phase);tx,ty=-uy,ux
        for row in range(3):
            r=40.5+(row-1)*1.6
            intervals=[(-3,3)] if i&(1<<row) else [(-3,-.7),(.7,3)]
            for a,b in intervals:path(d,[(cx+ux*r+tx*a,cy+uy*r+ty*a),(cx+ux*r+tx*b,cy+uy*r+ty*b)],'#d5b76c',.45)
    save(im,'formation')
def backing(name,w,h,strength,fade):
    im=canvas(w,h);d=ImageDraw.Draw(im)
    for x in range(w*S):
        edge=min(1,x/(fade*S),(w*S-1-x)/(fade*S))
        for y in range(h*S):
            alpha=round(strength*edge*(1-.5*y/(h*S)))
            d.point((x,y),fill=(7,25,35,alpha))
    save(im,name)
panel();slot('material_slot',True);slot('inventory_slot',False);preview()
button('button');button('button_selected',selected=True);button('button_gold',gold=True);formation()
backing('header_shadow',180,18,210,24);backing('section_shadow',104,12,160,16)
bar('bar_track',(12,31,40),(4,15,23),True)
bar('bar_border',None,None,True)
bar('bar_gold',(238,209,138),(160,111,39))
bar('bar_spirit',(140,218,224),(45,119,137))
bar('bar_danger',(242,168,112),(153,68,50))
progress_backing();divider();header_linework()
print('Built nineteen original UI fittings; 4x assets, 16x supersampling')
