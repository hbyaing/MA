"""Package the approved native SVG preview into fixed corners and extensible rails."""
from pathlib import Path
from PIL import Image
import json
root=Path(__file__).resolve().parents[1]
source=root/'source-assets/outer-frame-generated-20261011/frame-preview-v2.png'
folder=root/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/outer_frame_v2'
folder.mkdir(parents=True,exist_ok=True)
im=Image.open(source).convert('RGBA')
def native_piece(box):
    piece=im.crop(box)
    # Preserve vector resolution for the screen's scaled GUI, with a solid
    # bright stroke core and antialiased silhouette instead of 13px blocks.
    piece.putalpha(piece.getchannel('A').point(lambda a:0 if a<6 else min(255,round(a*1.5))))
    return piece
corner=native_piece((8,5,47,44))
top=native_piece((48,5,248,14))
left=native_piece((8,45,17,245))
pieces={'tl':corner,'tr':native_piece((1413,5,1452,44)),
        'bl':corner.transpose(Image.Transpose.FLIP_TOP_BOTTOM),
        'br':corner.transpose(Image.Transpose.FLIP_LEFT_RIGHT).transpose(Image.Transpose.FLIP_TOP_BOTTOM),
        'top':top,'bottom':top.transpose(Image.Transpose.FLIP_TOP_BOTTOM),
        'left':left,'right':left.transpose(Image.Transpose.FLIP_LEFT_RIGHT)}
# Native vector junctions must use the same stroke profile as their straight
# rails; isolated corner path endpoints otherwise rasterize at a different alpha.
for name,vertical,horizontal in [('tl','left','top'),('tr','right','top'),('bl','left','bottom'),('br','right','bottom')]:
    tile=pieces[name]
    for row in range(3):
        yy=38-row if name in ('tl','tr') else row
        for offset in range(9):
            xx=offset if name in ('tl','bl') else 30+offset
            tile.putpixel((xx,yy),pieces[vertical].getpixel((offset,100)))
    for col in range(3):
        xx=38-col if name in ('tl','bl') else col
        for offset in range(9):
            yy=offset if name in ('tl','tr') else 30+offset
            tile.putpixel((xx,yy),pieces[horizontal].getpixel((100,offset)))
for name,piece in pieces.items():
    piece.save(folder/(name+'.png'))
    (folder/(name+'.png.mcmeta')).write_text('{"texture":{"blur":true,"clamp":true}}')
# Same sizes and source pieces as the Java renderer, at a representative panel size.
width,height=1440,882
preview=Image.new('RGBA',(width,height),'#10212A')
placements=[('top',39,0,width-78,9),('bottom',39,height-9,width-78,9),
            ('left',0,39,9,height-78),('right',width-9,39,9,height-78),
            ('tl',0,0,39,39),('tr',width-39,0,39,39),
            ('bl',0,height-39,39,39),('br',width-39,height-39,39,39)]
for name,x,y,w,h in placements:
    preview.alpha_composite(pieces[name].resize((w,h),Image.Resampling.BILINEAR),(x,y))
preview.save(source.parent/'installed-frame-preview.png')
(source.parent/'packaged-v2.json').write_text(json.dumps({'source':source.name,'pieces':{k:v.size for k,v in pieces.items()},'gui_corner':13,'gui_edge':3,'scope':'main UI outer frame only'},indent=2))
print('Packaged approved corners and rails; transparency preserved')
