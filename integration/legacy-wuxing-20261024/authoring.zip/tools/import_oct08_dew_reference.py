"""Import the supplied three-stage dew flower sheet; no build or installation."""
from pathlib import Path
from PIL import Image
import json
root=Path(__file__).resolve().parents[1]
assets=root/'src/main/resources/assets/wuxingxiantu'
source=Image.open(root/'source-assets/oct08-gameplay-references/dew_drop_flower.png').convert('RGBA')
w,h=source.size
preview=Image.new('RGBA',(480,160),(35,39,42,255))
for i,(stage,left,right,height) in enumerate([('young',0,.32,17),('growing',.32,.65,24),('mature',.65,1,30)]):
    im=source.crop((round(w*left),0,round(w*right),h))
    im.putdata([(r,g,b,0 if max(r,g,b)<14 or a<64 else 255) for r,g,b,a in im.getdata()])
    im=im.crop(im.getbbox())
    width=min(30,max(1,round(im.width*height/im.height)))
    im=im.resize((width,height),Image.Resampling.NEAREST)
    canvas=Image.new('RGBA',(32,32));canvas.alpha_composite(im,((32-width)//2,32-height))
    canvas.save(assets/f'textures/block/dew_drop_flower_{stage}.png')
    suffix=['_low','_mid',''][i]
    p=assets/f'models/block/dew_drop_flower{suffix}.json'
    d=json.loads(p.read_text(encoding='utf-8'));d['textures']['cross']=f'wuxingxiantu:block/dew_drop_flower_{stage}'
    p.write_text(json.dumps(d,indent=2),encoding='utf-8')
    if i==2:canvas.save(assets/'textures/item/dew_drop_flower.png')
    preview.alpha_composite(canvas.resize((128,128),Image.Resampling.NEAREST),(i*160+16,16))
p=root/'reports/dew-vision-20261008/preview.png';p.parent.mkdir(parents=True,exist_ok=True);preview.save(p)
print('Imported dew flower: three transparent 32x32 stages and mature item.')
