"""Export the approved imagegen texture atlas into Minecraft's six face assets."""
from pathlib import Path
import json,shutil,hashlib
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parents[1]
out=root/'deliverables/task-20261015-herb-table-review';out.mkdir(parents=True,exist_ok=True)
src=Path('C:/Users/Nostzephert/.codex/generated_images/01a13ad0-66f9-7730-9197-507bb5d273ab/exec-b687ddd0-5e36-4bb0-aa1c-768b9590d690.png')
shutil.copy2(src,out/'灵药加工台-生产图集.png')
atlas=Image.open(src).convert('RGBA');w,h=atlas.size;assert w*2==h*3
assets=root/'src/main/resources/assets/wuxingxiantu';data=root/'src/main/resources/data'
faces=['top','front','left','right','back','bottom'];labels=['顶面','正面','左侧','右侧','背面','底面']
preview=Image.new('RGB',(6*144,176),(24,29,37));draw=ImageDraw.Draw(preview);font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',16)
records=[]
for i,name in enumerate(faces):
 x=i%3*w//3
 # The generated atlas places the horizontal seam at y=500 and ends the second
 # row at y=1012; trim that seam/footer instead of sampling adjacent faces.
 y0,y1=(0,500) if i<3 else (500,1012)
 texture=atlas.crop((x,y0,x+w//3,y1)).resize((64,64),Image.Resampling.NEAREST)
 dest=assets/'textures/block'/f'herb_processing_table_{name}.png';texture.save(dest)
 texture.save(out/f'{name}-64px.png')
 preview.paste(texture.resize((128,128),Image.Resampling.NEAREST),(i*144+8,8));draw.text((i*144+8,144),labels[i],font=font,fill='white')
 records.append({'face':name,'sourceBox':[x,y0,x+w//3,y1],'size':[64,64],'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
preview.save(out/'灵药加工台-最终六面贴图.png')
def write(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
write(out/'贴图导出记录.json',{'source':str(src),'sourceSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'sourceDimensions':[w,h],'export':'3x2 atlas split; nearest-neighbor 64x64; no geometry added','faces':records})
write(assets/'models/block/herb_processing_table.json',{'parent':'minecraft:block/cube','textures':{
 'particle':'wuxingxiantu:block/herb_processing_table_front','up':'wuxingxiantu:block/herb_processing_table_top','down':'wuxingxiantu:block/herb_processing_table_bottom',
 'north':'wuxingxiantu:block/herb_processing_table_front','south':'wuxingxiantu:block/herb_processing_table_back','west':'wuxingxiantu:block/herb_processing_table_left','east':'wuxingxiantu:block/herb_processing_table_right'}})
write(assets/'models/item/herb_processing_table.json',{'parent':'wuxingxiantu:block/herb_processing_table'})
write(assets/'blockstates/herb_processing_table.json',{'variants':{f'facing={direction}':{'model':'wuxingxiantu:block/herb_processing_table','y':angle} for direction,angle in [('north',0),('east',90),('south',180),('west',270)]}})
write(data/'wuxingxiantu/loot_tables/blocks/herb_processing_table.json',{'type':'minecraft:block','pools':[{'rolls':1,'conditions':[{'condition':'minecraft:survives_explosion'}],'entries':[{'type':'minecraft:item','name':'wuxingxiantu:herb_processing_table'}]}]})
write(data/'wuxingxiantu/recipes/herb_processing_table.json',{'type':'minecraft:crafting_shaped','pattern':['SSS','CTC','PPP'],'key':{'S':{'item':'minecraft:smooth_stone_slab'},'C':{'item':'minecraft:copper_ingot'},'T':{'item':'minecraft:crafting_table'},'P':{'tag':'minecraft:planks'}},'result':{'item':'wuxingxiantu:herb_processing_table'}})
p=data/'minecraft/tags/blocks/mineable/axe.json';tag=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'replace':False,'values':[]}
if 'wuxingxiantu:herb_processing_table' not in tag['values']:tag['values'].append('wuxingxiantu:herb_processing_table')
write(p,tag)
write(data/'wuxingxiantu/advancements/recipes/herb_processing_table.json',{'parent':'minecraft:recipes/root','criteria':{'has_stone_slab':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':['minecraft:smooth_stone_slab']}]}},'has_the_recipe':{'trigger':'minecraft:recipe_unlocked','conditions':{'recipe':'wuxingxiantu:herb_processing_table'}}},'requirements':[['has_stone_slab','has_the_recipe']],'rewards':{'recipes':['wuxingxiantu:herb_processing_table']}})
for lang in ('zh_cn','en_us'):
 p=assets/'lang'/f'{lang}.json';v=json.loads(p.read_text(encoding='utf-8'));v.update({
 'block.wuxingxiantu.herb_processing_table':'灵药加工台' if lang=='zh_cn' else 'Spirit Herb Processing Table',
 'tooltip.wuxingxiantu.intro.herb_processing_table.category':'灵药工坊' if lang=='zh_cn' else 'Herbal Workshop',
 'tooltip.wuxingxiantu.intro.herb_processing_table.lore':'青铜护角，石纹药案，为灵药工坊添一处雅致。' if lang=='zh_cn' else 'A stone herb bench with bronze fittings for your herbal workshop.',
 'tooltip.wuxingxiantu.intro.herb_processing_table.action.0':'可合成与摆放的灵药工坊陈设。' if lang=='zh_cn' else 'Craft and place this herbal workshop furnishing.'})
 write(p,v)
print('Exported six 64x64 faces, standard cube assets, acquisition recipe, loot, and translations.')
