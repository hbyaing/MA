param([string]$Stamp = (Get-Date -Format 'yyyyMMdd-HHmmss'), [string]$JarPath)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$delivery = Join-Path $projectRoot 'deliverables'
New-Item -ItemType Directory -Path $delivery -Force | Out-Null
$archivePath = Join-Path $delivery "wuxingxiantu-source-$Stamp.zip"
if (Test-Path -LiteralPath $archivePath) { throw "Output already exists: $archivePath" }
$builtJar = $null
if (![string]::IsNullOrWhiteSpace($JarPath)) { $builtJar = Get-Item -LiteralPath $JarPath }
$excluded = @('build', '.gradle', '.codex', '.git', 'deliverables', 'reports', 'logs')
$contract = Join-Path $projectRoot 'source-assets/contracts/heart_sword_v2_import.json'
if (!(Test-Path -LiteralPath $contract)) { throw 'Missing required heart-sword source contract.' }
$files = @(Get-ChildItem -LiteralPath $projectRoot -Force | Where-Object Name -NotIn $excluded | ForEach-Object {
    if ($_.PSIsContainer) { Get-ChildItem -LiteralPath $_.FullName -Recurse -File -Force }
    else { $_ }
} | Where-Object { $_.FullName -notmatch '[\\/]__pycache__[\\/]' })
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($archivePath, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($projectRoot.Length + 1).Replace('\', '/')
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName,
            "wuxingxiantu-source/$relative", [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $zip.Dispose() }
$zip = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($zip.Entries.Count -ne $files.Count) { throw 'Source ZIP entry count mismatch' }
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($projectRoot.Length + 1).Replace('\', '/')
        $entry = $zip.GetEntry("wuxingxiantu-source/$relative")
        if ($null -eq $entry -or $entry.Length -ne $file.Length) { throw "Missing or truncated: $relative" }
        $stream = $entry.Open()
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            $digest = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '')
            if ($digest -ne (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash) {
                throw "ZIP content differs: $relative"
            }
        } finally { $stream.Dispose(); $sha.Dispose() }
    }
} finally { $zip.Dispose() }
if ($null -ne $builtJar) {
    $deliveryJar = Join-Path $delivery ($builtJar.BaseName + "-$Stamp.jar")
    if (Test-Path -LiteralPath $deliveryJar) { throw "Output already exists: $deliveryJar" }
    Copy-Item -LiteralPath $builtJar.FullName -Destination $deliveryJar
    Get-FileHash -LiteralPath $deliveryJar -Algorithm SHA256 | Format-List
}
Write-Output "Verified $($files.Count) source ZIP entries against SHA256 of local files."
Get-Item -LiteralPath $archivePath | Select-Object FullName, Length | Format-List
Get-FileHash -LiteralPath $archivePath -Algorithm SHA256 | Format-List
