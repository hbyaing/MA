"""Import the shared heart-method texture without changing item behavior."""
from pathlib import Path
import json
import shutil
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'source-assets/heart-method-20261008'
OUT.mkdir(parents=True, exist_ok=True)
source = OUT / 'reference-original.png'
if not source.exists():
    shutil.copy2('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-a362a498-2a3b-4db4-b2e5-db543785abb5.png', source)
original = Image.open(source).convert('RGBA')
assert original.getchannel('A').getextrema() == (0, 255)
bounds = original.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
icon = original.crop(bounds)
icon.thumbnail((60, 60), Image.Resampling.NEAREST)
texture = Image.new('RGBA', (64, 64))
texture.paste(icon, ((64-icon.width)//2, (64-icon.height)//2))
target = ROOT / 'src/main/resources/assets/wuxingxiantu/textures/item/heart_method_scroll.png'
backup = OUT / 'before-heart_method_scroll.png'
if target.exists() and not backup.exists():
    shutil.copy2(target, backup)
texture.save(target)
models = list((ROOT / 'src/main/resources/assets/wuxingxiantu/models/item').glob('heart_method*.json'))
assert len(models) == 11
for model in models:
    assert json.loads(model.read_text(encoding='utf-8'))['textures']['layer0'] == 'wuxingxiantu:item/heart_method_scroll'
alpha = texture.getchannel('A')
assert alpha.getextrema() == (0, 255)
assert all(alpha.crop(box).getextrema() == (0, 0) for box in [(0,0,64,1),(0,63,64,64),(0,0,1,64),(63,0,64,64)])
preview = Image.new('RGBA', (320,320))
draw = ImageDraw.Draw(preview)
for y in range(0,320,20):
    for x in range(0,320,20):
        draw.rectangle((x,y,x+19,y+19), fill=(205,205,205,255) if (x//20+y//20)%2 else (240,240,240,255))
preview.alpha_composite(texture.resize((320,320), Image.Resampling.NEAREST))
preview.save(OUT / 'preview-checkerboard.png')
(OUT / 'manifest.json').write_text(json.dumps({'source_size':original.size,'crop_bounds':bounds,'size':texture.size,'models':len(models),'alpha':alpha.getextrema(),'resampling':'NEAREST'},indent=2),encoding='utf-8')
print('PASS: shared heart-method texture 64x64; 11 model references; transparent borders')
