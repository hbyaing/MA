const fs=require('fs'),vm=require('vm'),assert=require('assert');
const elements=new Map();
for(const id of ['texture','stage','tex','keepLeft','keepRight','editStatus','axis','download','importImage','resetEdits','exportTexture','info'])elements.set(id,{value:'',classList:{toggle(){}},parentElement:{prepend(){}},replaceChildren(){this.options=[];this.value=''},options:[],add(o){this.options.push(o);if(this.options.length===1)this.value=o.value},set selectedIndex(i){this.value=this.options[i]?.value||''}});
let saved,exported;
class Canvas{constructor(){this.width=0;this.height=0}getContext(){return {drawImage(src){saved=src.ref},clearRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){}}}toBlob(fn){fn({})}}
const context={Map,console,setTimeout(){},URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}},Image:function(){},Option:function(label,value){this.value=value},document:{createElement(type){return type==='canvas'?new Canvas():{click(){exported=this.download}}}},$:(id)=>elements.get(id),images:new Map(),gpuTextures:new Map(),gl:{deleteTexture(){}},tc:new Canvas().getContext(),draw(){},drawTexture(){},imageFor(ref){return {ref,complete:true,naturalWidth:32,naturalHeight:32}}};
vm.createContext(context);
vm.runInContext(fs.readFileSync('deliverables/plant-workbench-20261010/data.js','utf8')+`;var plant=DATA.plants.find(p=>p.id==='spirit_sprout_grass'),model;
function merge(ref){const m=DATA.models[ref],p=m.parent?merge(m.parent):{};return {...p,...m,textures:{...p.textures,...m.textures}}}
function textureRef(ref){for(let i=0;ref.startsWith('#')&&i<20;i++)ref=model.textures[ref.slice(1)];return ref}`,context);
const viewer=fs.readFileSync('deliverables/plant-workbench-20261010/viewer.js','utf8');
vm.runInContext(viewer.slice(viewer.indexOf('function selectStage()'),viewer.indexOf('function rotate(')),context);
elements.get('stage').value='7';context.selectStage();
vm.runInContext(fs.readFileSync('deliverables/plant-workbench-20261010/editor.js','utf8'),context);
for(const [age,filename] of [[7,'spirit_sprout_grass'],[2,'spirit_sprout_grass_growing'],[0,'spirit_sprout_grass_young'],[3,'spirit_sprout_grass_growing']]){
 elements.get('stage').value=String(age);elements.get('stage').onchange();elements.get('exportTexture').onclick();
 assert.equal(exported,filename+'.png');assert.equal(saved,'wuxingxiantu:block/'+filename);
}
console.log('PASS: mature -> growing -> young -> growing exports actual selected-stage pixels and filename');
