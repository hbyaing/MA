import cn.blockforge.generated.generatedmod.balance.DamageDomainBalance;
import cn.blockforge.generated.generatedmod.balance.DamageDomainBalance.Domain;
import cn.blockforge.generated.generatedmod.balance.RealmBalance;

/** Run against production pure helpers, never a copied formula. */
public final class DomainRealmAudit {
    public static void main(String[] args){
        String[] names={"练气","筑基","金丹","元婴","化神","炼虚","合体","大乘","地仙"};
        System.out.println("境界,灵力上限,业火单目标每秒,业火12目标每秒,异火单目标每秒,万雷单目标每秒");
        for(int r=0;r<9;r++){
            double a=RealmBalance.attack(r)+1;int m=RealmBalance.mana(r);
            System.out.println(names[r]+","+m+","+cost(Domain.FIRE,a,r,m,1)+","+cost(Domain.FIRE,a,r,m,12)+","+cost(Domain.EXOTIC,a,r,m,1)+","+cost(Domain.THUNDER,a,r,m,1));
        }
    }
    private static int cost(Domain d,double a,int r,int m,int n){return DamageDomainBalance.manaCost(d,4,a,r,m,n,true,false);}
}
