"""Extract user-supplied refining UI elements; dynamic values stay in Java."""
from pathlib import Path
from PIL import Image
import json, hashlib, shutil
root=Path(__file__).resolve().parents[1]
source=Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-a5df1823-b249-4ac8-8e19-adce35b7bc4e.png')
archive=root/'source-assets/refining-ui-reference-20261011'
runtime=root/'src/main/resources/assets/wuxingxiantu/textures/gui/refining'
archive.mkdir(parents=True,exist_ok=True);runtime.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,archive/'reference-original.png')
im=Image.open(source).convert('RGBA')
assert im.size==(1545,1018),im.size
sizes={}
def save(name,box,gold=False):
    out=im.crop(box)
    if gold:
        px=out.load()
        for y in range(out.height):
            for x in range(out.width):
                r,g,b,a=px[x,y]
                alpha=max(0,min(255,round(min(r-55,(r-b)*2.5)*2))) if r>g and g>b else 0
                px[x,y]=(r,g,b,alpha)
    if name=='panel':
        # Only keep the actual border and corner ornaments, excluding the
        # close button and sample reason text close to the outside edges.
        px=out.load()
        for y in range(out.height):
            for x in range(out.width):
                edge=x<14 or x>=out.width-14 or y<14 or y>=out.height-14
                corner=(x<42 or x>=out.width-42) and (y<42 or y>=out.height-42)
                if not(edge or corner):px[x,y]=(0,0,0,0)
    out.save(runtime/(name+'.png'))
    (runtime/(name+'.png.mcmeta')).write_text('{"texture":{"blur":true,"clamp":true}}')
    sizes[name]=list(out.size)
save('landscape',(180,135,670,367))
save('panel',(15,18,1530,999),True)
save('title',(554,47,994,104),True)
save('separator',(285,628,1260,649),True)
save('card',(69,422,531,551),True)
save('output',(706,189,841,321),True)
save('previous',(85,191,176,282))
save('next',(1369,191,1460,282))
save('close',(1448,44,1509,105))
save('button',(137,808,1409,908),True)
save('button_left',(141,830,263,894),True)
save('button_right',(1250,830,1397,894),True)
manifest={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sizes':sizes,
          'dynamic_text_baked':False,'frame_center_used':False}
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps(manifest,indent=2))
