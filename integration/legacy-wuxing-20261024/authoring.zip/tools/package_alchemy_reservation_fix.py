"""Package only the two alchemy crash fixes on the approved trail-connect JAR.

The current complete build also contains an unapproved firecoil candidate, so it
must never be copied wholesale to this release. Run after build/reobfJar succeeds.
Existing output files are accepted only when their contents already match.
"""
from __future__ import annotations

import argparse
from copy import copy
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "deliverables/task-20261015-trail-connect/wuxingxiantu-0.2-20261015-trail-connect.jar"
BASELINE_SHA256 = "D3F87847B84ED752E0CC41F8CF475C5488ED8C597BFADF667D1571D3E3514BDF"
CANDIDATE = ROOT / "build/libs/wuxingxiantu-0.2.jar"
OUTPUT_DIRECTORY = ROOT / "deliverables/task-20261015-alchemy-reservation-fix"
OUTPUT_NAME = "wuxingxiantu-0.2-20261015-alchemy-reservation-fix.jar"
ALLOWED = frozenset({
    "cn/blockforge/generated/generatedmod/AlchemyRecipe.class",
    "cn/blockforge/generated/generatedmod/HerbPreparation.class",
})
QA_TOKENS = (
    "GameTest", "ClientCapture", "Regression", "VolumePerformanceProbe",
    "FurnaceMotionFixture", "DomainUiCapture", "BaselineHostScan",
)
METADATA_FIELDS = (
    "filename", "date_time", "compress_type", "comment", "extra",
    "create_system", "internal_attr", "external_attr",
)
CONTAINER_FIELDS = ("create_version", "extract_version", "reserved", "flag_bits")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(data: bytes) -> str:
    return sha256(data).hexdigest().upper()


def entries(archive: ZipFile) -> dict[str, bytes]:
    names = archive.namelist()
    require(len(names) == len(set(names)), "Duplicate ZIP entry names are not allowed")
    require(archive.testzip() is None, "ZIP entry checksum verification failed")
    return {name: archive.read(name) for name in names}


def qa_prefixes() -> set[str]:
    """Include exact fixture names from every local non-production source set."""
    prefixes: set[str] = set()
    for source_set in (ROOT / "src").iterdir():
        if not source_set.is_dir() or source_set.name == "main":
            continue
        for path in source_set.rglob("*.java"):
            package = re.search(
                r"^\s*package\s+([\w.]+)\s*;",
                path.read_text(encoding="utf-8-sig"), re.MULTILINE,
            )
            if package:
                prefixes.add(package.group(1).replace(".", "/") + "/" + path.stem)
    return prefixes


def verify_release_names(names: set[str], fixture_prefixes: set[str]) -> None:
    require(not any("firecoil" in name.lower() for name in names),
            "Unapproved firecoil entry found in release")
    for name in names:
        if not name.endswith(".class"):
            continue
        require(not any(token in name for token in QA_TOKENS),
                "Test class found in release: " + name)
        require(not any(name == prefix + ".class" or name.startswith(prefix + "$")
                        for prefix in fixture_prefixes),
                "Non-production source-set class found in release: " + name)


def check_existing(path: Path, expected: bytes) -> None:
    if path.exists():
        require(path.is_file() and path.read_bytes() == expected,
                "Refusing to overwrite different existing output: " + str(path))


def write_new_or_verify(path: Path, data: bytes) -> None:
    if path.exists():
        check_existing(path, data)
        return
    try:
        with path.open("xb") as stream:
            stream.write(data)
    except FileExistsError:
        check_existing(path, data)
    require(path.read_bytes() == data, "Written output verification failed: " + str(path))


def package(baseline: Path, candidate: Path, output_directory: Path) -> dict:
    baseline = baseline.resolve(strict=True)
    candidate = candidate.resolve(strict=True)
    output_directory = output_directory.resolve()
    baseline_bytes = baseline.read_bytes()
    candidate_bytes = candidate.read_bytes()
    require(digest(baseline_bytes) == BASELINE_SHA256, "Approved baseline SHA256 mismatch")
    fixture_prefixes = qa_prefixes()

    with ZipFile(BytesIO(baseline_bytes)) as old, ZipFile(BytesIO(candidate_bytes)) as built:
        before = entries(old)
        built_entries = entries(built)
        require(ALLOWED <= before.keys(), "Baseline is missing an alchemy fix class")
        require(ALLOWED <= built_entries.keys(), "Reobfuscated build is missing an alchemy fix class")
        verify_release_names(set(before), fixture_prefixes)
        for name in ALLOWED:
            require(built_entries[name][:4] == b"\xca\xfe\xba\xbe", "Invalid class bytes: " + name)
            require(before[name] != built_entries[name], "Expected crash fix class is unchanged: " + name)

        output_buffer = BytesIO()
        with ZipFile(output_buffer, "w") as patched:
            patched.comment = old.comment
            for info in old.infolist():
                data = built_entries[info.filename] if info.filename in ALLOWED else before[info.filename]
                output_info = copy(info)
                patched.writestr(output_info, data)
                # zipfile assigns Unix 0600 when the original external_attr is
                # zero. Restore the approved attribute before the central
                # directory is written; external_attr has no local-header field.
                output_info.external_attr = info.external_attr
        output_bytes = output_buffer.getvalue()

        with ZipFile(BytesIO(output_bytes)) as patched:
            after = entries(patched)
            changed = sorted(name for name in before.keys() & after.keys() if before[name] != after[name])
            added = sorted(after.keys() - before.keys())
            removed = sorted(before.keys() - after.keys())
            require(set(changed) == ALLOWED, "Changed entries differ from the exact two-class whitelist")
            require(not added and not removed, "Release must not add or remove entries")
            require(patched.namelist() == old.namelist(), "Baseline ZIP entry order changed")
            require(patched.comment == old.comment, "Baseline ZIP comment changed")
            container_changes: dict[str, dict] = {}
            for old_info, new_info in zip(old.infolist(), patched.infolist()):
                require(all(getattr(old_info, key) == getattr(new_info, key) for key in METADATA_FIELDS),
                        "Baseline ZIP metadata changed: " + old_info.filename)
                for key in CONTAINER_FIELDS:
                    previous, current = getattr(old_info, key), getattr(new_info, key)
                    if previous == current:
                        continue
                    label = f"{key}:{previous}->{current}"
                    row = container_changes.setdefault(label, {
                        "field": key, "before": previous, "after": current,
                        "entries": 0, "exampleEntries": [],
                    })
                    row["entries"] += 1
                    if len(row["exampleEntries"]) < 3:
                        row["exampleEntries"].append(old_info.filename)
            verify_release_names(set(after), fixture_prefixes)
            for name in ALLOWED:
                require(after[name] == built_entries[name], "Released class differs from reobfuscated build: " + name)

    output = output_directory / OUTPUT_NAME
    require(output not in {baseline, candidate}, "Output must not replace an input artifact")
    report = {
        "result": "PASS",
        "baseline": str(baseline),
        "baselineSha256": digest(baseline_bytes),
        "reobfuscatedBuild": str(candidate),
        "reobfuscatedBuildSha256": digest(candidate_bytes),
        "artifact": str(output),
        "sha256": digest(output_bytes),
        "bytes": len(output_bytes),
        "changed": changed,
        "added": added,
        "removed": removed,
        "unchangedEntries": len(before) - len(changed),
        "allOtherEntryBytesUnchanged": True,
        "zipEntryOrderPreserved": True,
        "zipEntryTimestampsAttributesCommentsPreserved": True,
        "zipContainerNormalization": list(container_changes.values()),
        "zipContainerNote": (
            "Python zipfile rebuilds ZIP headers and compression streams. "
            "Container version or flag normalization listed here does not change "
            "uncompressed entry bytes. All non-whitelisted class and resource "
            "bytes remain identical to the approved baseline."
        ),
        "firecoilEntriesAbsent": True,
        "testClassesAbsent": True,
        "classesMatchReobfuscatedBuild": True,
        "classSha256": {
            name: {"before": digest(before[name]), "after": digest(built_entries[name])}
            for name in sorted(ALLOWED)
        },
        "installed": False,
    }
    report_bytes = (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    report_path = output_directory / "release-verification.json"
    # Check both destinations before creating either output.
    check_existing(output, output_bytes)
    check_existing(report_path, report_bytes)
    output_directory.mkdir(parents=True, exist_ok=True)
    write_new_or_verify(output, output_bytes)
    write_new_or_verify(report_path, report_bytes)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    parser.add_argument("--input", type=Path, default=CANDIDATE, dest="candidate")
    parser.add_argument("--output-directory", type=Path, default=OUTPUT_DIRECTORY)
    arguments = parser.parse_args()
    report = package(arguments.baseline, arguments.candidate, arguments.output_directory)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
