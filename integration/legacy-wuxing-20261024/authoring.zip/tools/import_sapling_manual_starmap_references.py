"""Import supplied fragment and essence references as transparent 64x64 icons."""
from pathlib import Path
import json
import shutil
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
OUT = ROOT / 'source-assets/sapling-manual-starmap-20261008'
OUT.mkdir(parents=True, exist_ok=True)
REFERENCES = {
    'peach_sapling': '229fe6a6-e443-4cda-aa60-00934be59583',
    'wanfa_guizong': 'f69479ad-7935-4b94-9262-b62ab4f539eb',
    'gangdou_starmap': '79a5022b-3c59-432c-9916-6823042208a9',
    'ri_yue_ting_lun_fragment': '9eb774e4-a3b1-4ed7-bb5d-2ca0f8779f8b',
    'zhonglv_fragment': '7cbf15d6-acb7-4fc1-a952-9d64e1dba72b',
}
manifest = {}
preview = Image.new('RGBA', (320 * len(REFERENCES), 320), (42, 45, 44, 255))
for index, (name, reference) in enumerate(REFERENCES.items()):
    source = OUT / f'{name}-original.png'
    if not source.exists():
        shutil.copy2(Path('C:/Users/NOSTZE~1/AppData/Local/Temp') / f'codex-clipboard-{reference}.png', source)
    original = Image.open(source).convert('RGBA')
    bounds = original.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
    assert bounds is not None
    crop = original.crop(bounds)
    crop.save(OUT / f'{name}-crop.png')
    icon = crop.copy()
    size = 128 if name == 'zhonglv_fragment' else 64
    padding = 4 if size == 128 else 2
    icon.thumbnail((size-padding*2, size-padding*2), Image.Resampling.NEAREST)
    texture = Image.new('RGBA', (size, size))
    texture.paste(icon, ((size-icon.width)//2, (size-icon.height)//2))
    texture_path = ASSETS / 'textures/item' / f'{name}.png'
    model_path = ASSETS / 'models/item' / f'{name}.json'
    for file in (texture_path, model_path):
        backup = OUT / f'before-{file.name}'
        if file.exists() and not backup.exists():
            shutil.copy2(file, backup)
    texture.save(texture_path)
    model_path.write_text(json.dumps({'parent': 'minecraft:item/generated',
        'textures': {'layer0': f'wuxingxiantu:item/{name}'}}, indent=2)+'\n', encoding='utf-8')
    check = Image.open(texture_path).convert('RGBA')
    assert check.size == (size, size) and check.getchannel('A').getextrema()[0] == 0
    assert check.getchannel('A').getextrema()[1] >= 128
    preview.alpha_composite(texture.resize((320, 320), Image.Resampling.NEAREST), (index*320, 0))
    manifest[name] = {'source_size': original.size, 'crop_bounds': bounds,
        'icon_size': icon.size, 'texture_size': texture.size, 'resampling': 'NEAREST'}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
preview.save(OUT / 'preview.png')
print('PASS: fragment and essence references imported as independent transparent icons (Zhonglv 128x128; others 64x64)')
