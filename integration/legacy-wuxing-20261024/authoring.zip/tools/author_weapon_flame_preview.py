"""Author a local Photon material study; it does not replace the mod's held-item renderer."""
import argparse
import importlib.util
import json
from pathlib import Path

from PIL import Image


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--skill', type=Path, required=True)
    parser.add_argument('--game', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--effect', required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('photon_workflow', args.skill / 'scripts/photon_workflow.py')
    workflow = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(workflow)
    helper = workflow.Helper()
    world = helper.call('get_world_info')
    if world.get('world_name') != 'ASTRA_VFX_TEST':
        raise RuntimeError('The authorized preview world is not loaded')
    args.output.mkdir(parents=True, exist_ok=False)
    # Reuse the project's stepped flame silhouette, with an explicit colored heat ramp.
    root = Path(__file__).resolve().parents[1]
    sheet = Image.open(root / 'src/main/resources/assets/wuxingxiantu/textures/effect/weapon_flame.png').convert('RGBA')
    frames = []
    for index in range(4):
        frame = sheet.crop((16 * index, 0, 16 * (index + 1), 32))
        for y in range(frame.height):
            for x in range(frame.width):
                value, _, _, alpha = frame.getpixel((x, y))
                color = (255, 236, 158) if value > 230 else (255, 111, 24)
                frame.putpixel((x, y), (*color, alpha))
        path = args.output / f'flame-{index}.png'
        frame.save(path)
        frames.append(path)
    prepared = args.output / 'prepared'
    workflow.prepare(frames, prepared, cell=64, columns=4,
                     prompt='Project pixel masks recolored to orange bodies and pale hot cores; no AI image generation.')
    alpha = '{enable:1b,color:{_type:"Gradient",a:[0.0f,0.0f,0.12f,1.0f,0.7f,0.8f,1.0f,0.0f],r:[0.0f,1.0f,1.0f,1.0f],g:[0.0f,1.0f,1.0f,1.0f],b:[0.0f,1.0f,1.0f,1.0f]}}'
    config = '{simulationSpace:"World",startSpeed:{_type:"Constant",number:0.045f},renderer:{shade:0b,renderMode:"Billboard"},shape:{shape:{_type:"cone",angle:30.0f,radius:0.24f,radiusThickness:1.0f}},colorOverLifetime:' + alpha + '}'
    document = {'emitters': [
        {'type': 'particle', 'name': 'Detached stepped flames', 'color': '#FFFFFFFF',
         'size': .32, 'rate': .65, 'lifetime': 14, 'maxParticles': 32, 'config': config},
        {'type': 'particle', 'name': 'Small hot fragments', 'color': '#FFFFDC82',
         'size': .10, 'rate': .3, 'lifetime': 20, 'maxParticles': 16, 'config': config.replace('0.045f', '0.09f')}
    ]}
    workflow.deploy(helper, prepared, args.effect, args.effect, document=document)
    # Bind both emitters explicitly; no vanilla particle texture remains in the study.
    helper.call('photon_bind_texture', id=args.effect, texture=args.effect, index=1, columns=4, rows=1, frames=4)
    helper.reload()
    helper.call('photon_clear_fx_cache')
    helper.call('execute_command', command='photon_editor')
    helper.call('photon_editor_load', id=args.effect)
    helper.call('photon_editor_bind_texture', texture=args.effect, index=0, columns=4, rows=1, frames=4)
    helper.call('photon_editor_bind_texture', texture=args.effect, index=1, columns=4, rows=1, frames=4)
    helper.call('photon_editor_export', id=args.effect, mode='replace')
    helper.reload()
    workflow.snapshot(helper, args.effect, args.game, args.output / 'revision', prepared=prepared, editor=True)
    helper.call('photon_editor_close')
    helper.call('client_resume')
    player = helper.call('get_player_info')
    import math
    x, y, z = map(float, player['pos'].split())
    yaw, pitch = (math.radians(v) for v in map(float, player['rotation'].split()))
    position = {'x': x - math.sin(yaw) * math.cos(pitch) * 3,
                'y': y + 1.62 - math.sin(pitch) * 3 - .35,
                'z': z + math.cos(yaw) * math.cos(pitch) * 3}
    workflow.capture(helper, args.effect, args.output / 'capture', frames=24, fps=6, position=position)
    (args.output / 'scope.json').write_text(json.dumps({'world': world['world_name'], 'effect': args.effect,
        'scope': 'Photon material study only; revised Java held, hit and burn rendering is unbuilt.',
        'position': position}, indent=2), encoding='utf-8')
    print(args.output.resolve())


if __name__ == '__main__':
    main()
