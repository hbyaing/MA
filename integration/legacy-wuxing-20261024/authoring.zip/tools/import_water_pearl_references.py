"""Import the supplied 2x2 water pearl reference as four 32x32 pixel-art textures."""
from pathlib import Path
import json
import shutil
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
OUT = ROOT / 'source-assets/water-pearl-20261008'
SOURCE = Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-5bb50d8f-9408-4552-9fd2-160738283cbf.png')
OUT.mkdir(parents=True, exist_ok=True)
shutil.copy2(SOURCE, OUT / 'reference-original.png')
sheet = Image.open(SOURCE).convert('RGBA')
assert sheet.size == (1254, 1254), sheet.size
boxes = [(0, 0, 627, 578), (627, 0, 1254, 578),
         (0, 578, 608, 1254), (608, 578, 1254, 1254)]
preview = Image.new('RGBA', (1200, 340), (42, 45, 44, 255))
manifest = {}
for i, grade in enumerate(['low', 'mid', 'high', 'perfect']):
    box = boxes[i]
    crop = sheet.crop(box)
    bounds = crop.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
    assert bounds is not None
    crop = crop.crop(bounds)
    crop.save(OUT / f'{grade}-crop.png')
    icon = crop.copy()
    icon.thumbnail((30, 30), Image.Resampling.NEAREST)
    tile = Image.new('RGBA', (32, 32))
    offset = ((32-icon.width)//2, (32-icon.height)//2)
    tile.paste(icon, offset)
    name = f'{grade}_water_pearl'
    texture_path = ASSETS / 'textures/item' / f'{name}.png'
    tile.save(texture_path)
    (ASSETS / 'models/item' / f'{name}.json').write_text(json.dumps({
        'parent': 'minecraft:item/generated', 'textures': {'layer0': f'wuxingxiantu:item/{name}'}
    }, indent=2)+'\n', encoding='utf-8')
    # Verify the final 32x32 texture and the nearest-neighbour pixels on its canvas.
    check = Image.open(texture_path).convert('RGBA')
    x, y = offset
    assert check.size == (32, 32)
    assert check.crop((x, y, x+icon.width, y+icon.height)).tobytes() == icon.tobytes()
    assert check.getchannel('A').getextrema() == (0, 255)
    art = tile.resize((288, 288), Image.Resampling.NEAREST)
    preview.alpha_composite(art, (i*300+(300-art.width)//2, 320-art.height))
    manifest[name] = {'source_box': box, 'crop_bounds': bounds, 'crop_size': crop.size,
                      'texture_size': tile.size, 'resampling': 'NEAREST', 'icon_size': icon.size}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
preview.save(OUT / 'preview.png')
print('PASS: four independent 32x32 water pearl textures with transparency and nearest-neighbour scaling')
print(manifest)
