from pathlib import Path
import zipfile, hashlib, json, shutil
ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'reports/ui-compact-merged-20261007'
def log(name):
    raw=(REPORT/name).read_bytes()
    return raw.decode('utf-16' if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig',errors='replace')
assert (REPORT/'build.exit').read_text().strip()=='0' and 'BUILD SUCCESSFUL' in log('build.log')
assert (REPORT/'domain-tests.exit').read_text().strip()=='0' and 'All 12 required tests passed' in log('domain-tests.log')
assert 'PASS: 20' in log('layout.log') and 'PASS: 60' in log('vision-layout.log')
jar=ROOT/'build/libs/wuxingxiantu-0.2.jar'
expected={'cn/blockforge/generated/generatedmod/CultivationDataImpl.class',
          'cn/blockforge/generated/generatedmod/network/packet/cultivation/RootFormPacket.class'}
with zipfile.ZipFile(jar) as current,zipfile.ZipFile(ROOT/'deliverables/wuxingxiantu-0.2-20261007-vision-layout.jar') as previous:
    changed=set(); images=0
    for name in previous.namelist():
        if name.endswith('.class') and '/client/' not in name:
            if current.read(name)!=previous.read(name):changed.add(name)
        if name.startswith('assets/wuxingxiantu/textures/gui/wuxia/') and name.endswith('.png'):
            assert current.read(name)==previous.read(name),'Image unexpectedly changed: '+name
            images+=1
    assert changed==expected,changed
target=ROOT/'deliverables/wuxingxiantu-0.2-20261007-ui-compact-passive-thunder.jar'
shutil.copy2(jar,target);digest=hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.jar.sha256').write_text(digest+'  '+target.name+'\n',encoding='ascii')
result={'artifact':str(target),'sha256':digest,'size':target.stat().st_size,'max_window':[480,294],
        'layout_cases':80,'gametests':12,'unchanged_ui_images':images,'client_runtime_verified':False,
        'nonclient_changes':sorted(changed),'save_format_unchanged':True}
(REPORT/'artifact-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
