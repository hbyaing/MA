"""Import four wood seed grades as 32x32 pixel-art textures, preserving proportions."""
from pathlib import Path
import json
import shutil
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
OUT = ROOT / 'source-assets/wood-seed-20261008'
SOURCE = Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-b49cb3f4-9c63-4f81-b855-28bcbc43d78d.png')
OUT.mkdir(parents=True, exist_ok=True)
shutil.copy2(SOURCE, OUT / 'reference-original.png')
sheet = Image.open(SOURCE).convert('RGBA')
boundaries = [0, 540, 1080, 1630, sheet.width]
preview = Image.new('RGBA', (1200, 340), (42, 45, 44, 255))
manifest = {}
for i, grade in enumerate(['low', 'mid', 'high', 'perfect']):
    box = (boundaries[i], 0, boundaries[i+1], sheet.height)
    crop = sheet.crop(box)
    bounds = crop.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
    assert bounds is not None
    crop = crop.crop(bounds)
    crop.save(OUT / f'{grade}-crop.png')
    icon = crop.copy()
    icon.thumbnail((30,30), Image.Resampling.NEAREST)
    tile = Image.new('RGBA', (32,32))
    tile.paste(icon, ((32-icon.width)//2, (32-icon.height)//2))
    name = f'{grade}_wood_seed'
    tile.save(ASSETS / 'textures/item' / f'{name}.png')
    (ASSETS / 'models/item' / f'{name}.json').write_text(json.dumps({
        'parent': 'minecraft:item/generated', 'textures': {'layer0': f'wuxingxiantu:item/{name}'}
    }, indent=2)+'\n', encoding='utf-8')
    art = tile.resize((288,288), Image.Resampling.NEAREST)
    preview.alpha_composite(art, (i*300+(300-art.width)//2, 320-art.height))
    manifest[name] = {'source_box': box, 'crop_bounds': bounds, 'crop_size': crop.size,
                      'texture_size': tile.size, 'resampling': 'NEAREST'}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
preview.save(OUT / 'preview.png')
print(manifest)
