param([switch]$CompileOnly, [switch]$DomainTests, [string]$ReportName = 'ui-reference-install-20261007')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
Set-Location -LiteralPath $projectRoot
$env:JAVA_HOME = 'C:\tmp\temurin17\jdk-17.0.20.1+1'
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
$env:TEMP = 'C:\gradle-tmp'
$env:TMP = 'C:\gradle-tmp'
if ($ReportName -notmatch '^[A-Za-z0-9-]+$') { throw 'Invalid report name' }
$reportRoot = Join-Path (Join-Path $projectRoot 'reports') $ReportName
New-Item -ItemType Directory -Force -Path $reportRoot | Out-Null
$runName = if ($CompileOnly) { 'compile-hidden' } elseif ($DomainTests) { 'domain-tests' } else { 'build' }
$logPath = Join-Path $reportRoot ($runName + '.log')
$exitPath = Join-Path $reportRoot ($runName + '.exit')
$gradleArgs = @('--offline', '-Dorg.gradle.java.home=C:\tmp\temurin17\jdk-17.0.20.1+1', '-Dorg.gradle.jvmargs=-Xmx3G -Dfile.encoding=UTF-8 -Djava.io.tmpdir=C:\gradle-tmp', '-PpythonExecutable=C:\Users\Nostzephert\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')
if ($CompileOnly) { $gradleArgs += 'compileJava' }
elseif ($DomainTests) { $gradleArgs += @('runGameTestServer','-PentryUiOnly') }
else { $gradleArgs += 'build' }
try {
    $ErrorActionPreference = 'Continue' # Native javac warnings are stderr, not build failures.
    & (Join-Path $projectRoot 'gradlew.bat') @gradleArgs *> $logPath
    $LASTEXITCODE | Set-Content -LiteralPath $exitPath -Encoding ASCII
} catch {
    $_ | Out-File -LiteralPath $logPath -Append
    '1' | Set-Content -LiteralPath $exitPath -Encoding ASCII
}
