"""Bake original, tapered cloud-calligraphy Beziers into an armor-UV data mask.

Only the mask is a game resource. Private vanilla textures are used solely for
the local comparison preview and are never copied to the resource directory.
RGBA = (coverage, path_progress * coverage, cluster_phase * coverage, coverage).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source-assets/spirit-guard-cloud-20261013"
TARGET = ROOT / "src/main/resources/assets/wuxingxiantu/textures/effect/spirit_guard_cloud_mask.png"
LEVEL_SOURCE = SOURCE / "levels"
SIZE = (1024, 512)
UV_SCALE = SIZE[0] / 64.0

# Original center curves. The first is a broad, unclosed C curl with a sharp
# rising tail; the second carries a higher S curl; the last is a thin escort.
# Coordinates follow texture V (downward). No random generation or tiling.
STROKES = [
    {
        "name": "rising-c-cloud", "start": [0.03, 0.97],
        "cubics": [
            [[0.19, 0.81], [0.78, 0.78], [0.73, 0.58]],
            [[0.70, 0.44], [0.29, 0.53], [0.29, 0.37]],
            [[0.28, 0.21], [0.63, 0.23], [0.66, 0.34]],
            [[0.70, 0.44], [0.52, 0.46], [0.53, 0.38]],
        ],
        "width_profile": [[0, 0.003], [.18, .045], [.39, .132], [.59, .103], [.79, .057], [.93, .030], [1, .001]],
        "progress_range": [0.00, .79],
    },
    {
        "name": "upper-s-cloud", "start": [.40, .86],
        "cubics": [
            [[.86, .75], [.93, .58], [.79, .49]],
            [[.58, .36], [.91, .36], [.83, .20]],
            [[.80, .13], [.59, .17], [.64, .09]],
            [[.69, .01], [.89, .06], [.88, .13]],
        ],
        "width_profile": [[0, .001], [.20, .043], [.48, .092], [.69, .082], [.84, .051], [1, .001]],
        "progress_range": [.13, .95],
    },
    {
        "name": "thin-brush-escort", "start": [.02, .75],
        "cubics": [
            [[.37, .60], [.07, .54], [.11, .40]],
            [[.13, .27], [.45, .15], [.50, .025]],
        ],
        "width_profile": [[0, .001], [.19, .030], [.43, .057], [.66, .043], [.88, .018], [1, .001]],
        "progress_range": [.24, 1.0],
    },
]

# Exact original 64 x 32 armor UV coordinates, independent from the material.
# Main faces retain their broad empty central region. The sides use accents,
# rather than repeating a full pattern on every face.
CLUSTERS = [
    {"name": "torso-front-main", "box": [24.55, 21.10, 27.70, 28.60], "phase": .02, "strokes": [0, 1, 2]},
    {"name": "torso-front-waist", "box": [20.30, 28.20, 22.70, 31.50], "phase": .43, "strokes": [0, 2], "mirror": True},
    {"name": "torso-back-cloud", "box": [34.10, 22.00, 38.40, 29.60], "phase": .71, "strokes": [0, 1, 2], "mirror": True},
    {"name": "torso-left-accent", "box": [16.45, 25.80, 19.25, 30.65], "phase": .28, "strokes": [0]},
    {"name": "torso-right-accent", "box": [28.50, 23.20, 31.40, 27.55], "phase": .57, "strokes": [1]},
    {"name": "arm-front-cloud", "box": [44.40, 20.70, 47.65, 26.30], "phase": .16, "strokes": [0, 1]},
    {"name": "arm-back-cloud", "box": [52.60, 24.65, 55.50, 29.85], "phase": .64, "strokes": [0], "mirror": True},
    {"name": "arm-outer-accent", "box": [40.55, 21.20, 43.45, 25.10], "phase": .86, "strokes": [1]},
    {"name": "arm-inner-accent", "box": [48.65, 28.00, 51.30, 31.30], "phase": .35, "strokes": [2]},
    {"name": "helmet-front-corner", "box": [12.75, 8.70, 15.40, 13.20], "phase": .53, "strokes": [0, 2]},
    {"name": "helmet-back-corner", "box": [24.70, 10.00, 28.10, 14.65], "phase": .91, "strokes": [0], "mirror": True},
    {"name": "helmet-left-accent", "box": [1.30, 11.00, 4.10, 15.15], "phase": .22, "strokes": [1]},
    {"name": "helmet-right-accent", "box": [19.60, 9.00, 22.80, 13.55], "phase": .78, "strokes": [2]},
    {"name": "leg-front-cloud", "box": [4.45, 22.65, 7.55, 29.85], "phase": .10, "strokes": [0, 2]},
    {"name": "leg-back-accent", "box": [12.55, 26.20, 15.45, 31.50], "phase": .60, "strokes": [1]},
    {"name": "leg-outer-accent", "box": [.40, 20.65, 3.50, 25.00], "phase": .39, "strokes": [0]},
    {"name": "leg-inner-accent", "box": [8.60, 28.30, 11.35, 31.60], "phase": .82, "strokes": [2]},
]

# All levels retain complete main curls. Progression adds accents gradually;
# color and moving light carry the main level distinction.
LEVEL_ONE = {
    "torso-front-main": [0, 1], "torso-front-waist": [0],
    "torso-back-cloud": [0, 1], "torso-left-accent": [0], "torso-right-accent": [1],
    "arm-front-cloud": [0, 1], "arm-back-cloud": [0],
    "helmet-front-corner": [0], "helmet-back-corner": [0],
    "leg-front-cloud": [0, 2], "leg-back-accent": [1], "leg-outer-accent": [0],
}
LEVEL_TWO = {
    "torso-front-main": [0, 1], "torso-front-waist": [0],
    "torso-back-cloud": [0, 1], "torso-left-accent": [0], "torso-right-accent": [1],
    "arm-front-cloud": [0, 1], "arm-back-cloud": [0], "arm-outer-accent": [1],
    "arm-inner-accent": [2],
    "helmet-front-corner": [0], "helmet-back-corner": [0], "helmet-left-accent": [1],
    "helmet-right-accent": [2],
    "leg-front-cloud": [0, 2], "leg-back-accent": [1], "leg-outer-accent": [0], "leg-inner-accent": [2],
}

# Short open brush branches are unique to IV. Their thickness still spans roughly
# two output pixels; the existing .32 pixel coverage edge remains untouched.
LEVEL_FOUR_STROKES = [
    {
        "name": "fine-cloud-guard", "start": [.02, .92],
        "cubics": [
            [[.16, .79], [.63, .75], [.64, .51]],
            [[.65, .35], [.26, .40], [.28, .23]],
            [[.29, .10], [.57, .09], [.76, .025]],
        ],
        "width_profile": [[0, .001], [.20, .048], [.46, .079], [.69, .057], [.86, .032], [1, .001]],
        "progress_range": [.20, .88],
    },
    {
        "name": "short-cloud-branch", "start": [.06, .83],
        "cubics": [
            [[.32, .76], [.73, .72], [.73, .49]],
            [[.72, .31], [.42, .36], [.38, .20]],
            [[.35, .095], [.57, .13], [.63, .035]],
        ],
        "width_profile": [[0, .001], [.23, .051], [.44, .078], [.68, .052], [.85, .027], [1, .001]],
        "progress_range": [.36, .98],
    },
]
LEVEL_FOUR_ACCENTS = [
    {"name": "torso-front-fine-guard", "box": [20.55, 21.20, 23.65, 25.70], "phase": .12, "strokes": [3]},
    {"name": "torso-back-fine-branch", "box": [32.35, 20.65, 34.00, 24.80], "phase": .81, "strokes": [4], "mirror": True},
    {"name": "arm-front-fine-branch", "box": [44.65, 27.00, 47.30, 31.15], "phase": .26, "strokes": [4]},
    {"name": "arm-back-fine-guard", "box": [52.45, 20.35, 55.50, 24.30], "phase": .74, "strokes": [3], "mirror": True},
    {"name": "helmet-front-fine-guard", "box": [9.05, 9.20, 12.10, 12.65], "phase": .63, "strokes": [3]},
    {"name": "helmet-back-fine-branch", "box": [28.55, 8.50, 31.60, 12.60], "phase": .01, "strokes": [4], "mirror": True},
    {"name": "leg-front-fine-branch", "box": [4.70, 20.25, 7.40, 22.55], "phase": .20, "strokes": [4]},
    {"name": "leg-back-fine-guard", "box": [12.50, 21.25, 15.10, 25.65], "phase": .70, "strokes": [3], "mirror": True},
]
LEVEL_DESIGNS = {
    1: {"name": "初护", "description": "完整双笔主云簇与腰部、正背侧基础护纹，共16笔；以柔和湖蓝和较慢流光表现初阶。"},
    2: {"name": "成纹", "description": "沿一级主纹补齐5处侧面细笔，共21笔；以清透青蓝与明亮流光区分，纹路密度平滑递进。"},
    3: {"name": "云篆", "description": "原版完整三笔主簇与侧面护纹，像素与现有三级资源完全相同。"},
    4: {"name": "护篆", "description": "在三级原纹上仅添八处短护笔与细分枝，围绕既有主纹留白，不平铺、不加柔光。"},
}


def clusters_for_level(level: int) -> list[dict]:
    if level not in LEVEL_DESIGNS:
        raise ValueError("Spirit Guard mask level must be 1 through 4")
    if level in (1, 2):
        selected = LEVEL_ONE if level == 1 else LEVEL_TWO
        return [{**cluster, "strokes": selected[cluster["name"]]}
                for cluster in CLUSTERS if cluster["name"] in selected]
    return list(CLUSTERS) + (LEVEL_FOUR_ACCENTS if level == 4 else [])


def curves_for_level(level: int) -> list:
    strokes = STROKES + LEVEL_FOUR_STROKES
    return [(strokes[s], cluster, *sample_curve(strokes[s], cluster))
            for cluster in clusters_for_level(level) for s in cluster["strokes"]]


def sample_curve(stroke: dict, cluster: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    points = []
    start = np.array(stroke["start"], dtype=float)
    for controls in stroke["cubics"]:
        c1, c2, end = np.array(controls, dtype=float)
        t = np.linspace(0, 1, 81)[:, None]
        sampled = (1 - t) ** 3 * start + 3 * (1 - t) ** 2 * t * c1 + 3 * (1 - t) * t ** 2 * c2 + t ** 3 * end
        points.extend(sampled if not points else sampled[1:])
        start = end
    p = np.array(points)
    if cluster.get("mirror"):
        p[:, 0] = 1 - p[:, 0]
    x0, y0, x1, y1 = cluster["box"]
    p = p * np.array([x1 - x0, y1 - y0]) + np.array([x0, y0])
    cumulative = np.concatenate(([0.0], np.cumsum(np.linalg.norm(np.diff(p, axis=0), axis=1))))
    along = cumulative / cumulative[-1]
    profile = np.array(stroke["width_profile"])
    widths = np.interp(along, profile[:, 0], profile[:, 1]) * min(x1 - x0, y1 - y0)
    start_progress, end_progress = stroke["progress_range"]
    progress = start_progress + along * (end_progress - start_progress)
    return p, widths, progress


def rasterize(curves: list) -> np.ndarray:
    result = np.zeros((SIZE[1], SIZE[0], 4), dtype=np.float32)
    # Smoothstep coverage at the output resolution: AA changes only coverage,
    # never a cluster's decoded phase or path progress.
    aa = .32 / UV_SCALE
    for _, cluster, p, widths, progress in curves:
        for i in range(len(p) - 1):
            a, b = p[i:i + 2]
            radius = max(widths[i], widths[i + 1]) * .5 + aa
            lo = np.maximum(np.floor((np.minimum(a, b) - radius) * UV_SCALE).astype(int), 0)
            hi = np.minimum(np.ceil((np.maximum(a, b) + radius) * UV_SCALE).astype(int), SIZE)
            if np.any(hi <= lo):
                continue
            ys, xs = np.mgrid[lo[1]:hi[1], lo[0]:hi[0]]
            pixel = np.stack(((xs + .5) / UV_SCALE, (ys + .5) / UV_SCALE), axis=-1)
            ab = b - a
            fraction = np.clip(np.sum((pixel - a) * ab, axis=-1) / max(np.dot(ab, ab), 1e-12), 0, 1)
            closest = a + fraction[..., None] * ab
            dist = np.linalg.norm(pixel - closest, axis=-1)
            half_width = (widths[i] * (1 - fraction) + widths[i + 1] * fraction) * .5
            q = np.clip((half_width + aa - dist) / (2 * aa), 0, 1)
            coverage = q * q * (3 - 2 * q)
            sub = result[lo[1]:hi[1], lo[0]:hi[0]]
            winner = coverage > sub[..., 0]
            current_progress = progress[i] * (1 - fraction) + progress[i + 1] * fraction
            sub[..., 0][winner] = coverage[winner]
            sub[..., 1][winner] = (current_progress * coverage)[winner]
            sub[..., 2][winner] = (cluster["phase"] * coverage)[winner]
            sub[..., 3][winner] = coverage[winner]
    quantized = np.rint(result * 255).clip(0, 255).astype(np.uint8)
    quantized[quantized[..., 0] == 0] = 0
    return quantized


def vector_source(curves: list) -> str:
    svg = ET.Element("svg", {"xmlns": "http://www.w3.org/2000/svg", "viewBox": "0 0 64 32", "width": "1024", "height": "512"})
    ET.SubElement(svg, "rect", {"width": "64", "height": "32", "fill": "#111923"})
    for stroke, cluster, p, width, _ in curves:
        tangent = np.gradient(p, axis=0)
        normal = np.stack((-tangent[:, 1], tangent[:, 0]), axis=-1)
        normal /= np.maximum(np.linalg.norm(normal, axis=1, keepdims=True), 1e-10)
        outline = np.concatenate((p + normal * width[:, None] * .5, (p - normal * width[:, None] * .5)[::-1]))
        d = "M " + " L ".join(f"{x:.5f},{y:.5f}" for x, y in outline) + " Z"
        element = ET.SubElement(svg, "path", {"d": d, "fill": "#a8ddff", "data-cluster": cluster["name"], "data-stroke": stroke["name"]})
        ET.SubElement(element, "title").text = f"{cluster['name']} / {stroke['name']}"
    return ET.tostring(svg, encoding="unicode")


def visual_previews(data: np.ndarray, texture: Path | None) -> None:
    coverage = data[..., 0].astype(float) / 255
    white = np.zeros_like(data)
    white[..., :3] = np.array([133, 208, 255], dtype=np.uint8)
    white[..., 3] = data[..., 0]
    Image.fromarray(white).save(SOURCE / "cloud-brush-color-preview.png")
    Image.fromarray(data).resize((1024, 512), Image.Resampling.NEAREST).save(SOURCE / "rgba-contract-preview.png")
    if not texture or not texture.is_file():
        return
    base = Image.open(texture).convert("RGBA").resize(SIZE, Image.Resampling.NEAREST)
    visible = np.array(base).astype(float)
    # Static pale-blue coverage preview, not a screenshot of the game shader.
    tint = np.array([143, 215, 255], dtype=float)
    visible[..., :3] = visible[..., :3] * (1 - coverage[..., None] * .82) + tint * coverage[..., None] * .82
    overlay = Image.fromarray(visible.clip(0, 255).astype(np.uint8))
    preview = Image.new("RGB", (1016, 640), "#0e1520")
    draw = ImageDraw.Draw(preview)
    font_path = Path("C:/Windows/Fonts/msyh.ttc")
    font = ImageFont.truetype(str(font_path), 22) if font_path.is_file() else ImageFont.load_default()
    small = ImageFont.truetype(str(font_path), 15) if font_path.is_file() else ImageFont.load_default()
    draw.text((24, 20), "云篆护纹 · 原创笔形与原版下界合金对照", font=font, fill="#d7edff")
    boxes = [("胸甲正面原纹理", [20, 20, 28, 32], base), ("正面云篆遮罩", [20, 20, 28, 32], overlay),
             ("胸甲背面原纹理", [32, 20, 40, 32], base), ("背面云篆遮罩", [32, 20, 40, 32], overlay)]
    for index, (label, box, image) in enumerate(boxes):
        crop_box = tuple(round(v * UV_SCALE) for v in box)
        crop = image.crop(crop_box).resize((224, 336), Image.Resampling.NEAREST)
        x = 24 + index * 248
        preview.paste(crop.convert("RGB"), (x, 104))
        draw.text((x, 65), label, font=small, fill="#a1bfde")
    large_crop = overlay.crop((round(24.4 * UV_SCALE), round(21 * UV_SCALE), round(27.9 * UV_SCALE), round(29 * UV_SCALE)))
    preview.paste(large_crop.resize((106, 160), Image.Resampling.NEAREST).convert("RGB"), (24, 464))
    draw.text((155, 474), "局部笔形：三笔一簇，主 C 回旋 + 上挑 S 弧 + 细笔护尾", font=small, fill="#bbd4ed")
    draw.text((155, 505), "展示的是静态遮罩覆盖；游戏中逐笔显现、接力消散，底材不改写。", font=small, fill="#9db1c7")
    draw.text((155, 536), "数据图 1024×512，使用原版 64×32 装备 UV；留白区 RGBA 全零。", font=small, fill="#9db1c7")
    draw.text((155, 567), "原版纹理仅用于本地审美对照，不进入发布资源。", font=small, fill="#9db1c7")
    preview.save(SOURCE / "netherite-cloud-comparison.png")


def mask_stats(data: np.ndarray, level: int, curves: list) -> dict:
    stats = {"level": level, "size": list(SIZE), "clusters": len(clusters_for_level(level)), "strokes": len(curves),
             "whole_atlas_nonzero_percent": round(float(np.mean(data[..., 0] > 0) * 100), 3),
             "whole_atlas_coverage_percent": round(float(np.mean(data[..., 0] / 255) * 100), 3),
             "nonzero_pixels": int(np.count_nonzero(data[..., 0])),
             "coverage_pixel_equivalent": round(float(np.sum(data[..., 0] / 255)), 3),
             "empty_rgba_zero": bool(np.all(data[data[..., 0] == 0] == 0)),
             "alpha_equals_red": bool(np.array_equal(data[..., 0], data[..., 3])),
             "premultiplied_gb_le_red": bool(np.all(data[..., 1:3] <= data[..., 0, None]))}
    for label, box in [("torso_front", [20, 20, 28, 32]), ("torso_back", [32, 20, 40, 32]), ("arm_front", [44, 20, 48, 32])]:
        x0, y0, x1, y1 = [round(v * UV_SCALE) for v in box]
        crop = data[y0:y1, x0:x1, 0]
        stats[label + "_coverage_percent"] = round(float(np.mean(crop / 255) * 100), 3)
        stats[label + "_nonzero_percent"] = round(float(np.mean(crop > 0) * 100), 3)
    return stats


def level_previews(level_masks: dict[int, np.ndarray]) -> None:
    """A source-asset diagram, deliberately separate from game capture evidence."""
    LEVEL_SOURCE.mkdir(parents=True, exist_ok=True)
    preview = Image.new("RGB", (1216, 896), "#0c1420")
    draw = ImageDraw.Draw(preview)
    font_path = Path("C:/Windows/Fonts/msyh.ttc")
    font = ImageFont.truetype(str(font_path), 24) if font_path.is_file() else ImageFont.load_default()
    small = ImageFont.truetype(str(font_path), 17) if font_path.is_file() else ImageFont.load_default()
    draw.text((24, 18), "灵力御体 I–IV · 原创云篆分级遮罩", font=font, fill="#d7edff")
    draw.text((24, 53), "静态笔形资产对照，非游戏截图；同尺寸、同锐度，等级增加造型层次。", font=small, fill="#93aac0")
    for level, data in level_masks.items():
        color = np.zeros_like(data)
        color[..., :3] = np.array([133, 208, 255], dtype=np.uint8)
        color[..., 3] = data[..., 0]
        colored = Image.fromarray(color)
        colored.save(LEVEL_SOURCE / f"level-{level}-brush-preview.png")
        x = 24 + (level - 1) * 300
        draw.text((x, 92), f"{['I', 'II', 'III', 'IV'][level - 1]} · {LEVEL_DESIGNS[level]['name']}", font=font, fill="#c3e4fc")
        for y, label, box in [(151, "胸甲正面", [20, 20, 28, 32]), (515, "胸甲背面", [32, 20, 40, 32])]:
            draw.text((x, y - 27), label, font=small, fill="#94afc6")
            crop_box = tuple(round(v * UV_SCALE) for v in box)
            # Pixel enlargement exposes the real narrow AA, rather than introducing soft resampling.
            crop = colored.crop(crop_box).resize((224, 336), Image.Resampling.NEAREST)
            panel = Image.new("RGBA", crop.size, "#17232f")
            panel.alpha_composite(crop)
            preview.paste(panel.convert("RGB"), (x, y))
            draw.rectangle((x, y, x + 223, y + 335), outline="#2c4054")
    draw.text((24, 866), "只展示原创数据遮罩；底材、实际流动与受击波纹由游戏渲染接入决定。", font=small, fill="#8299ae")
    preview.save(LEVEL_SOURCE / "level-comparison.png")


def write_level_assets(level_three: np.ndarray) -> dict:
    level_masks = {3: level_three}
    for level in (1, 2, 4):
        curves = curves_for_level(level)
        data = rasterize(curves)
        level_masks[level] = data
        name = f"spirit_guard_cloud_{level}.png"
        Image.fromarray(data).save(TARGET.with_name(name))
        LEVEL_SOURCE.mkdir(parents=True, exist_ok=True)
        Image.fromarray(data).save(LEVEL_SOURCE / name)
    level_masks = dict(sorted(level_masks.items()))
    stats = {str(level): mask_stats(data, level, curves_for_level(level)) for level, data in level_masks.items()}
    assert all(stats[str(level)]["empty_rgba_zero"] and stats[str(level)]["alpha_equals_red"]
               and stats[str(level)]["premultiplied_gb_le_red"] for level in LEVEL_DESIGNS)
    assert all(stats[str(level)]["coverage_pixel_equivalent"] < stats[str(level + 1)]["coverage_pixel_equivalent"]
               for level in (1, 2, 3)), "Visual tiers must increase their actual stroke coverage"
    stats["iv_original_nonzero_pixels_changed"] = int(np.count_nonzero(
        np.any(level_masks[4] != level_three, axis=-1) & (level_three[..., 0] > 0)))
    stats["iv_retains_original_coverage"] = bool(np.all(level_masks[4][..., 0] >= level_three[..., 0]))
    stats["level_iii_resource"] = TARGET.name
    stats["anti_alias_edge_pixels"] = .32
    (LEVEL_SOURCE / "mask-validation.json").write_text(json.dumps(stats, indent=2) + "\n", encoding="utf-8")
    recipes = {"schema": "spirit-guard-cloud-levels/1", "size": list(SIZE), "uv_extent": [64, 32],
               "anti_alias_edge_pixels": .32,
               "channel_contract": {"R": "coverage", "G": "pathProgress * coverage", "B": "clusterPhase * coverage", "A": "coverage"},
               "strokes": STROKES + LEVEL_FOUR_STROKES,
               "levels": {str(level): {**LEVEL_DESIGNS[level],
                   "resource": TARGET.name if level == 3 else f"spirit_guard_cloud_{level}.png",
                   "clusters": clusters_for_level(level)} for level in LEVEL_DESIGNS}}
    (LEVEL_SOURCE / "cloud-brush-levels.json").write_text(json.dumps(recipes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for level in LEVEL_DESIGNS:
        (LEVEL_SOURCE / f"level-{level}-outlines.svg").write_text(vector_source(curves_for_level(level)), encoding="utf-8")
    level_previews(level_masks)
    rows = "\n".join(f"| {level} | {LEVEL_DESIGNS[level]['name']} | {stats[str(level)]['clusters']} | "
                     f"{stats[str(level)]['strokes']} | {stats[str(level)]['whole_atlas_coverage_percent']}% | "
                     f"{recipes['levels'][str(level)]['resource']} |" for level in LEVEL_DESIGNS)
    descriptions = "\n\n".join(f"**{['I', 'II', 'III', 'IV'][level - 1]} {info['name']}：**{info['description']}"
                                for level, info in LEVEL_DESIGNS.items())
    (LEVEL_SOURCE / "README.md").write_text(
        "# 灵力御体四级云篆资产\n\n"
        "生成器：`tools/generate_guard_cloud_mask.py`。三级沿用原始资源，其余三级写入新文件。"
        "`cloud-brush-levels.json` 保存全部原创贝塞尔中心曲线、宽度、逐笔进度、簇 phase 与各级装备 UV 布局。\n\n"
        + descriptions + "\n\n"
        "| 等级 | 造型 | 云簇数 | 笔数 | 全图实际覆盖 | 游戏资源 |\n"
        "|---|---|---:|---:|---:|---|\n" + rows + "\n\n"
        "所有等级均为1024×512，使用原版64×32装备UV与0.32像素窄抗锯齿边缘。R=A=coverage，"
        "G=pathProgress×coverage，B=clusterPhase×coverage；空白RGBA全零。颜色、亮度、流速和受击强度由游戏接入控制，"
        "等级遮罩只决定独立笔形层次，不改原装备底材。三级像素不变，四级在原有云纹之外添加少量细笔。\n\n"
        "`level-comparison.png`、`level-N-brush-preview.png` 和 `level-N-outlines.svg` 只作静态原创资产说明，"
        "不代表游戏实测、最终动态效果或后处理发光。数据PNG不能当普通彩色贴图显示。\n",
        encoding="utf-8")
    return stats


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preview-texture", type=Path, default=Path("E:/着色器渲染/spirit-guard-glint-lab/textures/netherite_1.png"))
    args = parser.parse_args()
    SOURCE.mkdir(parents=True, exist_ok=True)
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    curves = [(STROKES[s], c, *sample_curve(STROKES[s], c)) for c in CLUSTERS for s in c["strokes"]]
    data = rasterize(curves)
    Image.fromarray(data).save(TARGET)
    Image.fromarray(data).save(SOURCE / "spirit_guard_cloud_mask.png")
    source = {"schema": "spirit-guard-cloud-brush/1", "size": list(SIZE), "uv_extent": [64, 32],
              "channel_contract": {"R": "coverage", "G": "pathProgress * coverage", "B": "clusterPhase * coverage", "A": "coverage"},
              "shader_decode": "pathProgress = g / max(r, 1.0 / 255.0); clusterPhase = b / max(r, 1.0 / 255.0)",
              "strokes": STROKES, "clusters": CLUSTERS}
    (SOURCE / "cloud-brush-source.json").write_text(json.dumps(source, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (SOURCE / "cloud-brush-outlines.svg").write_text(vector_source(curves), encoding="utf-8")
    visual_previews(data, args.preview_texture)
    stats = {"size": list(SIZE), "clusters": len(CLUSTERS), "strokes": len(curves),
             "whole_atlas_nonzero_percent": round(float(np.mean(data[..., 0] > 0) * 100), 3),
             "whole_atlas_coverage_percent": round(float(np.mean(data[..., 0] / 255) * 100), 3),
             "empty_rgba_zero": bool(np.all(data[data[..., 0] == 0] == 0)),
             "alpha_equals_red": bool(np.array_equal(data[..., 0], data[..., 3])),
             "premultiplied_gb_le_red": bool(np.all(data[..., 1:3] <= data[..., 0, None]))}
    for label, box in [("torso_front", [20, 20, 28, 32]), ("torso_back", [32, 20, 40, 32]), ("arm_front", [44, 20, 48, 32])]:
        x0, y0, x1, y1 = [round(v * UV_SCALE) for v in box]
        crop = data[y0:y1, x0:x1, 0]
        stats[label + "_coverage_percent"] = round(float(np.mean(crop / 255) * 100), 3)
        stats[label + "_nonzero_percent"] = round(float(np.mean(crop > 0) * 100), 3)
    (SOURCE / "mask-validation.json").write_text(json.dumps(stats, indent=2) + "\n", encoding="utf-8")
    (SOURCE / "README.md").write_text(
        "# 云篆护纹原创遮罩\n\n"
        "生成器：`tools/generate_guard_cloud_mask.py`。`cloud-brush-source.json` 保存原创三次贝塞尔中心曲线、沿程宽度、进度范围和精确原版装备 UV 布局。\n\n"
        "`cloud-brush-outlines.svg` 是按上述曲线与宽度采样的闭合笔形轮廓，尖笔尾由宽度渐零产生，不使用随机噪声、规则网格或平铺。主簇三笔，副簇一到两笔，各簇 phase 错开。\n\n"
        "数据图为 1024×512 RGBA：R=A=coverage，G=pathProgress×coverage，B=clusterPhase×coverage；空白像素四通道全零。收窄到0.32像素的抗锯齿边缘，避免小笔画被柔边吞没。着色器采样后用 g/r 与 b/r 恢复进度和簇 phase，线性过滤不把边缘混为零 phase。数据图不能作为普通彩色贴图展示。\n\n"
        "`cloud-brush-color-preview.png` 只便于观察笔形；`rgba-contract-preview.png` 为通道伪彩色。`netherite-cloud-comparison.png` 使用玩家本地原版下界合金纹理进行静态对照，非游戏截图、非最终动态效果，也不包含在 mod 资源中。底材从未被修改。\n\n"
        "资源路径：`assets/wuxingxiantu/textures/effect/spirit_guard_cloud_mask.png`。装备复用原版 64×32 UV，动画循环由着色器控制，支持甲面逐笔显现、沿笔形亮芯以及接力消散。\n\n"
        "该原始资源现作为灵力御体III，像素保持不变。I、II、IV新增独立遮罩，完整分级配方、统计与静态资产对照见[四级说明](levels/README.md)。\n",
        encoding="utf-8")
    level_stats = write_level_assets(data)
    print(json.dumps(level_stats, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
