"""Import the supplied cultivation insight artwork as a transparent 64x64 item texture."""
from pathlib import Path
import json
import shutil
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
OUT = ROOT / 'source-assets/cultivation-insight-20261008'
SOURCE = Path('C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-20070d75-e1c0-44c5-ba89-e01d5da4199a.png')
OUT.mkdir(parents=True, exist_ok=True)
if not (OUT/'reference-original.png').exists(): shutil.copy2(SOURCE, OUT/'reference-original.png')
SOURCE = OUT/'reference-original.png'
original = Image.open(SOURCE).convert('RGBA')
bounds = original.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
assert bounds is not None
crop = original.crop(bounds)
crop.save(OUT/'crop.png')
icon = crop.copy()
icon.thumbnail((60,60), Image.Resampling.NEAREST)
texture = Image.new('RGBA',(64,64))
offset = ((64-icon.width)//2,(64-icon.height)//2)
texture.paste(icon,offset)
path = ASSETS/'textures/item/cultivation_insight.png'
model = ASSETS/'models/item/cultivation_insight.json'
for file in [path,model]:
    backup=OUT/('before-'+file.name)
    if file.exists() and not backup.exists(): shutil.copy2(file,backup)
texture.save(path)
model.write_text(json.dumps({'parent':'minecraft:item/generated',
                            'textures':{'layer0':'wuxingxiantu:item/cultivation_insight'}},indent=2)+'\n',encoding='utf-8')
check = Image.open(path).convert('RGBA')
assert check.size == (64,64)
assert check.getchannel('A').getextrema()[0] == 0
assert check.getchannel('A').getextrema()[1] >= 128
assert json.loads(model.read_text())['textures']['layer0']=='wuxingxiantu:item/cultivation_insight'
preview = Image.new('RGBA',(320,320),(42,45,44,255))
preview.alpha_composite(texture.resize((320,320),Image.Resampling.NEAREST))
preview.save(OUT/'preview.png')
(OUT/'manifest.json').write_text(json.dumps({'source_size':original.size,'crop_bounds':bounds,
    'crop_size':crop.size,'icon_size':icon.size,'texture_size':texture.size,'resampling':'NEAREST'},indent=2)+'\n',encoding='utf-8')
print('PASS: cultivation_insight 64x64 transparent texture and independent model reference')
