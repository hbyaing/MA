"""Extract the current Java catalogues; keep facts separate from authored VFX recipes."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
JAVA = ROOT / 'src/main/java/cn/blockforge/generated/generatedmod'
LANG_PATH = ROOT / 'src/main/resources/assets/wuxingxiantu/lang/zh_cn.json'


def source(path: Path, text: str, offset: int = 0) -> dict:
    return {'path': path.relative_to(ROOT).as_posix(), 'line': text[:offset].count('\n') + 1,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def read_java(relative: str):
    path = JAVA / relative
    return path, path.read_text(encoding='utf-8-sig')


def extract() -> dict:
    lang = json.loads(LANG_PATH.read_text(encoding='utf-8-sig'))
    entries, sources = [], {}

    def add(id, name, group, path, text, offset, **facts):
        evidence = source(path, text, offset)
        sources[evidence['path']] = evidence['sha256']
        entry = dict(id=id, name=name, category=group, source=evidence, facts=facts)
        entries.append(entry)
        return entry

    path, text = read_java('ArtCatalog.java')
    for m in re.finditer(r'new Entry\("(art_[^"]+)",\s*(\d+),\s*Type\.(\w+)\)', text):
        id, tier, kind = m.groups()
        add(id, lang['item.wuxingxiantu.' + id].removeprefix('功法秘籍·'), '功法', path, text, m.start(),
            tier=int(tier), type=kind, description=lang.get('art.wuxingxiantu.function.' + id, ''),
            implementation='network/packet/cultivation/ArtReleasePacket.java',
            reality_note='普通攻击分支使用玩家 AABB 扩张范围结算；粒子造型不代表新增弹道。御剑剑技走独立控制器。')
    path, text = read_java('yujian/SwordTechniqueRegistry.java')
    for m in re.finditer(r'new Technique\("([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)\)', text):
        id, name, desc, tier, stage, insight, mana, cd, shadows = m.groups()
        e = next(e for e in entries if e['id'] == id)
        e['category'] = '御剑剑技'
        e['facts']['sword_technique'] = dict(name=name, description=desc, requiredTier=int(tier), requiredStage=int(stage), mana=int(mana), cooldown=int(cd), maxShadows=int(shadows))
        e['implementation_source'] = source(path, text, m.start())
        sources[e['implementation_source']['path']] = e['implementation_source']['sha256']
    path, text = read_java('DivineArtCatalog.java')
    for m in re.finditer(r'new Entry\("([^"]+)",\s*(\d+),\s*(\d+),\s*"([^"]+)"\)', text):
        id, realm, cd, item = m.groups()
        add(id, lang['divine.wuxingxiantu.' + id], '神通', path, text, m.start(), requiredRealm=int(realm), cooldownTicks=int(cd), item=item, description=lang.get('divine.wuxingxiantu.function.' + id, ''), implementation='DivineArtLogic.java')
    path, text = read_java('HeartMethodCatalog.java')
    ids = re.search(r'METHOD_IDS\s*=\s*List.of\((.*?)\);', text, re.S)
    for m in re.finditer(r'"([^"]+)"', ids[1]):
        id = m[1]
        add('heart_method_' + id, lang['item.wuxingxiantu.heart_method_' + id], '心法·被动', path, text, ids.start(1) + m.start(),
            description=lang['gui.wuxingxiantu.heart_method.description.' + id],
            reality_note='心法为被动系统；本库提供修炼/激活外观建议，不声称源码已有主动施放技能。')
    path, text = read_java('boss/combat/BossCombatCatalog.java')
    profiles = list(re.finditer(r'add\(profiles,\s*"([^"]+)",\s*0x([0-9A-Fa-f]+)', text))
    program_path, program = read_java('boss/combat/BossSkillPrograms.java')
    methods = list(re.finditer(r'private static void (\w+)\(BossCombatController c,int n\)', program))
    method_blocks = {m[1]: (program[m.start():methods[i+1].start() if i+1<len(methods) else program.index('private static void wave')], m.start()) for i,m in enumerate(methods)}
    for i, profile in enumerate(profiles):
        boss, color = profile.groups()
        end = profiles[i+1].start() if i+1<len(profiles) else text.index('PROFILES =')
        for m in re.finditer(r'skill\("[^"]+",\s*(\d+),\s*"([^"]+)",\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*"([^"]+)"\)', text[profile.start():end]):
            no, name, phase, windup, recovery, cd, hint = m.groups()
            e = add(f'{boss}_{int(no):02}', name, 'Boss', path, text, profile.start()+m.start(), boss=boss, bossName=lang['entity.wuxingxiantu.'+boss], color='#'+color, phase=int(phase), windupTicks=int(windup), recoveryTicks=int(recovery), cooldownTicks=int(cd), hint=hint)
            block, offset = method_blocks[boss]
            case = re.search(r'case '+no+r'\s*->(.*?)(?=\n\s*(?:case \d+|default))', block, re.S)
            if case is None:
                raise ValueError(f'Missing implementation for {e["id"]}')
            e['implementation_source'] = source(program_path, program, offset+case.start())
            e['facts']['program'] = case[0].strip()
            e['facts']['operations'] = sorted(set(re.findall(r'\b(?:c\.)?(line|ring|cone|circle|column|wave|sweep|projectile|zone|dash|pull|tether|gapRing|walls|sectors|mirrors|gaze|feast|radial)\(', case[0])))
    path, text = read_java('boss/combat/HeartDemonSkillPrograms.java')
    for m in re.finditer(r'skill\((\d+),"([^"]+)",(\d+),(\d+),(\d+),(\d+),"([^"]+)","([^"]+)"\)', text):
        no, name, phase, w, rec, cd, anim, hint = m.groups()
        case = re.search(r'case '+no+r'\s*->(.*?)(?=\n\s*(?:case \d+|default))', text, re.S)
        e = add(f'heart_demon_{int(no):02}', name, 'Boss', path, text, m.start(), boss='heart_demon', bossName='心魔', color='#C786ED', phase=int(phase), windupTicks=int(w), recoveryTicks=int(rec), cooldownTicks=int(cd), animation='animation.xinmo_wuxiang.'+anim, hint=hint, program=case[0].strip(), operations=sorted(set(re.findall(r'\b(?:c\.)?(line|ring|cone|circle|column|wave|dash|pull|gaze)\(', case[0]))))
        e['implementation_source'] = source(path, text, case.start())
    path, text = read_java('TalismanCatalog.java')
    glyphs = {}
    for m in re.finditer(r'put\("([^"]+)",\s*"([^"]+)",\s*Effect\.(\w+),.*?new String\[\]\s*\{(.*?)\}', text, re.S):
        id, key, effect, glyph = m.groups()
        glyphs[id] = re.findall(r'"([.X]+)"', glyph)
        add('talisman_'+id, lang[key], '符箓', path, text, m.start(), effect=effect, glyphAsset='glyph_'+id, reality_note='符纹严格采用源码中的 16×32 模板。')
    path, text = read_java('fire/FireCatalog.java')
    for m in re.finditer(r'new Definition\("([^"]+)",\s*(\d+),\s*"([^"]+)",\s*(\d+),\s*Acquisition\.(\w+)\)', text):
        id, tier, rarity, realm, acquisition = m.groups()
        colors_path = ROOT / 'src/main/resources/assets/wuxingxiantu/weapon_flames' / (id+'.json')
        colors = json.loads(colors_path.read_text('utf-8'))['colors']
        sources[colors_path.relative_to(ROOT).as_posix()] = hashlib.sha256(colors_path.read_bytes()).hexdigest()
        name = next((v for k,v in lang.items() if k in ('fire.wuxingxiantu.'+id, 'exotic_fire.wuxingxiantu.'+id, 'block.wuxingxiantu.exotic_fire_'+id)), lang.get('item.wuxingxiantu.fire_seed_'+id,id).replace('火种瓶·','异火·'))
        add('fire_'+id, name, '异火素材', path, text, m.start(), tier=int(tier), colors=colors, acquisition=acquisition, reality_note='只提供新素材与已有配色；不恢复已退役的剑身缠绕和拖尾实现。')
    path, text = read_java('HeartSwordSystem.java')
    for action, name in [('SUMMON','心剑凝聚'),('DISPERSE','心剑消散'),('FORGE','心铸'),('UNFORGE','解铸')]:
        add('heart_sword_'+action.lower(), name, '心剑仪式', path, text, text.index('enum Action'), action=action, reality_note='绑定现有 HeartSwordVisualPacket 的阶段事件，取消必须停止持续发射。')
    for id,name,relative,needle,description in [
        ('tribulation','渡劫雷击','TribulationManager.java','ELECTRIC_SPARK','以劫雷判定落点为准；不要用装饰闪电扩大伤害范围。'),
        ('alchemy','丹成灵光','client/AlchemyFurnaceEffects.java','class AlchemyFurnaceEffects','丹炉客户端持续火星与丹成提示素材。'),
        ('offering','祭炼聚灵','client/OfferingItemRenderer.java','class OfferingItemRenderer','祭炼物品的吸附、聚灵与消散层。')]:
        path,text=read_java(relative)
        add(id,name,'系统特效',path,text,text.index(needle),description=description)
    for e in entries:
        if 'implementation_source' in e:
            s=e['implementation_source']; sources[s['path']]=s['sha256']
    for relative in ['network/packet/cultivation/ArtReleasePacket.java','DivineArtLogic.java','boss/combat/BossCombatController.java','network/packet/boss/BossCombatFxPacket.java','yujian/SwordTechniqueRegistry.java']:
        path,text=read_java(relative); sources[path.relative_to(ROOT).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
    sources[LANG_PATH.relative_to(ROOT).as_posix()] = hashlib.sha256(LANG_PATH.read_bytes()).hexdigest()
    assert len({e['id'] for e in entries})==len(entries), 'Duplicate skill id'
    return dict(schemaVersion=1, sourceDate='2026-09-29', entries=entries, glyphs=glyphs, sourceHashes=sources,
                scope='当前目录注册表、对应 Boss 程序、符箓、异火、心剑仪式及三项系统特效；不包含所有生物 AI 的普通攻击或七十二变逐实体动作。')
