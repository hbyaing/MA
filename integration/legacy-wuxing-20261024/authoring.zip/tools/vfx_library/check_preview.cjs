const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
const {chromium} = require('playwright');
const root = path.resolve(__dirname, '../..');
const out = path.join(root, 'source-assets/skill-particle-library-v1');
const reports = path.join(root, 'reports/skill-particle-library-v1');
fs.mkdirSync(reports, {recursive: true});
(async () => {
  const browser = await chromium.launch({headless:true, executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
  const page = await browser.newPage({viewport:{width:1500,height:1120},deviceScaleFactor:1});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>errors.push(r.url()+': '+r.failure().errorText));
  await page.goto(pathToFileURL(path.join(out,'preview/index.html')).href);
  await page.waitForFunction(()=>window.VFX_PREVIEW_READY===true,{timeout:30000});
  await page.evaluate(()=>window.VFX_PREVIEW.seek(14));
  await page.screenshot({path:path.join(reports,'preview-flame.png'),fullPage:true});
  const states=await page.evaluate(()=>{
    const api=window.VFX_PREVIEW,d=window.VFX_LIBRARY,checks=[];
    for(const e of d.entries){api.selectSkill(e.id);api.seek(16);if(document.getElementById('title').textContent!==e.name)throw Error('Title '+e.id);checks.push(e.id)}
    for(const m of d.materials){api.selectMaterial(m.id);for(const t of [0,15,30,45,59])api.seek(t)}
    return {skills:checks.length,materials:d.materials.length,materialFrameSamples:d.materials.length*5};
  });
  await page.click('#skillTab');await page.fill('#search','心魔');
  const searchCount=await page.locator('#list .entry').count();
  if(searchCount!==10)throw Error('Heart demon search: '+searchCount);
  await page.fill('#search','no_matching_ability_123');
  if(await page.locator('#list .entry').count()!==0)throw Error('Empty search');
  await page.fill('#search','');
  await page.evaluate(()=>{window.VFX_PREVIEW.selectSkill('art_thunder');window.VFX_PREVIEW.seek(7)});
  await page.screenshot({path:path.join(reports,'preview-thunder.png'),fullPage:true});
  await page.evaluate(()=>{window.VFX_PREVIEW.selectSkill('heart_demon_05');window.VFX_PREVIEW.seek(22)});
  await page.screenshot({path:path.join(reports,'preview-gaze.png'),fullPage:true});
  await page.locator('#color').fill('#36abff');
  if(await page.locator('#colorHex').textContent()!=='#36ABFF')throw Error('Color input');
  await page.locator('#time').fill('500');
  if(await page.locator('#play').textContent()!=='播放')throw Error('Seek must pause');
  const downloaded=page.waitForEvent('download');await page.click('#download');const file=await downloaded;await file.saveAs(path.join(reports,'exported-recipe.json'));
  const saved=JSON.parse(fs.readFileSync(path.join(reports,'exported-recipe.json'),'utf8'));if(saved.skillId!=='heart_demon_05'||saved.previewColor!=='#36abff')throw Error('Export mismatch');
  await page.setViewportSize({width:680,height:960});
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);if(overflow)throw Error('Mobile horizontal overflow');
  await page.screenshot({path:path.join(reports,'preview-mobile.png'),fullPage:true});
  await page.setViewportSize({width:1500,height:1120});
  await page.evaluate(()=>{window.VFX_PREVIEW.selectSkill('art_flame_wave');window.VFX_PREVIEW.seek(12)});
  const frameDir=path.join(reports,'frames');fs.mkdirSync(frameDir,{recursive:true});
  for(let i=0;i<24;i++){await page.evaluate(t=>window.VFX_PREVIEW.seek(t),i*2);await page.locator('#stage').screenshot({path:path.join(frameDir,String(i).padStart(3,'0')+'.png')});}
  await browser.close();
  const result={passed:errors.length===0,...states,heartDemonSearchResults:searchCount,localFileAssetsLoaded:true,exportVerified:true,mobileOverflow:overflow,errors};
  fs.writeFileSync(path.join(reports,'browser-validation.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));if(errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
