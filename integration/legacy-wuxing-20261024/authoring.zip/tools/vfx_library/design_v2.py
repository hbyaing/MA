"""Art-directed V2: individual visual language, motif, choreography and stage rhythm."""
from design import PALETTES, MATERIALS as BASE_MATERIALS, assign

# Each extra ID has its own silhouette or internal structure in textures_v2.py.
EXTRA_MATERIALS = [
 ('ink_crescent','泼墨剑月','剑意','once','add'),('spear_head','贯日枪锋','剑意','none','add'),
 ('sword_fan','万剑折扇','剑意','none','add'),('bell_shell','金钟壳纹','护体','none','add'),
 ('armor_scale','甲鳞','护体','none','alpha'),('pierce_diamond','破甲菱锋','剑意','once','add'),
 ('branch_bloom','萌枝','生机','once','alpha'),('root_lattice','缠根网','生机','none','alpha'),
 ('seed_pod','种荚','生机','none','alpha'),('feather_lift','轻羽','身法','none','alpha'),
 ('tide_crest','卷潮尖','水势','loop','add'),('frost_fern','霜蕨','水势','none','add'),
 ('ice_lance','六面冰枪','水势','none','alpha'),('mountain_ridge','叠山','地势','none','alpha'),
 ('quake_wedge','崩岩楔纹','地势','once','add'),('sand_grain','砂砾','地势','none','alpha'),
 ('meridian_knot','经络结','修行','loop','add'),('blood_fang','血牙','修行','none','alpha'),
 ('fire_brush','赤流焰锋','异火·九形','loop','add'),('molten_drip','熔金液脉','异火·九形','loop','add'),
 ('bone_flare','枯骨寒焰','异火·九形','loop','add'),('budding_flame','木芽青焰','异火·九形','loop','add'),
 ('sea_flame','碧海涡焰','异火·九形','loop','add'),('plasma_flame','紫霄电焰','异火·九形','loop','add'),
 ('solar_prominence','日珥','异火·九形','loop','add'),('nether_veil','冥火幽帷','异火·九形','loop','alpha'),
 ('phoenix_plume','涅槃凤翎','异火·九形','loop','add'),
 ('iris_spokes','虹瞳辐纹','目魇','loop','add'),('chroma_prism','分色棱光','目魇','none','add'),
 ('lens_crescent','月牙透镜','目魇','none','add'),('mirage_frame','重影镜框','目魇','none','add'),
 ('tuning_fork','震音双叉','耳魅','none','add'),('sound_ribbon','弦音','耳魅','loop','add'),
 ('waveform_gate','频谱声墙','耳魅','loop','add'),('echo_lozenge','回声梭','耳魅','once','add'),
 ('spore_cluster','孢子簇','鼻嗔','none','alpha'),('venom_needle','毒腺针','鼻嗔','none','alpha'),
 ('toxic_veins','瘴脉','鼻嗔','loop','alpha'),('scent_ribbon','追香细带','鼻嗔','loop','alpha'),
 ('tongue_sickle','舌镰','舌饕','none','alpha'),('taste_curl','味蕾涡纹','舌饕','loop','add'),
 ('acid_teardrop','垂酸','舌饕','none','alpha'),('hunger_maw','饕口牙环','舌饕','once','alpha'),
 ('crystal_fan','扇生晶须','身淫','none','alpha'),('crystal_lotus','棱晶莲','身淫','once','add'),
 ('spike_crown','晶刺冠','身淫','none','alpha'),('nerve_tendril','感触神经丝','身淫','loop','add'),
 ('folded_mirror','折叠镜片','意惑','none','alpha'),('memory_footprint','旧影足迹','意惑','none','add'),
 ('thought_rift','妄念裂口','意惑','loop','add'),('mind_knot','心结','意惑','loop','add'),
 ('coin_charm','古钱','彭倨','none','alpha'),('ingot_wing','金翅刃','彭倨','none','add'),
 ('gold_stamp','镇金印','彭倨','none','add'),('greed_hook','贪念钩','彭倨','none','add'),
 ('wine_foam','腐酒泡沫','彭质','loop','alpha'),('wine_stream','酒液飞带','彭质','loop','alpha'),
 ('gut_wave','腹腔褶浪','彭质','once','alpha'),('sucker_disc','触手吸盘','彭质','none','alpha'),
 ('metal_sigil','金核刃纹','彭矫·五核','none','add'),('wood_sigil','木核枝纹','彭矫·五核','none','add'),
 ('water_sigil','水核回纹','彭矫·五核','none','add'),('fire_sigil','火核赤纹','彭矫·五核','none','add'),
 ('earth_sigil','土核岳纹','彭矫·五核','none','add'),
 ('torn_mask','无相残面','心魔','none','alpha'),('karma_petal','业火残瓣','心魔','loop','add'),
 ('heart_fissure','裂心纹','心魔','once','add'),('delusion_eye','妄念竖瞳','心魔','loop','add'),
 ('chain_barb','倒刺锁节','心魔','none','alpha'),
 ('giant_halo','法相肩轮','神通','none','add'),('dipper_thread','七星连络','神通','loop','add'),
 ('astral_body','元神轮廓','神通','loop','add'),('yin_yang_clock','阴阳时轮','神通','loop','add'),
 ('ruyi_cloud','如意云头','神通','loop','alpha'),
 ('furnace_breath','炉息','炼制','loop','add'),('pill_orbit','丹纹','炼制','none','add'),
 ('forge_stitch','心铸缝光','心铸','once','add'),('unweave_thread','解铸断丝','心铸','once','add'),
]
MATERIALS=BASE_MATERIALS+EXTRA_MATERIALS

# Explicit authoring parameters; not damage geometry. These are consumed by preview and native exporter.
def L(material,motion,count=1,size=1.2,delay=0,life=30,**params):
    return dict(material=material,motion=motion,count=count,sizeBlocks=size,delayTicks=delay,lifetimeTicks=life,**params)

def hero(mat,motion='center',size=3,**params):
    params.setdefault('role','主形');return L(mat,motion,1,size,**params)
def accent(mat,motion,count=8,size=.6,**params):
    params.setdefault('role','次形');params.setdefault('colorRole','edge');return L(mat,motion,count,size,**params)
def glints(mat,motion='burst',count=9,size=.2,**params):
    params.setdefault('role','余韵');params.setdefault('colorRole','core');return L(mat,motion,count,size,**params)

# Every slot is independently authored. Common minor motes are deliberately kept secondary.
ART_RECIPES={
 'sword_aura':('墨月出鞘：单次宽弧、碎锋沿切线飞离',[hero('ink_crescent','sweep',3.8,life=18),accent('pierce_diamond','fan',7,.4,delay=5),glints('spark_needle','tangent',12,delay=7)]),
 'renewal':('萌枝回春：枝芽逐层生长、种子缓升',[hero('branch_bloom','grow',2.8,life=48),accent('seed_pod','helix',9,.35,delay=9,life=44),glints('leaf','petal_fall',6,.4,delay=18,life=40)]),
 'spirit_shield':('灵力膜：六角护片收束成壳',[hero('shield_hex','shell',2.8,life=44),accent('meridian_knot','converge',6,.8,delay=4),glints('spark_soft','suspend',8,.2,delay=18)]),
 'immobilize':('锁根定身：四方束线、脚下缠根',[hero('root_lattice','ground',3.5,life=50),accent('chain_barb','cage',6,.7,delay=5,life=40),glints('seal_glyph','stamp',1,1.0,delay=16)]),
 'light_body':('轻羽托身：羽片斜掠、双股上升风',[accent('feather_lift','helix',10,.85,life=50),hero('wind_curl','rise',2.4,delay=8,life=38),glints('water_droplet','rise',8,.16,delay=14)]),
 'golden_bell':('金钟扣合：钟壳下落、鳞甲沿周缘闭合',[hero('bell_shell','stamp',3.6,life=56),accent('armor_scale','shell',9,.65,delay=9,life=44),glints('coin_charm','orbit',5,.28,delay=16)]),
 'ice_spike':('破土冰枪：错峰升刺、横向霜蕨铺展',[accent('ice_lance','eruption',7,1.5,life=34,staggerTicks=2),hero('frost_fern','ground',4,delay=7,life=38),glints('snow_crystal','burst',9,.25,delay=16)]),
 'spirit_gathering':('旋生聚灵：灵种由外汇聚、经络渐亮',[hero('meridian_knot','center',2.8,life=58),accent('seed_pod','converge',18,.35,life=45),glints('branch_bloom','grow',3,.8,delay=27)]),
 'armor_break':('菱锋破甲：先窄后裂、甲片向外翻飞',[hero('pierce_diamond','lunge',3.4,life=17),accent('armor_scale','shatter',12,.62,delay=9,life=36),glints('sword_cross','slash',1,2,delay=10)]),
 'flame_wave':('赤流浪头：火锋扇推、热浪后继',[accent('fire_brush','fan',7,1.7,life=30,spread=2.3),hero('heat_wisp','sweep',3.8,delay=7,life=30),glints('ember_fragment','ballistic',16,.3,delay=10)]),
 'flash_step':('折光闪身：前后残影错位、羽状裂丝',[accent('thought_rift','afterimage',4,2.3,life=24,staggerTicks=3),glints('feather_lift','lunge',10,.6,delay=4),hero('lens_crescent','shatter',2.4,delay=14,life=16)]),
 'purification':('净邪开瓣：白莲展开、污痕向外脱落',[hero('lotus','bloom',3.6,life=44),accent('glyph_purge','helix',5,.72,delay=10,life=35),glints('talisman_ash','shatter',14,.25,delay=15)]),
 'bloodlust':('血牙脉冲：尖锐逆向回旋、两次心搏',[hero('blood_fang','pulse',3.2,life=38),accent('karma_petal','inward',12,.72,delay=4,life=35),glints('heart_fissure','pulse',1,1.5,delay=13)]),
 'thunder':('霆网镇落：主雷纵劈、地面分枝电网',[hero('lightning_branch','column',5.2,life=12),hero('toxic_veins','ground',4.0,delay=5,life=25,colorRole='core'),accent('plasma_flame','fork',5,.9,delay=3,life=18),glints('thunder_core','burst',3,.7,delay=8)]),
 'myriad_swords':('万剑开屏：扇状剑幕、分批坠下',[hero('sword_fan','bloom',4.8,life=44),accent('sword_ghost','rain',24,1.2,delay=12,life=30,staggerTicks=1),glints('pierce_diamond','eruption',10,.4,delay=29)]),
 'immovable_mountain':('岳影镇身：三重山脊、低位砂浪',[hero('mountain_ridge','stamp',4.4,life=58),accent('earth_shard','cage',6,1.3,delay=10,life=45),glints('sand_grain','ground_wave',22,.25,delay=16)]),
 'human_harmony':('天人经络：上行枝脉、双向丹纹回旋',[hero('meridian_knot','grow',3.8,life=64),accent('pill_orbit','helix',7,.55,delay=14,life=44),glints('feather_lift','petal_fall',8,.6,delay=20)]),
 'five_elements':('五相轮转：五种核纹依次合拢、五瓣爆发',[accent('metal_sigil','pentad',1,1.45,life=44,colorRole='metal'),accent('wood_sigil','pentad',1,1.45,delay=4,life=44,angle=72,colorRole='wood'),accent('water_sigil','pentad',1,1.45,delay=8,life=44,angle=144,colorRole='water'),accent('fire_sigil','pentad',1,1.45,delay=12,life=44,angle=216,colorRole='fire'),accent('earth_sigil','pentad',1,1.45,delay=16,life=44,angle=288,colorRole='earth'),hero('crystal_lotus','bloom',4.0,delay=32)]),
 'sword_pierce':('飞星贯日：窄锋加速、透点拖束',[hero('spear_head','lunge',3.8,life=24),accent('wind_streak','tangent',8,1,delay=4,life=22),glints('prism_glint','beam',6,.22,delay=10)]),
 'sword_sweep':('回风双环：切向剑月、反向羽流',[accent('ink_crescent','orbit',3,2.3,life=34,speed=1.8),accent('feather_lift','tangent',12,.55,delay=7,speed=-1),hero('tide_crest','ground_wave',3.0,delay=12)]),
 'sword_guard':('六御成壁：六剑定向、甲纹逐面亮起',[accent('sword_ghost','hex_guard',6,1.8,life=60),accent('armor_scale','shell',12,.6,delay=10,life=50),hero('metal_sigil','ground',2.0,delay=14,life=42)]),
 'sword_array':('太虚天门：镜隙开启、剑列穿门下落',[hero('mirage_frame','gate',4.4,life=52),accent('sword_ghost','rain',15,1.5,delay=15,life=28,staggerTicks=2),hero('thought_rift','column',3.3,delay=24,life=32)]),
 'sword_flight':('凌霄流羽：两股前行气流、云足展开',[hero('spear_head','beam',2.6,life=44),accent('feather_lift','ribbon',12,.8,life=50),accent('ruyi_cloud','wake',3,1.8,delay=10,life=38)]),
}

# Ten boss families, each with explicitly different sub-skills and timings.
BOSS_RECIPES={
 'muyan':[
 ('三枚虹梭前后追发',[hero('chroma_prism','lunge',2.5),accent('iris_spokes','beam',3,1.3,staggerTicks=8),glints('lens_crescent','wake',8,.5,delay=9)]),
 ('偏心虹扇横扫',[hero('lens_crescent','sweep',4.8,life=44),accent('chroma_prism','fan',9,.7,delay=8,staggerTicks=2),glints('prism_glint','tangent',10,.3,delay=12)]),
 ('交错透镜向外震荡',[accent('lens_crescent','ground_wave',4,3.3,staggerTicks=8,life=32),hero('iris_spokes','pulse',2.0,life=46),glints('chroma_prism','tangent',8,.35,delay=16)]),
 ('三面重影框与真假瞳光',[accent('mirage_frame','mirror_pair',3,2.3,life=52),accent('eye_sigil','afterimage',3,1.2,delay=10),glints('folded_mirror','shatter',8,.6,delay=32)]),
 ('竖瞳聚焦后脉冲开镜',[hero('iris_spokes','converge',4.1,life=62),hero('eye_sigil','pulse',2.5,delay=17,life=42),accent('lens_crescent','shell',4,1.1,delay=22)]),
 ],
 'ermei':[
 ('弦音扇面与分叉音刃',[accent('tuning_fork','fan',7,1.5,life=30),hero('sound_ribbon','sweep',4,delay=5),glints('echo_lozenge','wake',8,.4,delay=10)]),
 ('三层低频波峰贴地外扩',[hero('sound_wave','ground_wave',4.4,life=38),accent('echo_lozenge','orbit',8,.55,delay=6),hero('gut_wave','pulse',2.1,delay=14,life=26)]),
 ('回声梭弯曲追猎',[accent('echo_lozenge','homing',3,1.7,life=44,staggerTicks=7),accent('sound_ribbon','ribbon',10,.9,delay=4),glints('tuning_fork','wake',5,.45,delay=16)]),
 ('三拍落点依次起伏',[accent('waveform_gate','stamp',3,2.8,life=18,staggerTicks=14),accent('quake_wedge','ground_wave',3,2,delay=7,staggerTicks=14),glints('sand_grain','ballistic',12,.25,delay=24)]),
 ('双频谱墙相向合拢',[accent('waveform_gate','walls',2,3.8,life=52),accent('tuning_fork','curtain',8,.6,delay=14,life=40),glints('echo_lozenge','inward',10,.35,delay=22)]),
 ('由密至疏的频谱收束与寂灭',[hero('waveform_gate','pulse',5.0,life=62),accent('sound_wave','ground_wave',3,3.4,delay=10,staggerTicks=14),accent('sound_ribbon','converge',8,1.0,delay=39,life=28)]),
 ],
 'bichen':[
 ('三滴重腐液落下、孢簇炸散',[accent('acid_teardrop','ballistic',3,1.4,staggerTicks=9),accent('spore_cluster','eruption',9,.65,delay=18),hero('acid_splash','ground',3.2,delay=15,life=45)]),
 ('瘴脉弧扫、香带贴地飘行',[hero('toxic_veins','sweep',4.2,life=42),accent('scent_ribbon','ribbon',10,1.1,delay=7),glints('spore_cluster','wake',8,.45,delay=20)]),
 ('针簇双轮放射',[accent('venom_needle','radial',12,1.0,life=25),accent('venom_needle','fan',7,.8,delay=16,angle=22),hero('spore_cluster','pulse',2.2,delay=5)]),
 ('香迹指向扑点、毒泡压裂',[hero('scent_ribbon','lunge',4.5,life=25),hero('poison_bubble','stamp',3.2,delay=12),accent('venom_needle','ground_wave',8,.7,delay=23)]),
 ('五路吸瘴收回、毒脉鼓胀',[accent('scent_ribbon','converge',5,1.8,life=50),hero('toxic_veins','pulse',3.3,delay=24),accent('poison_bubble','inward',14,.5,delay=5)]),
 ('分区孢群生长、重瘴压低',[accent('spore_cluster','cage',8,1.25,life=60,staggerTicks=3),hero('toxic_veins','ground',5,delay=12,life=62),accent('poison_cloud','curtain',6,1.9,delay=25,life=44)]),
 ],
 'shetao':[
 ('双侧舌镰接窄刺',[accent('tongue_sickle','sweep',2,3.1,life=20,staggerTicks=13),hero('spear_head','lunge',2.8,delay=29,life=16),glints('taste_curl','wake',7,.4,delay=9)]),
 ('卷舌伸出、倒钩回卷',[hero('tongue_sickle','tether',4.0,life=44),accent('greed_hook','reel',6,.55,delay=8),hero('hunger_maw','pulse',2.6,delay=20)]),
 ('酸滴四批落地溅开',[accent('acid_teardrop','rain',16,.7,life=24,staggerTicks=2),hero('acid_splash','ground',4,delay=17,life=50),glints('poison_bubble','rise',10,.3,delay=29)]),
 ('饕口喷出短粗辣焰',[hero('hunger_maw','center',2.8,life=36),accent('fire_brush','fan',9,1.3,delay=8,spread=1.5),accent('taste_curl','ribbon',5,.9,delay=16)]),
 ('供食味纹围口聚合',[accent('taste_curl','pentad',5,1.3,life=52),hero('hunger_maw','converge',3.5,delay=15),accent('seed_pod','inward',10,.6,delay=12)]),
 ('滚腹残口与地面重碾',[hero('hunger_maw','rolling',3.8,life=36),accent('tongue_sickle','wake',4,1.6,delay=7),glints('quake_wedge','ground_wave',3,1.9,delay=17)]),
 ('五味分扇翻涌',[accent('taste_curl','sectors',5,2.2,life=28,staggerTicks=6,colorRole='elements'),accent('acid_teardrop','ballistic',10,.65,delay=13),hero('hunger_maw','bloom',4.3,delay=37)]),
 ],
 'shenyin':[
 ('四处晶须错拍刺出',[accent('crystal_fan','eruption',4,2.0,life=32,staggerTicks=6),accent('nerve_tendril','ribbon',7,.7,delay=6),glints('prism_glint','burst',10,.3,delay=23)]),
 ('两重触臂内外交错',[accent('nerve_tendril','sweep',2,4.4,life=26,staggerTicks=17),accent('crystal_fan','fan',7,.8,delay=10),hero('spike_crown','ground_wave',3.1,delay=24)]),
 ('神经旋流吸入晶心',[hero('nerve_tendril','helix',4.0,life=54),accent('crystal_shard','converge',15,.7,life=46),hero('crystal_lotus','bloom',3.2,delay=34)]),
 ('三处晶块掷落、扇簇生长',[accent('crystal_shard','ballistic',3,1.6,life=28,staggerTicks=8),accent('crystal_fan','grow',3,2.2,delay=20,life=45),glints('spike_crown','stamp',3,1.1,delay=32)]),
 ('三侧晶冠围牢、裂口留空',[accent('spike_crown','cage',3,2.3,life=58,angle=45),accent('crystal_fan','walls',2,2.8,delay=10),hero('heart_fissure','pulse',1.6,delay=21)]),
 ('神经串晶的可断链',[accent('crystal_shard','tether',12,.55,life=52),hero('nerve_tendril','beam',4.8,life=50),hero('mind_knot','pulse',1.5,delay=18)]),
 ('五瓣晶莲依次升华',[hero('crystal_lotus','bloom',4.6,life=54),accent('crystal_fan','sectors',5,1.8,delay=8,staggerTicks=5),glints('nerve_tendril','converge',10,.6,delay=31)]),
 ],
 'yihuo':[
 ('两侧虚镜、中央实刃',[accent('folded_mirror','mirror_pair',2,2,life=32),hero('thought_rift','lunge',3.7,delay=14),accent('pierce_diamond','fan',5,.6,delay=22)]),
 ('足迹折返镜移、显形裂口',[accent('memory_footprint','afterimage',6,.7,life=26,staggerTicks=2),hero('folded_mirror','gate',3.1,delay=9),hero('thought_rift','sweep',3.3,delay=21)]),
 ('旧影步点顺次重放',[accent('memory_footprint','path_echo',9,.8,life=23,staggerTicks=4),accent('folded_mirror','afterimage',3,1.8,delay=8),glints('mirror_shard','shatter',8,.4,delay=37)]),
 ('真假镜框交叉换位',[accent('folded_mirror','swap',3,2.5,life=48),accent('mind_knot','mirror_pair',2,.9,delay=15),hero('mirage_frame','center',3.0,delay=31)]),
 ('镜板双壁、逐片割裂',[accent('folded_mirror','walls',4,2.0,life=44),accent('thought_rift','curtain',5,1.1,delay=22),glints('mirror_shard','shatter',17,.48,delay=32)]),
 ('心结探距、三路反制',[hero('mind_knot','pulse',2.9,life=43),accent('thought_rift','fork',3,2.0,delay=13),accent('lens_crescent','converge',5,1.0,delay=23)]),
 ('念索双股、心结断点',[hero('mind_knot','pulse',2.2,life=58),accent('unweave_thread','tether',9,.8,life=48),accent('folded_mirror','reel',5,.7,delay=20)]),
 ('倒映半界交替实体化',[accent('mirage_frame','swap',2,4.3,life=60),accent('thought_rift','sectors',4,2.0,delay=9,staggerTicks=10),accent('memory_footprint','path_echo',7,.65,delay=19)]),
 ],
 'pengju':[
 ('双啄金喙、片状碎金',[accent('ingot_wing','lunge',2,2.7,life=16,staggerTicks=13),accent('armor_scale','shatter',9,.48,delay=16),hero('gold_stamp','stamp',1.6,delay=29)]),
 ('金甲冲线、钱纹拖迹',[hero('ingot_wing','lunge',3.5,life=29),accent('coin_charm','wake',14,.48,delay=5),accent('metal_sigil','afterimage',3,1.3,delay=8)]),
 ('铜钱开扇、金翅斜飞',[accent('coin_charm','fan',11,.72,life=32),accent('ingot_wing','fan',5,1.0,delay=10,angle=16),glints('sand_grain','ballistic',12,.22,delay=19)]),
 ('方印竖落、四角出锋',[hero('gold_stamp','stamp',4.2,life=40),accent('pierce_diamond','radial',4,.9,delay=18),glints('coin_charm','ground_wave',8,.4,delay=23)]),
 ('三批钱雨、飞翅余振',[accent('coin_charm','rain',21,.68,life=24,staggerTicks=2),accent('ingot_wing','rain',7,.95,delay=12,life=25),hero('gold_stamp','ground',3,delay=29)]),
 ('内外反转钱环',[accent('coin_charm','orbit',12,.65,life=56,speed=1),accent('ingot_wing','orbit',8,.8,life=56,speed=-1,spread=2.6),hero('metal_sigil','pulse',1.9,delay=16)]),
 ('金鳞合甲、反震破浪',[accent('armor_scale','shell',12,.9,life=46),hero('gold_stamp','center',2.5,delay=8),accent('ingot_wing','ground_wave',6,1.1,delay=28)]),
 ('左右钱索夹击、金钩牵引',[accent('greed_hook','walls',2,2.2,life=43),accent('coin_charm','tether',14,.5,delay=6),accent('gold_stamp','mirror_pair',2,1.8,delay=19)]),
 ('钱瀑坠殿、金印破碎',[accent('coin_charm','curtain',25,.72,life=38),hero('gold_stamp','stamp',4.4,delay=18),accent('ingot_wing','shatter',11,.85,delay=32),glints('armor_scale','ballistic',12,.45,delay=37)]),
 ],
 'pengzhi':[
 ('双触盘交替重拍',[accent('sucker_disc','stamp',2,3.5,life=24,staggerTicks=16),accent('gut_wave','ground_wave',3,2.2,delay=13),glints('wine_foam','ballistic',9,.5,delay=23)]),
 ('低位触盘链横扫',[accent('sucker_disc','sweep',7,1.0,life=37),hero('wine_stream','ribbon',3.8,delay=7),glints('acid_splash','ground',4,.9,delay=20)]),
 ('腹褶下压、泡沫炸浪',[hero('gut_wave','stamp',4.8,life=35),accent('wine_foam','eruption',14,.6,delay=18),hero('quake_wedge','ground_wave',4,delay=21)]),
 ('腐酒弯柱、黏液拖尾',[hero('wine_stream','sweep',4.4,life=48),accent('acid_teardrop','fan',12,.65,delay=8),accent('wine_foam','wake',11,.45,delay=16)]),
 ('腹口吸息后粗流喷出',[hero('gut_wave','pulse',3.8,life=55),accent('wine_stream','converge',6,1.3,life=28),accent('wine_foam','fan',18,.6,delay=30)]),
 ('吸盘长触伸出回摔',[accent('sucker_disc','tether',10,.75,life=45),hero('wine_stream','reel',4,delay=7),hero('gut_wave','stamp',3.0,delay=30)]),
 ('五股地面酒液回流',[accent('wine_stream','converge',5,2.0,life=52),accent('wine_foam','inward',17,.45,delay=8),hero('gut_wave','bloom',3.0,delay=33)]),
 ('三叠拍扫撞、收招滴酒',[hero('sucker_disc','stamp',3.7,life=21),hero('wine_stream','sweep',4.2,delay=19,life=25),hero('gut_wave','lunge',3.7,delay=39,life=25),glints('acid_teardrop','rain',8,.5,delay=52)]),
 ('内外腹浪反转、最后重吐',[accent('gut_wave','ground_wave',2,4.2,life=32,staggerTicks=24),accent('wine_foam','converge',16,.65,delay=20),hero('wine_stream','lunge',4.8,delay=47,life=27)]),
 ],
 'pengjiao':[
 ('五核合流后短距撞击',[accent('metal_sigil','converge',5,1.1,life=26,colorRole='elements'),hero('five_elements_seal','lunge',3.7,delay=16),glints('crystal_shard','shatter',12,.5,delay=28)]),
 ('金核聚锋、细长贯心光矛',[hero('metal_sigil','pulse',2.6,life=35),hero('spear_head','lunge',4.3,delay=12),accent('pierce_diamond','beam',9,.45,delay=18)]),
 ('木核记步、藤棘顺次出土',[accent('vine_thorn','eruption',9,1.4,life=34,staggerTicks=3),hero('wood_sigil','ground',3.3,life=52),glints('branch_bloom','grow',5,.6,delay=26)]),
 ('水核缺口、卷潮向内收束',[accent('tide_crest','inward',7,1.6,life=45,gapDegrees=60),hero('water_sigil','pulse',2.5,life=45),accent('water_droplet','reel',14,.4,delay=11)]),
 ('双赤轮沿弧线错行',[accent('fire_sigil','twin_arc',2,2.7,life=46),accent('fire_brush','wake',10,.8,delay=10),glints('ember_fragment','ballistic',13,.3,delay=20)]),
 ('土核膨胀、三条地裂放射',[hero('earth_sigil','stamp',3.8,life=36),accent('quake_wedge','radial',3,2.8,delay=16),accent('earth_shard','eruption',13,.7,delay=23)]),
 ('五核错峰穿行',[accent('metal_sigil','lunge',1,2.2,life=21,colorRole='metal'),accent('wood_sigil','lunge',1,2.2,delay=10,life=21,colorRole='wood',angle=72),accent('water_sigil','lunge',1,2.2,delay=20,life=21,colorRole='water',angle=144),accent('fire_sigil','lunge',1,2.2,delay=30,life=21,colorRole='fire',angle=216),accent('earth_sigil','lunge',1,2.2,delay=40,life=21,colorRole='earth',angle=288),glints('spark_needle','path_echo',10,.4,delay=18)]),
 ('活动核追猎、停核留印',[accent('wood_sigil','homing',2,1.8,life=46,colorRole='wood'),accent('water_sigil','mirror_pair',2,1.5,delay=12,colorRole='water'),accent('earth_sigil','path_echo',4,.8,delay=20,colorRole='earth')]),
 ('星形连线换宫、核纹穿插',[accent('forge_stitch','pentad',5,1.8,life=50),accent('fire_sigil','swap',2,1.4,delay=8,colorRole='fire'),accent('metal_sigil','swap',3,1.2,delay=16,colorRole='metal')]),
 ('五路归元、阵心沉落',[accent('metal_sigil','converge',3,.9,life=42,colorRole='metal'),accent('wood_sigil','converge',3,.9,delay=6,colorRole='wood'),accent('water_sigil','converge',3,.9,delay=12,colorRole='water'),accent('fire_sigil','converge',3,.9,delay=18,colorRole='fire'),accent('earth_sigil','converge',3,.9,delay=24,colorRole='earth'),hero('five_elements_seal','stamp',4.4,delay=41)]),
 ],
 'heart_demon':[
 ('左右残面斩、裂心直刺',[accent('torn_mask','sweep',2,2.6,life=20,staggerTicks=14),hero('heart_fissure','lunge',3.5,delay=31),glints('karma_petal','shatter',11,.5,delay=19)]),
 ('脚下断影、无相面突进',[accent('memory_footprint','path_echo',6,.8,life=24,staggerTicks=3),hero('torn_mask','lunge',3.4,delay=14),accent('unweave_thread','wake',9,.65,delay=19)]),
 ('裂心起伏、残瓣潮汐',[hero('heart_fissure','pulse',3.5,life=45),accent('karma_petal','ground_wave',13,.8,delay=8),accent('delusion_eye','inward',5,.8,delay=25)]),
 ('旧念步痕、碎面依次重演',[accent('memory_footprint','path_echo',8,.8,life=22,staggerTicks=5),accent('torn_mask','afterimage',4,1.5,delay=8),glints('unweave_thread','shatter',10,.5,delay=37)]),
 ('裂面退开、妄念竖瞳逼视',[accent('torn_mask','walls',2,3.0,life=58),hero('delusion_eye','pulse',3.8,delay=12,life=54),accent('heart_fissure','converge',5,.8,delay=24)]),
 ('倒刺妄链、裂心结点',[accent('chain_barb','tether',14,.6,life=56),hero('heart_fissure','pulse',2.0,life=56),accent('karma_petal','reel',8,.6,delay=17)]),
 ('四向镜花、心核可破',[accent('torn_mask','cage',4,1.8,life=52),accent('folded_mirror','fork',4,1.6,delay=12),hero('delusion_eye','center',2.3,delay=20),glints('mirror_shard','shatter',9,.4,delay=39)]),
 ('先收残瓣、再反照业火',[accent('karma_petal','converge',16,.9,life=32),hero('heart_fissure','pulse',2.8,delay=14),accent('bone_flare','ground_wave',9,1.2,delay=34)]),
 ('无相残面裂开、裂隙分叉',[hero('torn_mask','shatter',3.8,life=24),accent('thought_rift','fork',3,3,delay=10),accent('chain_barb','fan',7,.7,delay=24)]),
 ('万念环绕被吸尽、灰烬最后下落',[accent('delusion_eye','sectors',6,1.8,life=26,staggerTicks=6),accent('karma_petal','converge',22,.7,delay=22,life=38),hero('heart_fissure','collapse',4.3,delay=40),glints('talisman_ash','petal_fall',20,.3,delay=55,life=45)]),
 ],
}

DIVINE_RECIPES={
 'fa_tian_xiang_di':('双肩法轮、法相自下擎起',[hero('giant_halo','grow',5,life=70),accent('mountain_ridge','eruption',3,2.4,delay=14),accent('armor_scale','shell',12,.8,delay=23)]),
 'ta_gang_bu_dou':('七星逐点引亮、星络步进',[hero('dipper_thread','constellation',4.8,life=72),accent('star_dipper','path_echo',2,1.8,delay=12),glints('spark_star','constellation',7,.5,delay=18,staggerTicks=6)]),
 'yuan_shen_chu_qiao':('灵体轮廓上浮、躯壳脉络留驻',[hero('astral_body','rise',3.6,life=70),hero('meridian_knot','ground',2.7,life=60),accent('unweave_thread','helix',10,.7,delay=14)]),
 'yi_hun_ji_po':('双魂牵连、心结在索间移动',[accent('astral_body','mirror_pair',2,2.5,life=62),accent('forge_stitch','tether',10,.7,delay=8),hero('mind_knot','homing',1.6,delay=19)]),
 'qi_shi_er_bian':('覆羽折面旋转合拢',[accent('folded_mirror','shell',8,1.1,life=48),hero('astral_body','collapse',3.0,delay=12),accent('phoenix_plume','bloom',7,1.0,delay=28)]),
 'jin_dou_yun':('三叠如意云、长尾气流',[accent('ruyi_cloud','wake',3,2.8,life=64),accent('feather_lift','ribbon',14,.7,delay=6),accent('wind_curl','twin_arc',2,1.6,delay=21)]),
 'ri_yue_ting_lun':('阴阳时轮开合、余光骤停',[hero('yin_yang_clock','pulse',4.7,life=86),accent('lens_crescent','freeze',7,.8,delay=10,life=70),glints('coin_charm','suspend',12,.24,delay=26,life=60)]),
}
FIRE_RECIPES={
 'red_flow':('赤炎如笔扫流',[hero('fire_brush','ribbon',3.0,life=55),accent('ember_fragment','fan',13,.35),glints('heat_wisp','wake',5,.9)]),
 'molten_gold':('熔金滴落、凝成金珠',[accent('molten_drip','rain',9,1.1,life=50,staggerTicks=2),accent('coin_charm','ballistic',8,.45,delay=18),hero('acid_splash','ground',2.4,delay=24)]),
 'cold_ash':('骨状寒火逆升、霜蕨碎灰',[accent('bone_flare','helix',5,1.6,life=62),accent('frost_fern','suspend',6,.6,delay=12),glints('talisman_ash','petal_fall',17,.27,delay=20)]),
 'azure_wood':('火芽抽枝、灵种入焰',[hero('budding_flame','grow',3.6,life=65),accent('branch_bloom','helix',6,.9,delay=12),accent('seed_pod','inward',11,.4,delay=20)]),
 'cobalt_sea':('海焰内卷、水冠外翻',[hero('sea_flame','pulse',3.6,life=56),accent('tide_crest','orbit',5,1.05,delay=8),glints('water_droplet','ballistic',16,.27,delay=18)]),
 'violet_thunder':('电焰跳跃、枝雷分叉',[hero('plasma_flame','stutter',3.6,life=52),accent('electric_arc','fork',7,.9,delay=8),glints('lightning_branch','eruption',4,.8,delay=23)]),
 'sun_saint':('日珥拱起、短促放射',[hero('solar_prominence','bloom',4.3,life=65),accent('giant_halo','center',1,2.7,delay=13),glints('prism_glint','radial',13,.4,delay=23)]),
 'nether_void':('暗焰垂帷、细缝内吞',[hero('nether_veil','curtain',4.4,life=65,colorRole='glow'),accent('thought_rift','converge',5,1.2,delay=12),glints('soul_wisp','inward',12,.45,delay=17)]),
 'nirvana':('凤翎火羽、环抱后向上绽放',[accent('phoenix_plume','bloom',7,1.7,life=63),hero('budding_flame','rise',2.9,delay=12),glints('karma_petal','helix',14,.5,delay=23)]),
}

METHOD_RECIPES={
 'yuan_hun':('混元环络缓慢呼吸',[hero('yin_yang_clock','ground',3,life=72),accent('meridian_knot','orbit',3,.9,life=72)]),
 'gathering':('聚灵种荚分流汇入',[accent('seed_pod','converge',14,.45,life=62),hero('root_lattice','ground',2.9,life=70)]),
 'tiangang':('罡气金锋定点守护',[accent('metal_sigil','hex_guard',6,.8,life=66),hero('bell_shell','pulse',2.3,life=70)]),
 'xuanshui':('玄水潮头沿脚边回绕',[accent('tide_crest','orbit',4,1.1,life=68),hero('water_sigil','ground',2.8,life=72)]),
 'nine_turns':('九转丹纹逐圈凝炼',[accent('pill_orbit','helix',9,.62,life=72),hero('dipper_thread','center',2.6,life=74)]),
 'burning_heaven':('焚天日珥与上升灼羽',[hero('solar_prominence','rise',2.7,life=64),accent('fire_brush','helix',5,.9,life=67)]),
 'thick_earth':('厚土山影低伏、砂砾稳旋',[hero('mountain_ridge','ground',3.4,life=75),accent('sand_grain','orbit',14,.28,life=70)]),
 'taixu':('太虚魂轮若隐若现',[hero('astral_body','suspend',2.3,life=72),accent('thought_rift','orbit',3,1.0,life=65)]),
 'wanling':('万灵芽叶交替抽生',[accent('branch_bloom','grow',4,1.3,life=65),accent('petal','helix',12,.48,life=70)]),
 'beast_taming':('御兽缚根与契纹相扣',[hero('root_lattice','shell',2.7,life=70),accent('nerve_tendril','tether',6,.7,life=65)]),
}
OTHER_RECIPES={
 'heart_sword_summon':('散丝编心、心剑由虚凝实',[accent('forge_stitch','converge',16,.75,life=40),hero('sword_ghost','grow',2.8,delay=16,life=45),glints('meridian_knot','pulse',3,.6,delay=32)]),
 'heart_sword_disperse':('剑形解体、心丝回散',[hero('sword_ghost','collapse',2.8,life=23),accent('unweave_thread','shatter',18,.75,delay=8),glints('pill_orbit','rise',7,.3,delay=18)]),
 'heart_sword_forge':('双侧缝光、甲纹覆剑',[hero('sword_ghost','center',2.6,life=54),accent('forge_stitch','walls',8,.95,delay=7),accent('armor_scale','shell',9,.45,delay=22)]),
 'heart_sword_unforge':('甲纹离剑、缝线松脱',[accent('armor_scale','shatter',9,.6,life=38),accent('unweave_thread','reel',12,.8,delay=9),hero('heart_fissure','collapse',2.4,delay=15)]),
 'tribulation':('云中主雷、地面崩裂余震',[hero('lightning_branch','column',5.9,life=14),accent('plasma_flame','fork',5,1.4,delay=4),hero('quake_wedge','ground_wave',4.6,delay=10),glints('sand_grain','ballistic',20,.3,delay=15)]),
 'alchemy':('炉息双旋、成丹浮纹',[accent('furnace_breath','helix',4,1.7,life=50),hero('pill_orbit','rise',2.6,delay=20,life=45),glints('seed_pod','orbit',9,.35,delay=26)]),
 'offering':('贡物细光向心编织',[accent('forge_stitch','converge',13,.7,life=52),hero('dipper_thread','ground',3.6,life=52),accent('talisman_ash','rise',12,.3,delay=25)]),
}

def individual_recipe(entry):
    import copy
    id=entry['id'];cat=entry['category'];_,palette=assign(entry)
    if cat in ('功法','御剑剑技'): note,layers=ART_RECIPES[id.removeprefix('art_')]
    elif cat=='Boss':note,layers=BOSS_RECIPES[entry['facts']['boss']][int(id.rsplit('_',1)[1])-1]
    elif cat=='神通':note,layers=DIVINE_RECIPES[id]
    elif cat=='异火素材':note,layers=FIRE_RECIPES[id.removeprefix('fire_')]
    elif cat=='心法·被动':note,layers=METHOD_RECIPES[id.removeprefix('heart_method_')]
    elif cat=='符箓':
        kind=id.removeprefix('talisman_');mat,motion={'fire':('fire_brush','fan'),'shield':('armor_scale','shell'),'heal':('branch_bloom','grow'),'speed':('feather_lift','ribbon'),'gather':('seed_pod','converge'),'purge':('karma_petal','shatter')}[kind]
        note=entry['name']+'：源码符纹为主，按符效分化次形与消散轨迹'
        layers=[hero('glyph_'+kind,'stamp',2.2,life=34),accent(mat,motion,8,.8,delay=10),glints('talisman_ash','petal_fall',7,.25,delay=25)]
    else:note,layers=OTHER_RECIPES[id]
    layers=copy.deepcopy(layers)
    layers[0]['role']='主形'
    for layer in layers:
        layer.setdefault('role','主形');layer.setdefault('colorRole','body')
    return dict(id=id,name=entry['name'],artDirection=note,layers=layers,defaultPalette=palette,
        durationTicks=max(l['delayTicks']+l['lifetimeTicks']+l.get('staggerTicks',0)*(l['count']-1) for l in layers),
        quality={'low':.35,'medium':.65,'high':1.0},recommendedMaxParticles=128,
        sourceSkill=id,geometryNote='二维选材与动作设计；不替代服务器判定或三维场景。',
        stages=['起势','主形展开','次形响应','余韵收束'])

SUPPORTED_MOTIONS=set('center ground pulse grow bloom collapse fan sweep helix converge inwards inward orbit burst rise rain beam lunge slash tangent petal_fall shell cage stamp shatter ballistic ground_wave fork afterimage curtain radial homing mirror_pair reel sectors rolling swap path_echo pentad twin_arc tether eruption wake hex_guard ribbon constellation freeze suspend stutter column ring scatter'.split())
