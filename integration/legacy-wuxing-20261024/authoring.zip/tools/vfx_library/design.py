"""Authored palette, reusable material modules and explicit per-skill assignments."""
PALETTES = {
    'spirit': ['灵力白青','#A7F0FF','#EFFFFF','#377DC8'],
    'metal': ['金','#FFD167','#FFF3BD','#AA702D'],
    'wood': ['木','#79DFA0','#E2FFD5','#2A886F'],
    'water': ['水','#64CFEF','#DEF8FF','#356EC5'],
    'fire': ['火','#FF793D','#FFF0AA','#BA293B'],
    'earth': ['土','#D1AC70','#FFF0C3','#775843'],
    'thunder': ['雷','#A88DFF','#F0EEFF','#5B65D5'],
    'wind': ['风','#B6E4D9','#F0FFFF','#4C9EAF'],
    'blood': ['气血','#EE5870','#FFD5AF','#882D50'],
    'muyan': ['目魇·幻虹','#DA78FF','#D5FDFF','#7545C3'],
    'ermei': ['耳魅·声纹','#76DAE8','#E8FFFF','#4276B8'],
    'bichen': ['鼻嗔·毒瘴','#8FC657','#E8EAB6','#5C7140'],
    'shetao': ['舌饕·五味','#F18A86','#FFDA9D','#AA475D'],
    'shenyin': ['身淫·晶莲','#EE9DDF','#F5EDFF','#AA64BC'],
    'yihuo': ['意惑·镜念','#AB83E8','#E9E6FF','#614986'],
    'pengju': ['彭倨·金颅','#FFD167','#FFF1AC','#AE7B36'],
    'pengzhi': ['彭质·腐酿','#CC786A','#F3C193','#75444D'],
    'pengjiao': ['彭矫·五气','#97DCF2','#E6FFFF','#5689AD'],
    'heart_demon': ['心魔·无相','#C786ED','#FFD9EF','#69386D'],
}

# id, Chinese label, family, animation mode (none/loop/once), blending
MATERIALS = [
 ('spark_soft','柔光灵点','通用','none','add'),('spark_star','四芒星','通用','none','add'),
 ('spark_needle','针状火花','通用','none','add'),('flash_radial','放射闪光','通用','once','add'),
 ('impact_burst','命中炸纹','通用','once','add'),('ring_soft','柔边环','预警与法阵','none','add'),
 ('ring_double','双层符环','预警与法阵','none','add'),('ring_broken','缺口环','预警与法阵','none','add'),
 ('rune_circle','刻度法阵','预警与法阵','loop','add'),('seal_glyph','镇印符心','预警与法阵','none','add'),
 ('sword_slash','单弧剑气','剑与风','once','add'),('sword_cross','交叉剑痕','剑与风','once','add'),
 ('sword_ghost','灵剑剪影','剑与风','none','add'),('trail_ribbon','流线拖带','剑与风','loop','add'),
 ('wind_curl','风卷','剑与风','loop','add'),('wind_streak','风线','剑与风','none','add'),
 ('flame_tongue','焰舌','火','loop','add'),('ember_fragment','碎焰','火','none','add'),
 ('smoke_puff','翻滚烟团','火','once','alpha'),('heat_wisp','热流细丝','火','loop','add'),
 ('water_droplet','水滴','水与冰','none','alpha'),('water_splash','水花冠','水与冰','once','add'),
 ('ripple','水波纹','水与冰','once','add'),('ice_shard','冰刺','水与冰','none','alpha'),
 ('snow_crystal','六角霜晶','水与冰','none','add'),('leaf','灵叶','木','none','alpha'),
 ('petal','花瓣','木','none','alpha'),('vine_thorn','藤棘','木','none','alpha'),
 ('poison_cloud','毒瘴雾团','毒与腐酿','loop','alpha'),('poison_bubble','毒液泡','毒与腐酿','none','alpha'),
 ('acid_splash','腐液溅斑','毒与腐酿','once','alpha'),('earth_shard','岩片','土','none','alpha'),
 ('ground_crack','地裂纹','土','none','add'),('dust_plume','尘柱','土','once','alpha'),
 ('lightning_branch','分叉劫雷','雷','loop','add'),('electric_arc','电弧','雷','loop','add'),
 ('thunder_core','雷击核心','雷','once','add'),('crystal_shard','棱晶','晶体与幻镜','none','alpha'),
 ('prism_glint','棱镜星光','晶体与幻镜','none','add'),('mirror_shard','镜片','晶体与幻镜','none','alpha'),
 ('mirror_crack','镜裂','晶体与幻镜','once','add'),('soul_wisp','魂丝','魂与心魔','loop','add'),
 ('eye_sigil','凝视眼纹','魂与心魔','none','add'),('chain_link','锁链环节','魂与心魔','none','add'),
 ('sound_wave','声波重环','声波','once','add'),('sound_blade','音刃','声波','none','add'),
 ('star_dipper','北斗七星','神通','none','add'),('lotus','五瓣莲纹','神通','none','add'),
 ('eclipse_ring','日月停轮','神通','loop','add'),('talisman_ash','符灰','符箓','none','alpha'),
 ('cloud_scroll','祥云','神通','loop','alpha'),('shield_hex','六角护片','护体','none','add'),
 ('five_elements_seal','五行阵心','预警与法阵','none','add'),('mist_spiral','引力旋涡','魂与心魔','loop','add'),
] + [('glyph_'+k,n+'符纹','符箓','none','add') for k,n in [('fire','火'),('shield','护体'),('heal','疗伤'),('speed','神行'),('gather','聚灵'),('purge','净邪')]]

# Shared stage curves use normalized particle age. Durations are authoring suggestions.
CURVES = {'alpha': [[0,0],[.08,1],[.68,.8],[1,0]],
          'size': [[0,.35],[.18,1],[.8,1.15],[1,.7]]}


def layer(material, motion='burst', count=12, size=.5, delay=0, lifetime=22, **kw):
    return dict(material=material,motion=motion,count=count,sizeBlocks=size,delayTicks=delay,lifetimeTicks=lifetime,**kw)


RECIPES = {
 'sword_cut': ('剑气斩 / 破甲', [layer('sword_slash','slash',2,3),layer('spark_needle',count=20,size=.22),layer('impact_burst',count=1,size=1.6)]),
 'sword_pierce': ('飞星贯日', [layer('sword_ghost','beam',1,2.4),layer('trail_ribbon','beam',2,3),layer('spark_needle',count=16,size=.18)]),
 'sword_orbit': ('环剑 / 环斩', [layer('sword_ghost','orbit',6,1.1,lifetime=40),layer('ring_double','ring',1,3),layer('wind_streak','orbit',12,.6)]),
 'sword_rain': ('落剑 / 万剑', [layer('rune_circle','ground',1,4,lifetime=40),layer('sword_ghost','rain',12,1.6,delay=8,lifetime=24),layer('impact_burst','scatter',8,.8,delay=18)]),
 'heal': ('回春 / 净化', [layer('lotus','ground',1,2.3,lifetime=40),layer('leaf','rise',16,.32,lifetime=35),layer('spark_soft','rise',18,.24,lifetime=32)]),
 'shield': ('护盾 / 金钟', [layer('shield_hex','orbit',10,.65,lifetime=50),layer('ring_double','ground',1,2.5,lifetime=50),layer('spark_star','rise',10,.24,lifetime=30)]),
 'bind': ('定身 / 符锁', [layer('chain_link','orbit',12,.42,lifetime=40),layer('seal_glyph','ground',1,2.3,lifetime=40),layer('electric_arc',count=3,size=1.2)]),
 'wind': ('轻身 / 御剑', [layer('wind_curl','orbit',3,1.4,lifetime=35),layer('wind_streak','beam',12,.65),layer('cloud_scroll','ground',2,1.8,lifetime=35)]),
 'gather': ('聚灵 / 归元', [layer('rune_circle','ground',1,3,lifetime=50),layer('soul_wisp','inward',24,.38,lifetime=40),layer('spark_star','inward',12,.2,lifetime=40)]),
 'ice': ('冰刺 / 霜爆', [layer('ice_shard','rise',10,1.25),layer('snow_crystal',count=16,size=.3),layer('ripple','ground',1,3)]),
 'flame': ('焰浪 / 异火', [layer('flame_tongue','rise',16,1.05,lifetime=32),layer('ember_fragment','rise',20,.24,lifetime=40),layer('smoke_puff','rise',5,1.5,delay=8,lifetime=38)]),
 'blink': ('闪现 / 镜步', [layer('mirror_crack',count=1,size=2.8),layer('mirror_shard',count=16,size=.45),layer('soul_wisp','beam',16,.6)]),
 'blood': ('气血激发', [layer('heat_wisp','rise',12,.7,lifetime=35),layer('ring_soft','ground',1,2.4),layer('spark_needle','rise',16,.28)]),
 'thunder': ('落雷 / 渡劫', [layer('lightning_branch','column',2,4,lifetime=10),layer('thunder_core',count=1,size=2.2,lifetime=12),layer('electric_arc',count=10,size=.7,lifetime=16),layer('ground_crack','ground',1,3,lifetime=28)]),
 'earth': ('坠岳 / 震地', [layer('ground_crack','ground',1,4,lifetime=40),layer('earth_shard',count=18,size=.5,lifetime=30),layer('dust_plume','rise',6,1.4,lifetime=40),layer('ring_soft','ring',1,4)]),
 'five_elements': ('五行合击', [layer('five_elements_seal','ground',1,4,lifetime=50),layer('flame_tongue','orbit',5,.7,colorRole='elements'),layer('leaf','orbit',5,.5,colorRole='elements'),layer('water_droplet','orbit',5,.5,colorRole='elements'),layer('spark_star','inward',20,.4,colorRole='elements'),layer('flash_radial',count=1,size=3,delay=20)]),
 'beam': ('光矛 / 扫射', [layer('trail_ribbon','beam',2,5,lifetime=24),layer('prism_glint','beam',6,.4),layer('spark_needle','beam',16,.3)]),
 'ring': ('震荡 / 缺口环', [layer('ring_broken','ring',2,4,lifetime=35),layer('spark_soft','orbit',20,.18,lifetime=32)]),
 'sound': ('音刃 / 声墙', [layer('sound_wave','ring',2,4,lifetime=36),layer('sound_blade','slash',3,2.3),layer('spark_soft','orbit',12,.2)]),
 'poison': ('瘴息 / 腐液', [layer('poison_cloud','ground',5,2,lifetime=50),layer('poison_bubble','rise',16,.38,lifetime=40),layer('acid_splash','ground',3,1.4,lifetime=35)]),
 'crystal': ('晶刺 / 晶牢', [layer('crystal_shard','rise',12,1.4,lifetime=35),layer('prism_glint',count=12,size=.45),layer('lotus','ground',1,3,lifetime=35)]),
 'mirror': ('分身 / 镜墙', [layer('mirror_shard','orbit',12,.8,lifetime=40),layer('mirror_crack',count=1,size=3),layer('soul_wisp','rise',12,.65)]),
 'gaze': ('凝视 / 聚瞳', [layer('eye_sigil','center',1,3,lifetime=55),layer('rune_circle','center',1,3.5,lifetime=55),layer('soul_wisp','inward',20,.3,lifetime=40)]),
 'tether': ('锁链 / 心结', [layer('chain_link','beam',16,.35,lifetime=50),layer('seal_glyph','center',1,1.2,lifetime=50),layer('soul_wisp','inward',12,.4,lifetime=40)]),
 'vortex': ('牵引 / 回流', [layer('mist_spiral','ground',1,4,lifetime=50),layer('soul_wisp','inward',28,.5,lifetime=42),layer('ring_double','ring',1,3)]),
 'gold_seal': ('金印 / 飞刃', [layer('seal_glyph','column',1,3,lifetime=35),layer('spark_needle','rain',20,.5),layer('flash_radial',count=1,size=2.5,delay=16)]),
 'dipper': ('踏罡 / 七星', [layer('star_dipper','ground',1,4,lifetime=60),layer('spark_star','rise',7,.45,lifetime=50),layer('rune_circle','ground',1,4.5,lifetime=60)]),
 'soul': ('元神 / 寄魄', [layer('soul_wisp','rise',20,.65,lifetime=50),layer('mist_spiral','ground',1,2.5,lifetime=45),layer('spark_soft','rise',14,.25)]),
 'eclipse': ('日月停轮', [layer('eclipse_ring','center',1,4,lifetime=80),layer('star_dipper','orbit',2,1,lifetime=70),layer('spark_star','suspend',24,.22,lifetime=80)]),
 'cloud': ('筋斗 / 祥云', [layer('cloud_scroll','ground',5,1.7,lifetime=50),layer('wind_streak','beam',14,.65,lifetime=30),layer('spark_soft','rise',10,.2)]),
 'talisman': ('符箓激活', [layer('glyph_fire','center',1,1.5,lifetime=30),layer('talisman_ash','rise',16,.3,delay=16),layer('rune_circle','ground',1,2.5)]),
 'summon': ('心剑 / 心铸', [layer('soul_wisp','inward',24,.35,lifetime=35),layer('sword_ghost','center',1,2,delay=14,lifetime=35),layer('spark_star',count=12,size=.3,delay=25)]),
}

ARTS = {
 'sword_aura':('sword_cut','spirit'), 'renewal':('heal','wood'), 'spirit_shield':('shield','spirit'),
 'immobilize':('bind','metal'), 'light_body':('wind','wind'), 'golden_bell':('shield','metal'),
 'ice_spike':('ice','water'), 'spirit_gathering':('gather','wood'), 'armor_break':('sword_cut','metal'),
 'flame_wave':('flame','fire'), 'flash_step':('blink','thunder'), 'purification':('heal','spirit'),
 'bloodlust':('blood','blood'), 'thunder':('thunder','thunder'), 'myriad_swords':('sword_rain','metal'),
 'immovable_mountain':('earth','earth'), 'human_harmony':('gather','wood'), 'five_elements':('five_elements','pengjiao'),
 'sword_pierce':('sword_pierce','spirit'), 'sword_sweep':('sword_orbit','wind'),
 'sword_guard':('sword_orbit','metal'), 'sword_array':('sword_rain','thunder'), 'sword_flight':('wind','spirit'),
}
DIVINE = {'fa_tian_xiang_di':('earth','metal'),'ta_gang_bu_dou':('dipper','thunder'),'yuan_shen_chu_qiao':('soul','spirit'),'yi_hun_ji_po':('tether','thunder'),'qi_shi_er_bian':('mirror','wood'),'jin_dou_yun':('cloud','wind'),'ri_yue_ting_lun':('eclipse','metal')}
METHODS = {'yuan_hun':('gather','spirit'),'gathering':('gather','wood'),'tiangang':('shield','metal'),'xuanshui':('ring','water'),'nine_turns':('gather','metal'),'burning_heaven':('flame','fire'),'thick_earth':('shield','earth'),'taixu':('soul','thunder'),'wanling':('heal','wood'),'beast_taming':('bind','wood')}
BOSS_RECIPES = {
 'muyan':['beam','beam','ring','mirror','gaze'],
 'ermei':['sound','sound','sound','earth','sound','sound'],
 'bichen':['poison','poison','poison','earth','vortex','poison'],
 'shetao':['sword_cut','tether','poison','flame','gather','earth','five_elements'],
 'shenyin':['crystal','ring','vortex','crystal','crystal','tether','crystal'],
 'yihuo':['sword_cut','blink','mirror','mirror','mirror','ring','tether','mirror'],
 'pengju':['sword_cut','beam','sword_cut','gold_seal','gold_seal','ring','shield','tether','gold_seal'],
 'pengzhi':['earth','ring','earth','poison','vortex','tether','vortex','earth','poison'],
 'pengjiao':['earth','beam','crystal','ring','flame','earth','five_elements','five_elements','tether','five_elements'],
 'heart_demon':['sword_cut','blink','ring','mirror','gaze','tether','mirror','flame','sword_cut','vortex'],
}


def assign(entry):
    id, cat = entry['id'], entry['category']
    if cat in ('功法','御剑剑技'): return ARTS[id.removeprefix('art_')]
    if cat=='神通': return DIVINE[id]
    if cat=='心法·被动': return METHODS[id.removeprefix('heart_method_')]
    if cat=='Boss':
        boss=entry['facts']['boss']; no=int(id.rsplit('_',1)[1]); palette=boss
        if boss=='pengjiao' and 2<=no<=6: palette=['metal','wood','water','fire','earth'][no-2]
        return BOSS_RECIPES[boss][no-1],palette
    if cat=='异火素材': return 'flame',id
    if cat=='符箓': return 'talisman',{'fire':'fire','shield':'metal','heal':'wood','speed':'wind','gather':'water','purge':'spirit'}[id.removeprefix('talisman_')]
    if cat=='心剑仪式': return 'summon','spirit'
    return {'tribulation':('thunder','thunder'),'alchemy':('gather','metal'),'offering':('gather','spirit')}[id]
