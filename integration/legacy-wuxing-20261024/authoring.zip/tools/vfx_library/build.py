"""Build standalone authoring assets; deliberately does not alter the production mod."""
from __future__ import annotations
import argparse
from collections import Counter
import copy
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

from catalog import ROOT,extract
from design import MATERIALS,PALETTES,RECIPES,CURVES,assign
from textures import build_textures


def write_json(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def build(output):
    output.mkdir(parents=True,exist_ok=True)
    data=extract();palettes=copy.deepcopy(PALETTES)
    for entry in data['entries']:
        if entry['category']=='异火素材':
            col=entry['facts']['colors'];palettes[entry['id']]=[entry['name'],col['bodyColor'],col['coreColor'],col['edgeColor']]
    recipes=[]
    defaults={'heal':'wood','flame':'fire','poison':'bichen','earth':'earth','thunder':'thunder','gold_seal':'metal','ice':'water','crystal':'shenyin','mirror':'yihuo','gaze':'muyan','sound':'ermei','blood':'blood','five_elements':'pengjiao','eclipse':'metal','tether':'heart_demon','vortex':'heart_demon'}
    for id,(name,layers) in RECIPES.items():
        recipes.append(dict(id=id,name=name,layers=copy.deepcopy(layers),defaultPalette=defaults.get(id,'spirit'),curves=CURVES,
            durationTicks=max(ly['delayTicks']+ly['lifetimeTicks'] for ly in layers),
            geometryNote='浏览器为二维构图预览；Photon 样片为 Billboard 材质组合。地面法阵、真实射线和曲线拖尾需由游戏几何/发射器承载。',
            quality=dict(low=.35,medium=.65,high=1.0),recommendedMaxParticles=128))
    for entry in data['entries']:
        recipe,palette=assign(entry)
        overrides={}
        if entry['category']=='符箓': overrides['glyph_fire']=entry['facts']['glyphAsset']
        if entry['id']=='pengjiao_03': overrides['crystal_shard']='vine_thorn';overrides['prism_glint']='leaf'
        if entry['id']=='pengjiao_04': overrides['ring_broken']='ripple'
        entry['design']=dict(recipe=recipe,palette=palette,materialOverrides=overrides,
            basis='定制美术建议，不修改玩法；组合配方中的数量、尺寸和寿命均为建议值。',
            binding='每次实际子攻击/落点触发配方；禁止用一个总前摇代替 Boss 多段程序。' if entry['category']=='Boss' else '绑定对应释放/生效/取消事件。')
    counts=dict(Counter(e['category'] for e in data['entries']))
    data['counts']=counts
    write_json(output/'catalog/skills.json',data)
    write_json(output/'catalog/palettes.json',palettes)
    write_json(output/'catalog/recipes.json',recipes)
    materials=build_textures(output,MATERIALS,data['glyphs'])
    write_json(output/'catalog/materials.json',materials)
    for recipe in recipes: write_json(output/'recipes'/(recipe['id']+'.json'),recipe)
    write_json(output/'resourcepack/pack.mcmeta',{'pack':{'pack_format':15,'description':'五行仙途 · 技能粒子素材库 v1 / Photon 1.1.17 authoring samples'}})
    from photon import export
    exports=export(output,materials,recipes,palettes)
    with (output/'catalog/skills.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['ID','名称','分类','Boss','阶段','前摇tick','恢复tick','冷却tick','配方','配色','源码','行','实装程序','提示'])
        for e in data['entries']:
            v=e['facts'];writer.writerow([e['id'],e['name'],e['category'],v.get('bossName',''),v.get('phase',''),v.get('windupTicks',''),v.get('recoveryTicks',''),v.get('cooldownTicks',''),e['design']['recipe'],e['design']['palette'],e['source']['path'],e['source']['line'],v.get('program',''),v.get('hint',v.get('description',''))])
    model=dict(entries=data['entries'],counts=counts,materials=materials,recipes=recipes,palettes=palettes)
    (output/'preview/library-data.js').write_text('window.VFX_LIBRARY='+json.dumps(model,ensure_ascii=False).replace('</','<\\/')+';\n',encoding='utf-8')
    shutil.copyfile(Path(__file__).parent/'preview.html',output/'preview/index.html')
    make_docs(output,data,materials,recipes,exports)
    files={p.relative_to(output).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(output.rglob('*')) if p.is_file() and p.name not in ('manifest.json','validation.json')}
    manifest=dict(schemaVersion=1,name='五行仙途技能粒子库',version='1.0.0',sourceDate='2026-09-29',
        counts=dict(entries=len(data['entries']),categories=counts,materials=len(materials),animated=sum(m['frames']>1 for m in materials),recipes=len(recipes),photonSamples=len(exports)),
        verification=dict(sourceExtracted=True,nativeNbtRoundtrip=True,minecraftRendered=False,productionIntegrated=False),files=files)
    write_json(output/'manifest.json',manifest)
    return manifest


def make_docs(output,data,materials,recipes,exports):
    (output/'README.md').write_text('''# 五行仙途 · 技能粒子库 v1

从当前源码提取目录，供制作功法、Boss、神通、符箓及系统特效使用。

## 直接使用

1. 打开 `preview/index.html`，可搜索中文名称/ID/源码程序，切换材质与配方，换色、暂停、拖动时间、调整数量和大小；直接双击可用，无 CDN、无服务器要求。
2. `resourcepack/assets/wuxingxiantu_vfx/textures/library/`：256×256 白色 RGBA 基础材质；动画为 512×512、4×4、每格128×128的16帧图集。透明边缘，按行从左到右再从上到下读取。
3. `catalog/skills.csv` / `catalog/skills.json`：逐技能源码、行号、描述、Boss 时序和程序片段；`recipes/`：32套建议配方。
4. Photon 1.1.17 / LDLib 1.0.42：把单独的资源包 ZIP 放入目标实例 resourcepacks 并启用；从 `photon/projects/` 选 `.fxproj` 在 Photon 编辑器打开。每个项目的材质库均包含全部60种材质。
5. `.fx` 位于资源包 `assets/wuxingxiantu_vfx/fx/`，包含60个循环单材质样片和32个有限组合样片。循环样片测试完需停止。

资源 ID 示例：`wuxingxiantu_vfx:materials/flame_tongue`、`wuxingxiantu_vfx:recipes/thunder`。在支持原生 Photon 命令的隔离测试场景中，可用 `/photon fx wuxingxiantu_vfx:recipes/thunder block X Y Z`，其中 X Y Z 应替换为真实坐标。停止同一位置的该效果：`/photon fx remove block X Y Z true wuxingxiantu_vfx:recipes/thunder`。命令格式依本地既有 Photon 接口记录；本次未进入游戏执行。

## 覆盖范围和状态

139项：18个普通功法、5个御剑剑技、7个神通、10个被动心法、77个Boss招式、6种符箓、9种异火、4个心剑仪式、3个系统特效。御剑5招已经包含在ArtCatalog的23项中，不重复计数。Boss为九位常规Boss加心魔共十位。

60种独立基础材质、32套组合配方；具体动画数量见 manifest.json。心法只提供被动/修炼外观设计；异火只提供新素材与源码配色。源码描述和新美术建议分字段保存；普通功法有些实际上按玩家周围AABB结算，不能根据描述文字臆造新的命中弹道。

**这是制作素材库，未接入当前模组技能。** 模组当前没有 Photon 依赖；资源包也不会凭空注册新的 Forge 粒子类型。Photon 示例由已有原生导出格式生成，完成离线 NBT 读写和引用检查；未做本轮 Minecraft 加载、可见播放、联机或性能实测。浏览器画面是材质构图预览，不是游戏录像。

Photon 组合样片使用 Billboard 粒子，用于选材、染色、发射和淡出调参；浏览器中的环绕、内吸、射线、落剑等是配方意图，尚未一比一转为游戏空间轨迹。真实地面法阵、光束、拖尾和晶柱应使用平面/几何/Beam/Trail或实体模型承载，不应靠一个贴图冒充完整三维技能。

范围不含全部生物AI普通攻击、七十二变逐实体动作。晶体素材是二维晶片，不是屏幕折射；镜片不是实时镜面。

## 制作约定

- 时间单位为tick；游戏常规20tick/s。Boss前摇、恢复和冷却是源码提取值；配方粒子寿命、数量、尺寸为美术建议。
- 每次真实子攻击调用一次配方；多段落点继续由BossSkillPrograms/HeartDemonSkillPrograms决定。现有BossCombatFx地面预警及安全缺口保持服务端几何一致。
- 金/木/水/火/土与10位Boss有独立色板；九种异火采用当前JSON的body/core/edge，不恢复旧退役外观。符箓六张符纹由源码16×32图样生成。
- 发光用SRC_ALPHA/ONE；烟、毒雾、叶、石片等用SRC_ALPHA/ONE_MINUS_SRC_ALPHA。保持深度测试，半透明层关闭深度写入；全亮并不意味着自动bloom。
- 白色RGB+straight alpha；不要再预乘一次。图集帧格有透明边距；禁止跨帧生成mipmap。多个发射器共享图集和材质。
- 建议低/中/高档数量35%/65%/100%，单个完整配方同时在场粒子上限128；48格后降档、96格后停发装饰。以上是设计预算，非测得性能结果。现有BossCombatFx的32粒子/tick预算需在实际接入时统一分配。
- 目标实体卸载、维度切换、施法取消、死亡时停止持续发射并清理句柄；伤害、击退、定身不由视觉层决定。

## 重建

项目中脚本：`tools/vfx_library/build.py`，依赖Python3、Pillow、NumPy、nbtlib==2.0.4。运行 `python tools/vfx_library/build.py`，再运行 `python tools/vfx_library/validate.py`。默认产物位于 `source-assets/skill-particle-library-v1/`。运行 `python tools/vfx_library/build.py --package` 可打包完整制作库和独立资源包。无Gradle步骤，不改动生产Java/资源。

程序化绘制的全部60种材质来自本轮确定性生成器，无AI图像生成调用，也未复用已退役火焰图片。Photon结构模板来自项目内既有原生导出，仅保留序列化结构。所有本轮新生成素材可随本项目编辑、打包和分发；不改变项目、Photon或LDLib本身的许可证。
''',encoding='utf-8')
    lines=['# 源码技能 → 粒子配方映射','',data['scope'],'','源码字段为提取结果；配方列为本轮定制建议。完整实现片段见 skills.json / CSV。','', '| 分类 | 名称 / ID | 前摇 | 配方 | 源码 |','|---|---|---:|---|---|']
    for e in data['entries']:
        s=e['source'];w=e['facts'].get('windupTicks','—');name=(e['facts'].get('bossName','')+' · ' if e['category']=='Boss' else '')+e['name']
        lines.append(f"| {e['category']} | {name} / `{e['id']}` | {w} | `{e['design']['recipe']}` | `{s['path']}:{s['line']}` |")
    (output/'catalog/技能与配方总表.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def package(output):
    from validate import validate
    validate(output)
    delivery=ROOT/'deliverables';delivery.mkdir(exist_ok=True)
    for name,base in [('wuxingxiantu-skill-particle-library-v1.zip',output),('wuxingxiantu-vfx-resourcepack-v1.zip',output/'resourcepack')]:
        with zipfile.ZipFile(delivery/name,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
            for p in sorted(base.rglob('*')):
                if p.is_file(): archive.write(p,p.relative_to(base))
            if base==output:
                for p in sorted(Path(__file__).parent.glob('*')):
                    if p.is_file(): archive.write(p,Path('generator')/p.name)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'source-assets/skill-particle-library-v1');ap.add_argument('--package',action='store_true');args=ap.parse_args()
    print(json.dumps(build(args.output)['counts'],ensure_ascii=False))
    if args.package: package(args.output)
