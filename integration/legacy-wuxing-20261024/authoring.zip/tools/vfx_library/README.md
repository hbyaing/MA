# 粒子库生成器

Boss 推荐 V3：`python tools/vfx_library/build_v3.py`。输出 `source-assets/skill-particle-library-v3/`，10类原始模型、50种新专属材质、77技能、173源码分支。先运行 `validate_v3.py`、`check_ranges_v3.py` 与 `check_preview_v3.cjs`，再用 `build_v3.py --package-only` 打包。详见 `docs/boss-particle-library-v3.md`。需要本机 Java 17+、Pillow、NumPy、nbtlib；预览本身无需联网。

阵法与基础粒子扩展：`python tools/vfx_library/formation_library_v1.py --package`。输出 `source-assets/formation-particle-library-v1/`，9 个家族、36 套阵法、108 种角色化材质、16 帧阵法层图集。先运行 `validate_formation_v1.py` 与 `check_formation_preview.cjs`。详见 `docs/formation-particle-library-v1.md`。

其余技能继续使用 V2：`python tools/vfx_library/build_v2.py --package`。输出`source-assets/skill-particle-library-v2/`，138种材质、139套独立配方。浏览器检查先验证file://离线载入，再启动仅绑定127.0.0.1临时端口的只读测试服务进行像素检查，结束后关闭。V1/V2入口及产物继续保留。

默认从本项目当前 Java 与 zh_cn.json 提取目录，输出至 `source-assets/skill-particle-library-v1/`。不会启动 Minecraft、调用 Gradle、修改生产 Java 或生产资源。

```powershell
python -m pip install -r tools/vfx_library/requirements.txt
python tools/vfx_library/build.py --package
python tools/vfx_library/validate.py
```

在本机 Python 不在 PATH 时，用现有 Python 的完整路径。`nbtlib` 也可安装到项目的 `build/vfx-tool-deps/`，两个 NBT 脚本会优先读取该目录；无需改系统 Python。

- `catalog.py`：源码提取；注册表中的静态构造调用有显式语法约束。源码改为不同写法时，应修改提取器并检查缺项，不把它当成完整 Java 解析器。
- `design.py`：60种材质、32套配方、色板、逐技能映射；美术参数与源码事实分开。
- `textures.py`：确定性 RGBA 生成器。改变造型在这里修改，不依赖任何远程图片。
- `photon.py`：使用已存在原生模板生成 `.fx` 与 `.fxproj`。NBT读回验证只说明文件结构，不说明Photon引擎实际渲染成功。
- `photon_particle_template.snbt`：来自本项目此前原生 Photon 1.1.17 导出的结构模板，旧图片引用已替换。
- `preview.html`：离线预览源码，构建后会复制到产物。
- `check_preview.cjs`：使用Playwright与本机Edge做独立浏览器检查；需要Node可解析Playwright。只打开新建无头浏览器，检查后关闭；不操作用户正在浏览的页面。

完整包内的 `generator/` 是这些脚本的副本。要从源码重建，请把脚本放回原工程 `tools/vfx_library/`，并保留原工程 `src/`；完整包本身不包含模组Java源码。

修改后先运行生成与验证，再运行浏览器检查。报告位于 `reports/skill-particle-library-v1/`。脚本允许覆盖本轮生成目录下的同名产物；不要在生成目录内直接编辑唯一的手工版本，先另存。
