"""Assemble inspected browser frames into labeled V1/V2 and identity boards."""
from pathlib import Path
import json
from PIL import Image,ImageDraw
from catalog import ROOT
from textures import font

report=ROOT/'reports/skill-particle-library-v2'
catalog=json.loads((ROOT/'source-assets/skill-particle-library-v2/catalog/skills.json').read_text('utf-8'))
names={e['id']:e['name'] for e in catalog['entries']}

def board(ids,filename,title,columns=3,gray=False):
    width=1260;cellw=width//columns;cellh=265
    out=Image.new('RGB',(width,105+((len(ids)+columns-1)//columns)*cellh),'#0B151D');d=ImageDraw.Draw(out)
    d.text((24,19),title,font=font(28),fill='#E0EEE8');d.text((24,64),'V2 独立纹样与动作编排 · 浏览器制作预览，非游戏实机',font=font(15),fill='#81A4B0')
    for i,id in enumerate(ids):
        file=('gray-ermei-'+str(i+1)+'.png') if gray else id+'.png'
        pic=Image.open(report/file).convert('RGB');pic=pic.resize((cellw-16,200),Image.Resampling.LANCZOS)
        x=(i%columns)*cellw+8;y=105+(i//columns)*cellh
        out.paste(pic,(x,y));d.text((x+12,y+204),names[id],font=font(18),fill='#D8E9E8');d.text((x+12,y+233),id,font=font(11),fill='#7998A7')
    out.save(report/filename)

board(['fire_red_flow','fire_molten_gold','fire_cold_ash','fire_azure_wood','fire_cobalt_sea','fire_violet_thunder','fire_sun_saint','fire_nether_void','fire_nirvana'],'nine-flames-v2.png','九种异火 · 九种主形')
board([f'ermei_{i:02}' for i in range(1,7)],'ermei-gray-v2.png','耳魅六招 · 去掉颜色仍可辨认',gray=True)
board(['muyan_05','bichen_03','shetao_02','shenyin_07','yihuo_03','pengju_03','pengzhi_05','heart_demon_05','ri_yue_ting_lun'],'identities-v2.png','专属纹样 · Boss 与神通')
ids=['ermei_01','ermei_03','ermei_05','fire_cold_ash','fire_nirvana']
out=Image.new('RGB',(1300,125+len(ids)*275),'#0B151D');d=ImageDraw.Draw(out)
d.text((26,18),'同技能配方对比 · V1 → V2',font=font(29),fill='#DBEEE9')
d.text((28,65),'V1 / 通用配方',font=font(18),fill='#98A6AE');d.text((677,65),'V2 / 专属主形与轨迹',font=font(18),fill='#7DE1C8')
for i,id in enumerate(ids):
    y=115+i*275
    for j,prefix in enumerate(('v1-','')):
        pic=Image.open(report/(prefix+id+'.png')).convert('RGB').resize((628,226),Image.Resampling.LANCZOS);out.paste(pic,(20+j*648,y))
    d.text((27,y+231),names[id]+'  /  '+id,font=font(16),fill='#B2CCCF')
out.save(report/'before-after-v2.png')
frames=[Image.open(p).convert('RGB') for p in sorted((report/'frames').glob('*.png'))]
frames[0].save(report/'sound-wall-v2.gif',save_all=True,append_images=frames[1:],duration=100,loop=0)
print('Created 4 labeled comparison boards and animation.')
