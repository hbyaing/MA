const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const http=require('node:http');
const {pathToFileURL}=require('node:url'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'../..'),out=path.join(root,'source-assets/skill-particle-library-v2'),report=path.join(root,'reports/skill-particle-library-v2');
fs.mkdirSync(report,{recursive:true});
(async()=>{
 const server=http.createServer((req,res)=>{
  try{const url=new URL(req.url,'http://localhost');const parts=decodeURIComponent(url.pathname).split('/').filter(Boolean);const version=parts.shift();if(!['v1','v2'].includes(version)){res.writeHead(404);res.end();return}
   const base=path.join(root,'source-assets/skill-particle-library-'+version),file=path.resolve(base,...parts);if(!file.startsWith(base+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end();return}
   const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.png':'image/png','.json':'application/json; charset=utf-8'};res.setHeader('Content-Type',types[path.extname(file)]||'text/plain');fs.createReadStream(file).pipe(res);
  }catch{res.writeHead(400);res.end()}
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
 try{
 const page=await browser.newPage({viewport:{width:1500,height:1120},deviceScaleFactor:1});const errors=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>errors.push(r.url()+': '+r.failure().errorText));
 await page.goto(pathToFileURL(path.join(out,'preview/index.html')).href);await page.waitForFunction(()=>window.VFX_PREVIEW_READY===true,null,{timeout:30000});
 // file:// loading is verified above; same-origin HTTP permits pixel-level QA.
 await page.goto(origin+'/v2/preview/index.html');await page.waitForFunction(()=>window.VFX_PREVIEW_READY===true);
 const checks=await page.evaluate(()=>{
   const api=window.VFX_PREVIEW,d=window.VFX_LIBRARY,canvas=document.getElementById('stage'),g=canvas.getContext('2d');let checked=0;const blank=[];
   for(const e of d.entries){api.selectSkill(e.id);if(document.getElementById('title').textContent!==e.name)throw Error('Title '+e.id);api.seek(0);const before=g.getImageData(0,0,canvas.width,canvas.height).data;let best=0;
     const recipe=d.recipes.find(r=>r.id===e.design.recipe);
     for(const pct of [.18,.42,.67,.86]){api.seek(recipe.durationTicks*pct);const after=g.getImageData(0,0,canvas.width,canvas.height).data;let pixels=0;for(let i=0;i<after.length;i+=16)if(Math.abs(after[i]-before[i])+Math.abs(after[i+1]-before[i+1])+Math.abs(after[i+2]-before[i+2])>20)pixels++;best=Math.max(best,pixels);checked++}
     if(best<12)blank.push(e.id);
   }
   for(const m of d.materials){api.selectMaterial(m.id);for(const t of [8,24,40,55])api.seek(t)}
   return{skills:d.entries.length,materials:d.materials.length,skillFrameSamples:checked,materialFrameSamples:d.materials.length*4,blank};
 });
 if(checks.blank.length)throw Error('Blank skill previews '+checks.blank.join(','));
 await page.click('#skillTab');await page.fill('#search','心魔');const found=await page.locator('#list .entry').count();if(found!==10)throw Error('Search '+found);await page.fill('#search','');
 const selected=['ermei_01','ermei_03','ermei_04','ermei_05','muyan_05','bichen_03','shetao_02','shenyin_07','yihuo_03','pengju_03','pengzhi_05','heart_demon_05','fire_red_flow','fire_molten_gold','fire_cold_ash','fire_azure_wood','fire_cobalt_sea','fire_violet_thunder','fire_sun_saint','fire_nether_void','fire_nirvana','art_renewal','art_armor_break','art_golden_bell','ri_yue_ting_lun'];
 for(const id of selected){await page.evaluate(id=>{const r=window.VFX_LIBRARY.recipes.find(r=>r.id===id);window.VFX_PREVIEW.selectSkill(id);window.VFX_PREVIEW.seek(r.durationTicks*.43)},id);await page.locator('#stage').screenshot({path:path.join(report,id+'.png')})}
 const grayHashes=[];
 for(let i=1;i<=6;i++){await page.evaluate(id=>{window.VFX_PREVIEW.selectSkill(id);window.VFX_PREVIEW.setGray(true);window.VFX_PREVIEW.seek(23)},'ermei_0'+i);const buffer=await page.locator('#stage').screenshot();grayHashes.push(crypto.createHash('sha256').update(buffer).digest('hex'));fs.writeFileSync(path.join(report,'gray-ermei-'+i+'.png'),buffer)}
 if(new Set(grayHashes).size!==6)throw Error('Same grayscale sound skills');
 await page.evaluate(()=>{window.VFX_PREVIEW.selectSkill('heart_demon_05');window.VFX_PREVIEW.setGray(false);window.VFX_PREVIEW.seek(28)});
 await page.screenshot({path:path.join(report,'preview-v2.png'),fullPage:true});
 await page.click('#isolate');if(await page.locator('#isolate').textContent()!=='主形')throw Error('Layer isolation');await page.click('#grayscale');if(!await page.evaluate(()=>window.VFX_PREVIEW.state.gray))throw Error('Grayscale toggle');
 await page.locator('#color').fill('#36abff');await page.locator('#time').fill('500');
 const down=page.waitForEvent('download');await page.click('#download');const file=await down;await file.saveAs(path.join(report,'exported-recipe.json'));
 const saved=JSON.parse(fs.readFileSync(path.join(report,'exported-recipe.json'),'utf8'));if(saved.skillId!=='heart_demon_05'||saved.previewColor!=='#36abff'||!saved.layers[0].paths)throw Error('Export');
 await page.setViewportSize({width:680,height:960});if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1))throw Error('Overflow');
 await page.screenshot({path:path.join(report,'preview-mobile.png'),fullPage:true});await page.setViewportSize({width:1500,height:1120});
 const frameDir=path.join(report,'frames');fs.mkdirSync(frameDir,{recursive:true});
 for(let i=0;i<24;i++){await page.evaluate(t=>{window.VFX_PREVIEW.selectSkill('ermei_05');window.VFX_PREVIEW.setGray(false);window.VFX_PREVIEW.seek(t)},i*2);await page.locator('#stage').screenshot({path:path.join(frameDir,String(i).padStart(3,'0')+'.png')})}
 // Existing V1 remains unmodified and is read only to create like-for-like comparisons.
 await page.goto(origin+'/v1/preview/index.html');await page.waitForFunction(()=>window.VFX_PREVIEW_READY===true);
 for(const id of ['ermei_01','ermei_03','ermei_04','ermei_05','fire_red_flow','fire_cold_ash','fire_nirvana']){await page.evaluate(id=>{window.VFX_PREVIEW.selectSkill(id);window.VFX_PREVIEW.seek(16)},id);await page.locator('#stage').screenshot({path:path.join(report,'v1-'+id+'.png')})}
 const result={passed:errors.length===0,...checks,heartDemonSearchResults:found,graySoundSkillHashes:grayHashes,layerIsolation:true,recipeExportWithPaths:true,mobileOverflow:false,errors};fs.writeFileSync(path.join(report,'browser-validation.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));if(errors.length)process.exitCode=1;
 }finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
})().catch(e=>{console.error(e);process.exitCode=1});
