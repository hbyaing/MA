"""Original, deterministic RGBA masks. No borrowed game textures or generated-image service."""
from __future__ import annotations
import math
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont


def render(id: str, size=256, phase=.35, glyphs=None) -> Image.Image:
    from textures_v2 import DEFS, render_extra
    if id in DEFS:
        return render_extra(id,size,phase)
    axis=(np.arange(size,dtype=np.float32)+.5)/size*2-1
    x,y=np.meshgrid(axis,axis); r=np.hypot(x,y); a=np.arctan2(y,x)
    gauss=lambda v,w: np.exp(-(v/w)**2)
    ring=lambda rad,w=.018: gauss(r-rad,w)
    im=Image.new('L',(size,size)); d=ImageDraw.Draw(im)
    def xy(p): return ((p[0]+1)*size/2,(p[1]+1)*size/2)
    def line(points,width=.017,fill=255): d.line([xy(p) for p in points],fill=fill,width=max(1,round(width*size/2)),joint='curve')
    def poly(points,fill=255): d.polygon([xy(p) for p in points],fill=fill)
    def star(n,outer,inner,angle=0,fill=255):
        poly([(math.cos(i*math.pi/n+angle)*(outer if i%2==0 else inner),math.sin(i*math.pi/n+angle)*(outer if i%2==0 else inner)) for i in range(n*2)],fill)
    def radial_lines(n,inner,outer,width=.014,rotation=0):
        for i in range(n):
            ang=i*math.tau/n+rotation
            line([(math.cos(ang)*inner,math.sin(ang)*inner),(math.cos(ang)*outer,math.sin(ang)*outer)],width)
    def crystal(points):
        poly(points,110); line(points+[points[0]],.024,245)
        center=(sum(p[0] for p in points)/len(points),sum(p[1] for p in points)/len(points))
        for p in points: line([p,center],.012,180)
    def lightning(seed=37):
        rng=np.random.default_rng(seed)
        points=[(float(rng.uniform(-.22,.22)+.07*math.sin(phase*math.tau+i)),float(v)) for i,v in enumerate(np.linspace(-.82,.82,12))]
        line(points,.025)
        for i in (3,5,7):
            px,py=points[i]; side=(-1 if i%3 else 1)
            line([(px,py),(px+side*.16,py+.09),(px+side*.12,py+.23),(px+side*.40,py+.36)],.012,200)
    mask=np.zeros_like(x)
    if id=='spark_soft': mask=gauss(r,.20)*.72+gauss(r,.055)*.28
    elif id=='spark_star': mask=gauss(x,.017)*gauss(y,.41)+gauss(y,.017)*gauss(x,.41)+gauss(r,.1)*.7
    elif id=='spark_needle': mask=gauss(x,.025)*np.maximum(0,1-np.abs(y)/.76)**1.1
    elif id in ('flash_radial','thunder_core'):
        rays=np.maximum(0,np.cos(a*(10 if id=='flash_radial' else 7)+phase*.5))**26
        mask=gauss(r,.10+phase*.12)+rays*gauss(r,.65)*np.minimum(1,r*10)
    elif id=='impact_burst':
        star(13,.60+phase*.16,.16+phase*.2,phase*.15)
        mask=ring(.18+phase*.52,.015)*.8
    elif id in ('ring_soft','ring_double','ring_broken','ripple','sound_wave'):
        radius=.63 if id not in ('ripple','sound_wave') else .23+phase*.5
        mask=ring(radius,.018)+ring(radius,.055)*.25
        if id in ('ring_double','sound_wave','ripple'): mask+=ring(radius*.72,.012)*.65
        if id=='sound_wave': mask+=ring(radius*.44,.012)*.45
        if id=='ring_broken': mask*=np.abs(a)>math.pi/6
    elif id in ('rune_circle','five_elements_seal'):
        mask=ring(.74,.010)+ring(.68,.007)*.65+ring(.43,.012)*.75
        radial_lines(32,.685,.725,.009,phase*math.tau if id=='rune_circle' else 0)
        if id=='rune_circle': mask+=gauss(np.hypot(x-.74*math.cos(phase*math.tau),y-.74*math.sin(phase*math.tau)),.04)
        for i in range(8 if id=='rune_circle' else 5):
            ang=i*math.tau/(8 if id=='rune_circle' else 5)-math.pi/2
            cx,cy=math.cos(ang)*.55,math.sin(ang)*.55
            line([(cx-.035,cy-.035),(cx+.035,cy-.035),(cx+.035,cy+.035),(cx-.035,cy+.035),(cx-.035,cy-.035)],.012)
        if id=='five_elements_seal':
            line([(math.cos(-math.pi/2+i*math.tau*2/5)*.39,math.sin(-math.pi/2+i*math.tau*2/5)*.39) for i in range(6)],.019)
    elif id=='seal_glyph':
        line([(-.52,-.52),(.52,-.52),(.52,.52),(-.52,.52),(-.52,-.52)],.026)
        line([(-.42,-.42),(.42,-.42),(.42,.42),(-.42,.42),(-.42,-.42)],.01,160)
        for yy in (-.27,0,.27): line([(-.3,yy),(.3,yy)],.028)
        line([(0,-.39),(0,.39)],.031)
        line([(-.27,.08),(0,-.16),(.27,.08)],.021)
    elif id in ('sword_slash','sword_cross','sound_blade'):
        curve=np.sqrt((x/.87)**2+((y+.18)/.70)**2)
        mask=gauss(curve-.78,.04)*(y>.0)*np.maximum(0,1-(x/.86)**2)
        mask+=gauss(curve-.67,.018)*(y>.02)*.5
        if id=='sword_cross': mask=np.maximum(mask,mask.T)
        if id=='sound_blade': mask+=gauss(curve-.48,.025)*(y>-.07)*.55
        mask*=np.clip(1-phase*.35,0,1)
    elif id=='sword_ghost':
        poly([(0,-.83),(.085,-.60),(.06,.35),(-.06,.35),(-.085,-.60)],215)
        line([(0,-.72),(0,.31)],.017); line([(-.24,.33),(.24,.33)],.039)
        line([(0,.32),(0,.70)],.045,180); mask=gauss(x,.11)*gauss(y,.57)*.15
    elif id in ('trail_ribbon','wind_streak','heat_wisp','soul_wisp'):
        if id=='trail_ribbon':
            center=.08*np.sin(x*8-phase*math.tau); mask=gauss(y-center,.035)*(np.cos(x*math.pi/2)**2)+gauss(y-center-.10,.014)*.35*(1-x*x)
        else:
            xx=x+.14*np.sin(y*7+phase*math.tau)*(0.3 if id=='wind_streak' else 1)
            mask=gauss(xx,.018 if id=='wind_streak' else .035)*np.maximum(0,1-(y/.82)**2)**2
            if id!='wind_streak': mask+=gauss(xx,.10)*.18*np.maximum(0,1-(y/.82)**2)**2
            if id=='soul_wisp':
                mask+=gauss(x-.15*np.sin(y*9+phase*math.tau)-.1,.018)*np.maximum(0,1-(y/.76)**2)*.6
                mask+=gauss(np.hypot(x+.05,y+.27),.115)*.48
    elif id in ('wind_curl','mist_spiral'):
        twist=a+r*(13 if id=='mist_spiral' else 8)-phase*math.tau
        mask=gauss(np.sin(twist*(2 if id=='mist_spiral' else 1)),.06)*gauss(r-.44,.28)*np.clip(r*8,0,1)
        if id=='mist_spiral':mask*=.74+.26*np.cos(a-phase*math.tau)
    elif id=='flame_tongue':
        height=np.clip((.75-y)/1.5,0,1)
        center=.12*np.sin(height*8-phase*math.tau)*height
        width=.28*(1-height)**.65+.01
        body=np.clip(1-np.abs((x-center)/width),0,1)**.6
        base=np.clip((y+.80)*10,0,1)*np.clip((.77-y)*15,0,1)
        hollow=gauss(x-center,width*.35)*np.clip((y+.1)*3,0,.55)
        mask=(body-hollow)*base
    elif id in ('ember_fragment','talisman_ash'):
        poly([(-.17,.38),(-.24,.05),(.02,-.55),(.12,-.08),(.26,.11),(.09,.40)],220 if id=='ember_fragment' else 160)
        line([(-.06,.27),(.02,-.32)],.025)
    elif id in ('smoke_puff','poison_cloud','dust_plume','cloud_scroll'):
        rng=np.random.default_rng(12)
        for i in range(12):
            cx,cy=rng.uniform(-.4,.4,2)
            if id=='dust_plume': cx*=.5;cy-=phase*.20
            if id=='cloud_scroll': cy*=.35
            rr=float(rng.uniform(.14,.28))
            dx=x-cx-.04*math.sin(phase*math.tau+i); dy=y-cy-.04*math.cos(phase*math.tau+i)
            mask+=gauss(np.hypot(dx,dy),rr)*(.11 if id=='poison_cloud' else .13)
        turbulence=(np.sin(x*13+.9*np.sin(y*8)+phase*math.tau)+np.sin(y*17+.8*np.cos(x*11)-phase*math.tau)+.5*np.cos(x*27)*np.sin(y*23))/2.5
        mask*=.78+.25*turbulence
        if id=='poison_cloud':mask*=1.2;mask*=.75+.25*np.cos(a*3+r*12-phase*math.tau)
    elif id=='water_droplet':
        poly([(0,-.72),(-.29,.05),(-.25,.35),(0,.51),(.25,.35),(.29,.05)],150)
        line([(-.14,-.08),(-.18,.13),(-.10,.28)],.035,240)
    elif id in ('water_splash','acid_splash'):
        rng=np.random.default_rng(61)
        for i in range(13):
            ang=i*math.tau/13; rr=.35+float(rng.uniform(0,.2))+phase*.1
            cx,cy=math.cos(ang)*rr,math.sin(ang)*rr
            mask+=gauss(np.hypot(x-cx,y-cy),.045+float(rng.uniform(0,.06)))
        mask+=gauss(r-(.2+phase*.25),.024 if id=='water_splash' else .1)*.65
    elif id in ('ice_shard','crystal_shard','mirror_shard','earth_shard'):
        shapes={'ice_shard':[(0,-.79),(.20,-.22),(.12,.61),(-.13,.57),(-.20,-.25)],
                'crystal_shard':[(0,-.78),(.31,-.29),(.28,.45),(0,.72),(-.28,.45),(-.31,-.29)],
                'mirror_shard':[(-.40,-.56),(.51,-.32),(.28,.60),(-.33,.25)],
                'earth_shard':[(-.35,-.42),(.18,-.57),(.51,-.08),(.32,.45),(-.20,.51),(-.48,.12)]}
        crystal(shapes[id])
    elif id=='snow_crystal':
        for i in range(6):
            ang=i*math.pi/3; co,si=math.cos(ang),math.sin(ang)
            rot=lambda px,py:(px*co-py*si,px*si+py*co)
            line([rot(0,0),rot(.7,0)],.024)
            for rr in (.28,.48):
                line([rot(rr+.12,-.12),rot(rr,0),rot(rr+.12,.12)],.017)
        mask=ring(.12,.012)
    elif id in ('leaf','petal'):
        shape=((x+.22*np.sin(y*3))/.31)**2+(y/.69)**2
        mask=np.clip(1-shape,0,1)**.32*.85
        if id=='leaf':
            line([(-.1,.54),(0,0),(.1,-.54)],.022)
            for yy in (-.3,0,.3): line([(-.16,yy-.12),(0,yy),(.2,yy-.15)],.012,190)
    elif id=='vine_thorn':
        line([(-.10,.78),(.05,.42),(-.12,.12),(.07,-.18),(-.03,-.72)],.065,195)
        for yy,side in [(.4,1),(.0,-1),(-.3,1)]: poly([(0,yy),(.33*side,yy-.21),(.03,yy+.11)],220)
    elif id=='poison_bubble': mask=ring(.45,.025)*.7+gauss(r,.43)*.14+gauss(np.hypot(x+.18,y+.25),.072)*.8
    elif id in ('ground_crack','mirror_crack'):
        rng=np.random.default_rng(88)
        for i in range(9 if id=='mirror_crack' else 6):
            ang=i*math.tau/(9 if id=='mirror_crack' else 6)
            pts=[(0,0)]
            for rr in (.19,.36,.54,.76):
                aa=ang+float(rng.uniform(-.19,.19));pts.append((math.cos(aa)*rr,math.sin(aa)*rr))
            line(pts,.013)
            p=pts[2]; line([p,(p[0]+.15*math.cos(ang+.8),p[1]+.15*math.sin(ang+.8))],.009,180)
        if id=='mirror_crack': mask=ring(.35,.009)*.4
    elif id=='lightning_branch': lightning()
    elif id=='electric_arc':
        points=[]
        for i in range(25):
            ang=-2.6+i*5.2/24; rad=.54+.055*math.sin(i*2.7+phase*math.tau)
            points.append((math.cos(ang)*rad,math.sin(ang)*rad))
        line(points,.025); mask=gauss(r-.54,.08)*.10
    elif id=='prism_glint':
        star(4,.72,.055,math.pi/4);mask=gauss(r,.12)*.75
    elif id=='eye_sigil':
        mask=gauss(np.abs(y)-.32*(1-(x/.75)**2),.018)*(np.abs(x)<.75)+ring(.19,.022)+gauss(x,.029)*gauss(y,.20)
    elif id=='chain_link':
        rr=np.sqrt((x/.25)**2+(y/.48)**2);mask=gauss(rr-1,.055)
        mask+=gauss(rr-.86,.028)*.4
    elif id=='star_dipper':
        points=[(-.63,-.44),(-.2,-.53),(-.13,-.13),(-.49,-.04),(.08,.18),(.36,.38),(.68,.48)]
        line(points,.012,150)
        for cx,cy in points: mask+=gauss(np.hypot(x-cx,y-cy),.035)+gauss(np.hypot(x-cx,y-cy),.085)*.3
    elif id=='lotus': mask=gauss(r-(.46+.19*np.cos(5*a-math.pi/2)),.019)+ring(.18,.012)
    elif id=='eclipse_ring':
        mask=ring(.61,.028)+ring(.68,.009)*.4
        mask+=gauss(np.hypot(x-math.cos(phase*math.tau)*.61,y-math.sin(phase*math.tau)*.61),.08)
        radial_lines(24,.70,.75,.009)
    elif id=='shield_hex':
        pts=[(math.cos(i*math.pi/3)*.66,math.sin(i*math.pi/3)*.66) for i in range(6)]
        line(pts+[pts[0]],.025);poly([(p[0]*.85,p[1]*.85) for p in pts],22)
        radial_lines(6,.10,.40,.009)
    elif id.startswith('glyph_'):
        rows=glyphs[id[6:]]
        for yy,row in enumerate(rows):
            for xx,ch in enumerate(row):
                if ch=='X':
                    x0=(xx/16-.5)*.80;y0=(yy/32-.5)*1.6
                    d.rectangle([xy((x0,y0)),xy((x0+.047,y0+.047))],fill=255)
    else: raise ValueError('Unimplemented material '+id)
    drawn=np.asarray(im,dtype=np.float32)/255
    blur=np.asarray(im.filter(ImageFilter.GaussianBlur(size/100)),dtype=np.float32)/255
    mask=np.maximum(mask,drawn*.88+blur*.24)
    if id=='mirror_crack': mask*=np.clip((.18+phase*.72-r)*18,0,1)
    # Four-pixel minimum transparent gutter even in the 128 px animation cells.
    gutter=np.clip((.92-np.maximum(np.abs(x),np.abs(y)))/.09,0,1)
    alpha=np.clip(mask*gutter,0,1)
    rgba=np.full((size,size,4),255,dtype=np.uint8)
    rgba[:,:,3]=np.round(alpha*255).astype(np.uint8)
    return Image.fromarray(rgba)


def tinted(im,hexcolor):
    out=Image.new('RGBA',im.size,hexcolor);out.putalpha(im.getchannel('A'));return out


def font(size):
    for path in ['C:/Windows/Fonts/msyh.ttc','C:/Windows/Fonts/simhei.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']:
        if Path(path).exists(): return ImageFont.truetype(path,size)
    return ImageFont.load_default()


def build_textures(output, materials, glyphs):
    base=output/'resourcepack/assets/wuxingxiantu_vfx/textures/library'
    base.mkdir(parents=True,exist_ok=True)
    thumbs=output/'preview/thumbs'; thumbs.mkdir(parents=True,exist_ok=True)
    records=[]
    for id,name,family,animation,blend in materials:
        image=render(id,256,glyphs=glyphs)
        path=base/(id+'.png');image.save(path)
        atlas_path=None
        if animation!='none':
            atlas=Image.new('RGBA',(512,512),(255,255,255,0))
            for i in range(16):
                frame=render(id,128,phase=(i/16 if animation=='loop' else .03+.94*i/15),glyphs=glyphs)
                atlas.paste(frame,(i%4*128,i//4*128))
            atlas_path=base/(id+'_sheet.png');atlas.save(atlas_path)
        records.append(dict(id=id,name=name,family=family,blend=blend,animation=animation,
            texture=f'wuxingxiantu_vfx:textures/library/{id}.png',
            file=path.relative_to(output).as_posix(),
            sheet=atlas_path.relative_to(output).as_posix() if atlas_path else None,
            sheetTexture=f'wuxingxiantu_vfx:textures/library/{id}_sheet.png' if atlas_path else None,
            width=256,height=256,columns=4 if atlas_path else 1,rows=4 if atlas_path else 1,
            frames=16 if atlas_path else 1,frameSize=128 if atlas_path else 256,
            alpha='straight',rgb='white tintable',gutterPixels=4,
            sampling='linear / clamp; no mipmaps across atlas cells',
            orientation='XY sprite; trail ribbons run along U; floor placement must be set by emitter/mesh'))
        bg=Image.new('RGBA',(256,256),'#101E2B'); bg.alpha_composite(tinted(image,'#A3DCEC')); bg.convert('RGB').save(thumbs/(id+'.png'))
    sheet=Image.new('RGB',(1440,140+math.ceil(len(records)/8)*211),'#0B1520');d=ImageDraw.Draw(sheet)
    d.text((28,22),'五行仙途  /  技能粒子材质库',font=font(32),fill='#E2EBE8')
    d.text((30,68),f'{len(records)} 个独立形状 · 白色透明底可染色 · 含序列帧 · 非实机截图',font=font(17),fill='#88A7B8')
    colors=['#BDEFFF','#FFD167','#79DFA0','#64CFEF','#FF793D','#D1AC70','#B59DFF','#EE9DDF','#F5C99A','#8FC657']
    for i,rec in enumerate(records):
        xx=20+(i%8)*177;yy=110+(i//8)*211
        d.rounded_rectangle((xx,yy,xx+164,yy+196),radius=10,fill='#132536',outline='#284455')
        tile=tinted(Image.open(output/rec['file']).resize((143,143)),colors[(i//6)%len(colors)])
        sheet.paste(tile,(xx+11,yy+4),tile)
        d.text((xx+10,yy+148),rec['name'],font=font(17),fill='#E4EFED')
        d.text((xx+10,yy+176),rec['id'],font=font(10),fill='#81A0AF')
    sheet.save(output/'preview/material-contact.png')
    return records
