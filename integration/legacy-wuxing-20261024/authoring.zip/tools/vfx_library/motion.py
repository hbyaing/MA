"""One sampled choreography source shared by the HTML preview and Photon export.

Coordinates describe a front-facing authoring stage, not game hit volumes.
"""
import math

def pose(layer,index,count,u):
    m=layer['motion'];a=index/max(1,count)*math.tau;v=(index+.5)/max(1,count)
    n=(math.sin(index*12.9898+len(layer['material'])*78.233)*43758.5453)%1
    speed=layer.get('speed',1);ease=1-(1-u)**2
    spread=layer.get('spread',1);x=y=rot=0.;sx=sy=sz=1.
    if m=='center':pass
    elif m=='ground':y=1.1;sy=.38
    elif m=='pulse':sz=.86+.16*math.sin(u*math.tau*2);rot=.07*math.sin(u*math.tau)
    elif m=='grow':x=(v-.5)*1.9 if count>1 else 0;y=.8-u*.65;sz=.2+.85*ease
    elif m=='bloom':
        x=math.cos(a)*ease*1.8 if count>1 else 0;y=math.sin(a)*ease*1.3 if count>1 else 0;rot=a+u*.45 if count>1 else u*.15;sz=.25+1.0*ease
    elif m=='collapse':sz=max(.10,1.2*(1-u)**.7);rot=u*.55
    elif m=='fan':
        ang=(v-.5)*1.9;dist=.3+u*3.0;x=math.cos(ang)*dist-1.3;y=math.sin(ang)*dist*.85;rot=ang+math.pi/2
    elif m in ('sweep','slash'):
        x=(ease-.5)*2.6;y=math.sin(u*math.pi)*.5;rot=-.85+u*1.7+(index-(count-1)/2)*.4
    elif m=='helix':
        ang=a+u*math.tau*speed;x=math.cos(ang)*(1.0+n*.5);y=1.1-u*2.6+math.sin(ang)*.32;rot=ang*.3
    elif m in ('converge','inward'):
        ang=a+u*(.7 if m=='converge' else -.7);radius=(1-u)*2.65;x=math.cos(ang)*radius;y=math.sin(ang)*radius*.75;rot=ang-math.pi/2
        if count==1:x=y=0;sz=1.25-.40*u
    elif m=='orbit':
        ang=a+u*math.tau*.7*speed;x=math.cos(ang)*1.8*spread;y=math.sin(ang)*.7*spread;rot=ang+.3
    elif m in ('burst','radial','shatter'):
        radius=ease*(1.25+n*1.1);x=math.cos(a)*radius;y=math.sin(a)*radius
        rot=a+(u*3 if m=='shatter' else math.pi/2)
        if count==1:x=y=0;sz=.5+ease*.8
    elif m=='rise':x=(v-.5)*2.1 if count>1 else 0;y=.8-u*2.5;rot=(n-.5)*.4
    elif m=='rain':x=(v-.5)*4.4;y=-2.0+u*3.3;rot=math.pi
    elif m=='beam':x=(v-.5)*4.4 if count>1 else 0;rot=math.pi/2 if 'ribbon' not in layer['material'] else 0
    elif m=='lunge':x=-2.5+ease*4.8;y=(v-.5)*.45 if count>1 else 0;rot=math.pi/2
    elif m=='tangent':
        x=math.cos(a)*.9-math.sin(a)*u*2.6;y=math.sin(a)*.5+math.cos(a)*u*1.6;rot=a+u*speed
    elif m=='petal_fall':x=(v-.5)*3.6+math.sin(u*6+a)*.4;y=-.9+u*2.5;rot=a+u*2
    elif m=='shell':
        ang=a+u*.30;x=math.cos(ang)*1.35;y=math.sin(ang)*1.3;rot=ang+math.pi/2
        if count==1:x=y=0;sz=.5+.5*ease
    elif m in ('cage','hex_guard'):
        gap=math.radians(layer.get('gapDegrees',0));ang=gap/2+v*(math.tau-gap)
        x=math.cos(ang)*1.9;y=.15+math.sin(ang)*.80;rot=0 if m=='hex_guard' else ang*.12
    elif m=='stamp':
        x=(v-.5)*3.0 if count>1 else 0;y=-1.7+min(1,u/.43)*2.5;sz=.65+.35*min(1,u/.43)
        if u>.43:sz+=math.sin((u-.43)*math.pi)*.10
    elif m=='ballistic':x=(v-.5)*3.8*u;y=-math.sin(math.pi*u)*(1.3+n)+u*1.4;rot=(n-.5)*u*4
    elif m=='ground_wave':
        if count<=4:x=y=0;y=1.0;sy=.40;sz=.2+ease*1.5
        else:x=math.cos(a)*ease*2.5;y=1+math.sin(a)*ease*.7;rot=a
    elif m=='fork':x=(index-(count-1)/2)*u*1.25;y=-u*1.1;rot=(index-(count-1)/2)*.31
    elif m=='afterimage':x=(v-.5)*3.8+(u-.5)*.65;y=.1*math.sin(a);sz=1-.25*v
    elif m=='curtain':x=(v-.5)*4.5 if count>1 else 0;y=-.6+u*1.3;sy=1.1
    elif m=='walls':
        side=-1 if index%2==0 else 1;x=side*(2.55-1.55*ease);y=(index//2-(count//2-1)/2)*.46 if count>2 else 0;sy=1.15
    elif m=='homing':
        t=u*math.pi;x=-2.5+u*4.5;y=math.sin(t+a*.4)*1.2*(1-u);rot=math.pi/2+math.cos(t)*.5
    elif m=='mirror_pair':x=(v-.5)*3.8 if count>1 else 0;y=math.sin(u*math.pi+index)*.13
    elif m=='reel':x=(v-.5)*4.6*(1-u);y=math.sin(v*math.pi*2+u*3)*.3;rot=math.pi/2+u
    elif m=='sectors':
        ang=a-math.pi/2;x=math.cos(ang)*(1.3+.7*u);y=math.sin(ang)*(1+.5*u);rot=ang+math.pi/2
    elif m=='rolling':x=-2.6+u*5.0;y=.8;rot=u*math.tau*1.4
    elif m=='swap':x=math.cos(a+u*math.pi)*2.0;y=math.sin(a+u*math.pi)*.75;rot=.1*math.sin(u*math.pi)
    elif m=='path_echo':x=(v-.5)*4.4;y=math.sin(v*math.pi*2)*.55+.65;rot=math.sin(v*math.pi*2)*.35;sz=.8+.2*u
    elif m=='pentad':
        ang=(a if count>1 else -math.pi/2)+u*.30;x=math.cos(ang)*1.85;y=math.sin(ang)*1.5;rot=ang+.4
    elif m=='twin_arc':
        side=-1 if index%2==0 else 1;x=side*(2.15-2*u);y=.6-math.sin(u*math.pi)*1.8;rot=side*u*math.tau
    elif m=='tether':x=(v-.5)*4.8 if count>1 else 0;y=.20*math.sin(v*math.pi*2+u*4);rot=math.pi/2+.12*math.cos(v*math.pi*2+u*4)
    elif m=='eruption':x=(v-.5)*4.0;y=1.15-ease*(1.2+n*.5);sz=.2+.9*min(1,u/.32)
    elif m=='wake':x=-2.0+v*3.5-u*.6;y=.35*math.sin(a+u*3);rot=math.pi/2
    elif m=='ribbon':x=(v-.5)*4.3;y=.5*math.sin(v*math.pi*2-u*math.tau);rot=math.atan2(.5*math.cos(v*math.pi*2-u*math.tau),1)+math.pi/2
    elif m=='constellation':
        points=[(-1.8,-.8),(-.7,-1.3),(-.3,-.3),(-1.3,.2),(.1,.5),(1,1),(1.9,1.3)]
        if count>1:x,y=points[index%7]
        sz=.8+.2*math.sin(u*math.pi)
    elif m=='freeze':
        t=min(u,.36);x=math.cos(a+t*4)*1.9;y=math.sin(a+t*4)*1.35;rot=a+t*2
    elif m=='suspend':x=math.cos(a)*(1.1+n);y=math.sin(a)*(1+n) if count>1 else 0
    elif m=='stutter':x=.15*math.sin(u*math.pi*12);y=-.15*math.sin(u*math.pi*6);sz=.9+.09*math.sin(u*math.pi*8)
    elif m=='column':y=-.50
    elif m=='gate':sx=.6+.4*ease;sy=1.15;y=-.2
    else:raise ValueError('Unknown motion '+m)
    angle=math.radians(layer.get('angle',0));x,y=x*math.cos(angle)-y*math.sin(angle),x*math.sin(angle)+y*math.cos(angle);rot+=angle
    return [round(v,5) for v in (x,y,rot,sx,sy,sz)]

def attach_paths(recipe):
    for layer in recipe['layers']:
        layer['paths']=[[pose(layer,i,layer['count'],j/24) for j in range(25)] for i in range(layer['count'])]
    return recipe
