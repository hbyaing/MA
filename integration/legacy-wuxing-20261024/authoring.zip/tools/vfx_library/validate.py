"""Validate source coverage, native NBT references, transparency and frame integrity."""
from __future__ import annotations
import hashlib,json,sys
import math
from pathlib import Path
from collections import Counter
import numpy as np
from PIL import Image
from catalog import ROOT,extract
sys.path.insert(0,str(ROOT/'build/vfx-tool-deps'))
import nbtlib


def validate(out):
    read=lambda p:json.loads((out/p).read_text('utf-8-sig'))
    catalog=read('catalog/skills.json');mats=read('catalog/materials.json');recipes=read('catalog/recipes.json');manifest=read('manifest.json');exports=read('photon/exports.json')
    fresh=extract();assert {e['id'] for e in catalog['entries']}=={e['id'] for e in fresh['entries']}
    for path,sha in catalog['sourceHashes'].items(): assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==sha, 'Source drift: '+path
    ids={m['id'] for m in mats};rids={r['id'] for r in recipes};pids=set(read('catalog/palettes.json'))
    v2=manifest.get('schemaVersion',1)>=2
    assert len(ids)==len(mats)==manifest['counts']['materials'] and len(rids)==len(recipes)==manifest['counts']['recipes']
    if v2:
        assert len(recipes)==len(catalog['entries'])==139
        assert len({e['design']['recipe'] for e in catalog['entries']})==139
        diversity=read('catalog/diversity.json')
        assert diversity['after']['repeatedChoreographies']==0
        assert diversity['after']['topMaterialUsage'][0][1]<diversity['before']['topMaterialUsage'][0][1]/2
    for e in catalog['entries']:
        assert e['design']['recipe'] in rids and e['design']['palette'] in pids
        assert set(e['design']['materialOverrides'].values())<=ids
        if e['category']=='Boss': assert e['facts']['program'] and e['facts']['windupTicks']>0
    animation_frames=0;unique=[]
    for m in mats:
        img=Image.open(out/m['file']);assert img.mode=='RGBA' and img.size==(256,256)
        a=np.array(img)[:,:,3];assert a.max()>20 and np.mean(a>8)>.005 and np.any(a==0),m['id']
        assert np.all(a[:4]==0) and np.all(a[-4:]==0) and np.all(a[:,:4]==0) and np.all(a[:,-4:]==0),m['id']+' clipped edge'
        unique.append(hashlib.sha256(a.tobytes()).hexdigest())
        if m['sheet']:
            atlas=Image.open(out/m['sheet']);assert atlas.mode=='RGBA' and atlas.size==(512,512)
            hashes=[]
            for i in range(16):
                frame=atlas.crop((i%4*128,i//4*128,i%4*128+128,i//4*128+128));alpha=np.array(frame)[:,:,3]
                assert alpha.max()>20 and np.mean(alpha>8)>.005,m['id']+' blank frame'
                assert np.all(alpha[:4]==0) and np.all(alpha[-4:]==0) and np.all(alpha[:,:4]==0) and np.all(alpha[:,-4:]==0),m['id']+' frame bleed'
                hashes.append(hashlib.sha256(alpha.tobytes()).hexdigest());animation_frames+=1
            assert len(set(hashes))>=8,m['id']+' does not animate'
    assert len(set(unique))==len(unique),'Duplicate base mask'
    for r in recipes:
        assert r['durationTicks']==max(l['delayTicks']+l['lifetimeTicks']+l.get('staggerTicks',0)*(l['count']-1) for l in r['layers'])
        assert sum(l['count'] for l in r['layers'])<=r['recommendedMaxParticles']
        for l in r['layers']: assert l['material'] in ids and l['count']>0 and l['lifetimeTicks']>0 and l['sizeBlocks']>0
        if v2:
            for l in r['layers']:
                assert len(l['paths'])==l['count']
                for path in l['paths']:
                    assert len(path)==25
                    for point in path:assert len(point)==6 and all(math.isfinite(v) and abs(v)<40 for v in point) and all(v>0 for v in point[3:])
    checked_textures=0
    def walk(node):
        nonlocal checked_textures
        if isinstance(node,dict):
            if str(node.get('_type',''))=='TextureMaterial':
                tex=str(node['texture']);ns,path=tex.split(':');assert (out/'resourcepack/assets'/ns/path).is_file(),tex;checked_textures+=1
            for v in node.values(): walk(v)
        elif isinstance(node,(list,nbtlib.List)):
            for v in node:walk(v)
    for e in exports:
        runtime=nbtlib.load(out/e['runtime']);project=nbtlib.load(out/e['project'])
        assert runtime['fx']==project['fx'];assert int(runtime['_version'])==1
        objs=runtime['fx']['mainFX']['fxObjects'];assert len(objs)==e['emitters']
        for ob in objs:
            cfg=ob['config'];assert str(cfg['simulationSpace'])=='World'
            assert cfg['startSize']['x']['number']>0 and cfg['maxParticles']<=128
            assert cfg['material']['depthTest']==1 and cfg['material']['depthMask']==0
        assert len(project['resources']['material'])==len(mats)
        if v2:assert len(objs)<=32
        walk(runtime);walk(project)
    for path,sha in manifest['files'].items():assert hashlib.sha256((out/path).read_bytes()).hexdigest()==sha,'Output modified: '+path
    result=dict(passed=True,entries=len(catalog['entries']),categoryCounts=dict(Counter(e['category'] for e in catalog['entries'])),materials=len(mats),uniqueMasks=len(set(unique)),animated=sum(m['frames']>1 for m in mats),animationFrames=animation_frames,recipes=len(recipes),nativeFx=len(exports),nativeProjects=len(exports),textureReferencesChecked=checked_textures,sourceFilesChecked=len(catalog['sourceHashes']),filesHashed=len(manifest['files']),minecraftRendered=False,productionIntegrated=False)
    (out/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False));return result


if __name__=='__main__':validate(Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'source-assets/skill-particle-library-v1')
