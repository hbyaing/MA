"""Distinct silhouettes for V2, drawn with deterministic vector strokes and scalar fields."""
import math
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
from design_v2 import EXTRA_MATERIALS

DEFS={m[0]:m for m in EXTRA_MATERIALS}

def render_extra(id,size=256,phase=.35):
    axis=(np.arange(size,dtype=np.float32)+.5)/size*2-1
    x,y=np.meshgrid(axis,axis);r=np.hypot(x,y);a=np.arctan2(y,x);p=phase*math.tau
    im=Image.new('L',(size,size));d=ImageDraw.Draw(im);field=np.zeros_like(x)
    def xy(pt):return((pt[0]+1)*size/2,(pt[1]+1)*size/2)
    def line(pts,w=.018,fill=235):d.line([xy(pt) for pt in pts],fill=fill,width=max(1,round(size*w/2)),joint='curve')
    def poly(pts,fill=130):d.polygon([xy(pt) for pt in pts],fill=fill)
    def arc(cx,cy,rx,ry,start=0,end=math.tau,w=.017,fill=235):
        line([(cx+rx*math.cos(t),cy+ry*math.sin(t)) for t in np.linspace(start,end,100)],w,fill)
    def gauss(v,width):return np.exp(-(v/width)**2)
    def ring(rad,w=.017):return gauss(r-rad,w)
    def rot(pt,ang):return(pt[0]*math.cos(ang)-pt[1]*math.sin(ang),pt[0]*math.sin(ang)+pt[1]*math.cos(ang))
    def polygon_ring(n,rad=.7,angle=0,w=.018):
        pts=[(math.cos(angle+i*math.tau/n)*rad,math.sin(angle+i*math.tau/n)*rad) for i in range(n)]
        line(pts+[pts[0]],w);return pts
    def faceted(pts):
        poly(pts,75);line(pts+[pts[0]],.018)
        for i in range(1,len(pts)-1):line([pts[0],pts[i]],.009,130)
    def blade(cx,cy,length=.55,angle=0,wide=.07):
        pts=[(0,-length),(-wide,-length*.52),(-wide*.48,length*.52),(0,length*.75),(wide*.48,length*.52),(wide,-length*.52)]
        pts=[(cx+rot(v,angle)[0],cy+rot(v,angle)[1]) for v in pts];poly(pts,175);line(pts+[pts[0]],.014);line([pts[0],pts[3]],.010,245)
    def branching(root=(0,.7),angle=-math.pi/2,length=.7,depth=3,seed=0):
        end=(root[0]+length*math.cos(angle),root[1]+length*math.sin(angle));line([root,end],.011+depth*.006,130+depth*25)
        if depth:
            branching(end,angle-.48+seed*.03,length*.61,depth-1,seed+1)
            branching(end,angle+.59-seed*.02,length*.56,depth-1,seed+2)
    if id=='ink_crescent':
        for i in range(7):
            points=[]
            for t in np.linspace(-2.8,-.2,80):
                rad=.62+.025*i+.009*math.sin(t*31+i)
                points.append((rad*math.cos(t),rad*.7*math.sin(t)+.35))
            line(points,.006+i*.003,235-i*12)
        for i in range(7):line([(.22+i*.065,.10-i*.031),(.55+i*.045,.02-i*.035)],.008,130)
    elif id=='spear_head':
        faceted([(0,-.82),(-.19,-.17),(-.045,-.27),(-.04,.75),(.04,.75),(.045,-.27),(.19,-.17)])
        line([(0,-.75),(0,.7)],.018)
    elif id=='sword_fan':
        for i in range(9):
            ang=(i-4)*.17;blade(math.sin(ang)*.23,.25,.57,ang,.038)
        arc(0,.25,.72,.72,-2.37,-.76,.012,140)
    elif id=='bell_shell':
        line([(-.62,.52),(-.44,.23),(-.37,-.38),(-.18,-.61),(.18,-.61),(.37,-.38),(.44,.23),(.62,.52),(-.62,.52)],.025)
        arc(0,-.66,.15,.1,math.pi,math.tau,.025);arc(0,.53,.59,.12,0,math.pi,.020)
        for xx in [-.22,0,.22]:line([(xx,-.3),(xx,.28)],.012,140)
        line([(-.45,.25),(.45,.25)],.009,180)
    elif id=='armor_scale':
        faceted([(-.53,-.48),(.53,-.48),(.45,.13),(0,.65),(-.45,.13)])
        line([(-.39,-.28),(.39,-.28),(.29,.08),(0,.4),(-.29,.08),(-.39,-.28)],.018,190)
    elif id=='pierce_diamond':
        faceted([(0,-.81),(.27,-.1),(.10,.08),(.21,.39),(0,.72),(-.21,.39),(-.10,.08),(-.27,-.1)])
    elif id=='branch_bloom':
        branching(length=.61,depth=3)
        for xx,yy,ang in [(-.34,-.20,-.7),(.31,-.16,.6),(-.17,-.58,-.6),(.19,-.63,.5)]:
            pts=[(xx+rot((.20*math.cos(t),.07*math.sin(t)),ang)[0],yy+rot((.20*math.cos(t),.07*math.sin(t)),ang)[1]) for t in np.linspace(0,math.tau,32)]
            poly(pts,145);line(pts+[pts[0]],.009)
    elif id=='root_lattice':
        for i in range(7):
            ang=i*math.tau/7;pts=[rot((.07*math.sin(t*8+i),t),ang) for t in np.linspace(.08,.72,30)]
            line(pts,.023,190)
            for j in (13,23):line([pts[j],rot((.17,j/40),ang)],.011,130)
        polygon_ring(7,.36,.2,.009)
    elif id=='seed_pod':
        arc(0,0,.25,.64);arc(0,.08,.17,.47,w=.011,fill=125)
        line([(0,-.7),(0,.63)],.012)
        for yy in (-.32,-.04,.25):arc(.035,yy,.07,.11,w=.027,fill=150)
    elif id=='feather_lift':
        stem=[(-.22+.35*t,.73-1.46*t) for t in np.linspace(0,1,40)];line(stem,.015)
        for i in range(18):
            t=i/18;xx=-.22+.35*t;yy=.73-1.46*t;width=.27*math.sin(math.pi*t)**.7
            line([(xx-width,yy+.13),(xx,yy),(xx+width,yy-.08)],.012,130+i*5)
    elif id=='tide_crest':
        for i in range(6):
            ts=np.linspace(-.8,.8,90);pts=[(t,.14*math.sin(t*4+p*.18)-.13*i+.07*i*t*t) for t in ts]
            line(pts,.022 if i==0 else .011,235-i*22)
        arc(.34,-.47,.25,.22,-math.pi*.9,math.pi*.65,.025)
    elif id=='frost_fern':
        branching((0,.69),-math.pi/2,.43,4)
        for side in (-1,1):
            for j in range(4):
                yy=.39-j*.24;line([(0,yy),(side*(.46-j*.07),yy-.12)],.01,200)
    elif id=='ice_lance':
        faceted([(0,-.85),(.20,-.45),(.27,.38),(0,.70),(-.27,.38),(-.20,-.45)])
        line([(0,-.85),(0,.70)],.022);line([(-.27,.38),(.27,.38)],.01)
    elif id=='mountain_ridge':
        for i in range(3):
            yy=.16*i;pts=[(-.8,.51-yy),(-.53,.11-yy),(-.39,.27-yy),(-.02,-.62+yy*.4),(.30,.13-yy),(.49,-.01+yy*.1),(.79,.5-yy)]
            line(pts,.035-i*.008,220-i*48)
            if i==0:poly(pts+[(-.8,.51)],50)
    elif id=='quake_wedge':
        for side in (-1,1):
            line([(0,-.04),(side*.16,.11),(side*.19,-.18),(side*.37,-.08),(side*.5,-.5),(side*.78,-.73)],.03)
            line([(side*.17,.13),(side*.34,.37),(side*.52,.30),(side*.71,.53)],.013,170)
        field=gauss(np.hypot(x,y+.05),.075)*.55
    elif id=='sand_grain':
        faceted([(-.27,-.31),(.13,-.39),(.40,-.05),(.21,.3),(-.20,.39),(-.36,.05)])
        line([(-.20,-.14),(.15,-.12),(.23,.1)],.034,100)
    elif id=='meridian_knot':
        for i in range(3):
            ts=np.linspace(0,math.tau,150);line([(.62*math.sin(t+i*math.tau/3),.57*math.sin(t*2)) for t in ts],.013,210)
        field=gauss(r,.08)*.8
    elif id=='blood_fang':
        poly([(-.15,-.77),(.31,-.39),(.27,.18),(-.09,.73),(.05,.03),(-.23,-.29)],180)
        line([(-.13,-.69),(.17,-.35),(.13,.04),(-.07,.56)],.027)
    elif id in ('fire_brush','molten_drip','bone_flare','budding_flame','sea_flame','plasma_flame','solar_prominence','nether_veil','phoenix_plume'):
        if id=='fire_brush':
            for i in range(8):
                ts=np.linspace(-.68,.70,70);line([(.15*math.sin(t*5+p)+i*.039-.15,t) for t in ts],.011+(.009 if i in (2,4) else 0),200-i*10)
            height=np.clip((.74-y)/1.47,0,1);center=.13*np.sin(height*6+p)*height
            width=.03+.28*(1-height)**.7
            field=np.clip(1-np.abs((x-center)/width),0,1)**.8*gauss(y-.05,.65)*.85
            field+=gauss(x-center,width*.25)*gauss(y-.2,.37)*.28
        elif id=='molten_drip':
            for i,cx in enumerate((-.36,0,.31)):
                yend=.37+.16*math.sin(p+i);ts=np.linspace(-.65,yend,60)
                line([(cx+.04*math.sin(t*9+p+i),t) for t in ts],.07-i*.01,185)
                field+=gauss(x-cx-.025*np.sin(y*9+p+i),.067)*np.clip((y+.72)*8,0,1)*np.clip((yend-y)*12,0,1)*.5
                field+=gauss(np.hypot(x-cx,y-yend),.10)*.95
            line([(-.42,-.66),(.45,-.53)],.045)
        elif id=='bone_flare':
            line([(0,.75),(0,-.77)],.026)
            for side in (-1,1):
                for i in range(6):
                    yy=.54-i*.19;line([(0,yy),(side*(.34-i*.035),yy-.04),(side*(.40-i*.042),yy-.18)],.024,205)
            width=.04+.24*np.clip((y+.8)/1.5,0,1)+.04*np.sin(y*26+p)
            field=gauss(x,width)*gauss(y,.62)*.60
        elif id=='budding_flame':
            for i in range(3):
                for side in (-1,1):
                    yy=.4-i*.33;cx=side*(.11+i*.03)
                    ts=np.linspace(0,math.pi,48);line([(cx+side*.20*math.sin(t),yy-.29*math.cos(t)) for t in ts],.018)
            line([(0,.75),(.05,-.78)],.022)
            for i in range(3):
                for side in (-1,1):
                    cy=.4-i*.33;cx=side*(.17+i*.03)
                    field+=gauss(np.sqrt(((x-cx)/.16)**2+((y-cy)/.27)**2),.85)*.47
            field+=gauss(x,.065)*gauss(y,.62)*.30
        elif id=='sea_flame':
            ts=np.linspace(0,math.pi*4.8,190);line([((.08+.049*t)*math.cos(t+p*.15),(.08+.041*t)*math.sin(t+p*.15)) for t in ts],.022)
            for i in range(3):arc(-.1+i*.15,-.10,.43,.57,-2.5,-.1,.010,125)
            field=gauss(np.sin(a+r*11+p*.15),.23)*gauss(r-.37,.24)*.50
            field+=gauss(r,.11)*.65
        elif id=='plasma_flame':
            for side in (-1,1):
                points=[(side*(.12+.15*math.sin(j*2.1+p)),.74-j*.135) for j in range(12)];line(points,.025)
                line([points[4],(side*.49,points[4][1]-.16),(side*.38,points[4][1]-.31)],.012,175)
            field=gauss(x-.045*np.sin(y*23+p),.13)*gauss(y,.67)*.72
        elif id=='solar_prominence':
            field=ring(.39,.030)+gauss(r,.31)*.45+gauss(r-.45,.13)*(.13+.20*np.maximum(0,np.sin(a*11+p)))
            for i in range(11):
                ang=i*math.tau/11
                line([rot((.39+.27*math.sin(t),.10*math.sin(t*2)),ang) for t in np.linspace(0,math.pi,60)],.018)
        elif id=='nether_veil':
            for i in range(7):
                xx=(i-3)*.13;ts=np.linspace(-.71,.65,60);line([(xx+.10*math.sin(t*5+p+i*.4),t) for t in ts],.029,145+i*8)
            field=gauss(x,.43)*gauss(y,.58)*(.32+.14*np.sin(y*8+p))
            field+=gauss(np.abs(x)-(.28+.10*np.sin(y*5+p)),.06)*gauss(y,.61)*.3
        elif id=='phoenix_plume':
            ts=np.linspace(-.74,.74,100);line([(.1*math.sin(t*3),t) for t in ts],.022)
            for i in range(16):
                yy=.63-i*.081;width=.37*math.sin((i+1)/18*math.pi)
                for side in (-1,1):line([(.1*math.sin(yy*3),yy),(side*width,yy-.1),(side*(width*.86),yy-.22)],.015,130+i*7)
            field=gauss(np.hypot(x,y+.44),.075)*.9
            feather_width=.07+.28*np.maximum(0,np.sin((y+.82)/1.64*math.pi))
            field+=np.clip(1-np.abs((x-.06*np.sin(y*4+p))/feather_width),0,1)*gauss(y,.67)*.62
    elif id=='iris_spokes':
        field=ring(.59,.011)+ring(.30,.018)
        for i in range(29):
            ang=i*math.tau/29;line([rot((.33,0),ang),rot((.53+.04*math.sin(i*1.7),.04),ang)],.011,190)
        field+=gauss(x,.035)*gauss(y,.19)
    elif id=='chroma_prism':
        for shift in (-.14,0,.14):
            pts=[(shift,-.71),(shift+.28,.06),(shift,.63),(shift-.28,.06),(shift,-.71)];line(pts,.015,220)
        line([(-.52,.20),(.50,-.21)],.03,200)
    elif id=='lens_crescent':
        for i in range(5):arc(.06,0,.66-i*.065,.53-i*.02,-1.60,1.60,.024 if i==0 else .011,220-i*26)
        line([(.04,-.56),(.02,.56)],.009,120)
    elif id=='mirage_frame':
        for i in range(3):
            off=(i-1)*.12;line([(-.39+off,-.63),(.39+off,-.63),(.50+off,.57),(-.31+off,.57),(-.39+off,-.63)],.019,235-i*60)
        line([(-.50,-.72),(-.61,-.60)],.021)
    elif id=='tuning_fork':
        line([(-.36,-.72),(-.36,.10),(-.17,.34),(0,.34),(.17,.34),(.36,.10),(.36,-.72)],.04)
        line([(0,.35),(0,.78)],.055);arc(0,-.35,.61,.29,math.pi,math.tau,.013,135)
    elif id=='sound_ribbon':
        for i in range(3):
            line([(t,.10*math.sin(t*15+p+i*.6)+(i-1)*.12) for t in np.linspace(-.8,.8,160)],.015,225-i*40)
    elif id=='waveform_gate':
        for i in range(19):
            xx=(i-9)*.078;h=.15+.46*(.5+.5*math.cos(i*.63+p))
            line([(xx,-h),(xx,h)],.024,155+i%4*24)
        line([(-.75,.72),(.75,.72)],.012,145)
    elif id=='echo_lozenge':
        for i in range(4):
            width=.59-i*.1;height=.36-i*.058;line([(-width,0),(0,-height),(width,0),(0,height),(-width,0)],.018,220-i*37)
        line([(-.78,0),(-.67,0)],.03);line([(.67,0),(.78,0)],.03)
    elif id=='spore_cluster':
        for i in range(11):
            ang=i*2.4;rad=.20+.035*i;cx=math.cos(ang)*rad;cy=math.sin(ang)*rad
            field+=gauss(np.hypot(x-cx,y-cy),.083+i%3*.025)*(.63+i%2*.2)
            line([(cx,cy),(cx*.62,cy*.62+.17)],.014,100)
    elif id=='venom_needle':
        poly([(0,-.82),(.11,-.08),(.22,.20),(.06,.14),(.06,.72),(-.07,.58),(-.05,.11),(-.24,.22),(-.11,-.1)],155)
        line([(0,-.7),(0,.65)],.021)
    elif id=='toxic_veins':
        for side in (-1,1):
            for j in range(3):branching((0,.5-j*.28),-math.pi/2+side*.7,.35,2,j)
        field=gauss(x,.1)*gauss(y,.60)*.3
    elif id=='scent_ribbon':
        for i in range(4):
            line([(t,.20*math.sin(t*5+p+i*.23)+(i-1.5)*.045) for t in np.linspace(-.80,.80,100)],.012,220-i*35)
        for i in range(4):arc(-.6+i*.4,.15*math.sin(i+p),.035,.035,w=.02,fill=160)
    elif id=='tongue_sickle':
        pts=[(.53,-.63),(.64,-.33),(.59,.10),(.30,.49),(-.11,.65),(-.58,.52),(-.68,.35),(-.29,.43),(.02,.30),(.24,.08),(.33,-.17)]
        poly(pts,130);line(pts+[pts[0]],.02);line([(-.56,.43),(-.15,.50),(.23,.25),(.42,-.12)],.011,230)
    elif id=='taste_curl':
        for i in range(3):
            ts=np.linspace(0,math.tau*1.6,130);line([rot(((.04+.056*t)*math.cos(t),(.04+.056*t)*math.sin(t)),i*math.tau/3) for t in ts],.013,195)
        arc(0,0,.75,.75,w=.010,fill=120)
    elif id=='acid_teardrop':
        pts=[(0,-.8),(.10,-.25),(.29,.10),(.23,.51),(0,.66),(-.26,.44),(-.22,.12),(-.07,-.31)]
        poly(pts,125);line(pts+[pts[0]],.015,200);arc(-.08,.2,.06,.18,-2.6,-.5,.031,235)
    elif id=='hunger_maw':
        arc(0,0,.7,.54,w=.029,fill=170)
        for i in range(14):
            ang=i*math.tau/14;poly([(.67*math.cos(ang-.07),.5*math.sin(ang-.07)),(.38*math.cos(ang),.30*math.sin(ang)),(.67*math.cos(ang+.07),.5*math.sin(ang+.07))],190)
    elif id=='crystal_fan':
        for i in range(5):
            ang=(i-2)*.25;pts=[rot((0,-.65),ang),rot((.12,-.21),ang),rot((.05,.61),ang),rot((-.09,.10),ang)]
            faceted(pts)
    elif id=='crystal_lotus':
        for i in range(5):
            ang=i*math.tau/5;faceted([rot((0,-.79),ang),rot((.23,-.35),ang),rot((0,-.05),ang),rot((-.23,-.35),ang)])
        polygon_ring(5,.20,-math.pi/2,.023)
    elif id=='spike_crown':
        pts=[(-.72,.44),(-.7,-.39),(-.37,.09),(-.30,-.58),(0,-.05),(.25,-.78),(.42,.07),(.75,-.35),(.66,.44)]
        faceted(pts);line([(-.61,.23),(.57,.23)],.027,210)
    elif id=='nerve_tendril':
        for i in (-1,1):line([(i*.24*math.sin(t*5+p*.5),t) for t in np.linspace(-.73,.73,120)],.019)
        for t in np.linspace(-.63,.63,7):arc(.19*math.sin(t*5),t,.038,.038,w=.015,fill=210)
    elif id=='folded_mirror':
        faceted([(-.61,-.59),(-.08,-.45),(0,.62),(-.49,.39)])
        faceted([(-.08,-.45),(.59,-.68),(.50,.43),(0,.62)])
    elif id=='memory_footprint':
        for cx,cy,ang in [(-.22,-.15,-.22),(.24,.28,.16)]:
            pts=[(cx+rot((.10*math.cos(t),.27*math.sin(t)),ang)[0],cy+rot((.10*math.cos(t),.27*math.sin(t)),ang)[1]) for t in np.linspace(0,math.tau,45)];poly(pts,160)
            arc(cx,cy+.36,.08,.10,w=.027,fill=205)
    elif id=='thought_rift':
        points=[(-.08,-.78),(.16,-.50),(-.03,-.18),(.13,.04),(-.17,.39),(.0,.80)]
        for off in (-.07,.07):line([(xx+off,yy) for xx,yy in points],.022)
        for i,(xx,yy) in enumerate(points[1:-1]):line([(xx,yy),(xx+(-1)**i*.28,yy-.05)],.011,165)
    elif id=='mind_knot':
        for i in range(4):
            ang=i*math.pi/2;pts=[rot((.55*math.sin(t),.26*math.cos(t)+.15),ang) for t in np.linspace(0,math.tau,100)];line(pts,.022,220)
        polygon_ring(4,.20,math.pi/4,.02)
    elif id=='coin_charm':
        field=ring(.62,.025)+ring(.51,.013)*.6
        line([(-.17,-.17),(.17,-.17),(.17,.17),(-.17,.17),(-.17,-.17)],.035)
        for ang in (0,math.pi/2,math.pi,math.pi*1.5):line([rot((.29,-.07),ang),rot((.43,-.07),ang),rot((.43,.07),ang),rot((.29,.07),ang)],.022,175)
    elif id=='ingot_wing':
        pts=[(0,-.24),(.79,-.59),(.56,.08),(.13,.48),(0,.35),(-.13,.48),(-.56,.08),(-.79,-.59)]
        faceted(pts);line([(-.63,-.34),(0,.15),(.63,-.34)],.017)
    elif id=='gold_stamp':
        polygon_ring(4,.78,math.pi/4,.024);polygon_ring(4,.64,math.pi/4,.011)
        for i in range(3):yy=-.29+i*.28;line([(-.31,yy),(.31,yy)],.026)
        line([(0,-.44),(0,.43)],.026);line([(-.22,-.20),(-.22,.29),(.21,.29),(.21,-.20)],.014)
    elif id=='greed_hook':
        arc(0,.13,.32,.4,-.2,math.pi*1.64,.045)
        line([(.29,.25),(.60,-.23),(.56,-.58),(.31,-.39)],.023)
        poly([(.30,.43),(.17,.30),(.18,.59)],190)
    elif id=='wine_foam':
        for i in range(16):
            ang=i*2.4;rr=.10+math.sqrt(i)*.12;cx=math.cos(ang)*rr;cy=math.sin(ang)*rr
            arc(cx,cy,.05+(i%3)*.025,.05+(i%3)*.025,w=.018,fill=135+i%4*25)
        field=gauss(r,.5)*.13
    elif id=='wine_stream':
        for i in range(5):line([(t,.17*math.sin(t*8+p)+(i-2)*.035) for t in np.linspace(-.74,.70,100)],.023,140+i*18)
        field=gauss(y-.17*np.sin(x*8+p),.09)*gauss(x,.61)*.32
    elif id=='gut_wave':
        for i in range(7):arc(0,.17,.74-i*.08,.43-i*.045,math.pi*.92,math.pi*2.08,.033,195-i*15)
        line([(-.70,.34),(-.43,.51),(.02,.56),(.46,.44),(.65,.26)],.025,150)
    elif id=='sucker_disc':
        field=gauss(np.sqrt((x/.65)**2+(y/.48)**2)-1,.045)*.7+gauss(r,.22)*.25
        for i in range(9):ang=i*math.tau/9;arc(.44*math.cos(ang),.30*math.sin(ang),.047,.047,w=.023,fill=230)
    elif id.endswith('_sigil') and id.split('_')[0] in ('metal','wood','water','fire','earth'):
        element=id.split('_')[0]
        if element=='metal':
            polygon_ring(4,.69,math.pi/4,.015)
            for ang in (0,math.pi/2,math.pi,math.pi*1.5):line([rot((0,-.49),ang),rot((.11,-.15),ang),rot((0,-.23),ang)],.025)
        elif element=='wood':branching((0,.65),-math.pi/2,.56,3);arc(0,0,.71,.71,-.2,2.7,.013)
        elif element=='water':
            for i in range(3):arc((i-1)*.13,(i-1)*.13,.46,.46,-2.5,1.1,.025)
        elif element=='fire':
            for i in range(3):
                ang=i*math.tau/3;line([rot((.05,.56),ang),rot((-.28,.16),ang),rot((.07,-.63),ang),rot((.23,-.20),ang)],.035)
        elif element=='earth':
            for i in range(3):yy=i*.16;line([(-.62,.47-yy),(0,-.64+yy),(.62,.47-yy),(-.62,.47-yy)],.021,220-i*40)
    elif id=='torn_mask':
        outline=[(-.48,-.61),(-.58,-.10),(-.37,.47),(-.12,.65),(.03,.41),(-.07,.18),(.11,-.12),(-.02,-.27),(.10,-.67)]
        poly(outline,120);line(outline+[outline[0]],.016)
        pts=[(-xx*.93,yy+.04) for xx,yy in outline];poly(pts,83);line(pts+[pts[0]],.012,170)
        line([(-.44,-.14),(-.20,-.06),(-.13,-.17)],.035);line([(.17,-.13),(.34,-.07),(.48,-.22)],.026)
        line([(-.19,.38),(.06,.31),(.26,.40)],.012,225)
    elif id=='karma_petal':
        pts=[(0,-.78),(.32,-.32),(.22,.32),(-.07,.60),(-.39,.26),(-.24,-.12)]
        poly(pts,85);line(pts+[pts[0]],.021)
        line([(-.07,.53),(.08,.09),(-.11,-.19),(.0,-.70)],.023)
        line([(.08,.09),(.31,-.26)],.01,150)
    elif id=='heart_fissure':
        line([(-.07,-.47),(-.44,-.60),(-.64,-.31),(-.52,.05),(0,.65),(.49,.10),(.64,-.26),(.45,-.60),(.19,-.50)],.025)
        line([(.11,-.71),(-.13,-.28),(.14,-.05),(-.07,.29),(.06,.49)],.039)
    elif id=='delusion_eye':
        line([(0,-.75),(-.42,-.19),(-.25,.38),(0,.75),(.31,.36),(.43,-.21),(0,-.75)],.021)
        arc(0,0,.16,.39,w=.024);line([(0,-.28),(0,.28)],.033)
        for side in (-1,1):line([(side*.36,-.04),(side*.65,-.23),(side*.53,-.47)],.014,160)
    elif id=='chain_barb':
        arc(0,0,.20,.49,w=.036,fill=190)
        for side in (-1,1):poly([(side*.16,-.19),(side*.44,-.44),(side*.21,.10)],150)
        line([(-.28,.60),(.21,.38)],.024)
    elif id=='giant_halo':
        arc(0,.10,.70,.67,math.pi*.94,math.pi*2.06,.019)
        for side in (-1,1):
            arc(side*.42,.1,.29,.38,w=.024);line([(side*.72,.26),(side*.63,.56),(side*.31,.73)],.025)
        polygon_ring(6,.22,0,.018)
    elif id=='dipper_thread':
        pts=[(-.69,-.4),(-.28,-.60),(-.13,-.20),(-.48,.04),(.03,.17),(.37,.40),(.7,.57)]
        line(pts,.018,170)
        for j,(cx,cy) in enumerate(pts):
            arc(cx,cy,.055,.055,w=.018);field+=gauss(np.hypot(x-cx,y-cy),.073)*(.55+.3*math.sin(p-j*.6))
        arc(.0,.05,.79,.68,-1.8,1.2,.009,95)
    elif id=='astral_body':
        arc(0,-.50,.17,.20,w=.015)
        for side in (-1,1):line([(side*.11,-.24),(side*.39,-.1),(side*.55,.35),(side*.30,.26),(side*.20,.67)],.023)
        line([(-.20,.67),(0,.42),(.20,.67)],.014);field=gauss(x,.20)*gauss(y-.02,.30)*.22
        arc(0,-.05,.08,.12,w=.017)
    elif id=='yin_yang_clock':
        field=ring(.68,.018)+ring(.76,.008)*.6
        arc(0,-.33,.33,.33,-math.pi/2,math.pi/2,.025);arc(0,.33,.33,.33,math.pi/2,3*math.pi/2,.025)
        arc(0,-.33,.055,.055,w=.035);arc(0,.33,.055,.055,w=.014)
        for i in range(12):ang=i*math.pi/6;line([rot((.70,0),ang),rot((.75,0),ang)],.021)
    elif id=='ruyi_cloud':
        for cx,cy,rx,ry in [(-.35,.05,.32,.25),(0,-.22,.33,.37),(.35,.07,.31,.25)]:arc(cx,cy,rx,ry,math.pi*.8,math.pi*2.7,.029,190)
        line([(-.64,.22),(-.3,.41),(.20,.37),(.67,.25)],.023,180)
        arc(.02,-.10,.13,.20,-1.5,2.4,.017,140)
    elif id=='furnace_breath':
        for side in (-1,1):
            line([(side*(.16+.18*math.sin(t*5+p)),t) for t in np.linspace(-.67,.70,120)],.027,215)
        for i in range(3):arc(0,.34-i*.36,.46-i*.07,.10,-math.pi*.1,math.pi*1.1,.014,140)
    elif id=='pill_orbit':
        field=ring(.32,.024)+gauss(r,.28)*.14
        for ang in (0,math.pi/3,-math.pi/3):line([rot((.73*math.cos(t),.17*math.sin(t)),ang) for t in np.linspace(0,math.tau,100)],.014,185)
        arc(.29,-.50,.057,.057,w=.025)
    elif id=='forge_stitch':
        line([(-.70,-.19),(.70,.19)],.016)
        for i in range(7):
            xx=-.6+i*.2;yy=xx*.27;line([(xx-.11,yy+.23),(xx+.11,yy-.23)],.021)
    elif id=='unweave_thread':
        for i in range(5):
            xx=(i-2)*.11;line([(xx-.15,-.7),(xx+.08,-.33),(xx-.02,-.09)],.017,160+i*17)
            line([(xx+.13,.08),(xx-.06,.37),(xx+.20,.67)],.012,135+i*20)
    else:raise ValueError(id)
    mask=np.maximum(np.array(im,dtype=np.float32)/255,field)
    mask+=np.array(im.filter(ImageFilter.GaussianBlur(size/150)),dtype=np.float32)/255*.15
    mode=DEFS[id][3]
    # Temporal reveal / travelling highlight adds motion inside each distinct drawing.
    if mode=='loop':mask*=.77+.23*np.cos(p-y*4-x*3)
    elif mode=='once':mask*=.38+.62*np.clip((.22+phase*1.5-r)*7,0,1)
    gutter=np.clip((.91-np.maximum(np.abs(x),np.abs(y)))/.07,0,1)
    result=np.full((size,size,4),255,dtype=np.uint8);result[:,:,3]=np.uint8(np.clip(mask*gutter,0,1)*255)
    return Image.fromarray(result)
