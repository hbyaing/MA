"""Build art-directed individual skill presets; keep the V1 artifact intact for comparison."""
import argparse,copy,csv,hashlib,json,math,shutil,zipfile
from collections import Counter,defaultdict
from pathlib import Path
from catalog import ROOT,extract
from design_v2 import MATERIALS,PALETTES,individual_recipe
from motion import attach_paths
from textures import build_textures
from build import write_json


def diversity(entries,recipes,old):
    def measure(es,rs):
        rs={r['id']:r for r in rs};shape_sets=[];programs=[];usage=Counter();leading=Counter()
        for e in es:
            layers=copy.deepcopy(rs[e['design']['recipe']]['layers']);overrides=e['design'].get('materialOverrides',{})
            for l in layers:l['material']=overrides.get(l['material'],l['material']);usage[l['material']]+=1
            leading[layers[0]['material']]+=1
            shape_sets.append(tuple(sorted({l['material'] for l in layers})))
            # Exclude names, colours, recipe IDs and sampled floating-point paths.
            programs.append(json.dumps([{k:v for k,v in l.items() if k not in ('colorRole','role','paths')} for l in layers],sort_keys=True))
        return dict(entries=len(es),distinctMaterialSets=len(set(shape_sets)),repeatedMaterialSets=len(es)-len(set(shape_sets)),distinctChoreographies=len(set(programs)),repeatedChoreographies=len(es)-len(set(programs)),topMaterialUsage=usage.most_common(12),topLeadingMotifs=leading.most_common(12))
    previous=json.loads((old/'catalog/skills.json').read_text('utf-8'))
    return dict(before=measure(previous['entries'],json.loads((old/'catalog/recipes.json').read_text('utf-8'))),after=measure(entries,recipes),
        methodology='按当前139项逐项计数；纹样集合忽略顺序、颜色和参数；动作签名忽略ID、名称、颜色与采样路径。统计不能代替审美判断。')


def build(out):
    out.mkdir(parents=True,exist_ok=True);data=extract();palettes=copy.deepcopy(PALETTES)
    for e in data['entries']:
        if e['category']=='异火素材':
            colors=e['facts']['colors'];palettes[e['id']]=[e['name'],colors['bodyColor'],colors['coreColor'],colors['edgeColor']]
    recipes=[]
    for e in data['entries']:
        recipe=attach_paths(individual_recipe(e));recipes.append(recipe)
        e['design']=dict(recipe=recipe['id'],palette=recipe['defaultPalette'],materialOverrides={},artDirection=recipe['artDirection'],
            basis='V2逐技能独立构图，主形、次形和余韵分层；所有美术参数为设计值。',
            binding='对照真实子攻击落点接入；示例时间线只展示美术节奏。' if e['category']=='Boss' else '绑定对应释放、生效及取消事件。')
    counts=dict(Counter(e['category'] for e in data['entries']));data['counts']=counts
    report=diversity(data['entries'],recipes,ROOT/'source-assets/skill-particle-library-v1')
    write_json(out/'catalog/diversity.json',report)
    write_json(out/'catalog/skills.json',data);write_json(out/'catalog/palettes.json',palettes);write_json(out/'catalog/recipes.json',recipes)
    materials=build_textures(out,MATERIALS,data['glyphs']);write_json(out/'catalog/materials.json',materials)
    for recipe in recipes:write_json(out/'recipes'/(recipe['id']+'.json'),recipe)
    write_json(out/'resourcepack/pack.mcmeta',{'pack':{'pack_format':15,'description':'五行仙途 · 技能粒子库 V2 / 逐技能纹样与轨迹'}})
    from photon import export
    exports=export(out,materials,recipes,palettes)
    with (out/'catalog/skills.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['ID','名称','分类','Boss','美术方向','配方','主纹样','源码','行'])
        for e,r in zip(data['entries'],recipes):w.writerow([e['id'],e['name'],e['category'],e['facts'].get('bossName',''),r['artDirection'],r['id'],','.join(l['material'] for l in r['layers']),e['source']['path'],e['source']['line']])
    model=dict(version='2.0.0',entries=data['entries'],counts=counts,materials=materials,recipes=recipes,palettes=palettes,diversity=report)
    (out/'preview/library-data.js').write_text('window.VFX_LIBRARY='+json.dumps(model,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+';\n','utf-8')
    template=(Path(__file__).parent/'preview.html').read_text('utf-8')
    # V2 retains the familiar layout, with a separate updated player and dynamic counts.
    start=template.index('<script>');end=template.index('</script>',start)
    template=template[:start]+'<script src="player-v2.js"></script>'+template[end+9:]
    template=template.replace('<b>60</b>','<b id="nMaterials">138</b>').replace('<b>32</b>','<b id="nRecipes">139</b>').replace('<b>V1</b>','<b>V2</b>')
    template=template.replace('粒子工坊</title>','粒子工坊 V2</title>')
    template=template.replace('<div class="section-title">配方使用材质', '<div class="section-title"><div>分层检查 <button id="isolate">全部层</button> <button id="grayscale">灰度对照</button></div><span>查看独立纹样 / 排除换色影响</span></div><div class="section-title">配方使用材质')
    (out/'preview/index.html').write_text(template,'utf-8')
    shutil.copyfile(Path(__file__).parent/'player-v2.js',out/'preview/player-v2.js')
    make_docs(out,data,materials,recipes,report)
    files={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ('manifest.json','validation.json')}
    manifest=dict(schemaVersion=2,name='五行仙途技能粒子库',version='2.0.0',sourceDate='2026-09-29',counts=dict(entries=len(data['entries']),materials=len(materials),addedMaterials=len(materials)-60,animated=sum(m['frames']>1 for m in materials),recipes=len(recipes),photonSamples=len(exports)),verification=dict(sourceExtracted=True,nativeNbtRoundtrip=True,minecraftRendered=False,productionIntegrated=False),files=files)
    write_json(out/'manifest.json',manifest);return manifest


def make_docs(out,data,mats,recipes,report):
    (out/'README.md').write_text(f'''# 五行仙途 · 技能粒子库 V2

本版解决V1的整套配方重复和主纹样滥用。沿用源码139项，改为139套逐项编排的材质、主次层和时间线。基础材质由60种增加到{len(mats)}种，新增{len(mats)-60}种；动画材质{sum(m['frames']>1 for m in mats)}种，每组16帧。完整程序化生成器随包放在generator，重建需要原工程src。

## 使用

- `preview/index.html` 双击打开：搜索技能、换色、播放、拖动、导出配方；新增“主形/次形/余韵”隔离和灰度对照。可以不依赖颜色判断技能差异。
- `recipes/` 每个ID一份完整配方，含主次角色、颜色角色、错峰延迟及归一化路径采样。`catalog/diversity.json` 为V1/V2重复统计。
- `resourcepack/` 为Minecraft 1.20.1格式15资源包。透明材质256×256，动画4×4共16帧，每帧128×128。白色straight-alpha，按行播放。
- `photon/projects/recipes__技能ID.fxproj` 为该技能的Photon可编辑样片；`materials__材质ID.fxproj` 为单材质样片。每个项目内有完整材质库。
- Photon 1.1.17 / LDLib 1.0.42：启用随附资源包后打开项目。运行资源ID如`wuxingxiantu_vfx:recipes/ermei_05`。V2与V1沿用材质命名空间，制作时建议只启用当前版本。

## 差异化重点

目魇用虹瞳、透镜与棱光；耳魅用声叉、频谱墙与回声梭；鼻嗔用毒针、孢簇与香带；舌饕用舌镰、饕口与垂酸；身淫用晶须、刺冠与神经丝；意惑用折镜、旧影足迹与心结；彭倨用古钱、金翅与方印；彭质用酒带、腹褶与吸盘；彭矫有五种独立核纹；心魔用残面、妄瞳、倒刺链与裂心。

九种异火各有独立主形：赤流焰锋、熔金液脉、枯骨寒焰、木芽青焰、碧海涡焰、紫霄电焰、日珥、冥火幽帷、涅槃凤翎。功法按剑意、生长、护壳、身法等划分；心法保留低密度修炼表现。共同火花仅作次要点缀。

## 数据与验证边界

V1最频繁的魂丝用于40项；V2最高频材质用于{report['after']['topMaterialUsage'][0][1]}项。忽略颜色、顺序和参数后，独立纹样集合{report['before']['distinctMaterialSets']}→{report['after']['distinctMaterialSets']}；忽略ID和颜色的动作组合{report['before']['distinctChoreographies']}→{report['after']['distinctChoreographies']}。这些数字只是复用检查，不代表审美评分。

预览与Photon样片读取同一套采样路径。Photon为每条曲线建立独立粒子发射器，使用现有原生字段导出位置、速度、大小、旋转和阶段颜色；复杂配方抽样到不超过32个发射器。曲线速度为离散导数，原生引擎积分与Billboard朝向可能使画面与浏览器有差异。地面压扁图、墙与束仍是选材构图，实际三维技能需对应模型、平面、Beam/Trail或实体接入。

完成PNG透明边界、动画帧、路径有限值、素材引用、NBT读回和浏览器检查。**本轮未加载Minecraft、未做游戏内播放和性能测试，未修改生产技能或伤害判定。** Boss真实前摇和多段判定仍以源码为准，样片时间线是美术设计值。V1目录与原ZIP保留。

## 重建

`python tools/vfx_library/build_v2.py --package`；`python tools/vfx_library/validate.py source-assets/skill-particle-library-v2`；浏览器验证使用`check_preview_v2.cjs`。依赖见generator/requirements.txt。不要在生成目录保存唯一的手工修改。
''',encoding='utf-8')
    lines=['# V2 逐技能美术设计','','| 技能 | 主次纹样 | 构图与节奏 |','|---|---|---|']
    for e,r in zip(data['entries'],recipes):lines.append(f"| {e['facts'].get('bossName','')}{e['name']} `{e['id']}` | {'、'.join(l['material'] for l in r['layers'])} | {r['artDirection']} |")
    (out/'catalog/逐技能美术设计.md').write_text('\n'.join(lines)+'\n','utf-8')


def package(out):
    from validate import validate
    validate(out)
    for name,base in [('wuxingxiantu-skill-particle-library-v2.zip',out),('wuxingxiantu-vfx-resourcepack-v2.zip',out/'resourcepack')]:
        with zipfile.ZipFile(ROOT/'deliverables'/name,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p in sorted(base.rglob('*')):
                if p.is_file():z.write(p,p.relative_to(base))
            if base==out:
                for p in sorted(Path(__file__).parent.iterdir()):
                    if p.is_file():z.write(p,Path('generator')/p.name)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'source-assets/skill-particle-library-v2');parser.add_argument('--package',action='store_true');args=parser.parse_args()
    print(json.dumps(build(args.output)['counts'],ensure_ascii=False))
    if args.package:package(args.output)
