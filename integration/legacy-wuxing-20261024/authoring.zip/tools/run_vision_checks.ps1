$ErrorActionPreference = 'Stop'
$reportName = 'ui-vision-layout-20261007'
& (Join-Path $PSScriptRoot 'run_ui_reference_build.ps1') -ReportName $reportName
$reportRoot = Join-Path (Split-Path $PSScriptRoot -Parent) ('reports/' + $reportName)
if ((Get-Content -LiteralPath (Join-Path $reportRoot 'build.exit')).Trim() -eq '0') {
    & (Join-Path $PSScriptRoot 'run_ui_reference_build.ps1') -DomainTests -ReportName $reportName
}
