"""Normalize registered spirit-plant textures to 32x32 and remap cropped block-model UVs."""
from pathlib import Path
import json
import re
import shutil
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/main/resources/assets/wuxingxiantu'
OUT = ROOT / 'source-assets/spirit-textures-32-20261008'
OUT.mkdir(parents=True, exist_ok=True)
catalog = (ROOT/'src/main/java/cn/blockforge/generated/generatedmod/plants/SpiritPlantCatalog.java').read_text(encoding='utf-8')
plants = set(re.findall(r'\.builder\("([a-z_]+)"', catalog))
assert len(plants) == 14
targets = plants | {'gold_marrow', 'wood_seed', 'water_pearl', 'fire_flame', 'earth_core'} | {
    f'{grade}_{base}' for grade in ['low','mid','high','perfect']
    for base in ['gold_marrow','wood_seed','water_pearl','fire_flame','earth_core']}
models = {}
for path in (ASSETS/'models/block').glob('*.json'):
    model = json.loads(path.read_text(encoding='utf-8'))
    cross = model.get('textures', {}).get('cross', '')
    if cross.startswith('wuxingxiantu:block/'):
        models.setdefault(cross.split('/')[-1], []).append((path, model))
manifest = {}
for kind in ['block', 'item']:
    for path in sorted((ASSETS/f'textures/{kind}').glob('*.png')):
        if not any(path.stem == name or path.stem.startswith(name+'_') for name in targets):
            continue
        original = Image.open(path).convert('RGBA')
        if original.size == (32, 32):
            continue
        backup = OUT/'before'/kind/path.name
        backup.parent.mkdir(parents=True, exist_ok=True)
        if not backup.exists(): shutil.copy2(path, backup)
        if max(original.size) <= 32:
            # Existing low-resolution sprites retain their full canvas and UV mapping.
            tile = original.resize((32, 32), Image.Resampling.NEAREST)
            bounds = (0, 0, original.width, original.height)
        else:
            bounds = original.getchannel('A').point(lambda a: 255 if a >= 128 else 0).getbbox()
            assert bounds is not None, path
            if kind == 'block' and models.get(path.stem):
                first = models[path.stem][0][1]
                faces = [f for e in first.get('elements', []) for f in e.get('faces', {}).values() if 'uv' in f]
                if faces:
                    uv = faces[0]['uv']
                    bounds = (round(min(uv[0],uv[2])*original.width/16),
                              round(min(uv[1],uv[3])*original.height/16),
                              round(max(uv[0],uv[2])*original.width/16),
                              round(max(uv[1],uv[3])*original.height/16))
            crop = original.crop(bounds)
            crop.thumbnail((30, 30), Image.Resampling.NEAREST)
            tile = Image.new('RGBA', (32, 32))
            x = (32-crop.width)//2
            y = 32-crop.height if kind == 'block' else (32-crop.height)//2
            tile.paste(crop, (x,y))
            if kind == 'block':
                for model_path, model in models.get(path.stem, []):
                    saved = OUT/'before/models'/model_path.name
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    if not saved.exists(): shutil.copy2(model_path, saved)
                    for element in model.get('elements', []):
                        for face in element.get('faces', {}).values():
                            uv = face.get('uv', [0,0,16,16])
                            left,right = x/2,(x+crop.width)/2
                            top,bottom = y/2,(y+crop.height)/2
                            if uv[0] > uv[2]: left,right = right,left
                            if uv[1] > uv[3]: top,bottom = bottom,top
                            face['uv'] = [left,top,right,bottom]
                    model_path.write_text(json.dumps(model,indent=2)+'\n',encoding='utf-8')
        tile.save(path)
        assert Image.open(path).size == (32,32)
        manifest[f'{kind}/{path.name}'] = {'previous_size': original.size, 'source_bounds': bounds, 'size': [32,32]}
prior = OUT/'manifest.json'
records = json.loads(prior.read_text()) if prior.exists() else {}
records.update(manifest)
prior.write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
print(f'Normalized {len(manifest)} textures; originals and old UVs retained in {OUT}')
