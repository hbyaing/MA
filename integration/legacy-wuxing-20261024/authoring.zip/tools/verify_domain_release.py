"""Verify combined domain/UI/guard delivery without replacing historical reports."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json, sys

root = Path(__file__).resolve().parents[1]
source, installed = map(Path, sys.argv[1:3])
digest = lambda p: sha256(p.read_bytes()).hexdigest().upper()
assert digest(source) == digest(installed)
classes = ('balance/DamageDomainBalance', 'combat/DomainDamageSource', 'client/DomainTooltips',
           'client/SpiritShieldRenderer', 'client/SpiritGuardArmorRenderer', 'client/XuanlingAnvilScreen')
with ZipFile(installed) as jar:
    names = jar.namelist()
    for name in classes:
        assert 'cn/blockforge/generated/generatedmod/' + name + '.class' in names, name
    for token in ('DomainUiCapture', 'CloudGlyphClientCapture', 'ShieldShatterCapture',
                  'SwordTrailClientCapture', 'GameTests', 'Regression'):
        assert not any(token in n and n.endswith('.class') for n in names), token
    checked = []
    for folder in ('assets/wuxingxiantu/shaders/core', 'assets/wuxingxiantu/textures/effect'):
        for path in (root / 'src/main/resources' / folder).glob('spirit_*'):
            if path.is_file():
                relative = path.relative_to(root / 'src/main/resources').as_posix()
                assert jar.read(relative) == path.read_bytes(), relative
                checked.append(relative)
ui_path = root / 'reports/domain-ui-client/captures.json'
ui = json.loads(ui_path.read_text(encoding='utf-8'))
assert not ui['failures'] and len(ui['captures']) == 9
assert all(row['glError'] == 0 for row in ui['captures'])
rows = {row['name']: row for row in ui['captures']}
assert '异火领域' in rows['exotic']['text']
assert rows['fire-buffed']['attack'] > rows['fire']['attack']
tiers_path = root / 'reports/guard-tier-color-20261013/runtime-validation.json'
tiers = json.loads(tiers_path.read_text(encoding='utf-8-sig'))
assert tiers.get('passed') or tiers.get('all_required_capture_checks_passed') or tiers.get('result') == 'PASS'
config = installed.parent.parent / 'config/wuxingxiantu-flight-client.toml'
assert 'trails = true' in config.read_text(encoding='utf-8')
report = dict(passed=True, sha256=digest(installed), installed=str(installed),
              resource_bytes_match_source=checked, production_classes=list(classes),
              test_fixtures_absent=True, protocol='76', flight_trails_enabled=True,
              ui_capture_sha256=digest(ui_path), tier_validation_sha256=digest(tiers_path))
if len(sys.argv)>3:
    guard_path=root / 'reports/cloud-glyph-client/captures.json'
    guard=json.loads(guard_path.read_text(encoding='utf-8-sig'))
    assert not guard['failures'] and guard['captureCount']==39
    active=[r for r in guard['captures'] if r['worldDraws']+r['guiDraws']>0]
    assert active and all(r['nativeFoilVertices']>0 and r['glError']==0 for r in active)
    anvil_path=root / 'reports/anvil-blue-ui-client/captures.json'
    anvil=json.loads(anvil_path.read_text(encoding='utf-8-sig'))
    assert not anvil['failures'] and len(anvil['captures'])==4
    assert all(r['glError']==0 for r in anvil['captures'])
    assert anvil['captures'][1]['result']=='玄灵剑' and anvil['captures'][2]['mayPickup']
    assert not anvil['captures'][3]['mayPickup']
    report.update(guard_native_foil_coexistence_frames=len(active),guard_capture_sha256=digest(guard_path),
                  anvil_capture_sha256=digest(anvil_path),anvil_native_rename_and_mana_gate=True)
report_path=Path(sys.argv[3]) if len(sys.argv)>3 else root / 'reports/domain-balance-20261013/installed-verification.json'
report_path.write_text(
    json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
