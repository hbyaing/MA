"""Copy only the selected V2 material PNGs, without editing art or modifying historical library exports."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
java = ROOT / 'src/main/java/cn/blockforge/generated/generatedmod/arts/ArtVfxCatalog.java'
text = java.read_text('utf-8')
materials = set(re.findall(r'new Recipe\("([^\"]+)", "([^\"]+)", "([^\"]+)"', text))
ids = {part for row in materials for part in row}
ids.update(['metal_sigil', 'wood_sigil', 'water_sigil', 'fire_sigil', 'earth_sigil'])
library = ROOT / 'source-assets/skill-particle-library-v2/resourcepack/assets/wuxingxiantu_vfx/textures/library'
assets = ROOT / 'src/main/resources/assets/wuxingxiantu'
(assets / 'textures/particle/arts').mkdir(parents=True, exist_ok=True)
entries = []
for name in sorted(ids):
    source = library / (name + '.png')
    data = source.read_bytes()
    target = assets / 'textures/particle/arts' / source.name
    target.write_bytes(data)
    (assets / 'particles' / ('art_' + name + '.json')).write_text(
        json.dumps({'textures': ['wuxingxiantu:arts/' + name]}) + '\n', 'utf-8')
    entries.append({'material': name, 'source': source.relative_to(ROOT).as_posix(),
                    'runtime': target.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest()})
contract = ROOT / 'source-assets/contracts/art_particle_library.json'
contract.write_text(json.dumps({'version': 1, 'origin': 'skill-particle-library-v2',
    'runtime': 'Static source PNGs; phase movement and fading animated by ArtVisualEffects',
    'materials': entries}, ensure_ascii=False, indent=2) + '\n', 'utf-8')
print(f'Imported {len(ids)} selected V2 materials, byte-for-byte; wrote runtime atlas definitions.')
