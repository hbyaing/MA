$env:JAVA_HOME='C:\tmp\temurin17\jdk-17.0.20.1+1'
$env:PATH="$env:JAVA_HOME\bin;$env:PATH"
$env:TEMP='C:\gradle-tmp';$env:TMP='C:\gradle-tmp'
Set-Location -LiteralPath (Split-Path $PSScriptRoot -Parent)
& .\gradlew.bat --offline '-Dorg.gradle.java.home=C:\tmp\temurin17\jdk-17.0.20.1+1' '-Dorg.gradle.jvmargs=-Xmx3G -Dfile.encoding=UTF-8 -Djava.io.tmpdir=C:\gradle-tmp' compileJava *> 'reports/spirit-guard-compile-20261011.log'
$LASTEXITCODE | Set-Content 'reports/spirit-guard-compile-20261011.exit'
