"""Verify the current performance/UI artifact against real client/server evidence."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json, math, statistics, sys

root = Path(__file__).resolve().parents[1]
report_dir = root / 'reports/performance-20261014'
source = Path(sys.argv[1]).resolve()
installed = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else None
digest = lambda p: sha256(p.read_bytes()).hexdigest().upper()
if installed is not None:
    assert digest(source) == digest(installed), 'Installed JAR differs from validated artifact'
with ZipFile(source) as jar:
    names = jar.namelist()
    for name in ('AnvilTemplateMemory', 'balance/ManaLossLedger',
                 'network/packet/cultivation/ManaLossTogglePacket', 'client/AlchemyPreviewRenderer',
                 'client/furnacevolume/FireCornerCache', 'client/furnacevolume/VolumeGpu',
                 'client/JindouCloudTrailCache', 'client/anvillight/AnvilRuneEmission'):
        assert 'cn/blockforge/generated/generatedmod/' + name + '.class' in names, name
    assert not any(n.endswith('.class') and any(t in n for t in
        ('GameTests', 'ClientCapture', 'DomainUiCapture', 'Regression', 'VolumePerformanceProbe', 'BaselineHostScan', 'FireHashCache')) for n in names)
    resources = root / 'src/main/resources'
    checked = 0
    for file in resources.rglob('*'):
        if file.is_file():
            rel = file.relative_to(resources).as_posix()
            expected = root / 'build/resources/main' / rel if rel == 'META-INF/mods.toml' else file
            assert jar.read(rel) == expected.read_bytes(), rel
            checked += 1
    for name in ('recipe.json', 'nine-flames.json'):
        assert jar.read('assets/wuxingxiantu/shaders/furnacevolume/' + name) == (report_dir/'baseline'/name).read_bytes(), 'Fire quality/palette changed: ' + name
    assert b'\x00\x0278' in jar.read('cn/blockforge/generated/generatedmod/network/NetworkChannel.class'), 'Protocol must be 78'

captures = {}
for folder, count in {'native':11, 'solas':11, 'ui':14, 'anvil-native':9,
                       'anvil-solas':9, 'cloud-native':14, 'cloud-solas':14}.items():
    report = json.loads((report_dir/folder/'captures.json').read_text(encoding='utf-8-sig'))
    assert not report['failures'], (folder, report['failures'])
    assert len(report['captures']) == count, (folder, len(report['captures']))
    for row in report['captures']:
        assert row.get('glError', 0) == 0, (folder, row)
        if folder.startswith('anvil-') and 'runeDraws' in row:
            assert row['runeDraws'] > 0, (folder, row)
        if folder in ('native', 'solas'):
            assert row['bottomVolumeDraws'] > 0, (folder, row)
    if folder.startswith('cloud-'):
        motion = report['cloudMotionValidation']
        assert motion['travelBlocks'] > 1000 and motion['observedFrames'] > 30
        assert motion['continuousFastHistoryFrames'] >= 10 and motion['teleportCleared']
        assert motion['maxAnchorError'] == 0 and motion['maxFutureSampleTicks'] <= 0
        assert motion['renderOriginXMax'] - motion['renderOriginXMin'] >= 256
    if folder == 'ui':
        by_name = {row['name']: row for row in report['captures']}
        assert not by_name['alchemy-preview-grey']['hasResult']
        assert by_name['alchemy-complete']['hasResult']
        assert not by_name['alchemy-collected']['hasResult']
    captures[folder] = count

performance = {}
for folder, file in [('native', report_dir/'paired-gpu.json'), ('solas', report_dir/'solas/paired-gpu.json')]:
    cases = json.loads(file.read_text(encoding='utf-8-sig'))['cases']
    assert len(cases) == 9 and len({r['fire'] for r in cases}) == 9
    for row in cases:
        assert row['samplesPerVersion'] == 24 and row['activeChannels'] > 0
        assert row['maxFloatError'] < 1e-5 and row['glError'] == 0, row
        assert all(math.isfinite(row[k]) for k in ('baselineGpuMs', 'optimizedGpuMs', 'rmse'))
        assert row['optimizedGpuMs'] < row['baselineGpuMs'], row
    performance[folder] = dict(cases=9, medianSavedPercent=statistics.median((1-r['optimizedGpuMs']/r['baselineGpuMs'])*100 for r in cases), maxFloatError=max(r['maxFloatError'] for r in cases))
server = (report_dir/'server-tests.log').read_text(errors='replace')
assert 'All 197 required tests passed' in server
assert 'BUILD SUCCESSFUL' in (report_dir/'build.log').read_text(errors='replace')
result = dict(source=str(source), installed=str(installed) if installed else None,
              sha256=digest(source), protocol=78, resourcesVerified=checked,
              serverTests=197, captures=captures, performance=performance)
(report_dir/('installed-verification.json' if installed else 'artifact-verification.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
