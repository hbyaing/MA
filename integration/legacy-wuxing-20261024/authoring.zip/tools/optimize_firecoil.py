from pathlib import Path
p=Path('E:/五行仙途/src/main/java/cn/blockforge/generated/generatedmod/client/firecoil/VolumeGpu.java')
s=p.read_text('utf-8')
s=s.replace('static double coverage,cpuMs;','static double coverage,cpuMs;\n static int lowFbo,lowTexture,lowWidth,lowHeight,composite;\n static double renderScale=.5;')
s=s.replace('width=main.width;height=main.height;','width=main.width;height=main.height;\n  lowWidth=Math.max(1,(int)Math.ceil(width*renderScale));lowHeight=Math.max(1,(int)Math.ceil(height*renderScale));\n  lowTexture=GlStateManager._genTexture();GlStateManager._bindTexture(lowTexture);GL11.glTexImage2D(GL11.GL_TEXTURE_2D,0,GL30.GL_RGBA16F,lowWidth,lowHeight,0,GL11.GL_RGBA,GL11.GL_FLOAT,(java.nio.ByteBuffer)null);GL11.glTexParameteri(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_MIN_FILTER,GL11.GL_LINEAR);GL11.glTexParameteri(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_MAG_FILTER,GL11.GL_LINEAR);GL11.glTexParameteri(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_WRAP_S,GL12.GL_CLAMP_TO_EDGE);GL11.glTexParameteri(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_WRAP_T,GL12.GL_CLAMP_TO_EDGE);lowFbo=GL30.glGenFramebuffers();GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER,lowFbo);GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER,GL30.GL_COLOR_ATTACHMENT0,GL11.GL_TEXTURE_2D,lowTexture,0);if(GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER)!=GL30.GL_FRAMEBUFFER_COMPLETE)throw new IllegalStateException("Incomplete fire-coil volume target");')
# Only the costly integration uses scaled coordinates. Keep full scene depth separate.
s=s.replace('GL20.glUniform2f(loc("Viewport"),width,height);','beginVolume();GL20.glUniform2f(loc("Viewport"),lowWidth,lowHeight);')
s=s.replace('GL11.glDrawArrays(GL11.GL_TRIANGLES,0,3);draws=1;', 'GL11.glDrawArrays(GL11.GL_TRIANGLES,0,3);finishVolume(main);draws=1;')
s=s.replace('GL11.glDrawArrays(GL11.GL_TRIANGLES,0,3);lastGl=', 'GL11.glDrawArrays(GL11.GL_TRIANGLES,0,3);finishVolume(main);lastGl=')
s=s.replace('private static void freeTargets(){','private static void freeTargets(){if(lowTexture!=0)GlStateManager._deleteTexture(lowTexture);if(lowFbo!=0)GL30.glDeleteFramebuffers(lowFbo);lowTexture=lowFbo=0;')
s=s.replace('program=vao=0;UNIFORMS.clear();','if(composite!=0)GL20.glDeleteProgram(composite);composite=0;program=vao=0;UNIFORMS.clear();')
s=s.replace('final int texture;','final int texture,texture1;')
s=s.replace('texture=GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);GlStateManager._activeTexture(active);','texture=GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);GlStateManager._activeTexture(GL13.GL_TEXTURE1);texture1=GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);GlStateManager._activeTexture(active);')
s=s.replace('GlStateManager._bindTexture(texture);GlStateManager._activeTexture(active);','GlStateManager._bindTexture(texture);GlStateManager._activeTexture(GL13.GL_TEXTURE1);GlStateManager._bindTexture(texture1);GlStateManager._activeTexture(active);')
at=s.index(' private static final class State')
s=s[:at]+''' private static void beginVolume(){
  int[] box=new int[4];GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX,box);boolean clipped=GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
  GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER,lowFbo);RenderSystem.viewport(0,0,lowWidth,lowHeight);GL11.glDisable(GL11.GL_SCISSOR_TEST);
  GL30.glClearBufferfv(GL11.GL_COLOR,0,new float[]{0,0,0,0});RenderSystem.disableBlend();
  if(clipped){GL11.glEnable(GL11.GL_SCISSOR_TEST);int x=Math.max(0,box[0]*lowWidth/width-2),y=Math.max(0,box[1]*lowHeight/height-2);GL11.glScissor(x,y,Math.min(lowWidth-x,(box[2]+3)*lowWidth/width+4),Math.min(lowHeight-y,(box[3]+3)*lowHeight/height+4));}
 }
 private static void finishVolume(com.mojang.blaze3d.pipeline.RenderTarget main)throws Exception{
  if(composite==0){int v=shader(GL20.GL_VERTEX_SHADER,VERTEX),f=shader(GL20.GL_FRAGMENT_SHADER,resource("composite.fsh"));int p=GL20.glCreateProgram();try{GL20.glAttachShader(p,v);GL20.glAttachShader(p,f);GL30.glBindFragDataLocation(p,0,"result");GL20.glLinkProgram(p);if(GL20.glGetProgrami(p,GL20.GL_LINK_STATUS)==0)throw new IllegalStateException(GL20.glGetProgramInfoLog(p));composite=p;}catch(Exception ex){GL20.glDeleteProgram(p);throw ex;}finally{GL20.glDeleteShader(v);GL20.glDeleteShader(f);}}
  GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER,main.frameBufferId);RenderSystem.viewport(0,0,width,height);GL11.glDisable(GL11.GL_SCISSOR_TEST);RenderSystem.enableBlend();RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA,GL11.GL_ONE,GL11.GL_ONE_MINUS_SRC_ALPHA);
  GlStateManager._glUseProgram(composite);GlStateManager._activeTexture(GL13.GL_TEXTURE0);GlStateManager._bindTexture(lowTexture);GL20.glUniform1i(GL20.glGetUniformLocation(composite,"Volume"),0);GlStateManager._activeTexture(GL13.GL_TEXTURE1);GlStateManager._bindTexture(depthTexture);GL20.glUniform1i(GL20.glGetUniformLocation(composite,"SceneDepth"),1);GL20.glUniform2f(GL20.glGetUniformLocation(composite,"Viewport"),width,height);GL11.glDrawArrays(GL11.GL_TRIANGLES,0,3);
 }
''' + s[at:]
# Full depth copy prevents stale texels at expanded scissor and reconstruction edges.
s=s.replace('area.x0,area.y0,area.x1,area.y1,area.x0,area.y0,area.x1,area.y1','0,0,width,height,0,0,width,height')
# Skip unsupported pipeline with fallback, do not permanently fail.
s=s.replace('throw new IllegalStateException("Fabulous rendering requires a separate adapter")','return').replace('throw new IllegalStateException("Main target replaced by another renderer; adapter required")','return')
p.write_text(s,'utf-8')
