"""Export supplied free mesh without replacing it with cubes; embedded textures preserved."""
import json, base64, math
from pathlib import Path
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'deliverables/噬灵虫模型/噬灵虫.bbmodel').read_text(encoding='utf-8'))
assets=root/'src/main/resources/assets/wuxingxiantu'
out=assets/'models/entity';out.mkdir(parents=True,exist_ok=True)
tex=assets/'textures/entity/spirit_devourer';tex.mkdir(parents=True,exist_ok=True)
for i,t in enumerate(m['textures']):
    (tex/f'{i}.png').write_bytes(base64.b64decode(t['source'].split(',',1)[1]))
groups={g['uuid']:g for g in m['groups']};elements={e['uuid']:e for e in m['elements']}
mesh=[]
def walk(node,chain):
    if isinstance(node,str):
        e=elements[node]
        if not e.get('visibility',True):return
        for f in e['faces'].values():
            ids=f['vertices'];t=f.get('texture')
            if t is None or len(ids)<3:continue
            for j in range(1,len(ids)-1):
                triangle=[ids[0],ids[j],ids[j+1]]
                mesh.append({'chain':chain,'texture':t,'points':[e['vertices'][v]+[f['uv'][v][0]/m['textures'][t]['uv_width'],f['uv'][v][1]/m['textures'][t]['uv_height']] for v in triangle]})
    else:
        g=groups[node['uuid']];new=chain+[{'name':g['name'].split('_')[0] if False else g['name'],'origin':g['origin'],'rotation':g.get('rotation',[0,0,0])}]
        for child in node.get('children',[]):walk(child,new)
for n in m['outliner']:walk(n,[])
(out/'spirit_devourer.json').write_text(json.dumps({'triangles':mesh},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print('Mesh export:',len(m['elements']),'elements;',len(mesh),'triangles;',len(m['textures']),'embedded textures')
def save(rel,data):
    p=root/'src/main/resources'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
for item in ['insect_carapace_fragment','spirit_devourer_sac']:
    save(f'assets/wuxingxiantu/models/item/{item}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'wuxingxiantu:item/{item}'}})
save('assets/wuxingxiantu/models/item/spirit_devourer_spawn_egg.json',{'parent':'minecraft:item/template_spawn_egg'})
save('data/wuxingxiantu/loot_tables/entities/spirit_devourer.json',{'type':'minecraft:entity','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'wuxingxiantu:insect_carapace_fragment','functions':[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':0,'max':2}}]}]}]})
save('data/wuxingxiantu/forge/biome_modifier/spirit_devourer.json',{'type':'forge:add_spawns','biomes':'#wuxingxiantu:spirit_devourer_habitat','spawners':{'type':'wuxingxiantu:spirit_devourer','weight':6,'minCount':2,'maxCount':3}})
save('data/wuxingxiantu/tags/worldgen/biome/spirit_devourer_habitat.json',{'replace':False,'values':['minecraft:forest','minecraft:birch_forest','minecraft:dark_forest','minecraft:plains','minecraft:lush_caves']})
for locale in ['zh_cn','en_us']:
    p=assets/f'lang/{locale}.json';d=json.loads(p.read_text(encoding='utf-8-sig'))
    d.update({'entity.wuxingxiantu.spirit_devourer':'噬灵虫' if locale=='zh_cn' else 'Spirit Devourer','item.wuxingxiantu.spirit_devourer_spawn_egg':'噬灵虫刷怪蛋' if locale=='zh_cn' else 'Spirit Devourer Spawn Egg','item.wuxingxiantu.insect_carapace_fragment':'虫甲碎片' if locale=='zh_cn' else 'Insect Carapace Fragment','item.wuxingxiantu.spirit_devourer_sac':'噬灵虫囊' if locale=='zh_cn' else 'Spirit Devourer Sac','effect.wuxingxiantu.dunguang':'遁光' if locale=='zh_cn' else 'Realm Flight','effect.wuxingxiantu.dunguang.description':'元婴及以上可双击跳跃发动遁光；模式在背包设置切换。' if locale=='zh_cn' else 'Double-tap jump to fly from Nascent Soul onward. Choose flight visuals in inventory settings.'})
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
