"""Generate weapon-only masks/profiles; never writes sword models or their textures."""
import json
from pathlib import Path
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'src/main/resources/assets/wuxingxiantu'
DATA=ASSETS/'weapon_flames'

def write(name,data):
    (DATA/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

def main():
    DATA.mkdir(exist_ok=True)
    # Existing fire identity/palette retained. Blue sea, red flow and violet thunder are the three motion samples.
    rows=[('red_flow','FFF0BB','FF7420','B92B16',.28,.085,1.28,1.15,1.35,.9,.32,.22,.32,.24,4,4,3),
          ('molten_gold','FFF6AC','FFAA28','AD5216',.23,.065,1.2,1.0,.8,.55,.15,.09,.23,.16,3,3,2),
          ('cold_ash','DCE3EB','9194AD','444052',.16,.045,1.1,1.3,.4,.22,.08,.04,.12,.09,3,2,1),
          ('azure_wood','C2FFD8','3CC882','17634D',.22,.06,1.2,1.15,.7,.4,.12,.1,.22,.16,4,3,2),
          ('cobalt_sea','E8FBFF','32A0FF','1C477C',.16,.04,1.08,1.25,.38,.18,.07,.06,.12,.09,3,2,0),
          ('violet_thunder','EACDFF','AA50FF','472074',.20,.06,1.16,.95,.8,.42,.24,.16,.24,.18,4,3,2),
          ('sun_saint','FFF3C4','FFD34F','CB791B',.16,.05,1.1,1.0,.6,.3,.06,.03,.15,.1,3,2,1),
          ('nether_void','764897','280A3C','10051B',.22,.065,1.15,1.25,.45,.25,.18,.15,.22,.15,4,3,1),
          ('nirvana','F4FFFF','40E0D0','235B68',.17,.045,1.1,1.1,.65,.32,.07,.04,.18,.12,3,2,1)]
    for name,core,body,edge,width,height,radius,turns,flow,coil,flicker,turbulence,stretch,trail,fade,peel,scatter in rows:
        profile=dict(type='fire',colors=dict(coreColor='#'+core,bodyColor='#'+body,edgeColor='#'+edge,sparkColor='#'+core,glowColor='#'+body),
            shape=dict(flameWidth=width,flameHeight=height,coilRadius=radius,coilTurns=turns,attachmentSize=.06),
            motion=dict(flowSpeed=flow,coilSpeed=coil,flickerStrength=flicker,turbulence=turbulence),
            combat=dict(attackStretch=stretch,trailLength=trail,trailFadeTime=fade,hitPeelAmount=peel,scatterAmount=scatter))
        if name=='red_flow':
            profile['schemaVersion']=2
            profile['shape']=dict(flameWidth=.35,flameHeight=.7,coilRadius=.86,coilTurns=1.45,attachmentSize=.12)
            profile['colors']['sparkColor']='#FFC857'
        write(name,profile)
    for name,root in [('dark_iron_sword',.675),('mingjue_sword',.66),('qingming_sword',.68),('jixiao_sword',.79)]:
        model=json.loads((ASSETS/'models/item'/f'{name}_flying.json').read_text())
        vertices=[]
        if 'elements' in model:
            for e in model['elements']:
                if e['from'][0]/16<=root*.5<=e['to'][0]/16:
                    vertices.extend(tuple(v/16 for v in e[k]) for k in ('from','to'))
        else:
            points=[];faces=[]
            for line in (ASSETS/model['model'].split(':')[1]).read_text().splitlines():
                if line.startswith('v '):points.append(tuple(map(float,line.split()[1:4])))
                elif line.startswith('f '):faces.append([int(v.split('/')[0])-1 for v in line.split()[1:]])
            plane=root*.5
            for face in faces:
                for i,index in enumerate(face):
                    a=points[index];b=points[face[(i+1)%len(face)]]
                    if min(a[0],b[0])<=plane<=max(a[0],b[0]) and abs(b[0]-a[0])>1e-9:
                        t=(plane-a[0])/(b[0]-a[0]);vertices.append(tuple(a[j]+(b[j]-a[j])*t for j in range(3)))
        blade=vertices
        width=max(v[2] for v in blade)-min(v[2] for v in blade)
        thick=max(v[1] for v in blade)-min(v[1] for v in blade)
        write(name,dict(type='weapon',hiltAnchor=[root,.5,.5],tipAnchor=[.012,.5,.5],widthAxis=[0,0,1],bladeWidth=width,bladeThickness=thick))
    for name in ('wuxiang_sword','guiyuan_sword','tianque_sword'):
        model=json.loads((ASSETS/'models/item'/f'{name}.json').read_text())
        blade=[e for e in model['elements'] if e['from'][1]>=3.5 and e['to'][1]>10]
        width=(max(e['to'][2] for e in blade)-min(e['from'][2] for e in blade))/16
        thick=(max(e['to'][0] for e in blade)-min(e['from'][0] for e in blade))/16
        write(name,dict(type='weapon',hiltAnchor=[.5,3.6/16,.5],tipAnchor=[.5,31.7/16,.5],widthAxis=[0,0,1],bladeWidth=width,bladeThickness=thick))
    texture=ASSETS/'textures/effect';texture.mkdir(exist_ok=True)
    # Four stepped grayscale tongues in one horizontal sheet, tinted by profile colors at draw time.
    atlas=Image.new('RGBA',(64,32))
    for frame in range(4):
        for y in range(32):
            t=y/31;center=7+(frame-1 if y<15 else 0)+(1 if (y//5+frame)%3==0 else 0)
            half=max(0,int(5*t*(1-.35*t)))
            for x in range(max(0,center-half),min(16,center+half+1)):
                value=255 if abs(x-center)<max(1,half//2) else 185
                alpha=255 if y<28 else (32-y)*55
                if (x+y+frame)%17==0 and abs(x-center)==half:continue
                atlas.putpixel((frame*16+x,y),(value,value,value,alpha))
    atlas.save(texture/'weapon_flame.png')
    band=Image.new('RGBA',(32,8));draw=ImageDraw.Draw(band)
    for x in range(32):
        inset=2 if x%11 in (0,1) else 1 if x%5<2 else 0
        draw.line((x,inset,x,7-inset),fill=(210,210,210,210))
        draw.line((x,3,x,4),fill=(255,255,255,255))
    band.save(texture/'weapon_flame_band.png')
    print('Wrote 9 fire profiles, 7 model-derived anchors and 2 weapon-only pixel masks.')

if __name__=='__main__':main()
