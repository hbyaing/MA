from pathlib import Path
import json, zipfile, shutil, hashlib

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables/灵力护盾受击波纹修复'
OUT.mkdir(parents=True,exist_ok=True)
jar=ROOT/'build/libs/wuxingxiantu-0.2.jar'
captures=ROOT/'reports/shield-impact-client'
assert (captures/'complete.txt').exists() and not (captures/'failure.txt').exists()
assert 'BUILD SUCCESSFUL' in (ROOT/'reports/shield-impact-build.log').read_text(encoding='utf-8',errors='replace')
with zipfile.ZipFile(jar) as z:
    for ext in ['fsh','json']:
        path=f'assets/wuxingxiantu/shaders/core/spirit_shield_sphere.{ext}'
        assert z.read(path)==(ROOT/'src/main/resources'/path).read_bytes()
    assert not any('ShieldImpactCapture' in name for name in z.namelist())
    assert 'cn/blockforge/generated/generatedmod/event/SpiritShieldImpactEvents.class' in z.namelist()
shutil.copy2(jar,OUT/'wuxingxiantu-0.2-20261012-shield-impact-fix.jar')
for name in ['idle.png','impact-1-early.png','impact-1.png','impact-2.png','impact-3.png','impact-4.png','contacts.txt','uniforms.txt','complete.txt']:
    shutil.copy2(captures/name,OUT/name)
report={'build':'passed','real_client_contacts':['creative arrow','survival arrow','melee','shield depletion'],
        'shader_uniform_checks':'passed','opengl_errors':0,'duration_seconds':{'base':20,'maximum_proficiency':26},
        'installed':False,'sha256':hashlib.sha256(jar.read_bytes()).hexdigest()}
(OUT/'验证报告.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'说明.md').write_text('''# 灵力护盾受击波纹修复

箭矢实际碰到护盾持有者时触发定向波纹，包含创造/免伤状态；普通近战伤害沿用伤害事件。相同箭矢同一刻的碰撞与伤害事件去重。仅在灵力护盾视觉效果存在且护盾容量大于零时触发，不增加免伤、拦截距离或额外扣灵力。

波纹按服务器确认的接触独立计时，从来袭方向扩散约1.2秒，包含第二道弱环和接触亮点。玩家受伤闪烁与吸收值同步不再重置波纹。护盾被击破时保留最后一次受击波纹并淡出。

主动灵力护盾从5秒提高为基础20秒，随熟练度为20/21/22/23/26秒（使用次数阈值0/10/30/60/100）；护盾视觉与吸收效果共享时长，界面说明同步更新。被动槽护盾保持原有持续刷新规则。护盾容量、消耗和冷却不变。

真实客户端验证：创造箭矢、生存箭矢、近战、护盾耗尽四种事件；实际生产网络包、着色器与截图，没有注入模拟特效包。校验波纹强度、年龄与箭矢来向，OpenGL无错误。完整build通过，成品与资源字节一致；测试代码未进入成品。此JAR未安装到玩家实例。

开发复验：`gradlew -PshieldImpactCapture runClient`。日志：`reports/shield-impact-client-run.log`、`reports/shield-impact-build.log`。
''',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
