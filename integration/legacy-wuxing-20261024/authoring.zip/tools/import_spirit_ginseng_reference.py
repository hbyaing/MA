"""Import supplied transparent sprites; roots are visible only in the item icon."""
from pathlib import Path
from PIL import Image
import shutil,json
root=Path(__file__).resolve().parents[1]
source=Path(r'C:/Users/NOSTZE~1/AppData/Local/Temp/codex-clipboard-b16e3e1a-6b9e-41bc-a639-9897eedf2f96.png')
archive=root/'source-assets/spirit-ginseng-20261008';archive.mkdir(parents=True,exist_ok=True)
shutil.copy2(source,archive/'reference-original.png')
im=Image.open(source).convert('RGBA')
assets=root/'src/main/resources/assets/wuxingxiantu'
stages=[('young',300,720,540),('growing',820,1370,429),('mature',1400,2040,339)]
preview=Image.new('RGBA',(768,256),(40,46,43,255))
manifest={}
for i,(stage,left,right,ground) in enumerate(stages):
    full=im.crop((left,0,right,724));bounds=full.getbbox();full=full.crop(bounds)
    full.save(archive/(stage+'-full.png'))
    # Horizontal soil boundary removes the reference's entire beige root.
    leaves=im.crop((left,0,right,ground));box=leaves.getbbox();leaves=leaves.crop(box)
    canvas=Image.new('RGBA',(1024,1024))
    # Preserve original crop pixels; transparent padding provides a power-of-two atlas tile.
    if leaves.width>1024 or leaves.height>1024:raise ValueError('Crop exceeds tile')
    canvas.alpha_composite(leaves,((1024-leaves.width)//2,1024-leaves.height))
    name='spirit_ginseng'+({'young':'_young','growing':'_growing','mature':''}[stage])
    canvas.save(assets/'textures/block'/(name+'.png'))
    canvas.save(archive/(stage+'-leaves.png'))
    model_stage={'young':'_low','growing':'_mid','mature':''}[stage]
    model_path=assets/'models/block'/('spirit_ginseng'+model_stage+'.json')
    model=json.loads(model_path.read_text())
    model['textures']['cross']='wuxingxiantu:block/'+name
    u=(1024-leaves.width)/128;v=(1024-leaves.height)/64
    for element in model['elements']:
        for face_name,face in element['faces'].items():
            face['uv']=[u,v,16-u,16] if face_name=='north' else [16-u,v,u,16]
    # Same block state and age IDs, foliage remains rooted at y=0.
    model_path.write_text(json.dumps(model,indent=2)+'\n')
    preview.alpha_composite(canvas.resize((256,256),Image.Resampling.NEAREST),(i*256,0))
    manifest[stage]={'source_leaf_bounds':[left+box[0],box[1],left+box[2],box[3]],'soil_boundary':ground}
    if stage=='mature':
        item=Image.new('RGBA',(1024,1024));item.alpha_composite(full,((1024-full.width)//2,(1024-full.height)//2))
        item.save(assets/'textures/item/spirit_ginseng.png')
(assets/'models/item/spirit_ginseng.json').write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'wuxingxiantu:item/spirit_ginseng'}},indent=2)+'\n')
preview.save(archive/'leaves-preview.png')
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Imported three foliage stages and full-root item icon')
