"""Strict artifact and actual runtime evidence verification for this delivery."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,re,statistics,sys
from PIL import Image
from verify_furnace_stability_release import verify_motion,verify_captures

ROOT=Path(__file__).resolve().parents[1];REPORT=ROOT/'reports/alchemy-followup-20261014'
jar=Path(sys.argv[1]).resolve();installed=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else None
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def log(path):
    raw=path.read_bytes();return raw.decode('utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig',errors='replace')
build=log(REPORT/'final-build-tests.log');assert 'BUILD SUCCESSFUL' in build and '203 required tests passed' in build
resources=0
with ZipFile(jar) as archive:
    names=archive.namelist();assert not any(any(t in name for t in ['GameTests','JeiCatalogCapture','RealmFlightDimensionCapture','CloudGlyphClientCapture','DomainUiCapture','AlchemyFollowupUi','VolumePerformanceProbe','FurnaceMotionFixture','software/bernie/']) for name in names)
    assert 'cn/blockforge/generated/generatedmod/compat/jei/WuXingJeiPlugin.class' in names
    assert not any(name.startswith('mezz/') for name in names),'JEI third-party classes must not be bundled'
    for file in (ROOT/'src/main/resources').rglob('*'):
        if file.is_file():
            relative=file.relative_to(ROOT/'src/main/resources').as_posix()
            expected=(ROOT/'build/resources/main'/relative).read_bytes() if relative=='META-INF/mods.toml' else file.read_bytes()
            assert archive.read(relative)==expected,file;resources+=1
    assert not any(name.endswith('bed_noise.glsl') or 'FireBedNoiseCache' in name for name in names),'Obsolete bed cache packaged'
images={}
for path in [*(ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision/roots').glob('*.png'),
             ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision/components/root_thunder.png',
             ROOT/'src/main/resources/assets/wuxingxiantu/textures/gui/wuxia/vision/components/root_exotic.png',
             ROOT/'src/main/resources/assets/wuxingxiantu/textures/item/pill_ash.png']:
    with Image.open(path) as image:
        assert image.mode=='RGBA' and image.size==((32,32) if path.name=='pill_ash.png' else (256,256)),path
        assert image.getchannel('A').getextrema()==(0,255),path
        images[path.name]=list(image.size)
performance={}
for folder in ['fire-surface-native','fire-surface-solas','fire-surface-oldclock']:
    verify_captures(REPORT/folder,11);rows=read(REPORT/folder/'paired-gpu.json')['cases'];assert len(rows)==9
    for row in rows:
        assert row['maxFloatError']<=1e-5 and row['glError']==0 and row['noiseCacheEnabled'] and row['cornerCacheEnabled']
        assert row['optimizedGpuMs']<row['baselineGpuMs'] and row['samplesPerVersion']==24
        assert row['seamDensity']>0 and row['belowPlinthDensity']==row['solidRoofDensity']==0
        if 'solidSupportDensity' in row:assert row['solidSupportDensity']==0
    performance[folder]={'baselineMs':statistics.median(r['baselineGpuMs'] for r in rows),'optimizedMs':statistics.median(r['optimizedGpuMs'] for r in rows),'savedPercent':statistics.median((1-r['optimizedGpuMs']/r['baselineGpuMs'])*100 for r in rows),'maxFloatError':max(r['maxFloatError'] for r in rows)}
motion={folder:verify_motion(REPORT/folder) for folder in ['fire-surface-motion-native','fire-surface-motion-solas']}
for folder,count in [('jei',5),('flight-dimension',2)]:
    doc=read(REPORT/folder/'verification.json');assert doc['failures']==[] and len(doc['cases'])==count
    assert (REPORT/folder/'complete.txt').is_file() and not (REPORT/folder/'failure.txt').exists()
    if folder=='jei':
        for row in doc['cases']:
            assert row['listEntries']==1 and row['glError']==0 and all('作弊' not in line for line in row['tooltip'])
            assert ('inner_core_immortal' in row['cheatStack']) if row['id']=='inner_core' else ('PERFECT' in row['cheatStack'] or row['id']=='calming_pill')
    else:
        for row in doc['cases']:assert row['portal'] and row['returnReadyTicks']<=2 and row['serverPeakPerTick']<=row['cruiseLimitPerTick']+.025
assert 'BUILD SUCCESSFUL' in log(REPORT/'ui.log'),'Latest UI run did not finish successfully'
assert (REPORT/'ui/complete.txt').stat().st_mtime> (ROOT/'src/main/java/cn/blockforge/generated/generatedmod/client/AlchemyScreen.java').stat().st_mtime,'UI evidence predates the latest screen change'
ui=read(REPORT/'ui/captures.json');assert ui['failures']==[] and len(ui['captures'])==24
for row in ui['captures']:assert row['glError']==0
normal=read(ROOT/'build/flight-input-client/flight-input-result.json');assert normal['failures']==[]
digest=sha256(jar.read_bytes()).hexdigest().upper()
if installed:assert sha256(installed.read_bytes()).hexdigest().upper()==digest
protocol=(ROOT/'src/main/java/cn/blockforge/generated/generatedmod/network/NetworkChannel.java').read_text();assert '"79"' in protocol
result={'artifact':str(jar),'installed':str(installed) if installed else None,'sha256':digest,'resourcesVerified':resources,'serverTests':203,'protocol':79,'qaClassesAbsent':True,'jeiEntries':18,'monsterCoreEntries':1,'icons':images,'performance':performance,'motion':motion,'portalRealms':[3,6],'uiCaptures':24,'jeiCaptures':5,'portalCaptures':8,'standardFlightInputPassed':True}
(REPORT/('installed-verification.json' if installed else 'artifact-verification.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
