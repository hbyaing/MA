"""Offline rig silhouette contact sheet; diagnostic rendering, not Minecraft screenshots."""
import json
import math
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "src/main/resources"
ASSETS = RES / "assets/wuxingxiantu"
OUT = ROOT / "reports/boss-motions"
FACES = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
CORNERS = np.array([[x, y, z] for x in (0, 1) for y in (0, 1) for z in (0, 1)])


def read(path): return json.loads(path.read_text(encoding="utf-8"))


def translate(v):
    m = np.eye(4)
    m[:3, 3] = v
    return m


def rotation(angles):
    x, y, z = np.radians(angles)
    a, b, c = np.eye(4), np.eye(4), np.eye(4)
    a[1:3, 1:3] = [[math.cos(x), -math.sin(x)], [math.sin(x), math.cos(x)]]
    b[:3, :3] = [[math.cos(y), 0, math.sin(y)], [0, 1, 0], [-math.sin(y), 0, math.cos(y)]]
    c[:2, :2] = [[math.cos(z), -math.sin(z)], [math.sin(z), math.cos(z)]]
    return c @ b @ a


def sample(track, time, default):
    if not isinstance(track, dict): return track or default
    values = sorted((float(t), v) for t, v in track.items())
    for i, (t, v) in enumerate(values):
        if t >= time:
            if i == 0: return v
            a, b = values[i - 1]
            return np.asarray(b) + (np.asarray(v) - b) * (time - a) / (t - a)
    return values[-1][1]


def mesh(geo, clip, tick):
    bones = {b["name"]: b for b in geo["bones"]}
    cache, polygons = {}, []

    def transform(name):
        if name in cache: return cache[name]
        b = bones[name]
        channels = clip["bones"].get(name, {})
        pivot = np.array(b.get("pivot", [0, 0, 0]))
        delta = sample(channels.get("position"), tick / 20, [0, 0, 0])
        angles = np.asarray(b.get("rotation", [0, 0, 0])) + sample(channels.get("rotation"), tick / 20, [0, 0, 0])
        scale = sample(channels.get("scale"), tick / 20, [1, 1, 1])
        s = np.diag([*scale, 1])
        local = translate(pivot + delta) @ rotation(angles) @ s @ translate(-pivot)
        cache[name] = (transform(b["parent"]) if b.get("parent") else np.eye(4)) @ local
        return cache[name]

    camera = rotation([12, -28, 0])
    for name, bone in bones.items():
        # Preview-only motes/rings are not part of the anatomical rig silhouette.
        if any(s in name for s in ("preview", "mote", "droplet")): continue
        for cube in bone.get("cubes", []):
            origin, size = np.asarray(cube["origin"]), np.asarray(cube["size"])
            if np.any(size == 0): continue
            points = origin + CORNERS * size
            points = np.c_[points, np.ones(8)]
            pivot = np.asarray(cube.get("pivot", origin + size / 2))
            local = translate(pivot) @ rotation(cube.get("rotation", [0, 0, 0])) @ translate(-pivot)
            points = (camera @ transform(name) @ local @ points.T).T[:, :3]
            for face in FACES:
                poly = points[list(face)]
                normal = np.cross(poly[1] - poly[0], poly[2] - poly[0])
                normal /= max(.0001, np.linalg.norm(normal))
                lighting = .48 + .4 * abs(float(normal @ np.array([.4, .7, -.5])))
                accent = any(s in name for s in ("iris", "tongue", "gland", "heart", "core", "maw", "tentacle", "tendril"))
                polygons.append((poly, lighting, accent))
    return polygons


def main():
    definitions = {d["id"]: d for d in read(RES / "data/wuxingxiantu/boss_visuals.json")}
    motions = [m for m in read(RES / "data/wuxingxiantu/boss_motions.json") if m["skill"].endswith("_basic")]
    sheet = Image.new("RGB", (1200, 1800), "#10161f")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 18)
    titles = ["待机姿态", "蓄力姿态", "打击姿态", "收招归位"]
    for row, m in enumerate(motions):
        boss = m["skill"].removesuffix("_basic")
        d = definitions["heart_demon_phase2" if boss == "heart_demon" else boss]
        geo = read(ASSETS / d["model"])["minecraft:geometry"][0]
        clip = read(ASSETS / d["animation"])["animations"][m["animation"]]
        times = [0, m["windup"] - 3, m["windup"], m["duration"]]
        states = [mesh(geo, clip, t) for t in times]
        points = np.concatenate([p for state in states for p, _, _ in state])
        lo, hi = points.min(axis=0), points.max(axis=0)
        scale = min(255 / max(1, hi[0] - lo[0]), 125 / max(1, hi[1] - lo[1]))
        for col, state in enumerate(states):
            x0, y0 = col * 300, row * 180
            draw.text((x0 + 12, y0 + 4), f"{boss} · {titles[col]}", font=font, fill="#dce6ef")
            for polygon, light, accent in sorted(state, key=lambda p: -p[0][:, 2].mean()):
                coords = [(x0 + 150 + (p[0] - (lo[0] + hi[0]) / 2) * scale,
                           y0 + 156 - (p[1] - lo[1]) * scale) for p in polygon]
                color = [160, 185, 207] if not accent else [235, 157, 84]
                color = tuple(int(v * light) for v in color)
                draw.polygon(coords, fill=color, outline="#25303e")
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "basic-attacks-rig-contact-sheet.png"
    sheet.save(path)
    print(path)


if __name__ == "__main__": main()
