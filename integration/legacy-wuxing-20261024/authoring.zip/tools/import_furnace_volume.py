"""Copy the reviewed furnace backend into host namespace; no standalone mod dependency."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
lab=Path('E:/着色器渲染/alchemy-vfx-lab')
target=root/'src/main/java/cn/blockforge/generated/generatedmod/client/furnacevolume'
target.mkdir(parents=True,exist_ok=True)
if (target/'VolumeGpu.java').exists():
    raise SystemExit('Host backend already adapted. Preserve it; review upstream differences manually instead of overwriting.')
for name in ('VolumeGpu','Recipe','HostAdapter'):
    text=(lab/f'forge/src/main/java/dev/alchemyvfx/{name}.java').read_text(encoding='utf-8')
    text=text.replace('package dev.alchemyvfx;','package cn.blockforge.generated.generatedmod.client.furnacevolume;')
    text=text.replace('/assets/alchemyvfx/shaders/','/assets/wuxingxiantu/shaders/furnacevolume/')
    if name=='VolumeGpu':
        text=text.replace('for(String key:Recipe.COLORS)', 'scalar("Nirvana",furnace.activeFireId().equals("wuxingxiantu:nirvana")?1:0);\n            for(String key:Recipe.COLORS)')
    (target/f'{name}.java').write_text(text,encoding='utf-8')
resources=root/'src/main/resources/assets/wuxingxiantu/shaders/furnacevolume'
resources.mkdir(parents=True,exist_ok=True)
for name in ('volume.fsh','volume.wrapper.glsl'):
    text=(lab/f'forge/src/main/resources/assets/alchemyvfx/shaders/{name}').read_text(encoding='utf-8')
    if name=='volume.fsh':
        text=text.replace('uniform float Time, Phase;','uniform float Time, Phase;\nuniform float Nirvana;')
        text=text.replace('return mix(c,FireCore,smoothstep(.57,.95,heat));','c=mix(c,FireCore,smoothstep(.57,.95,heat));if(Nirvana>.5){vec3 spectral=.5+.5*cos(6.2831853*(Time*.12+heat*.65+vec3(0,.33,.67)));c=mix(spectral*.8+vec3(.12),vec3(1),smoothstep(.80,1.,heat)*.65);}return c;')
    (resources/name).write_text(text,encoding='utf-8')
recipe=json.loads((lab/'current-recipe.json').read_text(encoding='utf-8'))
for key in ('vaporStrength','filamentStrength','coreStrength','burstStrength','sigilStrength','faceHeatStrength','faceSparkRate','aromaStrength','ingredientStrength','energyRingStrength'):
    recipe[key]=0
(resources/'recipe.json').write_text(json.dumps(recipe,ensure_ascii=False,indent=2),encoding='utf-8')
(resources/'nine-flames.json').write_bytes((lab/'nine-flames.json').read_bytes())
print('Imported actual alchemy volume core and bottom-only recipe, added ninth-fire evolving thermal gradient')
