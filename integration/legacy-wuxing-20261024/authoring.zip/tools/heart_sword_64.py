"""Rasterize a separate inventory icon. Never write the model texture, mesh or UVs."""
import hashlib
import json
import math
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'src/main/resources/assets/wuxingxiantu'
OBJ=ASSETS/'models/item/heart_sword.obj'
MTL=ASSETS/'models/item/heart_sword.mtl'
MATERIAL=ASSETS/'textures/item/heart_sword.png'
BB=ROOT/'source-assets/heart_sword.bbmodel'

def rotate(axis,degrees):
    a=math.radians(degrees);c,s=math.cos(a),math.sin(a)
    m=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
    i,j=((1,2),(2,0),(0,1))[axis]
    m[i][i]=m[j][j]=c;m[i][j]=-s;m[j][i]=s
    return m

def mul(a,b):
    return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]

def xyz(angles):
    return mul(mul(rotate(0,angles[0]),rotate(1,angles[1])),rotate(2,angles[2]))

def inventory_icon():
    vertices=[];uvs=[];faces=[]
    for line in OBJ.read_text().splitlines():
        fields=line.split()
        if not fields:continue
        if fields[0]=='v':vertices.append(tuple(map(float,fields[1:4])))
        elif fields[0]=='vt':uvs.append(tuple(map(float,fields[1:3])))
        elif fields[0]=='f':
            face=[tuple(int(i)-1 for i in item.split('/')[:2]) for item in fields[1:]]
            for i in range(1,len(face)-1):faces.append((face[0],face[i],face[i+1]))
    matrix=xyz((0,12,-42))
    points=[tuple(sum(matrix[i][j]*v[j] for j in range(3)) for i in range(3)) for v in vertices]
    lo=[min(p[i] for p in points) for i in range(2)];hi=[max(p[i] for p in points) for i in range(2)]
    scale=54/max(hi[0]-lo[0],hi[1]-lo[1]);cx=(lo[0]+hi[0])/2;cy=(lo[1]+hi[1])/2
    points=[((p[0]-cx)*scale+31.5,31.5-(p[1]-cy)*scale,p[2]) for p in points]
    image=Image.new('RGBA',(64,64));depth=[-float('inf')]*4096
    texture=Image.open(MATERIAL).convert('RGBA')
    for face in faces:
        a,b,c=[points[v] for v,uv in face]
        denominator=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
        if abs(denominator)<1e-8:continue
        for y in range(max(0,math.floor(min(a[1],b[1],c[1]))),min(64,math.ceil(max(a[1],b[1],c[1]))+1)):
            for x in range(max(0,math.floor(min(a[0],b[0],c[0]))),min(64,math.ceil(max(a[0],b[0],c[0]))+1)):
                wa=((b[1]-c[1])*(x+.5-c[0])+(c[0]-b[0])*(y+.5-c[1]))/denominator
                wb=((c[1]-a[1])*(x+.5-c[0])+(a[0]-c[0])*(y+.5-c[1]))/denominator
                weights=(wa,wb,1-wa-wb)
                if min(weights)<-1e-6:continue
                z=sum(w*p[2] for w,p in zip(weights,(a,b,c)))
                if z<depth[y*64+x]:continue
                u,v=[sum(w*uvs[index][i] for w,(_,index) in zip(weights,face)) for i in range(2)]
                color=texture.getpixel((min(texture.width-1,max(0,int(u*texture.width))),
                    min(texture.height-1,max(0,int((1-v)*texture.height)))))
                # Inventory-only contrast; the actual held model material is untouched.
                red,green,blue,alpha=color
                image.putpixel((x,y),(max(0,int(red*.82)),min(255,int(green*1.04)),min(255,int(blue*1.08)),alpha))
                depth[y*64+x]=z
    # One-pixel dark edging preserves the narrow blade on bright inventory slots.
    outlined=image.copy()
    for y in range(1,63):
        for x in range(1,63):
            if image.getpixel((x,y))[3]==0 and any(image.getpixel((x+dx,y+dy))[3] for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))):
                outlined.putpixel((x,y),(31,77,94,230))
    return outlined

def main():
    if len(json.loads(BB.read_text(encoding='utf-8')).get('textures',[])) > 1:
        raise SystemExit('Heart sword 2.0 uses multiple materials. Use tools/import_heart_sword_v2.py; this v1 tool must not overwrite its icon or transforms.')
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OBJ,MTL,MATERIAL,BB)}
    icon=inventory_icon();icon.save(ASSETS/'textures/item/heart_sword_inventory.png')
    modelPath=ASSETS/'models/item/heart_sword.json'
    model=json.loads(modelPath.read_text(encoding='utf-8'))
    # Match dark iron's 1.4 held scale and 1.3 third-person multiplier.
    # Its mesh is 1 block long; heart_sword spans 1.875 blocks before scaling.
    for view,angle,scale in [('firstperson',(0,-90,25),1.4/1.875),('thirdperson',(0,-65,65),1.4*1.3/1.875)]:
        for hand in ('right','left'):
            effective=angle if hand=='right' else (angle[0],-angle[1],-angle[2])
            # Heart +Y/+X blade/width maps to dark iron -X/+Z; combined model rotation is Z=-45.
            matrix=mul(mul(xyz(effective),rotate(1,180 if hand=='left' else 0)),rotate(2,-45))
            y=math.asin(max(-1,min(1,matrix[0][2])))
            if abs(math.cos(y))>1e-6:
                x=math.atan2(-matrix[1][2],matrix[2][2]);z=math.atan2(-matrix[0][1],matrix[0][0])
            else:
                x=0;z=math.atan2(matrix[1][0],matrix[1][1])
            rotation=[math.degrees(x),math.degrees(y),math.degrees(z)]
            if hand=='left':rotation=[rotation[0],-rotation[1],-rotation[2]]
            # ItemTransform mirrors left-hand X translation and Y/Z rotation at runtime.
            translation=[sum(matrix[i][j]*v for j,v in enumerate((.5,.7,.5)))*scale*16 for i in range(3)]
            if hand=='left':translation[0]*=-1
            model['display'][view+'_'+hand+'hand']={'rotation':[round(v,6) for v in rotation],
                    'translation':[round(v,6) for v in translation],'scale':[round(scale,9)]*3}
    modelPath.write_text(json.dumps(model,indent=2)+'\n',encoding='utf-8')
    for path,digest in hashes.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest
    (ROOT/'reports/heart_sword_64_contract.json').write_text(json.dumps({'inventory_size':[64,64],
        'unchanged_files':hashes},indent=2),encoding='utf-8')
    preview=Image.new('RGBA',(512,512),(32,39,44,255))
    preview.alpha_composite(icon.resize((512,512),Image.Resampling.NEAREST))
    preview.convert('RGB').save(ROOT/'reports/heart_sword_64_preview.png')
    print('Separate 64px inventory icon created. Model bitmap, OBJ, MTL and Blockbench file unchanged.')

if __name__=='__main__':main()
