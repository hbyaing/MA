"""Read-only JAR integrity and resource audit; never loads mod classes."""
import hashlib, json, re, struct, zipfile
from pathlib import Path
import argparse

p = argparse.ArgumentParser()
p.add_argument('jar', type=Path)
p.add_argument('--output', type=Path, default=Path('reports/enhancedflight-1.0.6'))
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(a.jar) as z:
    names = set(z.namelist())
    bad = z.testzip()
    classes = [n for n in sorted(names) if n.endswith('.class')]
    versions = {n: struct.unpack('>H', z.read(n)[6:8])[0] for n in classes}
    jsons = [n for n in sorted(names) if n.endswith('.json') or n == 'pack.mcmeta']
    for n in jsons:
        json.loads(z.read(n))
    mix = json.loads(z.read('enhancedflight.mixins.json'))
    missing_mixins = [s for s in mix['mixins'] + mix['client'] if mix['package'].replace('.', '/') + '/' + s + '.class' not in names]
    source = (a.output / 'decompiled/com/cheatyblack/enhancedflight/ModItems.java').read_text(encoding='utf-8')
    items = re.findall(r'ITEMS.register\("([^"]+)"', source)
    missing_models = [i for i in items if f'assets/enhancedflight/models/item/{i}.json' not in names]
    result = dict(jar=str(a.jar), sha256=hashlib.sha256(a.jar.read_bytes()).hexdigest(), size=a.jar.stat().st_size,
                  entries=len(names), files=sum(not n.endswith('/') for n in names), classes=len(classes),
                  crc_bad_entry=bad, class_major_versions=sorted(set(versions.values())), parsed_json=jsons,
                  missing_mixins=missing_mixins, refmap_present=mix['refmap'] in names,
                  assets=[n for n in sorted(names) if n.startswith('assets/') and not n.endswith('/')],
                  registered_items=items, missing_item_models=missing_models,
                  license_files=[n for n in sorted(names) if 'license' in n.lower() or 'notice' in n.lower()])
    (a.output / 'audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (a.output / 'jar-inventory.json').write_text(json.dumps([dict(path=e.filename, size=e.file_size, crc=e.CRC) for e in z.infolist()], ensure_ascii=False, indent=2), encoding='utf-8')
    for n in ['META-INF/mods.toml', 'META-INF/MANIFEST.MF', 'enhancedflight.mixins.json', 'enhancedflight.refmap.json', 'pack.mcmeta']:
        dest = a.output / 'metadata' / n
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(z.read(n))
print(json.dumps(result, ensure_ascii=False, indent=2))
